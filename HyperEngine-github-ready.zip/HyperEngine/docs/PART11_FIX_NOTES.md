# Part 11 fix drop: 12 bugs and lag

Not compiled or run on a device (no Kotlin toolchain / Android SDK where this was written). Brace/paren balance of every
edited file was checked; type-checking was not. Build and test before relying on it.

## Bugs

| # | File | Problem | Fix |
|---|---|---|---|
| 1 | core/ClipBufferEngine.kt | The encoder drain thread only guarded `dequeueOutputBuffer`. `getOutputBuffer` / `releaseOutputBuffer` throw `IllegalStateException` when a rotation re-open or `stop()` stops the codec under it, and an uncaught exception on a plain Thread **kills the app**. | Whole loop is guarded; if the codec really died the buffer shuts itself down. |
| 2 | core/ClipBufferEngine.kt | Rotation re-open (new encoder, codec stop/release) ran on the **main thread** from the display listener, and fired for every display event. | Debounced 250 ms, then runs on a worker thread. `stop()` waits 200 ms at most instead of 500. |
| 3 | core/ClipBufferEngine.kt | A failed save left an invisible `IS_PENDING` entry in MediaStore. | The half-written row is deleted on failure. |
| 4 | core/GamingSuiteManager.kt | `ProjectionHub.onReady/onLost` (main thread) opened and tore down the encoder synchronously. A pending request was never cleared when the grant ended. | Both run on the worker scope; the pending window is reset on loss. |
| 5 | service/GameDetectorService.kt | `isGame()` / `isIgnored()` (PackageManager, native-lib folder listing, `Settings.Secure`) ran on the **main thread** every tick. | Classified on the worker thread inside the poll; `process()` only reads the verdict. |
| 6 | service/GameDetectorService.kt | `"libgame"` substring matched many non-game apps, which then got a profile, the HUD and boosts. | Removed (`libgamemaker` etc. stay). |
| 7 | service/GameDetectorService.kt | The `dumpsys activity` fallback was polled every 1.5 s even with no game in front. | 2.5 s while no game is in front. |
| 8 | core/VirtualDisplayUpscaler.kt | The monitor ran `dumpsys activity activities` every 4 s for the whole session (a stutter every 4 s in the game). | Every 10 s once the game is confirmed on the display. |
| 9 | core/MaxPanelHzEngine.kt | Every display change (LTPO panels switch many times a second) rebuilt panel caps and re-stamped windows on the main thread. | Coalesced: once, 250 ms after the burst. |
| 10 | ui/CooldownTimers.kt, ui/TouchMacroController.kt, ui/EdgeTriggerView.kt | `RectF` / `Path` allocated inside `onDraw` (GC churn while a game is running). | Reused members. |
| 11 | ui/AfkLock.kt | A `DateFormat` was built on every draw. | Built once. |
| 12 | ui/SystemTools.kt, ui/CallBanner.kt | `String.format("%02d:%02d")` with the default locale prints non-Latin digits on some locales. | `Locale.US`. |

## Lag

- core/UpscaleRenderer.kt: eight `glGet*Location` string lookups per frame (60-120 fps) on the GL thread are now resolved once after the programs link.
- Items 2, 4, 5, 8, 9 above remove main-thread and system_server stalls.

## Not changed on purpose
- HyperBoost's `debug.sf.*` pacing properties (`disable_backpressure`, phase offsets) are ROM dependent and can cost smoothness on some devices. They cannot be judged without a device, so they were left as they are.
- Black-frame insertion intentionally redraws on every refresh.
