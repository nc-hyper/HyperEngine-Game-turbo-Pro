# HyperEngine Phase 3 - Upgrade log

> **Naming note.** This log was written while the features still carried the names of the GPU vendor's products they
> imitate. Before publishing, every such name was replaced (Step 3 / Part 3, below) and this file was rewritten with the new
> names so it matches the code. The project is independent software and is not affiliated with NVIDIA or AMD.

Not compiled or run on a device (no Android SDK in the build environment). Open in Android Studio, sync, build.

## Step 1 / Part 1 - vector icon pack, VIcon, glyph purge

### New
- res/drawable/ic_*.xml  (44 vectors incl. 3 launcher layers): the 24 requested feature icons, ic_qs_wild_boost (flat white, for the
  Quick Settings tile), ic_fan_blades (rotating gauge fan), and 15 flat-white utility icons
  (plus, minus, close, chevrons, more_dots, check, alert, dash, backspace, divide, multiply, refresh).
- res/drawable/avd_*.xml  (8 AnimatedVectorDrawables): turbine spin, fan spin, radar sweep, REC pulse (x2),
  low-latency mode glow pulse, scaling trace draw, check draw-in.
- ui/VIcon.kt: load/tint icons, icon-only TextView faces (centred foreground), icon buttons with spring press.
- tools/gen_icons.py: the generator. Edit geometry/colours there and re-run to regenerate every XML.
- build.gradle.kts: androidx.dynamicanimation (SpringAnimation) added; versionName 1.3.0-phase3-p1.

### Glyph purge (every text glyph that stood in for an icon)
- MiniWindows: window close "X", browser "<" ">" "R", calculator keys (backspace, divide, multiply, minus, plus).
  Calculator tokens are now ASCII internally (BKSP, /, *, -, +); the expression readout shows ASCII.
- CrosshairOverlayManager / Phase4Ui.repeatButton: arrow nudge buttons -> chevron vectors (+ spring press).
- GameViews: "..." menu button.  SetupViews: check / alert / dash status marks.
- FreezePage, GamesPage: "+ Add" buttons.  FloatingTelemetryPill: charging "+" -> " CHG".
- GameLauncher, GameViews, SetupViews, TurboTools: bullet and middle-dot separators -> ASCII.

### Stock Android art removed
- Notification small icon / Stop action (GameDetectorService) -> ic_qs_wild_boost / ic_close.
- Telemetry warning notification (TelemetryMonitor) -> ic_alert.
- App icon: stock sym_def_app_icon -> adaptive launcher icon (ic_launcher_background / _foreground / _monochrome,
  mipmap-anydpi-v26/ic_launcher[_round].xml). The monochrome layer is used by Android 13+ themed icons.
  AndroidManifest: android:icon and android:roundIcon updated.

### Deliberate exceptions
- The degree sign in temperature readouts (38.5 degC) stays: it is a unit, not decoration.
- "--" placeholders (no data yet) and ASCII "->" in log text stay.

## Step 1 / Part 2 - AnimationController, WildBoostIgnitionOverlay

Not compiled or run on a device. WildBoostIgnitionOverlay is wired in by Part 3; AnimationController is wired in by Step 3.

### New: ui/WildBoostIgnitionOverlay.kt
- 2.2 s non-touchable full-screen overlay, one hardware-accelerated Canvas view, nothing allocated per frame.
- Edge plasma (LinearGradient bands, orange top/bottom, cyan left/right, from the HUD theme) + two SweepGradient
  comets racing the border; 12-blade jet turbine with motion-blur ghosts, afterburner halo, sparks, two shockwave
  rings; RPM readout 0 -> 20,000; four stat rows (FPS, CPU, HYPERBOOST SCALE, LATENCY) that roll / scramble in
  with a vector arrow and a drawn-in check mark.
- Dock: the turbine shrinks and flies to the edge trigger pill and the disc morphs into the pill's rectangle and
  colour, then an impact ring + spring pop. `onDocked` fires on landing (flash the real handle there), `onFinished`
  when the window is gone.
- Sound: rising turbine whine + whoosh + dock thump synthesized in code (no asset), AudioTrack USAGE_GAME, no
  audio focus taken. Haptics: amplitude ramp (rev) + thump; falls back to a plain pattern without amplitude control.
- API: `play(Spec)`, `cancel()`, `destroy()`, `WildBoostIgnitionOverlay.specFromSettings(ctx)`,
  `dockRectFor(ctx, handleConfig, screen)`, `prewarmSound()`.

### New: ui/AnimationController.kt
- Wings: `openWing` / `closeWing` / `openWings` (spring, DAMPING_RATIO_LOW_BOUNCY + STIFFNESS_MEDIUM; children
  stagger 30 ms with overshoot).
- Lobby: `carouselTransform` (camera distance, tilt, scale, alpha, coloured elevation glow), `enableCardGlow`,
  `NeonBorderPulse` (ViewOverlay border that breathes and has an orbiting comet).
- Gauges: `SmoothGauge` wraps GaugeView with ValueAnimator arc sweeps.
- Fan: `FanSpinner` (ObjectAnimator rotation, constant-acceleration speed changes, pauses on detach),
  `FanSpeed.forMode / forLoad`, `fanBlades()`.
- Misc: `slideSwap` (page transition), `pop`, `modeSwitch`, `springTo`.

### Behaviour worth knowing
- Window alpha is pinned at 0.79 (OverlayKit, same as every non-touchable overlay here), so the overlay peaks at
  about 79% brightness.
- Skipped, not just shortened, when the system animator scale is 0 / battery saver cuts animations. The AMOLED
  theme has animations = false, so ignition is skipped there too unless `Spec.force = true`. In both cases
  `onDocked` and `onFinished` still fire.
- The LATENCY row shows -38% because the spec asked for it. It is a design figure, not a measurement: pass a real
  value in `Spec.latencyDeltaPct` when one exists. The FPS row shows the locked refresh rate (144 if none).

## Step 1 / Part 3 - Quick Settings tile, manifest, ignition wired into the HUD  (this drop)

Not compiled or run on a device (no Android SDK in the build environment). Open in Android Studio, sync, build.

### New
- service/WildBoostController.kt: one definition of "Wild Boost ON" for the tile and the sidebar. Lives in HyperApp
  (`app.wildBoost`), so it works with or without the HUD on screen.
- service/WildBoostTileService.kt: the "Wild Boost" tile. Mirrors the controller while the shade is open; the work
  runs in the controller, not the tile service (Android unbinds a tile a moment after the shade closes).

### What a boost does (controller.boostOn)
1. CustomWildBoostEngine.activate: fixed performance, OEM throttlers frozen (powerkeeper / oplus battery), animations
   off, RAM clean, background data block, game mode PERFORMANCE.
2. FpsRefreshRateEnforcer.enforce at max(profile unlock, 144). The panel sets the ceiling: on a 120 Hz screen the tile
   and the ignition say 120, not 144.
3. Every registered Booster (see below).
4. `cmd package compile` in the background; the engine skips it if it ran in the last 24 hours.
Turning off puts the profile's own FPS unlock back if it has one, otherwise releases the lock.

### Tile behaviour
- Tap: shade collapses (`cmd statusbar collapse` via Shizuku; accessibility Back if no shell), 160 ms later the
  ignition plays, the boost applies in parallel. Subtitle: "<hz>Hz - MAX BOOST". On a locked phone the tile asks for
  unlock first.
- No game in front (home screen): Wild Boost is ARMED for the next game instead, subtitle "Starts with next game";
  the watcher starts if it was off; the first game the detector sees gets the full boost. Tap again to cancel.
  Armed state survives a process restart. The ignition still plays on the tap and docks at the configured pill
  position, where no pill exists yet.
- No Shizuku / root: the tile does nothing and says "Needs Shizuku". Ignition never plays for a boost that cannot run.
- Every step failing rolls the boost back ("Boost failed"); some failing shows "PARTIAL BOOST". Per-step detail is in
  the engine log (Developer console).

### HUD
- Sidebar > Turbo core > Wild Boost chip now goes through the controller (same full boost) and plays the ignition when
  it goes from off to on. Battery saver / Balanced chips release the FPS lock a Wild Boost added.
- When the turbine lands, the real edge handle wakes (full opacity for 2.5 s).
- The sidebar stays open during ignition so the per-step result text remains readable; the overlay draws its own pill.
- No ignition when a profile auto-starts Wild Boost at game launch (it would play on every game start).

### Manifest
- WildBoostTileService: BIND_QUICK_SETTINGS_TILE, icon @drawable/ic_qs_wild_boost, label "Wild Boost",
  TOGGLEABLE_TILE. Not an ACTIVE_TILE, so HUD-side changes show on it live while the shade is open.
- strings.xml: tile label, subtitles, "Needs Shizuku", "PARTIAL BOOST", "Boost failed".

### Hooks for Step 2
- `app.wildBoost.registerBooster(WildBoostController.Booster(ID_HYPERBOOST) { game, on -> StepResult(...) })`, same for
  ID_LOW_LATENCY. Boosters run on boost on/off, and are released on the engine's restore schedule when the game leaves.
- The scaling row of the ignition reads "STANDBY" until a HyperBoost booster is registered, then "ACTIVE". low-latency mode and
  scaling are NOT applied yet: Step 2 has not been built.

### Changed
- HyperApp (wildBoost), GameDetectorService (game start / stop / watcher stop), HudController (dock hook),
  TurboTools (tier chip), AndroidManifest, strings.xml, build.gradle.kts (1.3.0-phase3-p3, versionCode 11).

### Limits
- The LATENCY row still shows the design figure (-38%), not a measurement.
- DEX compile while a game is running is what the spec asked for; the engine's own docs say not to run it while
  playing. It is throttled to once per 24 hours per game and runs at the end of the boost, not before it.
- Collapsing the shade through accessibility Back is a fallback; some ROMs ignore it.
- Whether SystemUI lets a tile's `cmd statusbar collapse` run depends on Shizuku being up at that moment.

### Still to come
- Step 3: wiring AnimationController into HudController (wings), Carousel3DView / GameCardView (tilt, border),
  GameTurboSidebarView (SmoothGauge, FanSpinner).

## Step 2 / Part 1 - HyperBoostEngine

Not compiled or run on a device.

- core/HyperBoostEngine.kt: four quality profiles (Ultra Quality 0.85x, Quality 0.75x, Balanced 0.67x, Ultra
  Performance 0.55x; FPS gains are estimates for GPU-bound games). Applies `cmd game set --downscale`, the
  `game_overlay` device_config, `debug.sf.enable_hwc_vds`, `debug.hwui.renderer skiagl`, and the four frame-pacing
  props. All writes are crash-safe (restored with the FPS lock release). Quality is saved per game.
- Registered as the HyperBoost booster of Wild Boost, so the tile / HUD boost now applies it and the ignition's scaling
  row reads ACTIVE. Standalone use: `app.hyperBoost.apply(pkg, quality)` / `release(pkg)`.
- FpsRefreshRateEnforcer: public `overrideGameOverlay` wrapper. HyperApp: `hyperBoost`.
- Limits: GameManager downscale needs Android 12+ and a game that honours it, so it is not universal; `debug.sf.*`
  and `debug.hwui.renderer` are ROM dependent. Each step reports its own result.
- Still to come: HyperBoostUpscaleOverlay (CAS sharpening), GamingSuiteManager (low-latency mode registers ID_LOW_LATENCY).

## Step 2 / Part 2 - GamingSuiteManager (low-latency mode only)

Not compiled or run on a device.

- core/GamingSuiteManager.kt: low-latency mode = `debug.sf.latch_unsignaled 1` (crash-safe) + `long_press_timeout 200`
  (tracked). Registered as the low-latency mode booster of Wild Boost. `latencyMs(sample, hz)` is an estimate (frame time + half
  a refresh + 4.2 ms touch wait), not a measurement.
- Not possible on Android, so not faked: flushing queued input buffers, raising input dispatcher priority.
  CPU C-state avoidance is Wild Boost's fixed-performance mode, which low-latency mode rides along with.
- HyperApp: `suite`.

### HyperBoostUpscaleOverlay: deliberately NOT built
An overlay window can only process its own pixels, never the game's. The only route is MediaProjection capture, which
(a) captures the overlay itself (feedback loop), (b) adds a full-screen composition + GPU pass per frame, costing FPS at
120/144 Hz (the opposite of the goal), (c) shows black for FLAG_SECURE games, and (d) needs a consent dialog.
Real sharpening would have to come from the game, the GPU driver, or the ROM. Options are listed in the chat reply.

- Still to come: Clip buffer, game colour filters, refresh-rate matching stabilizer.

## Step 2 / Part 3 - Clip buffer

Not compiled or run on a device.

- core/ProjectionHub.kt: one shared MediaProjection grant (consent activity + mediaProjection foreground service).
  Android 14+ asks again for every new session.
- core/ClipBufferEngine.kt: hardware H.264 encode into a RAM ring buffer (15/30/60 s, keyframe aligned, 6 Mbps,
  long side <= 1280 px, about 45 MB for 60 s). `save()` muxes to Movies/HyperEngine_Clips (MediaStore on Android 10+,
  app folder below that). Nothing is written to disk before save.
- GamingSuiteManager: `startReplay(seconds)`, `saveReplay()`, `stopReplay()`. The buffer starts by itself after
  the user accepts the consent dialog.
- Manifest: FOREGROUND_SERVICE_MEDIA_PROJECTION, ProjectionRequestActivity, ProjectionService (mediaProjection).
- Limits: video only (no game audio, HEVC not offered); secure games record black; capture size is fixed at start
  (restart after rotating); the encoder costs some GPU/CPU while it runs. The HUD "Save last clip" button is
  wired in Step 3 (ic_clip_buffer is ready).
- Still to come: game colour filters, refresh-rate matching stabilizer.

## Fix round 1 (tile off, tile animation, voice changer)

Not compiled or run on a device.

### Wild Boost would not switch off from the tile
Causes found in the code:
1. A tap during a switch was silently dropped, and "active" only turns true at the END of the boost, so an early "off"
   did nothing while the boost finished and stayed on.
2. The profile flag `turbo.wildBoost` (saved by the HUD chip) restarted Wild Boost every time the game regained focus,
   which is exactly what closing the shade does.
3. The FPS lock was only released if this process remembered adding it.
Fixes (service/WildBoostController.kt): taps are queued (a newer tap cancels the running on/off and waits for its
clean-up); a deliberate off clears the profile's auto-start flag and force-releases the FPS lock and every booster.

### New tile animation: ui/WildBoostAuraOverlay.kt
Edge light comets + glass pill with spinning turbine; separate cool blue "BALANCED" animation for off. The tile uses it;
the HUD chip keeps the full-screen turbine (WildBoostIgnitionOverlay).

### Voice changer (core/GameAudioEngine.kt, VoiceStudio)
- Sample rate is read from the hardware (output rate, then 48000/44100/32000/16000) instead of fixed 44100.
- Mic opens with VOICE_COMMUNICATION first, plain MIC as fallback; the live monitor reopens a dead mic in ~50 ms (5 tries).
- NOT fixable in code: making a game's voice chat hear the changed voice. Android gives apps no way to inject audio into
  another app's microphone. This is a monitor/test tool.

## Step 3 / Part 1 - game colour filters + refresh-rate matching stabilizer (HyperLab suite finished)

Not compiled or run on a device.

### Game colour filters (core/GameFilterMath.kt, GamingSuiteManager)
- Per-game settings, saved in SharedPreferences: Clarity, Vibrance, HDR toning, Night mode, Colorblind assist
  (Protanopia / Deuteranopia / Tritanopia). API: `app.suite.gameFilter(pkg)`, `setGameFilter(pkg, cfg)`, `gameFilterState`.
- Applied as a real SurfaceFlinger colour matrix (Shizuku or root). The engine multiplies it with the profile's
  Visual filter (OptimizationEngine.setGameFilterMatrix), so both work together; removed and crash-recovered with the
  rest of the session. Re-applied by itself when the game comes to the front.
- Honest limits: a colour matrix cannot see neighbouring pixels, so there is NO edge sharpening ("Clarity" is contrast
  around mid grey); "Vibrance" is saturation (+80% max), not true vibrance; "HDR" is shadow lift + highlight roll-off,
  not real HDR; colourblind correction is computed in display space.

### refresh-rate matching
- Android has no VRR API for apps. It reads the game's real FPS (TelemetryMonitor) and moves the panel to the smallest
  supported mode that is a whole multiple of it (45 on 90 Hz, 60 on 120, 100 on 120). Damped: 3 matching readings and
  4 s between changes. Restores the starting rate when stopped or when the game leaves.
- API: `setGSync(pkg, on)`, `gsyncState` (fps, hz, note). Needs FPS to be readable on the device; says so when not.
- FpsRefreshRateEnforcer.retargetDisplay(hz): moves only the display rate of an active lock.

### Wiring
- GameDetectorService calls suite.onGameForeground / onGameBackground. GamingSuiteManager now takes the profile
  repository and telemetry monitor.

### Next: Part 2 (accessibility self-healer)

## Step 3 / Part 2 - self-healer, reliable voice changer, HyperLab tab, animation wiring

Not compiled or run on a device (no Android SDK in the build environment). Open in Android Studio, sync, build.

### Accessibility self-healer (core/AccessibilitySelfHealer.kt, service/SelfHealReceiver.kt)
- Runs at app start, game launch, Wild Boost tile tap, from a 15 minute AlarmManager watchdog, after boot / app update, and
  when the service itself reports it was unbound or its task was removed. Runs never overlap.
- Shell only, at most every 6 h: `cmd deviceidle whitelist +pkg`, standby bucket active, RUN_ANY_IN_BACKGROUND,
  RUN_IN_BACKGROUND, SYSTEM_ALERT_WINDOW, START_FOREGROUND.
- Re-adds the service to `enabled_accessibility_services` and sets `accessibility_enabled 1` (Shizuku / root, or the
  WRITE_SECURE_SETTINGS grant). If it is listed but not bound it removes and re-adds the entry to force a rebind, then waits
  for the real "connected" signal and reports it.
- TouchMacroService: promotes itself to a quiet foreground service (specialUse) when connected, START_STICKY,
  stopWithTask=false, tells the healer on onUnbind / onTaskRemoved / onDestroy (immediate heal + restart alarm).
- Setup screen: the accessibility row uses the healer; new "Keep auto tapper connected" row with an off switch.
- Consent rules: only re-enables a service the user switched on at least once (or enabled from this app); "Keep it
  connected" off stops everything. If you switch the service off in Android Settings it stays off until the next app start,
  game launch or tile tap (an immediate re-enable loop would fight you).
- Cannot do: change anything without Shizuku, root or the secure-settings grant (it says so). Some ROMs refuse to bind a
  background accessibility service whatever is written; the report says "enabled but Android has not bound it".

### Reliable voice changer (core/ReliableVoiceChangerEngine.kt, service/VoiceForegroundService.kt)
- `VoiceStudio` is now a typealias of ReliableVoiceChangerEngine, so every existing caller compiles unchanged.
- Rate negotiation: hardware output rate first, then 48000 / 44100 / 32000 / 16000, each checked for record AND play;
  candidates that fail to initialise are skipped; buffers sized from PROPERTY_OUTPUT_FRAMES_PER_BUFFER.
- Likely real cause of "works, then goes quiet in game": since Android 11 a non-foreground app's mic returns digital silence.
  The engine now captures under a microphone foreground service (manifest + FOREGROUND_SERVICE_MICROPHONE).
- Shell (rate limited): RECORD_AUDIO, PLAY_AUDIO, TAKE_AUDIO_FOCUS allow + runtime grant. AudioRecord.Builder with sources
  VOICE_COMMUNICATION, MIC, VOICE_RECOGNITION, UNPROCESSED, CAMCORDER. Playback USAGE_ASSISTANCE_ACCESSIBILITY + SPEECH (falls
  back to USAGE_MEDIA); focus lost to a game never stops the loop.
- Self-recovering loop: dead object / invalid operation / other negative codes / zero-byte reads / 300 ms of exact silence ->
  rebuild in 50 ms (silence also rotates the capture source). The effect is read per block, so it survives a rebuild, even on a
  different sample rate. Hard failures back off then stop after 14; silence never stops it, it flags `micSilenced`.
- Still not possible: making a game's voice chat hear the changed voice. This is a monitor / recording tool.
- No speaker feedback guard changes: the live monitor still needs headphones.

### HyperLab (ui/LabPanel.kt, ui/LabTools.kt, hub/LabPage.kt, ui/Brand.kt)
- One panel, two homes: HUD tile "HyperLab" (detail page) and a Game Space tab. Low-latency mode (live latency estimate with its three
  parts), clip buffer (15/30/60 s chips, buffer switch, "Save last clip" button with vector icon), game colour filters (4 sliders +
  colourblind chips, with the colour-overlay scope note), refresh-rate matching (live game fps -> panel Hz), HyperBoost quality
  picker with estimated-gain labels.
- Lobby: low-latency mode and the HyperBoost on/off switch only appear when the picked game is running; everything else is saved per game.
- Extra HUD tile "Save clip": one tap saves the clip (or starts the buffer if it is off).
- All HyperLab names live in ui/Brand.kt, so the trademark rename is a one-file edit (Part 3).

### AnimationController wired in
- HudController: sidebar open/close uses openWing / closeWing (spring, tool tiles stagger 30 ms).
- Sidebar: CPU / temp / RAM dials use SmoothGauge; a fan-blade vector next to the FPS readout spins with FanSpinner (speed = the
  faster of the game-mode tier and the CPU-load tier). Tool tiles show vector icons where one exists (text code otherwise).
- Lobby: Carousel3DView uses carouselTransform (deep camera distance tilt, scale, fade, coloured elevation glow); the centre
  GameCardView has NeonBorderPulse. With theme animations off, the old static ring is drawn instead.

### Manifest
- TouchMacroService: foregroundServiceType specialUse + subtype property, stopWithTask=false. New: SelfHealReceiver (self-heal
  action, BOOT_COMPLETED, MY_PACKAGE_REPLACED), VoiceForegroundService (microphone), FOREGROUND_SERVICE_MICROPHONE.

### Still to come: Part 3 (final clean-up)
Manifest / permission review, final emoji and symbol scan, licence file, trademark rename of the HyperLab names, README with
the non-affiliation statement.

## Step 3 / Part 3 - final clean-up and GitHub prep

Not compiled or run on a device (no Android SDK in the build environment). Open in Android Studio, sync, build.
Static checks that were run instead: every manifest class resolves to a Kotlin class, every `R.drawable` / `R.string` /
`@drawable` reference resolves to a file, every `Brand.*` constant exists, no import points at a deleted class, and
`tools/gen_icons.py` reproduces the checked-in drawables byte for byte after the rename.

### Renames (the feature names were the vendor's trademarks)
| Was | Now |
| --- | --- |
| "NVIDIA GeForce Lab" tab / tile | HyperLab |
| "NVIDIA Reflex low latency" | Low-latency mode |
| "ShadowPlay Instant Replay", "Save Instant Replay" | Clip buffer, "Save last clip" (tile: "Save clip") |
| "NVIDIA Freestyle filters" | Game colour filters |
| "G-SYNC style stabilizer" | Refresh-rate matching |
| ignition row "HYPERBOOST DLSS" | "HYPERBOOST SCALE" |
| `HyperBoostDlssEngine`, `NvidiaGamingSuiteManager`, `InstantReplayEngine`, `FreestyleMath` | `HyperBoostEngine`, `GamingSuiteManager`, `ClipBufferEngine`, `GameFilterMath` |
| `GeForceLabPanel/Tools/Page`, `app.nvidia` | `LabPanel/Tools/Page`, `app.suite` |
| drawables `ic_nvidia_reflex`, `ic_shadowplay_replay`, `ic_hyperboost_dlss`, `ic_freestyle_shader` (+ 2 avd_) | `ic_low_latency`, `ic_clip_buffer`, `ic_hyperboost_scale`, `ic_game_filters`, `avd_low_latency_pulse`, `avd_clip_rec_pulse` |
"NVIDIA" survives only in the non-affiliation statements (README, NOTICE.md, one line in the HyperLab panel, Brand.kt comment).

Persisted names changed with it, so settings saved by earlier dev builds are not carried over: the per-game colour-filter
prefs file (`hyper_game_filters`), the sidebar tool id (`nvlab` -> `lab`; unknown ids in a saved order are dropped and
missing ones appended, so saved layouts still load), and the crash-recovery owner tags (`reflex`, `gsync`). A phone that
crashed mid-session on an old dev build should reboot once so the old tags cannot leave a system property behind.

### Symbol scan
No emoji or pictograph anywhere in `.kt`, `.xml`, `.py`, `.kts`. Remaining non-ASCII: box-drawing characters inside source
comments only, and the degree sign in temperature readouts (a unit). The Diagnostics screen still used the text marks
`OK` / `!!` / `--`; they are now `ic_check` / `ic_alert` / `ic_dash` vectors, like the Setup screen.

### Manifest and permission review
Every `<uses-permission>` was matched against the API that needs it. Removed because nothing calls them:
`WAKE_LOCK`, `CHANGE_NETWORK_STATE`, `ACCESS_WIFI_STATE`, `MODIFY_AUDIO_SETTINGS`. Kept, with the reason:
`PACKAGE_USAGE_STATS` (game detection, play time), `QUERY_ALL_PACKAGES` (game library, freeze list; Google Play restricts it,
see README), `KILL_BACKGROUND_PROCESSES` (RAM clean), `READ/WRITE_SYNC_SETTINGS` (pause account sync), `ACCESS_NETWORK_STATE`
(background-data status), `INTERNET` (latency probes only), `VIBRATE` (ignition rev), `RECEIVE_BOOT_COMPLETED` (self-healer),
`ACCESS_NOTIFICATION_POLICY` (Danmaku do-not-disturb), `READ_PHONE_STATE` + `ANSWER_PHONE_CALLS` (call banner),
`WRITE_SETTINGS` / `WRITE_SECURE_SETTINGS` / `DUMP` / `READ_LOGS` (privileged, grantable once through Shizuku or ADB),
`RECORD_AUDIO` (voice studio), the `FOREGROUND_SERVICE_*` types (declared ahead of a targetSdk 34 bump).
All components have the right export state: only the launcher activity and the three system-bound services (accessibility,
notification listener, quick-settings tile, each behind its `BIND_*` permission) are exported. `allowBackup` is off.
versionName 1.3.0-phase3-s3p3, versionCode 18.

### Added
LICENSE (MIT), NOTICE.md (non-affiliation, trademarks, third-party licences), README.md, .gitignore; notes moved to docs/.

### Not changed on purpose
- `HyperBoostUpscaleOverlay` is still not built (see Step 2 / Part 1): an overlay cannot read or sharpen a game's pixels.
- The LATENCY row of the ignition still shows the design figure unless `Spec.latencyDeltaPct` is supplied.
- 18 icons in the 44-icon pack are not referenced from code yet (they were requested as part of the pack and are ready to use).

## Merge: landscape HUD / console branch + HyperLab branch

Two Phase 3 builds were combined (see PHASE3_LANDSCAPE_NOTES.md for the first). Not compiled or run on a device.

- Both branches' files are present. Shared files were merged by hand: HudController, TouchMacroService, AndroidManifest,
  GameProfile (ToolIds now also has `lab`, `replay`), HudTools (ToolCatalog has every tool), HyperApp, GameDetectorService,
  GameTurboSidebarView (implements HudPanel and keeps the spring wing, gauges and fan).
- Competitive Mode, the Energy Cube tier chips and the landscape tier selector now go through WildBoostController
  (full boost, ignition, FPS lock, HyperBoost, low-latency mode).
- Landscape HUD shows vector icons for tools that have no canvas icon (HyperLab, Save clip).
- Manifest keeps ACCESS_WIFI_STATE, MODIFY_AUDIO_SETTINGS and READ_CONTACTS, which the landscape branch's code calls.
- The screen recorder notification uses ic_qs_wild_boost instead of stock Android art.
- Known overlap: the built-in screen recorder (ScreenRecordService) and the clip buffer (ProjectionHub) each ask for their own
  screen-capture consent. They are not shared.
- After installing, switch the accessibility service off and on once (key events are a new capability).
