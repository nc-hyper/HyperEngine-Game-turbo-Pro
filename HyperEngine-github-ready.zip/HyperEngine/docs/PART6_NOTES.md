# Part 6 - HUD wiring (ui/GameTurboLandscapeHudView.kt)
- Status bar: live Hz badge (rolling number, green at the panel's top rate; tap = lock / release the panel via MaxPanelHzEngine)
  and a "1% LOW" chip fed by HardwareFrameSmoother.stats (tap = details). Both sit in the existing status bar.
- Dashboard: "AnTuTu / Max Hardware Boost" card (AntutuBenchmarkBooster + HardwareFrameSmoother in one tap, live temp /
  thermal / RAM freed / Hz, busy shimmer, ring burst on start, shake on failure).
- Left rail: "Max HW" quick toggle above All tools.
- The HUD overlay window is restamped to the panel's top refresh rate on attach; the frame monitor runs while the HUD is open.
- The 1% LOW chip measures this app's own render pipeline (Choreographer frames) at the display rate, not the game's internal frames.
