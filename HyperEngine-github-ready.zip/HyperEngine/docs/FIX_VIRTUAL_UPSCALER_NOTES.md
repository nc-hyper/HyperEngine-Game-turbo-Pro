# Virtual-display upscaler (1.5.0-ui-p3-fix3)

Not compiled or run on a device (no Android SDK where this was written). Build and test before relying on it. The GL
shaders, the virtual-display flags and the `dumpsys` parsing are the parts most likely to need a tweak on a given ROM.

## What it is

The game runs on a private **virtual display** that is smaller than the screen (0.55x to 0.85x). A GL pipeline takes that
display's output, scales it to the real screen with a Catmull-Rom bicubic filter, then sharpens it with a contrast-adaptive
pass (the CAS idea: 5 taps, strength limited by local contrast, so no halos and no noise boost in flat areas). The result is
drawn in a full-screen overlay. Touches on the overlay are re-injected into the virtual display with scaled coordinates.

Compared with HyperBoost's "system resolution" route, nothing system-wide changes: the real screen, the HUD and every other
app stay native, and the picture is sharpened instead of only stretched by the panel scaler. Nothing persists either: the
virtual display belongs to this process, so a crash or a stop moves the game back to the phone screen. No restore step.

Where: HyperLab, new card "Virtual-display upscaler" (scale presets reuse the HyperBoost qualities, sharpening 0..100,
Start/Stop button, live status).

## Files

- `core/VirtualDisplayUpscaler.kt` (new): engine. Creates the display, launches the game on it, monitors it, tears down.
- `core/UpscaleRenderer.kt` (new): EGL + GLES2 thread. SurfaceTexture in, two shader passes, window surface out.
- `ui/UpscaleOverlay.kt` (new): picture window, touch forwarding, small Back / Stop pill (draggable by its grip).
- `core/InputManagerBridge.kt`: `inject()` and `pressKey()` take an optional `displayId` (default 0, so nothing else changes).
- `ui/HudPanel.kt`, `service/HudController.kt`: `HudBus.raiseHud` so the HUD is re-raised above the upscaler window.
- `ui/LabPanel.kt`, `ui/Brand.kt`, `HyperApp.kt`: the card, the name, the instance.
- No manifest, permission, layout or string changes.

## Flow

1. Checks: display-over-apps permission, Shizuku (touch injection binder), HyperBoost system resolution not active,
   the game has a launcher activity, screen orientation matches the game's declared orientation.
2. Renderer and overlay come up, then `DisplayManager.createVirtualDisplay` (PUBLIC | OWN_CONTENT_ONLY | SUPPORTS_TOUCH),
   size = screen x scale, density scaled the same way so the game's dp layout keeps its proportions.
3. `am force-stop <game>` (it must restart: an app already running keeps its task on the phone screen), then
   `am start --display <id> -n <launcher activity>`.
4. A monitor reads `dumpsys activity activities` every 4 s. If the game never shows up under the virtual display within
   14 s, or it disappears twice in a row after showing up, the upscaler stops itself with the reason. If the dump has no
   display headers on this ROM, nothing is assumed and the on-screen Stop button is the way out.
5. The screen rotating or changing size, or the system removing the display, also stops it.

## Needs

Shizuku running and permitted. Display-over-apps permission. A game that can run on a secondary display.

## Limits, said plainly

- **Not AI upscaling.** It is a spatial filter in the spirit of FSR 1 / CAS. It cannot add detail the low-resolution render
  never had; it hides softness. The gain is GPU relief: the game shades fewer pixels.
- **Likely 60 Hz cap.** Virtual displays normally refresh at 60 Hz, so a 90/120 fps game is capped. The status line shows
  the fps the upscaler really puts on screen. If your goal is high refresh rate, use HyperBoost instead.
- **FLAG_SECURE games render black** (the virtual display is not allowed to show secure layers), and DRM video does too.
- **Some games refuse a secondary display** (non-resizable activities on a ROM that does not allow them there). The game then
  opens on the phone screen, the monitor notices, and the upscaler stops with that reason.
- **Back and keys.** The system back gesture goes to the phone screen. Use the pill's Back button. Hardware volume keys
  are not forwarded.
- **Orientation.** Start with the screen already in the game's orientation (starting from the in-game HUD does that). Rotating
  the phone while it runs stops it.
- **Extra latency.** Touch goes overlay, injector thread, Shizuku binder, then the game; the picture goes through a GPU
  copy. Expect a small added delay compared with the native screen. Not measured.
- **Restarts the game.** Unsaved progress is lost.
- Game detection (`GameDetectorService`) reads usage events and `dumpsys`, neither of which was changed. It was not checked
  whether every ROM reports a game on a secondary display the same way; if the HUD drops while the upscaler runs, that is why.
- Sharpening changes apply live. A new render scale applies the next time the upscaler starts.
