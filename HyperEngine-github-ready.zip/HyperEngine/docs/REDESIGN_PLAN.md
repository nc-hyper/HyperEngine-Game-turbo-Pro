# HyperEngine UI redesign: HyperOS Game Turbo x RedMagic landscape

Goal: one new look across the whole app, easy access to every remaining feature, a slide bar for apps, and
notification edge lighting. Nothing is deleted until the part that replaces it ships. Unzip each part over the project.

| Part | Contains | Status |
|---|---|---|
| 1 | Design system (HyperOS and RedMagic tokens, switch, slider, chips, buttons, cards) + notification edge lighting | shipped |
| 2 | Landscape console shell: new top status bar, left quick-toggle rail, centre dashboard, right control wing, shoulder-key hints | shipped |
| 3 | Slide bar (HyperOS Game Turbo style): Apps, Chat apps, Browser, Notes, Calculator move out of the HUD into a built-in slide-out dock with floating windows. Removes `apps`, `social`, `browser`, `notes`, `calculator` from the HUD tool grid, `ToolIds`, `ToolCatalog`, and migrates saved tool order | this drop |
| 4 | "Overload" merge: overlapping features become single pages. Performance (Game mode + Wild Boost + Turbo core + Refresh rate + Resolution + Freeze + Gaming DNS + HyperLab / Low latency), Display (Filter + Brightness + Crosshair + Edge guard), Notifications (Danmaku + Edge lighting + Call banner), Capture (Screenshot + Recorder + Clip buffer + Studio) | |
| 5 | Game Space hub (the app itself): HubActivity, GamesPage, carousel, SetupViews, ThemesPage, RulesEditor in the new look, landscape lobby | |
| 6 | Console settings, Diagnostics, portrait sidebar parity, icon pack regeneration (`tools/gen_icons.py`), docs and polish | |

## Part 1: files

| File | What changed |
|---|---|
| ui/HudTheme.kt | New palettes: **HyperOS Game Turbo** (graphite glass, hairline borders, blue + orange) and **RedMagic Cyber Console** (carbon, signal red). New tokens `surface`, `divider`, `knobOff` (default-valued, nothing else breaks). |
| ui/HyperKit.kt (new) | `Hyper.card`, `Hyper.switchRow`, `Hyper.badge`, `Hyper.addDivider`, `HyperSwitch` (animated pill switch, gamepad focus ring), `GradientStrip`. Parts 2 to 6 build only from these. |
| ui/UiKit.kt | `tileRadius` rounder on HyperOS; `Ui.isSoft(theme)`; `section` is a quiet grey title on HyperOS and loud accent capitals on RedMagic / Realme; `button` is a full pill on soft themes; `slider` is a thick rounded track with a white knob; `ChipGroup` is pill segments without outlines on soft themes. |
| ui/Phase4Ui.kt | `ToolUi.check` now returns a HyperOS switch row instead of a CheckBox (all 34 callers just add it to a layout). |
| ui/EdgeLighting.kt (new) | `EdgeLightColors` (per-app colour, palettes), `EdgeLightView` (the light), `EdgeLighting` (controller), `EdgeLightPanel` (settings). |
| ui/DanmakuTicker.kt | Owns an `EdgeLighting`; every bullet also fires `edgeLight.pulse`. Test bullet lights the edge too. Danmaku on/off is a switch row. Edge lighting section added to the Danmaku page. |
| ui/MicroToolsManager.kt | Feeds `global.edgeLight` to the ticker on show and on every settings change. |
| service/DanmakuNotificationService.kt | `DanmakuMessage.color`: the notification's own colour, else the icon's dominant hue (cached per app). |
| data/GameProfile.kt | `EdgePalette`, `EdgeStyle`, `EdgeLightConfig`, and `GlobalSettings.edgeLight` (default-valued, old config files still load). |
| app/build.gradle.kts, README.md | version 1.5.0-ui-p1, pointer to this file. |

No manifest, layout or string changes. No new permissions: the light uses the overlay window the HUD already has.

## Part 3: files

| File | What changed |
|---|---|
| ui/SlideBar.kt (new) | `SlideBarTab` (edge tab), `SlideBarController` (edge tab, dock and flyout windows), `SlideBarTool` (the "Slide bar" tile / rail button). |
| ui/MiniWindows.kt | `BrowserTool`, `CalculatorTool`, `NotesTool`, `SocialTool` removed. The Chat apps page is now `ChatPanel.build(host, onLaunched)`. `MiniWindowHost.onChanged` fires when a window opens or closes. |
| ui/AppsPanel.kt | `AppsTool` removed. `AppsPanel.build` takes `focus` (keyboard request, defaults to the HUD's) and `onLaunched`. |
| ui/MicroToolsManager.kt | No longer registers the four tools. New `toggleBrowser(game)`, `toggleCalculator()`, `toggleNotes(game)` used by the slide bar. |
| ui/HudTools.kt, ui/HudIcons.kt | The five catalog entries and icon mappings removed. New `slidebar` entry. |
| ui/HudPanel.kt (`HudBus`) | `openSlideBar`, `closeSlideBar`, `slideBarOpen`. |
| ui/ConsoleShell.kt | `slidebar` can sit on the quick rail. |
| ui/ConsoleSettings.kt | New **Slide bar** section: enable, edge, dock buttons, pinned apps, close-after-launch, page width, tab opacity, open now. |
| service/HudController.kt | Owns the `SlideBarController`: shows it with the game, closes the HUD when it opens (and the other way round), hides it for screenshots, re-raises it above new overlays, follows the display-mode lock and rotation. |
| data/GameProfile.kt | `ToolIds.ALL` loses the five ids and gains `slidebar`. `ToolIds.MOVED_TO_SLIDE_BAR`, `SlideItemIds`, `SlideBarConfig`, `GlobalSettings.slideBar`, `GlobalSettings.migrated()`. |
| data/GameProfileRepository.kt | Runs `migrated()` on load and on backup import. |
| app/build.gradle.kts, README.md | version 1.5.0-ui-p3. |

No manifest, layout, string or permission changes.

**Migration.** Old `global.json` files and backups still load. `migrated()` drops `apps`, `social`, `browser`, `notes`, `calculator` from the saved tool order, hidden list and quick rail, and the new `slidebar` tile is appended to the order. Per-game data is untouched: the browser home page (`micro.browserHome`), pinned apps (`apps.pinned`) and floating window size (`apps.widthPct / heightPct`) carry over.

## Part 3: how the slide bar behaves

```
 game screen                                         +-------------------+
                                                     | All apps          |
                                          +-------+  |  [search]         |
                                          | Apps  |  |  grid of apps     |
                                          | Chat  |  |  ...              |
                                          | Brow. |  +-------------------+
   edge tab  ::                           | Notes |  (flyout, only for Apps and Chat)
   (tap or drag inward)                   | Calc  |
                                          |  --   |
                                          | pin 1 |
                                          | pin 2 |
                                          +-------+
```

* **Edge tab.** A slim tab with three grip dots, on the right edge by default (the HUD handle is on the left). Tap it or drag it inward to open. Long-press and drag moves it along the edge; the position is saved. If the HUD handle is on the same edge, the tab shifts to clear it.
* **Dock.** Round buttons: **Apps**, **Chat**, **Browser**, **Notes**, **Calc**, then up to six pinned apps under a divider. A button is lit while its window or page is open. The dock scrolls when it is taller than the screen.
* **Apps and Chat** open a flyout beside the dock: the same searchable grid of every launcher app and the same Floating / Split chat buttons as before, in the new look. The search box asks for keyboard focus and gives it back.
* **Browser, Notes and Calc** toggle their floating mini window straight away. With *Close the slide bar after opening* on (default) the bar steps aside so the window is not under it.
* **Pinned apps** are the ones you long-press in the Apps page. Tap opens one in a floating window, long-press unpins it.
* **Exclusive with the HUD.** Opening the slide bar closes the HUD, opening the HUD closes the slide bar. The "Slide bar" tile in All tools and the optional rail button open it from inside the HUD.
* **Touches.** The window is exactly the size of the dock (plus flyout). A tap on the game or on the empty part of the window closes it. It never takes focus except while the Apps search box is being used.
* **Screenshots and recording.** Both windows hide for the instant of a capture, like the HUD.

## Part 3: limits

* Not compiled or run on a device (no Android toolchain was available). Open in Android Studio, sync, build, and expect to fix small compile errors.
* Floating windows for Apps and Chat still need a ROM with freeform windows (or Shizuku); the pages say so, as before.
* The slide bar has no gamepad focus navigation yet. Touch only.
* The portrait sidebar still lists the "Slide bar" tile in its grid and keeps the old look until Part 6.

## Part 2: files

| File | What changed |
|---|---|
| ui/ConsoleShell.kt (new) | `ConsoleKit` (radius, focus ring, icon buttons), `ConsolePanel` (themed panel frame, moved out of the HUD), `StatChip`, `ModeSwitch` (ECO / BAL / WILD segmented control), `QuickItem`, `RailButton`, `KeyHintBar`, `QuickCatalog` (what can sit on the rail and what tap / long-press do). |
| ui/GameTurboLandscapeHudView.kt | Rebuilt around the new shell: top status bar, left quick-toggle rail, centre Dashboard / All tools tabs, right control wing, key hint strip. Still a `ToolHost` and `HudPanel`, so every tool page works unchanged. |
| ui/ConsoleSettings.kt | New sections: Controller key hints (Auto / Always / Never) and Quick toggle rail (one switch row per feature). Wing slider renamed Control wing width. |
| data/GameProfile.kt | `HudLayoutConfig.railItems`, `hintMode`, `centerTab` (default-valued, old config files still load). |
| app/build.gradle.kts, README.md | version 1.5.0-ui-p2. |

No manifest, layout, string or permission changes. Nothing was deleted: the old left tool grid moved into the **All tools** tab and **Restore** moved to the centre header.

## Part 2: how the console behaves

```
+--------------------------------------------------------------------------------+
| 21:40  Game   FPS  CPU  GPU  RAM  TEMP  PING  NET  BATT   [ECO|BAL|WILD] SHIZUKU  pill  gear  X |
+------+--------------------------------------------------------+----------------+
| rail | [Dashboard | All tools]                      [Restore]   | Energy Cube    |
| ( )  |  hero card: turbine, game, mode                        |  (L1 / R1)     |
| ( )  |  charts card: FPS, ping, battery temp                  |                |
| ( )  |  ... or the tool grid                                  | brightness     |
| All  |  footer: shell status, toasts                          | volume         |
+------+--------------------------------------------------------+----------------+
| B Back   Y Console settings   X Dashboard / All tools                L1 R1 Cube face |
+--------------------------------------------------------------------------------+
```

* **Status bar.** Clock, game name, eight live readouts (FPS, CPU, GPU, RAM, temperature, ping, network, battery), the ECO / BAL / WILD switch, the Shizuku badge, detach-FPS-pill, settings, close. Tapping the FPS chip also detaches the pill. The readouts scroll sideways when the screen is narrow.
* **Quick rail.** Round buttons, lit in the accent colour while a feature is on. Default set: Wild Boost, FPS pill, Crosshair, Danmaku, Edge guard, Screenshot. Choose any of 13 in Console settings. **Tap** flips the feature directly (Wild Boost, FPS pill, Crosshair, Danmaku, Edge guard) or runs / opens the tool (Screenshot, Record, Filter, Freeze, AFK, Auto tapper, Keyboard and mouse, Brightness lock). **Long-press** opens the feature's page (Wild Boost opens Turbo core). The list scrolls when it is taller than the screen; **All tools** is pinned below it.
* **Centre.** Two tabs. Dashboard: hero card (tap the turbine to toggle Wild Boost) and live FPS / ping / temperature charts. All tools: every registered tool in the user's order, the column count follows the panel width. Any tool page replaces the tabs with a back button. The last tab is remembered.
* **Right wing.** Energy Cube plus a card with brightness and volume sliders. Width is the existing wing-width setting.
* **Key hints.** B (also Back / Esc) goes back or closes, Y opens Console settings, X flips Dashboard / All tools, L1 / R1 turn the cube. Shown with a gamepad or keyboard connected (Auto), always, or never.
* **Settings changes keep your place.** A change that does not alter the look (danmaku flag, cube face, tab) no longer rebuilds the HUD. A rail or hint change rebuilds it but keeps an open tool page, so toggling rail switches inside Console settings does not kick you out of that page.

## Part 2: limits

* Not compiled or run on a device (no Android toolchain was available). Open in Android Studio, sync, build, and expect to fix small compile errors.
* Rail buttons for Wild Boost, FPS pill, Crosshair, Danmaku and Edge guard change the saved profile and rely on the existing profile / settings observers in `HudController` to update the overlays, the same path the FPS-pill button already used.
* Record, AFK, Macro and Keyboard and mouse have no one-tap flip in their tools, so their rail buttons open the tool page. Part 4 may change that when those pages are merged.
* Apps, Chat apps, Browser, Notes and Calculator were still in the All tools grid in this part. Part 3 moves them into the slide bar.
* The portrait sidebar keeps the old look until Part 6.
* On very short screens the centre panel can be tight: the dashboard charts shrink first, and the tool grid scrolls.

## Edge lighting: how it behaves

* Plays only while the danmaku ticker is on for the running game, one light per bullet. A burst inside 0.5 s is one light.
* Colour: **Per app** (notification colour, else icon hue), Rainbow, Aurora, Sunset, RedMagic, **Cycle** (next palette each time), One colour (HEX picker).
* Motion: **Flow** (two comets circle the screen), **Breathe** (soft full ring), **Pulse** (two flashes).
* Thickness 2 to 10 dp, brightness 30 to 100 %, duration 1.2 to 6 s, corner radius (0 = follow the phone's own screen corners on Android 12+).
* The window never takes touches and exists only while the light plays. Hardware layer, no per-frame allocation.
* Settings: HUD > Danmaku > Edge lighting (Part 4 moves it into the merged Notifications page).

## Limits

* Not compiled or run on a device. Open in Android Studio, sync, build.
* Icon hue is a 24 px sample weighted by saturation. Grey, white and black icons have no hue, so Per app falls back to Aurora.
* Needs Notification access (already used by the danmaku ticker) and the display-over-apps permission.
* Edge lighting is not a system feature: apps cannot draw over the status bar's cutout area on every ROM, so the light follows the visible screen.
