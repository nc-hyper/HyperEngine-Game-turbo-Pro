# Part 9 - lobby: ROM & Benchmark Optimizer Lab + native max refresh rate

Parts 7 and 8 (touch/multi-touch, voice/hands-free/freeform) were skipped on request; nothing in them was touched.

## Where it lives
The lobby of this project is Game Space (`hub/HubActivity`), a portrait screen (the manifest locks portrait; earlier phases
moved away from landscape). `MainActivity` is the developer console reached from the Game Space menu. Part 9 updates both.

| File | Change |
|---|---|
| `hub/RomLabCard.kt` (new) | The "ROM & Benchmark Optimizer Lab" card, reusable in any activity |
| `hub/RomLabPage.kt` (new) | New Game Space tab "ROM Lab" that hosts the card |
| `hub/HubKit.kt` | `RomLabPage` registered after HyperLab |
| `core/ConsoleWindow.kt` | `lockPanel(activity, sustained)` / `unlockPanel(activity)` |
| `hub/HubActivity.kt` | lobby window locked to the panel's top rate; sustained mode off while a benchmark boost runs |
| `MainActivity.kt` | window locked, card shown at the top, attach/detach with onResume/onPause |
| `DiagnosticsActivity.kt` | window locked |
| `app/build.gradle.kts` | versionCode 25, versionName 1.6.0-part9 |

## Native max refresh rate for the lobby
`ConsoleWindow.lockPanel` binds the activity window to `MaxPanelHzEngine` (preferredDisplayModeId + preferredRefreshRate,
re-stamped by the engine when the display mode changes) and to `HardwareFrameSmoother` (sustained-performance mode where
the device supports it). No Shizuku needed. The target is the fastest mode at the panel's CURRENT resolution (no
resolution switch / blink); the card shows when a faster mode exists only at another resolution.

## The card
- Live: rolling Hz badge (green at the panel's top rate), 1% LOW of this app's frames, battery temperature (vs. the 45 C
  limit), thermal state, RAM gained, engine states. Busy shimmer + animated icon while anything runs.
- Target picker: installed AnTuTu / 3DMark / Geekbench / PCMark first, then your 6 most recent games.
- AOT Speed Compile: `cmd package compile -m speed -f <target>` via `AntutuBenchmarkBooster.compileAsync` (minutes; keeps
  running if you leave the screen).
- AnTuTu Prep: `AntutuBenchmarkBooster.engage` (storage trim, RAM purge, sync + background data off, thermal override,
  fixed performance clocks, ROM performance keys, max panel Hz + GameManager fps for the target) then
  `HardwareFrameSmoother.engage`. The same button becomes "Stop and restore" and puts everything back.
  The 45 C battery watchdog also ends it by itself.
- Lock panel: `MaxPanelHzEngine` alone (disabled while the benchmark boost holds the lock).
- Open: starts the picked app (shell fallback when Android blocks the start).
- Result box: every real step result of the last action, failures in red; tap to expand.

## Limits (same as the engines)
- Most steps need Shizuku or root; the card says so when neither is granted. Panel lock and frame smoother work without.
- The thermal override changes what Android reports to apps; the chip's own protection stays on.
- A score depends on the silicon; this removes software reasons for a lower score.
- The 1% LOW measures this app's own Choreographer frames, not a game's internal frames.
