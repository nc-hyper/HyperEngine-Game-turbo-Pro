# HyperEngine Game Turbo Pro: Phase 2

Not compiled or run on a device (no Android SDK in the build environment). Open in Android Studio, sync, build.

## New files
- core/FpsRefreshRateEnforcer.kt  5-layer FPS override, app-switch watchdog, DisplayModeLock, motion smoothing + black-frame insertion
- core/CustomWildBoostEngine.kt   Wild Boost / Diablo, turbo fan + thermal guard, charge separation, Battery Saver sync, RAM cleaner, DEX compile, DNS
- core/Phase2Store.kt             crash-safe record of every non-settings change (app ops, props, device_config, charge, power modes)
- ui/TurboTools.kt                "Turbo core" sidebar panel + spinning RGB turbine
- core/TelemetryMonitor.kt        already complete in your Phase 1 zip (FPS, cores, RAM, temp, watts, ping); unchanged

## Changed files
- OptimizationEngine: putTracked / releaseTracked / isTracked
- GameProfile: TurboConfig, FanMode, wildBoostWhitelist
- HyperApp, GameDetectorService, TouchMacroService (+ window-state events), HudController, FloatingTelemetryPill, GameLauncher
- accessibility_service_config.xml, strings.xml

## Portrait
- Manifest: Hub, Diagnostics, Developer console = portrait
- HubActivity: vertical layout, bottom tab bar
- DiagnosticsActivity: one column
- ConsoleWindow: keeps system bars visible

## Limits
- Overlay display-mode lock: whether the compositor honours an overlay's refresh request depends on the ROM. The settings layers and watchdog are the dependable part.
- Panel is the ceiling: 144 FPS on a 120 Hz screen is rounded to 120 and reported.
- Charge separation: only a writable /sys charge node really stops charging (usually root). Otherwise `cmd battery unplug` is software-only and labelled so.
- Fan: no physical fan; cooling is real but modest. No generic Bluetooth/USB cooler protocol exists, so none is attempted.
- debug.sf.* pacing props are read by SurfaceFlinger at start-up; effect is ROM dependent.
