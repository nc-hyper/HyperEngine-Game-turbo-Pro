# Fix drop: notification edge lighting

Not compiled or run on a device. Build and test before relying on it.

## Causes

1. The light was only triggered from `DanmakuTicker.accept()`. The ticker is OFF by default (`DanmakuConfig.enabled = false`),
   and when it is off `DanmakuTicker.apply` sets `DanmakuNotificationService.sink = null`, so the listener dropped every
   notification before anything could light the edge. Only the "Preview" button worked, because it bypasses all of that.
2. Even with the ticker on, `accept()` returned before the pulse for a whitelisted-out app, an empty body, or a repeat within 3 s.
3. The Edge lighting settings were drawn only inside the ticker's `if (cfg.enabled)` block, so with the ticker off the page was unreachable.
4. The light only existed while a game was in front (the ticker belongs to the game HUD).

## Changes

- `service/DanmakuNotificationService.kt`: new `edgeSink`. Every eligible notification now goes to the edge light even with no
  ticker sink. With no game in front, the service lights the edge itself (`EdgeLighting.pulseStandalone`).
  Ongoing, group-summary, call, alarm, progress, transport and own-app notifications are still skipped.
- `ui/DanmakuTicker.kt`: registers `edgeSink` in `show()`, clears it in `hide()`; no longer pulses from `accept()`;
  the Edge lighting settings are always shown on the page.
- `ui/EdgeLighting.kt`: `pulseStandalone`, and an "Also outside games" switch.
- `data/GameProfile.kt`: `EdgeLightConfig.everywhere` (default true; old config files still load).

## Needs

Notification access (the Danmaku page shows its status and a grant button) and display-over-apps permission.
No manifest, layout, string or permission changes.
