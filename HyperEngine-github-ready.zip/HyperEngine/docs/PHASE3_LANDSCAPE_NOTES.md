# HyperEngine Game Turbo Pro: Phase 3 (on top of Phase 2)

Foreground game detector, landscape dual-wing HUD, Energy Cube, freeform app launcher, hands-free calls,
native screenshot / recorder / cast, virtual hardware slider, keyboard + mouse mapper.
Nothing in Phase 1 or 2 was removed. Unzip over your CodeAssist project and build.

## New files
| File | What it is |
|---|---|
| ui/GameTurboLandscapeHudView.kt | Full-screen landscape HUD: top telemetry arch, left tool wing, right Energy Cube wing, centre workspace. 4 themes. |
| ui/EnergyCubeView.kt | 4-face 3D cube: Performance, Thermal, Power, Display. Swipe, arrows, or L1 / R1. |
| ui/HudIcons.kt | Every icon, drawn with paths. No emoji or text glyphs. |
| ui/HudPanel.kt | `HudPanel` interface (sidebar and wings share it) and `HudBus` switchboard. |
| ui/HudProbes.kt | GPU load reader (sysfs) and Wi-Fi / cell signal reader. |
| ui/ConsoleSettings.kt | Theme, HUD layout, key chord, Competitive Mode options. |
| ui/AppsPanel.kt | Searchable grid of ALL launcher apps, pin, window size. |
| ui/CallBanner.kt | In-game call banner window and controller. |
| ui/SystemTools.kt | Screenshot, Recorder, RedMagic Studio and Calls tools. |
| ui/KbmUi.kt | Keyboard / mouse tool page and the on-screen layout editor. |
| service/GameSpaceTileService.kt | Quick Settings tile, `CompetitiveMode`, `SliderFeedback` (synthesised click + thunk, heavy haptic). |
| service/ScreenRecordService.kt, ProjectionActivity.kt | Built-in MediaProjection recorder and its consent helper. |
| core/FreeformAppLauncher.kt | Lists every app, opens it in a full-size freeform window. |
| core/HandsFreeCallManager.kt | Ring detection, answer on speaker, reject, mute. |
| core/NativeSystemActions.kt | Screenshot, OEM recorder launcher, cast, ADB helper, keyboard / mouse detection. |
| core/KbmMapper.kt | Keyboard + mouse to multi-touch (uses the pointer slots from Phase 1). |
| res/drawable/ic_tile_competitive.xml | Tile icon. |

## Changed files
GameProfile.kt (new configs, tool ids), HudController.kt (picks wings or sidebar, banner, mapper, bus),
GameDetectorService.kt (Competitive Mode hooks), TouchMacroService.kt (key chord, key handlers, screenshot,
mouse), EdgeTriggerView.kt (haptic, chevron, long-press drag along the edge), DanmakuNotificationService.kt
(caller name for the banner), GameTurboSidebarView.kt (implements HudPanel), HyperApp.kt, HudTools.kt,
SystemBridgeExecutor.kt (READ_CONTACTS grant), AndroidManifest.xml, accessibility_service_config.xml, strings.xml.

## What each feature really does, and its limits
* Landscape HUD opens when the game screen is landscape (Console settings: Automatic / Wings / Sidebar).
  It is one full-screen window with a dim layer; tapping outside the panels closes it. A gamepad or keyboard
  makes the window focusable so D-pad / A / B / L1 / R1 navigate it.
* GPU % needs a readable kernel counter (Adreno kgsl, Mali, MediaTek). Most phones only allow it through
  Shizuku. If none is found it shows "--"; it is never estimated.
* Detach FPS pill: tap the FPS cell or the pill icon. It turns on the existing floating pill.
* Brightness slider writes the system brightness as tracked settings, so leaving the game restores it.
* Freeform: ActivityOptions with bounds + windowing mode 5 first, then `am start --windowingMode 5` and
  `am task resize` through Shizuku. Android only shows a floating window if the ROM supports freeform.
  "Enable freeform" in the Apps page sets the two developer switches (reboot may be needed).
* Calls: answer = TelecomManager.acceptRingingCall, else KEYCODE_CALL via shell. There is no real
  `cmd telecom accept-ringing-call`, so it is not used. Speaker is forced 300 ms after answer and re-checked
  twice; routing goes through the Shizuku-bound audio service first. The banner says if the speaker refused.
  Caller name comes from the dialer notification (needs notification access) or contacts.
* Screenshot: hides the HUD, waits 150 ms, accessibility screenshot action, else KEYCODE_SYSRQ (120) via shell.
* Recorder: OEM recorders are launched if installed. Built-in recorder records video (+ optional mic), not
  game audio (Android does not allow that for MediaRecorder).
* ADB over network: sets `service.adb.tcp.port` only. It never restarts adbd, because Shizuku runs under it.
* Key chord: hold Volume Up + Down (default 1.2 s). In a game it toggles the HUD, otherwise it opens Game
  Space. Needs the accessibility service re-enabled once because it now requests key events.
* Competitive Mode tile: sound + thud, landscape lock (tracked, restored by the engine), Wild Boost / Diablo,
  then Game Space. The lobby itself is still portrait until Phase 6; the intent carries
  `EXTRA_LOBBY_LANDSCAPE` for it.
* Keyboard / mouse: WASD joystick and key taps work with Shizuku (synthetic pointer slots). Mouse buttons are
  only reported to accessibility services on Android 14+.

## After installing
1. Settings > Accessibility: turn HyperEngine off and on once (key events are a new capability).
2. Quick Settings: add the "Competitive Mode" tile.
3. If calls do not show: Calls tool > Grant phone permissions (needs Shizuku).
