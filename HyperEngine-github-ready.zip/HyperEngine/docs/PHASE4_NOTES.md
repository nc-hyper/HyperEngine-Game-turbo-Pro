# HyperEngine Game Turbo Pro: Phase 4 (on top of Phase 3)

Realme / OPPO Auto-Touch and Commands suite, RedMagic shoulder triggers, and the visual tools.
Phase 4 ships in three parts. Nothing from Phase 1 to 3 is removed. Unzip each part over the project.

| Part | Content |
|---|---|
| 1 (this drop) | Touch engine, no UI: dual-engine injector, auto-touch runner (3 trigger modes), macro recorder |
| 2 | Realme UI: floating dock, numbered reticles, swipe vectors, REC overlay, auxiliary buttons, settings popup, layout manager |
| 3 | RedMagic L1 / R1 (volume keys, bezel strips, gyro), Scout magnifier, Sound Radar, crosshair + filter upgrades |

Not compiled or run on a device (no Android SDK in the build environment). Open in Android Studio / CodeAssist, sync, build.

## Part 1: files

| File | What it is |
|---|---|
| core/MultiTouchInjector.kt | The one door to the screen. Engine A: Shizuku hardware multi-pointer injection. Engine B: accessibility. Slot allocator, held-finger handles, engine preference (Auto / Shizuku only / Accessibility only). |
| core/AccessibilityGestureLane.kt | Engine B internals: 8 ms tap strokes, chained `willContinue` strokes for fingers that stay down, one pump that packs everything simultaneous into one gesture. |
| core/AutoTouchEngine.kt | Runs an `AutoTouchScript`: Continuous, Hold-to-Rapid-Fire, 1-Tap Combo Macro. Timing, loop limits, humanizer. Live `state` flow. |
| core/MacroRecorder.kt | Turns raw MotionEvents into a `CommandMacro` (4 fingers, ms timestamps, thinned MOVE samples, optional live forwarding). |
| service/TouchMacroService.kt (changed) | Added `dispatchGestureAwait(GestureDescription)`. Nothing else touched. |
| HyperApp.kt (changed) | Added `app.touch` and `app.autoTouch`. |
| app/build.gradle.kts (changed) | versionName 1.4.0-phase4-p1 only. |

No manifest, layout or string changes in Part 1.

## How the engines work

### Engine A: Shizuku multi-pointer (primary)
`SyntheticPointerTable` (Phase 1) builds MotionEvents (SOURCE_TOUCHSCREEN) containing only our synthetic pointers,
ids 3, 4, 5 and 6, and injects them through `IInputManager.injectInputEvent` (ASYNC). Ids 0, 1 and 2 are never written,
so the player's aiming thumb and joystick thumb keep their own pointers while auto-touch fires beside them.
`ACTION_CANCEL` is never used. Sequence per finger: DOWN, POINTER_DOWN, MOVE, POINTER_UP, UP.

Slot map (pool of 4): auto-touch, macros and triggers take free slots from the top (3, 2, 1, 0); the keyboard mapper
keeps slot 0 for its joystick and takes key slots from 1 upward. Every grab checks `isDown`, so they never write the same finger.

### Engine B: accessibility fallback
* Instant taps (hold 20 ms or less) go out as 8 ms strokes; longer holds keep their length.
* A finger that must stay down is a chain of 60 ms `willContinue` strokes, each `continueStroke` of the previous.
* All open holds and every tap that arrived meanwhile are packed into one gesture (strokes of one gesture are simultaneous fingers).
* Selection is automatic (Shizuku first), per call: if engine A fails, that call is retried on engine B unless the user chose "Shizuku only".

## What each trigger mode really does
* Continuous: `app.autoTouch.load(script)`, then `startContinuous()`. Loops enabled nodes in order (tap or swipe), per-node timing override,
  stop at Infinite / N cycles / timer. The script is re-read every cycle, so edits apply live. 5 failed touches in a row stop it with a reason.
* Hold-to-Rapid-Fire: `holdStart(1)` / `holdStop()`. Hammers node 1 at the script's CPS (1..40) or interval (20..10000 ms) until released.
  Safety stop after 120 s without a release (a lost touch-up event must not leave it firing forever).
* Combo macro: `playMacro(id)`. Replays the recorded events at their recorded timestamps; each recorded finger is its own synthetic finger,
  so combos are truly simultaneous. Re-triggering while it plays is ignored. Fingers are always lifted, even on cancel.

## Limits worth knowing
* "No aim stutter" is the goal of engine A, not something an app can guarantee on every ROM: how a game merges injected and real pointers
  depends on that Android build's InputDispatcher and the game's own touch code.
* Engine B goes through the accessibility framework. On some ROMs a gesture can still interrupt a finger that is already down. That is why engine A is primary.
* The humanizer (random point inside the target circle, random interval jitter) only breaks a perfectly regular pattern. It does not make automation
  undetectable, and many online games forbid auto-tapping.
* Shizuku has to be running and permitted for engine A. After a Shizuku restart the binder reconnects on the next touch.

## Part 2 will use it like this
```kotlin
val app = HyperApp.instance
app.autoTouch.load(app.repository.activeScript(pkg) ?: return)
app.autoTouch.startContinuous()      // returns an error string or null
app.autoTouch.holdStart(1); app.autoTouch.holdStop()
app.autoTouch.playMacro(macroId)
val rec = MacroRecorder(app.touch); rec.begin(w, h); /* feed rec.onTouch(ev) */ val macro = rec.finish("Gloo wall")
app.autoTouch.state                  // StateFlow<AutoTouchState> for the dock
app.touch.status                     // StateFlow<InjectorStatus> for diagnostics
```
