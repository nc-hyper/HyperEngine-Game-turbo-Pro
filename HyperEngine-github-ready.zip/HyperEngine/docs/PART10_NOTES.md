# Part 10 - integration check + automatic restore on game exit

## Audit result (manifest, resources, wiring)
- Every `<activity>`, `<service>`, `<receiver>` in the manifest has a class (16 of 16, including `core.ProjectionRequestActivity` / `core.ProjectionService`).
- Every permission used in code is declared. The Part 2-9 engines need no new permission, activity or service, so the only manifest change is a comment recording this.
- Every `R.drawable.*` / `R.string.*` reference resolves.
- `GameDetectorAccessibilityService.kt` does not exist in this project. Game detection is `service/GameDetectorService.kt` (the foreground watcher);
  the accessibility service is `service/TouchMacroService.kt` (auto-tapper), kept alive by `AccessibilitySelfHealer`. Part 10 is wired into the watcher.
- Not compiled here: there was no Kotlin toolchain in the review environment. Build with Gradle once and send me the first error, if any.

## What was missing
Parts 2-9 added the engines and their UI, but nothing started or stopped them from the game lifecycle, and crash recovery only covered the older engines.

| File | Change |
|---|---|
| `core/GameSessionGuard.kt` (new) | auto-engage on game start, restore on game exit, benchmark watch, crash recovery |
| `service/GameDetectorService.kt` | calls the guard on game forward / back, every tick, on crash recovery and on `onDestroy` |
| `core/AntutuBenchmarkBooster.kt` | `engagedTargets()` (which apps the running boost was for) |
| `hub/RomLabCard.kt` | "Automatic mode" switches + live status line |
| `AndroidManifest.xml`, `app/build.gradle.kts` | audit note; versionCode 26, 1.7.0-part10 |

## Behaviour
Game comes forward
- `MaxPanelHzEngine.engage(game)` and `HardwareFrameSmoother.engage()`, after the profile engine finished its own step (waits up to 8 s).
- The panel lock is skipped when the profile already sets a refresh rate, an FPS unlock or motion smoothing: the per-game choice wins.
- A lock the user took from the HUD or the Lab card is never taken over, and never released by the guard.
- Switching straight from game A to game B re-locks for B.

Game leaves
- Same delay as the profile engine (profile or global restore delay, default 15 s). Coming back inside it cancels the restore.
- Smoother first, then the panel lock. While a benchmark boost is on the restore waits, and runs when the boost ends from anywhere.

Benchmark boost
- Ends 45 s after the app it was started for was in front and then left, or after 15 min if that app was never opened. The 45 s wait is shown in the card.
- The battery limit (45 C) still ends it by itself, as before.
- Our own app, the keyboard and system UI do not count as leaving, so looking at the Lab card mid-run does not end the boost.
- If the app was never read (no Usage Access and no Shizuku) the watcher cannot see apps, so only the 45 C limit and the manual stop apply.

Watcher stops (task swiped away with "keep running" off, tile, menu)
- Panel lock, smoother and any boost are released immediately.

Crash / reboot
- On the first good reading with no game in front the watcher calls `recoverPending()` on the booster, smoother and panel engine, which undo saved settings, game overrides and shell flags.

## Limits
- The smoother's ADPF session covers this app's threads (HUD, lobby), not the game's. It is a small cost, and can be switched off in the card.
- Releasing needs the same privileges as engaging: without Shizuku / root the shell steps report failure and retry on the next start.
