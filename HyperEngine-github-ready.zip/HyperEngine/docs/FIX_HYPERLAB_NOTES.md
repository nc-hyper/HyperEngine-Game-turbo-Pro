# Fix drop: HyperLab colour filter and HyperBoost render scale

Not compiled or run on a device (no Android SDK where this was written). Please build and test before relying on it.

## Colour filter (HyperLab)

Causes found by reading the code path:

1. `GamingSuiteManager.setGameFilter` only applied the filter when `activeGame == pkg`. `activeGame` is set only by the
   foreground detector, so a game started from the lobby, or before the detector reported it, got "saved, applies when the
   game is in front" and nothing ever applied it. The in-game HUD now passes `live = true`.
2. `OptimizationEngine.clearFilterLocked` fell through to `StepResult("Visual filter", ok = true, "filter off")` when
   SurfaceFlinger refused the game-filter matrix, so the UI reported success while nothing changed. A refusal is now
   reported with the real reason.
3. The compositor drops the matrix on screen off/on and display-mode switches (refresh matching causes these). A keeper in
   `GamingSuiteManager` re-sends it every 6 s while the filter is on (`OptimizationEngine.reassertColorMatrix`).
4. Without Shizuku, or when SurfaceFlinger refuses, night mode and HDR lift are now drawn as an overlay
   (`ColorMath.overlayForGameFilter`). Contrast, vibrance and colourblind assist need the real matrix.

## HyperBoost render scale

1. `cmd game set ... --fps <n>` was sent with the exact cap (for example 144). If the ROM rejects that fps the whole
   command failed and no downscale was applied. `SystemBridgeExecutor.setGameConfig` now retries with the nearest listed
   fps (30/45/60/90/120), then `disable`. The downscale is in every attempt.
2. The state said "active" if any step succeeded (a property write was enough). It now reports `scaleApplied` and
   `scaleMethod`, and reads `cmd game list-configs` back to confirm.
3. New universal route, `core/ResolutionScaler.kt`: `wm size` + `wm density` scaled together, so every game renders fewer
   pixels even when it ignores GameManager. Used automatically when GameManager refuses, or by the new HyperLab switch
   "Use system resolution (every game)". The original size and density are written to disk first, restored on release,
   after a crash (`HyperBoostEngine.recoverPending`, called from `GameDetectorService`), and after a restart.
4. "Restart game to apply the scale" button: GameManager's scale is read when a game starts.

## Files

core/SystemBridgeExecutor.kt, core/ColorMath.kt, core/OptimizationEngine.kt, core/GamingSuiteManager.kt,
core/HyperBoostEngine.kt, core/ResolutionScaler.kt (new), service/GameDetectorService.kt, ui/LabPanel.kt.
No manifest, layout, string or permission changes.

## Limits

- Real DLSS / FSR style upscaling and sharpening is still not possible from an overlay: it would have to capture the
  game's frames, which also captures the overlay itself, costs FPS, and is black for FLAG_SECURE games. The system
  resolution route lowers the render cost; it does not sharpen.
- `wm size` changes the whole screen, so the HUD and other overlays re-layout while it is on.
