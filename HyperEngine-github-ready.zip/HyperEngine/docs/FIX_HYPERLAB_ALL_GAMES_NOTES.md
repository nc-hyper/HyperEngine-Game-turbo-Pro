# Fix drop: HyperLab in every game

Not compiled or run on a device (no Kotlin toolchain / Android SDK where this was written). Build and test before relying on it.
Brace/paren balance of every edited file was checked; type-checking was not.

## Why HyperLab "did not work in all games"

1. **Games were not detected.** `GameDetectorService.isGame` needed an enabled profile or the Game category. Many games never
   declare it, so no HyperLab feature ever started for them. It now also recognises Unity / Unreal / Cocos / Godot / libGDX /
   GameMaker / Defold engine libraries. (Adding the game to the library by hand still works.)
2. **The game was "lost" while still on screen.** Usage-stats `ACTIVITY_PAUSED` cleared the game by package only. Games swap
   activities inside their own package (splash, login, ads); the old activity's PAUSED can arrive after the new one's RESUMED,
   which dropped the game, the HUD and every HyperLab feature. Pause now only clears the activity that is in front.
   The `dumpsys` fallback reads `topResumedActivity` first (the focused one) instead of any resumed line.
3. **Colour filter wiped by the profile engine.** The suite applied the matrix while the engine was applying / restoring in
   parallel; a restore (game switch) removes the matrix, and the keeper then stopped instead of re-applying. The suite now waits
   for the engine to go idle, the in-game HUD's "live" flag always wins over a stale foreground value, and the keeper re-installs
   the filter if the session was restored under it.
4. **Refresh matching used a fake FPS.** When SurfaceFlinger's per-layer latency cannot be read, telemetry falls back to counting
   vsyncs, which is just the panel's own rate. Matching on that is meaningless. It now only runs on a real SurfaceFlinger reading
   and says so otherwise.
5. **Virtual-display upscaler refused most games.** Non-resizable activities cannot run on a secondary display. It now turns on
   `force_resizable_activities` and `enable_non_resizable_multi_window` (tracked, restored on stop) and, when the game's declared
   orientation differs from the screen, rotates the screen to it (tracked, restored) instead of refusing.
6. **Clip buffer recorded the wrong size / failed on some phones.** Capture size was fixed at start, so starting in the portrait
   lobby and playing in landscape gave a tiny letterboxed picture. A size/rotation change now re-opens the encoder on the same
   virtual display and restarts the ring (clips cannot mix sizes). The encoder is opened through the codec's own capability
   limits (alignment, size, bitrate) and steps down 1280 -> 960 -> 720 px if one is refused; previous-frame repeat keeps keyframes
   regular on a still screen.
7. **HyperBoost trusted a GameManager scale the ROM did not hold.** A readback that showed another scale was listed and ignored.
   It now clears the GameManager scale and uses the system-resolution route instead.

## Files
service/GameDetectorService.kt, core/GamingSuiteManager.kt, core/ClipBufferEngine.kt, core/VirtualDisplayUpscaler.kt,
core/HyperBoostEngine.kt. No manifest, permission, layout or string changes.

## Still not possible (Android limits, unchanged)
- Real DLSS / AI upscaling; the upscaler is a bicubic + CAS-style filter.
- Games with FLAG_SECURE record / mirror black.
- Virtual displays usually run at 60 Hz.
- `wm size` (system resolution route) makes some games recreate their window; unsaved state may be lost.
- Games whose engine ignores GameManager only change through the system-resolution route.
