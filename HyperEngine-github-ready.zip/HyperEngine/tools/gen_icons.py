#!/usr/bin/env python3
"""
HyperEngine vector icon generator.

Emits Android <vector> / <animated-vector> XML into res/drawable. All geometry is authored here with
chamfered ("cyberpunk") corners, neon gradients and a faint wide under-stroke that fakes bloom.
Only absolute M/L/C/Q/Z path commands are produced, so the output is trivially portable.

Run:  python3 gen_icons.py <res/drawable output dir> [contact_sheet.png]
"""
import math
import os
import sys

# ----------------------------------------------------------------------------------------------
# geometry
# ----------------------------------------------------------------------------------------------

def fmt(v):
    s = ("%.2f" % v).rstrip("0").rstrip(".")
    return "0" if s in ("-0", "") else s


def pt(cx, cy, r, deg):
    a = math.radians(deg)
    return (cx + r * math.cos(a), cy + r * math.sin(a))


class Path:
    def __init__(self):
        self.p = []

    def M(self, x, y):
        self.p.append("M%s,%s" % (fmt(x), fmt(y)))
        return self

    def L(self, x, y):
        self.p.append("L%s,%s" % (fmt(x), fmt(y)))
        return self

    def C(self, x1, y1, x2, y2, x, y):
        self.p.append("C%s,%s,%s,%s,%s,%s" % tuple(fmt(v) for v in (x1, y1, x2, y2, x, y)))
        return self

    def Q(self, x1, y1, x, y):
        self.p.append("Q%s,%s,%s,%s" % tuple(fmt(v) for v in (x1, y1, x, y)))
        return self

    def Z(self):
        self.p.append("Z")
        return self

    def arc(self, cx, cy, rx, ry, a0, a1, move=True):
        """Elliptical arc as cubic segments; angles in degrees, screen space (clockwise positive)."""
        sweep = a1 - a0
        n = max(1, int(math.ceil(abs(sweep) / 90.0)))
        step = sweep / n
        for i in range(n):
            t0 = math.radians(a0 + step * i)
            t1 = math.radians(a0 + step * (i + 1))
            k = 4.0 / 3.0 * math.tan((t1 - t0) / 4.0)
            x0, y0 = cx + rx * math.cos(t0), cy + ry * math.sin(t0)
            x3, y3 = cx + rx * math.cos(t1), cy + ry * math.sin(t1)
            x1, y1 = x0 - k * rx * math.sin(t0), y0 + k * ry * math.cos(t0)
            x2, y2 = x3 + k * rx * math.sin(t1), y3 - k * ry * math.cos(t1)
            if i == 0 and move:
                self.M(x0, y0)
            self.C(x1, y1, x2, y2, x3, y3)
        return self

    def __str__(self):
        return "".join(self.p)


def poly(pts, close=True):
    p = Path()
    for i, (x, y) in enumerate(pts):
        (p.M if i == 0 else p.L)(x, y)
    if close:
        p.Z()
    return str(p)


def line(x1, y1, x2, y2):
    return str(Path().M(x1, y1).L(x2, y2))


def lines(*segs):
    p = Path()
    for s in segs:
        p.M(s[0], s[1]).L(s[2], s[3])
    return str(p)


def circle(cx, cy, r):
    return str(Path().arc(cx, cy, r, r, 0, 360))


def ellipse(cx, cy, rx, ry):
    return str(Path().arc(cx, cy, rx, ry, 0, 360))


def arc_path(cx, cy, r, a0, a1):
    return str(Path().arc(cx, cy, r, r, a0, a1))


def chamfer(x, y, w, h, c, c2=None):
    """Rectangle with 45-degree cut corners. c2 = optional different cut for the bottom corners."""
    c2 = c if c2 is None else c2
    pts = [(x + c, y), (x + w - c, y), (x + w, y + c), (x + w, y + h - c2), (x + w - c2, y + h),
           (x + c2, y + h), (x, y + h - c2), (x, y + c)]
    return poly(pts)


def regular(cx, cy, r, n, rot=0.0):
    return poly([pt(cx, cy, r, rot + 360.0 * i / n) for i in range(n)])


def diamond(cx, cy, r):
    return poly([(cx, cy - r), (cx + r, cy), (cx, cy + r), (cx - r, cy)])


def rect(x, y, w, h):
    return poly([(x, y), (x + w, y), (x + w, y + h), (x, y + h)])


# ----------------------------------------------------------------------------------------------
# colour system
# ----------------------------------------------------------------------------------------------

def grad(x1, y1, x2, y2, *stops):
    n = len(stops)
    st = [(i / float(n - 1) if not isinstance(s, tuple) else s[0], s if not isinstance(s, tuple) else s[1])
          for i, s in enumerate(stops)]
    return {"x1": x1, "y1": y1, "x2": x2, "y2": y2, "stops": st}


CYAN, BLUE, VIOLET, MAGENTA = "#FF00E5FF", "#FF2979FF", "#FF7C4DFF", "#FFFF2BD6"
YELLOW, ORANGE, RED, WHITE = "#FFFFEA00", "#FFFF6D00", "#FFFF1744", "#FFFFFFFF"
LIME, INK = "#FFB2FF59", "#FF0B121A"

COOL = grad(6, 6, 42, 42, CYAN, VIOLET)
COOL_V = grad(24, 4, 24, 44, CYAN, BLUE)
HOT = grad(8, 40, 40, 8, YELLOW, ORANGE, RED)
HOT_V = grad(24, 6, 24, 42, YELLOW, ORANGE, RED)
MIX = grad(6, 6, 42, 42, CYAN, MAGENTA)
ECO = grad(6, 40, 42, 8, LIME, CYAN)
REDDOT = grad(24, 10, 24, 38, "#FFFF5252", RED)
RGBG = grad(24, 4, 24, 44, "#FFFF1744", "#FFFFEA00", "#FF00E676", "#FF00E5FF", "#FF2979FF", "#FFD500F9")


def E(d, fill=None, stroke=None, sw=0.0, cap=None, join=None, fa=None, sa=None, name=None, ft=None, ml=None):
    return {"k": "path", "d": d, "fill": fill, "stroke": stroke, "sw": sw, "cap": cap, "join": join,
            "fa": fa, "sa": sa, "name": name, "ft": ft, "ml": ml}


def G(children, name=None, pivot=None, tf=None):
    return {"k": "group", "children": children, "name": name, "pivot": pivot, "tf": tf}


def neon(d, g=COOL, sw=2.2, cap="square", join="miter", name=None, glow=True, glow_name=None, sa=None, gm=3.0):
    out = []
    if glow:
        out.append(E(d, stroke=g, sw=sw * gm, cap="round", join="round", sa=0.16, name=glow_name))
    out.append(E(d, stroke=g, sw=sw, cap=cap, join=join, name=name, sa=sa))
    return out


def solid(d, g=HOT, fa=None, name=None, ft=None):
    return E(d, fill=g, fa=fa, name=name, ft=ft)


# ----------------------------------------------------------------------------------------------
# feature icons (viewport 48 x 48)
# ----------------------------------------------------------------------------------------------

def blade_pts(cx, cy, a, r0=4.5, r1=15.5, w=26, shear=10):
    return [pt(cx, cy, r0, a), pt(cx, cy, r1, a + shear), pt(cx, cy, r1, a + shear + w), pt(cx, cy, r0, a + w)]


def turbine_blades(cx=24, cy=24, n=6, r0=4.5, r1=15.5, w=24, shear=12):
    out = []
    for i in range(n):
        a = i * 360.0 / n
        pts = blade_pts(cx, cy, a, r0, r1, w, shear)
        out.append(E(poly(pts), fill=HOT_V, fa=0.95))
        out.append(E(poly(pts), stroke=grad(8, 8, 40, 40, YELLOW, RED), sw=0.8, join="miter"))
    return out


def ic_wild_boost_turbine():
    els = []
    els += neon(regular(24, 24, 20.5, 8, 22.5), COOL, 2.0)
    els.append(E(circle(24, 24, 17), stroke=COOL, sw=0.9, sa=0.45))
    # tick marks on the ring
    ticks = Path()
    for i in range(8):
        a = i * 45.0
        p0, p1 = pt(24, 24, 17, a), pt(24, 24, 14.6, a)
        ticks.M(*p0).L(*p1)
    els.append(E(str(ticks), stroke=CYAN, sw=1.2, sa=0.7))
    els.append(G(turbine_blades(), name="rotor", pivot=(24, 24)))
    els.append(E(circle(24, 24, 3.6), fill=grad(20, 20, 28, 28, WHITE, CYAN)))
    els.append(E(circle(24, 24, 1.4), fill=INK))
    return els


def ic_qs_wild_boost():
    """Quick Settings tile: single flat colour. The system tints it, only the alpha channel matters."""
    els = []
    els.append(E(regular(24, 24, 20.5, 8, 22.5), stroke=WHITE, sw=2.4, join="miter"))
    for i in range(6):
        a = i * 60.0
        els.append(E(poly(blade_pts(24, 24, a, 4.5, 15.0, 24, 12)), fill=WHITE))
    els.append(E(circle(24, 24, 3.4), fill=WHITE))
    return els


def ic_fan_blades():
    els = []
    n = 5
    for i in range(n):
        a = i * 360.0 / n
        p = Path()
        p.M(*pt(24, 24, 4.0, a))
        p.C(*pt(24, 24, 11, a - 30), *pt(24, 24, 22, a - 20), *pt(24, 24, 20.5, a + 10))
        p.C(*pt(24, 24, 18, a + 22), *pt(24, 24, 9, a + 30), *pt(24, 24, 4.0, a + 22))
        p.Z()
        els.append(E(str(p), fill=COOL, fa=0.92))
        els.append(E(str(p), stroke=grad(6, 6, 42, 42, WHITE, CYAN), sw=0.7, join="miter"))
    g = [G(els, name="rotor", pivot=(24, 24))]
    g.append(E(circle(24, 24, 4.2), fill=grad(20, 20, 28, 28, WHITE, CYAN)))
    g.append(E(circle(24, 24, 1.6), fill=INK))
    return g


def ic_hyperboost_scale():
    els = []
    els += neon(chamfer(6, 6, 36, 36, 7), COOL, 2.0)
    # low-res pixel blocks (what the GPU really renders)
    for (x, y, a) in ((11, 28, 0.9), (16.5, 28, 0.45), (11, 33.5, 0.45), (16.5, 33.5, 0.9)):
        els.append(E(rect(x, y, 4.5, 4.5), fill=CYAN, fa=a))
    # upscaling trace
    arrow = Path().M(22, 26).L(33, 15)
    head = Path().M(26.5, 14.5).L(33.5, 14.5).L(33.5, 21.5)
    els.append(E(str(arrow), stroke=HOT, sw=2.4, cap="square", join="miter", name="trace"))
    els.append(E(str(head), stroke=HOT, sw=2.4, cap="square", join="miter"))
    # AI sparkle
    sp = Path().M(33.5, 27.5).Q(33.5, 33, 39, 33).Q(33.5, 33, 33.5, 38.5).Q(33.5, 33, 28, 33).Q(33.5, 33, 33.5, 27.5).Z()
    els.append(E(str(sp), fill=grad(28, 27, 39, 39, WHITE, CYAN)))
    return els


def ic_low_latency():
    els = []
    els += neon(regular(24, 24, 20, 8, 22.5), COOL, 2.0, glow_name="glow")
    t = Path()
    for a in (0, 90, 180, 270):
        t.M(*pt(24, 24, 20, a)).L(*pt(24, 24, 15.5, a))
    els.append(E(str(t), stroke=CYAN, sw=2.0, cap="square"))
    bolt = [(28, 8.5), (15, 26), (22.5, 26), (20, 39.5), (34, 20.5), (26, 20.5), (30.5, 8.5)]
    els.append(E(poly(bolt), fill=HOT_V))
    els.append(E(poly(bolt), stroke=grad(10, 10, 38, 38, WHITE, YELLOW), sw=0.9, join="miter"))
    return els


def ic_clip_buffer():
    els = []
    a0, a1 = -52.0, -318.0
    els += neon(arc_path(24, 25, 16.5, a0, a1), COOL, 2.4, cap="butt")
    tip = pt(24, 25, 16.5, a1 - 15)
    b_in, b_out = pt(24, 25, 12.0, a1), pt(24, 25, 21.0, a1)
    els.append(E(poly([tip, b_in, b_out]), fill=CYAN))
    els.append(E(poly([(20, 17.5), (20, 32.5), (32, 25)]), fill=grad(20, 17, 32, 33, WHITE, CYAN)))
    els.append(E(circle(38.5, 9.5, 3.4), fill=REDDOT, name="rec_dot"))
    els.append(E(circle(38.5, 9.5, 5.6), stroke=RED, sw=0.9, sa=0.5))
    return els


def ic_game_filters():
    els = []
    rows = ((13, 31), (24, 15), (35, 26))
    for (y, kx) in rows:
        els += neon(line(7, y, 41, y), COOL, 1.8, glow=False, sa=0.55)
        els.append(E(line(7, y, kx, y), stroke=CYAN, sw=2.2, cap="square"))
        els.append(E(diamond(kx, y, 4.6), fill=HOT_V))
        els.append(E(diamond(kx, y, 4.6), stroke=WHITE, sw=0.9, join="miter", sa=0.9))
    els += neon(chamfer(4, 4, 40, 40, 6), COOL, 1.2, glow=False, sa=0.35)
    return els


def ic_autotouch_target():
    els = []
    els += neon(circle(22, 22, 13.5), COOL, 2.0)
    els.append(E(circle(22, 22, 7), stroke=CYAN, sw=1.2, sa=0.55))
    t = lines((22, 3, 22, 8.5), (22, 35.5, 22, 41), (3, 22, 8.5, 22), (35.5, 22, 41, 22))
    els.append(E(t, stroke=CYAN, sw=2.0, cap="square"))
    els.append(E(circle(22, 22, 2.2), fill=HOT_V))
    cur = [(26, 25), (26, 43), (31, 38), (35, 46), (38.5, 44.3), (34.5, 36.5), (41.5, 36)]
    els.append(E(poly(cur), fill=grad(26, 25, 42, 46, WHITE, CYAN), ))
    els.append(E(poly(cur), stroke=INK, sw=1.3, join="miter"))
    return els


def ic_macro_record():
    els = []
    els += neon(circle(24, 20, 15), COOL, 2.0)
    els.append(E(circle(24, 20, 7), fill=REDDOT))
    els.append(E(circle(24, 20, 10.5), stroke=RED, sw=1.0, sa=0.55))
    els.append(E(line(7, 42, 41, 42), stroke=CYAN, sw=1.4, sa=0.55, cap="butt"))
    els.append(E(rect(6, 39.5, 5, 5), fill=HOT))
    els.append(E(rect(21.5, 39.5, 5, 5), stroke=CYAN, sw=1.4))
    els.append(E(rect(37, 39.5, 5, 5), stroke=CYAN, sw=1.4))
    return els


def ic_voice_changer_mic():
    els = []
    cap = [(19, 10), (22, 6), (26, 6), (29, 10), (29, 22), (26, 26), (22, 26), (19, 22)]
    els.append(E(poly(cap), fill=COOL, fa=0.22))
    els += neon(poly(cap), COOL, 2.2)
    els.append(E(lines((22, 12, 26, 12), (22, 16, 26, 16), (22, 20, 26, 20)), stroke=CYAN, sw=1.2, sa=0.7))
    els += neon(arc_path(24, 22, 10.5, 180, 0), COOL, 2.0, cap="square", glow=False)
    els.append(E(lines((24, 32.5, 24, 40), (17, 40, 31, 40)), stroke=CYAN, sw=2.2, cap="square"))
    for (x, h) in ((7, 4), (11, 8), (37, 8), (41, 4)):
        els.append(E(line(x, 20 - h, x, 20 + h), stroke=HOT_V, sw=2.2, cap="square"))
    return els


def ic_shoulder_triggers():
    els = []
    body = [(6, 27), (11, 20.5), (37, 20.5), (42, 27), (43, 41), (37, 41), (31, 34), (17, 34), (11, 41), (5, 41)]
    els += neon(poly(body), COOL, 2.0)
    els.append(E(poly([(9, 12.5), (20, 12.5), (20, 17.5), (9, 19)]), fill=COOL, fa=0.55))
    els.append(E(poly([(39, 12.5), (28, 12.5), (28, 17.5), (39, 19)]), fill=COOL, fa=0.55))
    els += neon(poly([(9, 12.5), (20, 12.5), (20, 17.5), (9, 19)]), COOL, 1.4, glow=False)
    els += neon(poly([(39, 12.5), (28, 12.5), (28, 17.5), (39, 19)]), COOL, 1.4, glow=False)
    els.append(E(poly([(10, 5), (17, 5), (18, 10), (10, 10)]), fill=HOT_V))
    els.append(E(poly([(38, 5), (31, 5), (30, 10), (38, 10)]), fill=HOT_V))
    els.append(E(lines((14, 24.5, 14, 30.5), (11, 27.5, 17, 27.5)), stroke=CYAN, sw=2.0, cap="square"))
    for (x, y) in ((34, 24.5), (34, 30.5), (31, 27.5), (37, 27.5)):
        els.append(E(diamond(x, y, 1.7), fill=HOT_V))
    return els


def ic_4d_haptic_shock():
    els = []
    els += neon(chamfer(16, 7, 16, 34, 3.5), COOL, 2.2)
    els.append(E(line(21.5, 10.5, 26.5, 10.5), stroke=CYAN, sw=1.4, sa=0.7))
    els.append(E(poly([(25.5, 17), (20, 25.5), (24, 25.5), (22.5, 33), (28.5, 23.5), (24.5, 23.5), (27, 17)]), fill=HOT_V))
    for r, g, w in ((12.5, CYAN, 2.2), (18.5, HOT_V, 2.2)):
        dash = Path()
        dash.arc(24, 24, r, r, 150, 210)
        dash.arc(24, 24, r, r, -30, 30)
        els.append(E(str(dash), stroke=g if r < 15 else HOT, sw=w, cap="square", sa=1.0 if r < 15 else 0.85))
    els.append(E(arc_path(24, 24, 23.5, 160, 200), stroke=HOT, sw=1.8, cap="square", sa=0.45))
    els.append(E(arc_path(24, 24, 23.5, -20, 20), stroke=HOT, sw=1.8, cap="square", sa=0.45))
    return els


def ic_scout_sniper_zoom():
    els = []
    els += neon(circle(24, 24, 16.5), COOL, 2.0)
    els.append(E(lines((3, 24, 17, 24), (31, 24, 45, 24), (24, 3, 24, 17), (24, 31, 24, 45)), stroke=CYAN, sw=1.8, cap="butt"))
    els.append(E(lines((24, 18, 24, 20.5), (24, 27.5, 24, 30), (18, 24, 20.5, 24), (27.5, 24, 30, 24)), stroke=CYAN, sw=1.4, sa=0.6))
    for d in (6.5, 10.5):
        for (dx, dy) in ((d, 0), (-d, 0), (0, d), (0, -d)):
            els.append(E(diamond(24 + dx, 24 + dy, 0.9), fill=CYAN))
    els.append(E(diamond(24, 24, 2.8), fill=HOT_V))
    els.append(E(poly([(35, 8), (41, 8), (41, 14)], close=False), stroke=HOT, sw=2.0, cap="square", join="miter"))
    els.append(E(poly([(13, 40), (7, 40), (7, 34)], close=False), stroke=HOT, sw=2.0, cap="square", join="miter"))
    return els


def ic_crosshair_reticle():
    els = []
    seg = lines((24, 3.5, 24, 14.5), (24, 33.5, 24, 44.5), (3.5, 24, 14.5, 24), (33.5, 24, 44.5, 24))
    els += neon(seg, COOL, 2.4, glow=True)
    els.append(E(circle(24, 24, 12.5), stroke=CYAN, sw=1.0, sa=0.4))
    els.append(E(diamond(24, 24, 4.4), stroke=HOT, sw=1.8, join="miter"))
    els.append(E(diamond(24, 24, 1.6), fill=HOT_V))
    els.append(E(lines((24, 7.5, 24, 10.5)), stroke=HOT, sw=1.0))
    return els


def ic_floating_window():
    els = []
    back = poly([(16, 30), (6, 30), (6, 12), (10, 8), (32, 8), (32, 20)], close=False)
    els += neon(back, COOL, 1.8, glow=False, sa=0.6)
    front = chamfer(16, 20, 26, 22, 4, 0)
    els.append(E(front, fill=COOL, fa=0.18))
    els += neon(front, COOL, 2.2)
    els.append(E(line(16, 27.5, 42, 27.5), stroke=CYAN, sw=1.4, sa=0.7))
    for x in (20, 25, 30):
        els.append(E(rect(x, 22.5, 2.6, 2.6), fill=HOT))
    els.append(E(poly([(33, 38), (38, 38), (38, 33)], close=False), stroke=HOT, sw=2.0, cap="square", join="miter"))
    return els


def ic_handsfree_call():
    els = []
    handset = Path().M(13, 13).C(13, 29, 19, 35, 35, 35)
    els += neon(str(handset), COOL, 4.4, cap="butt", join="miter", glow=True, gm=1.7)
    els.append(E(lines((8.5, 12, 19, 12), (35.5, 29.5, 35.5, 41)), stroke=CYAN, sw=4.4, cap="butt"))
    for r in (7, 12.5, 18):
        els.append(E(arc_path(26, 22, r, -88, -2), stroke=HOT, sw=2.0, cap="butt", sa=1.0 if r < 15 else 0.65))
    return els


def ic_screen_record():
    els = []
    els += neon(chamfer(5, 8, 38, 27, 5), COOL, 2.2)
    els.append(E(circle(24, 21.5, 5.2), fill=REDDOT, name="rec_dot"))
    els.append(E(circle(24, 21.5, 8.6), stroke=RED, sw=1.0, sa=0.5))
    els.append(E(lines((24, 35, 24, 40), (15, 40.5, 33, 40.5)), stroke=CYAN, sw=2.2, cap="square"))
    els.append(E(poly([(9, 15), (9, 12), (12, 12)], close=False), stroke=HOT, sw=1.4, cap="square", join="miter"))
    els.append(E(poly([(39, 28), (39, 31), (36, 31)], close=False), stroke=HOT, sw=1.4, cap="square", join="miter"))
    return els


def ic_screenshot_capture():
    els = []
    br = Path()
    for (cx, cy, sx, sy) in ((5, 5, 1, 1), (43, 5, -1, 1), (5, 43, 1, -1), (43, 43, -1, -1)):
        br.M(cx + sx * 11, cy).L(cx, cy).L(cx, cy + sy * 11)
    els += neon(str(br), COOL, 2.4, cap="square", join="miter")
    els.append(E(regular(24, 24, 9, 8, 22.5), stroke=CYAN, sw=1.6, join="miter"))
    els.append(E(diamond(24, 24, 4.2), fill=HOT_V))
    els.append(E(lines((24, 12, 24, 15), (24, 33, 24, 36), (12, 24, 15, 24), (33, 24, 36, 24)), stroke=HOT, sw=1.2, sa=0.8))
    return els


def ic_wireless_cast():
    els = []
    scr = poly([(6, 17), (6, 11), (10, 7), (42, 7), (42, 37), (26, 37)], close=False)
    els += neon(scr, COOL, 2.2)
    for r, a in ((6.5, 1.0), (13, 0.85), (19.5, 0.65)):
        els.append(E(arc_path(7, 38, r, -90, 0), stroke=HOT, sw=2.2, cap="butt", sa=a))
    els.append(E(diamond(7.5, 37.5, 2.4), fill=HOT_V))
    els.append(E(poly([(34, 14), (34, 20), (28, 20)], close=False), stroke=CYAN, sw=1.4, sa=0.6))
    return els


def ic_battery_saver_leaf():
    els = []
    els += neon(chamfer(4, 12, 36, 24, 4), COOL, 2.0)
    els.append(E(rect(41, 20, 3.4, 8), fill=CYAN))
    leaf = Path().M(10.5, 30).C(10.5, 20, 18, 16.5, 33.5, 17).C(34, 28, 26, 31.5, 10.5, 30).Z()
    els.append(E(str(leaf), fill=ECO))
    els.append(E(lines((11.5, 29.5, 27, 21.5)), stroke=INK, sw=1.2, cap="butt"))
    return els


def ic_charge_separation():
    els = []
    left = poly([(24, 13), (8, 13), (4, 17), (4, 31), (8, 35), (20, 35)])
    right = poly([(31, 13), (40, 13), (44, 17), (44, 31), (40, 35), (27, 35)])
    els += neon(left, COOL, 2.0)
    els += neon(right, COOL, 2.0)
    els.append(E(poly([(28, 16), (22.5, 25), (26.5, 25), (24.5, 32.5), (30.5, 23), (26.5, 23), (29.5, 16)]), fill=HOT_V))
    els.append(E(lines((10, 24, 14, 24)), stroke=CYAN, sw=2.0, cap="square", sa=0.7))
    els.append(E(lines((36, 24, 40, 24)), stroke=CYAN, sw=2.0, cap="square", sa=0.7))
    return els


def ic_rgb_edge_light():
    els = []
    body = chamfer(14, 5, 20, 38, 4)
    els += neon(body, RGBG, 2.4)
    els.append(E(line(21, 9, 27, 9), stroke=CYAN, sw=1.4, sa=0.6))
    for y, c in ((14, "#FFFF1744"), (24, "#FF00E676"), (34, "#FF2979FF")):
        els.append(E(lines((7, y, 10.5, y), (37.5, y, 41, y)), stroke=c, sw=2.4, cap="square"))
        els.append(E(lines((4, y, 5, y), (43, y, 44, y)), stroke=c, sw=2.4, cap="square", sa=0.5))
    return els


def ic_dns_network():
    els = []
    els.append(E(circle(24, 25, 19), stroke=CYAN, sw=1.0, sa=0.35))
    nodes = [pt(24, 25, 19, -90), pt(24, 25, 19, 30), pt(24, 25, 19, 150)]
    for n in nodes:
        els.append(E(line(24, 25, n[0], n[1]), stroke=CYAN, sw=1.6, sa=0.7))
    els += neon(regular(24, 25, 7, 6, 0), COOL, 2.0)
    els.append(E(diamond(24, 25, 2.3), fill=HOT_V))
    for n in nodes:
        els.append(E(rect(n[0] - 3.2, n[1] - 3.2, 6.4, 6.4), fill=HOT_V))
        els.append(E(rect(n[0] - 3.2, n[1] - 3.2, 6.4, 6.4), stroke=INK, sw=1.0, join="miter"))
    return els


def ic_timer_cooldown():
    els = []
    els.append(E(circle(24, 27, 16), stroke=CYAN, sw=2.2, sa=0.28))
    els += neon(arc_path(24, 27, 16, -90, 170), HOT, 2.8, cap="butt")
    ticks = Path()
    for a in range(0, 360, 30):
        ticks.M(*pt(24, 27, 12.6, a)).L(*pt(24, 27, 10.8, a))
    els.append(E(str(ticks), stroke=CYAN, sw=1.1, sa=0.6))
    els.append(E(lines((24, 27, 24, 17.5)), stroke=WHITE, sw=2.2, cap="square"))
    els.append(E(diamond(24, 27, 2.2), fill=HOT_V))
    els.append(E(lines((19, 5.5, 29, 5.5), (24, 5.5, 24, 10.5)), stroke=CYAN, sw=2.2, cap="square"))
    els.append(E(line(36.5, 14, 39.5, 11), stroke=CYAN, sw=2.2, cap="square"))
    return els


def ic_afk_lock():
    els = []
    body = chamfer(11, 22, 26, 20, 3.5)
    els.append(E(body, fill=COOL, fa=0.18))
    els += neon(body, COOL, 2.2)
    sh = Path().M(17, 22).L(17, 16).C(17, 7, 31, 7, 31, 16).L(31, 22)
    els += neon(str(sh), COOL, 2.2, cap="butt", join="miter", glow=False)
    els.append(E(circle(24, 30.5, 2.8), fill=HOT_V))
    els.append(E(poly([(22.7, 31), (25.3, 31), (26, 37), (22, 37)]), fill=HOT_V))
    els.append(E(poly([(35, 4.5), (42, 4.5), (35, 11.5), (42, 11.5)], close=False), stroke=CYAN, sw=1.8, cap="square", join="miter"))
    els.append(E(poly([(41.5, 14.5), (45, 14.5), (41.5, 18), (45, 18)], close=False), stroke=CYAN, sw=1.3, cap="square", join="miter", sa=0.65))
    return els


def ic_sound_radar():
    els = []
    for r, a in ((19, 1.0), (12.7, 0.6), (6.4, 0.5)):
        els.append(E(circle(24, 24, r), stroke=CYAN, sw=1.2 if r < 19 else 2.0, sa=a))
    els.append(E(lines((24, 3, 24, 45), (3, 24, 45, 24)), stroke=CYAN, sw=0.9, sa=0.3))
    wedge = Path().M(24, 24).L(*pt(24, 24, 19, -90)).arc(24, 24, 19, 19, -90, -35, move=False).Z()
    sweep = [E(str(wedge), fill=grad(24, 24, 36, 8, "#00FF6D00", "#CCFF6D00")),
             E(line(24, 24, 24, 5), stroke=HOT, sw=2.2, cap="butt")]
    els.append(G(sweep, name="sweep", pivot=(24, 24)))
    els.append(E(rect(31, 12, 4, 4), fill=HOT_V))
    els.append(E(rect(13, 32, 3.4, 3.4), fill=HOT_V, fa=0.7))
    els.append(E(diamond(24, 24, 2.2), fill=WHITE))
    return els


# ----------------------------------------------------------------------------------------------
# Part 5: performance-lab icons (HUD Hz badge, stability meter, AnTuTu / Max Hardware Boost, ROM lab)
# ----------------------------------------------------------------------------------------------

def ic_refresh_rate_hz():
    els = []
    els += neon(chamfer(5, 8, 38, 27, 5), COOL, 2.0, glow_name="glow")
    els.append(E(lines((24, 35, 24, 40), (15, 41, 33, 41)), stroke=CYAN, sw=2.0, cap="square"))
    grid = lines((10, 29.5, 38, 29.5), (10, 14.5, 38, 14.5))
    els.append(E(grid, stroke=CYAN, sw=0.7, sa=0.28))
    wave = Path().M(10, 22).L(16, 22).L(19.5, 14).L(24.5, 30).L(28.5, 17).L(31.5, 22).L(38, 22)
    els.append(E(str(wave), stroke=HOT, sw=2.4, cap="square", join="miter", name="wave"))
    return els


def ic_frame_pacing():
    els = []
    els += neon(chamfer(4, 6, 40, 36, 6), COOL, 1.8)
    heights = (17, 18, 17, 17, 18, 17)
    for i, h in enumerate(heights):
        x = 9 + i * 5.6
        els.append(E(rect(x, 36 - h, 3.6, h), fill=ECO, fa=0.95))
    # the one slow frame that defines the "1% low"
    els.append(E(rect(9 + 3 * 5.6, 36 - 9, 3.6, 9), fill=REDDOT))
    els.append(E(line(8, 16.5, 40, 16.5), stroke=HOT, sw=1.4, cap="butt", sa=0.9))
    els.append(E(diamond(40, 16.5, 2.2), fill=HOT_V))
    return els


def ic_antutu_benchmark():
    els = []
    els += neon(arc_path(24, 27, 18, 150, 390), COOL, 2.4, cap="butt")
    ticks = Path()
    for i in range(9):
        a = 150 + i * 30.0
        ticks.M(*pt(24, 27, 14.6, a)).L(*pt(24, 27, 12.2 if i % 2 == 0 else 13.2, a))
    els.append(E(str(ticks), stroke=CYAN, sw=1.2, cap="butt", sa=0.8))
    hot_arc = arc_path(24, 27, 18, 330, 390)
    els.append(E(hot_arc, stroke=HOT, sw=2.4, cap="butt"))
    tip = pt(24, 27, 14.5, -48)
    needle = [E(line(24, 27, tip[0], tip[1]), stroke=HOT, sw=2.6, cap="square")]
    els.append(G(needle, name="needle", pivot=(24, 27)))
    els.append(E(diamond(24, 27, 3.2), fill=WHITE))
    # score plate
    els.append(E(chamfer(15, 36.5, 18, 6, 2), stroke=CYAN, sw=1.3, sa=0.9))
    els.append(E(rect(18, 38.8, 7, 1.6), fill=CYAN, fa=0.9))
    return els


def ic_max_hardware_boost():
    els = []
    els += neon(chamfer(11, 11, 26, 26, 5), COOL, 2.0, glow_name="glow")
    pins = Path()
    for v in (17, 24, 31):
        pins.M(v, 4.5).L(v, 11).M(v, 37).L(v, 43.5).M(4.5, v).L(11, v).M(37, v).L(43.5, v)
    els.append(E(str(pins), stroke=CYAN, sw=2.0, cap="square"))
    bolt = [(26.5, 14), (17, 25.5), (22.5, 25.5), (20.5, 34), (31, 22), (25, 22), (28.5, 14)]
    els.append(E(poly(bolt), fill=HOT_V))
    els.append(E(poly(bolt), stroke=grad(14, 14, 32, 34, WHITE, YELLOW), sw=0.8, join="miter"))
    return els


def ic_aot_compile():
    els = []
    els += neon(str(Path().M(17, 12).L(6, 24).L(17, 36)), COOL, 2.6, cap="square", join="miter")
    els += neon(str(Path().M(31, 12).L(42, 24).L(31, 36)), COOL, 2.6, cap="square", join="miter")
    els.append(E(line(27, 8, 21, 40), stroke=HOT, sw=2.8, cap="square", name="slash"))
    sp = Path().M(37, 4).Q(37, 8, 41, 8).Q(37, 8, 37, 12).Q(37, 8, 33, 8).Q(37, 8, 37, 4).Z()
    els.append(E(str(sp), fill=grad(33, 4, 41, 12, WHITE, CYAN)))
    return els


def ic_thermal_shield():
    els = []
    shield = Path().M(24, 4.5).L(39.5, 10.5).L(39.5, 24).Q(39.5, 36.5, 24, 43.5).Q(8.5, 36.5, 8.5, 24).L(8.5, 10.5).Z()
    els += neon(str(shield), COOL, 2.0, join="miter", glow_name="glow")
    els.append(E(line(24, 14, 24, 28), stroke=ECO, sw=4.2, cap="round"))
    els.append(E(circle(24, 31, 5.0), fill=ECO))
    els.append(E(circle(24, 31, 2.0), fill=WHITE, fa=0.9))
    els.append(E(lines((29.5, 16, 33, 16), (29.5, 21, 32, 21), (29.5, 26, 33, 26)), stroke=CYAN, sw=1.3, cap="butt", sa=0.85))
    return els


def ic_storage_trim():
    els = []
    for i, y in enumerate((6, 17, 28)):
        els += neon(chamfer(5, y, 30, 8.5, 2.5), COOL, 1.7, glow=False)
        els.append(E(rect(9, y + 3, 2.6, 2.6), fill=LIME))
        els.append(E(line(16, y + 4.25, 30, y + 4.25), stroke=CYAN, sw=1.2, cap="butt", sa=0.7))
    ring = arc_path(36, 37, 7.2, -40, -310)
    els.append(E(ring, stroke=HOT, sw=2.4, cap="butt"))
    els.append(E(poly(pt_tri(36, 37, 7.2, -310)), fill=HOT_V))
    return els


def pt_tri(cx, cy, r, deg):
    """Small arrow head sitting on a circle at [deg], pointing along the (counter-clockwise) travel direction."""
    tip = pt(cx, cy, r, deg - 22)
    a, b = pt(cx, cy, r - 3.4, deg), pt(cx, cy, r + 3.4, deg)
    return [tip, a, b]


def ic_ram_purge():
    els = []
    els += neon(chamfer(4, 10, 40, 20, 3.5), COOL, 2.0, glow=True)
    for x in (8.5, 19.5, 30.5):
        els.append(E(rect(x, 14.5, 9, 7.5), fill=CYAN, fa=0.85))
    pins = Path()
    for i in range(9):
        x = 8 + i * 4.0
        pins.M(x, 30).L(x, 34.5)
    els.append(E(str(pins), stroke=CYAN, sw=1.8, cap="butt"))
    els.append(E(lines((10, 25.5, 38, 25.5)), stroke=CYAN, sw=0.8, sa=0.35))
    els.append(E(str(Path().M(18, 38.5).L(24, 44).L(30, 38.5)), stroke=HOT, sw=2.6, cap="square", join="miter", name="purge"))
    return els


def ic_rom_lab():
    els = []
    flask = Path().M(18.5, 5).L(29.5, 5).L(29.5, 17).L(40.5, 37).Q(43, 43, 36.5, 43).L(11.5, 43).Q(5, 43, 7.5, 37).L(18.5, 17).Z()
    els += neon(str(flask), COOL, 2.0, join="miter")
    els.append(E(line(16, 5, 32, 5), stroke=CYAN, sw=2.2, cap="square"))
    liquid = Path().M(13.2, 30).L(34.8, 30).L(39, 37.8).Q(40.4, 41, 36, 41).L(12, 41).Q(7.6, 41, 9, 37.8).Z()
    els.append(E(str(liquid), fill=HOT_V, fa=0.9))
    els.append(E(circle(20, 35.5, 1.9), fill=WHITE, fa=0.9, name="bubble"))
    els.append(E(circle(27.5, 33.6, 1.4), fill=WHITE, fa=0.7))
    els.append(E(circle(26, 24, 1.6), fill=CYAN, fa=0.8))
    els.append(E(circle(22.5, 18.5, 1.1), fill=CYAN, fa=0.6))
    return els


def u_play():
    return [E(poly([(14, 8), (14, 40), (40, 24)]), fill=WHITE)]


def u_stop():
    return [E(rect(11, 11, 26, 26), fill=WHITE)]


def u_restore():
    p = Path().arc(24, 24, 14, 14, -140, 140)
    head = poly([(18, 4), (8, 14), (21, 16)])
    return [W(str(p), sw=3.4, cap="butt"), E(head, fill=WHITE)]


PART5_ICONS = [
    ("ic_refresh_rate_hz", ic_refresh_rate_hz),
    ("ic_frame_pacing", ic_frame_pacing),
    ("ic_antutu_benchmark", ic_antutu_benchmark),
    ("ic_max_hardware_boost", ic_max_hardware_boost),
    ("ic_aot_compile", ic_aot_compile),
    ("ic_thermal_shield", ic_thermal_shield),
    ("ic_storage_trim", ic_storage_trim),
    ("ic_ram_purge", ic_ram_purge),
    ("ic_rom_lab", ic_rom_lab),
]
PART5_UTILITY = [("ic_play", u_play), ("ic_stop", u_stop), ("ic_restore", u_restore)]


FEATURE_ICONS = [
    ("ic_wild_boost_turbine", ic_wild_boost_turbine),
    ("ic_hyperboost_scale", ic_hyperboost_scale),
    ("ic_low_latency", ic_low_latency),
    ("ic_clip_buffer", ic_clip_buffer),
    ("ic_game_filters", ic_game_filters),
    ("ic_autotouch_target", ic_autotouch_target),
    ("ic_macro_record", ic_macro_record),
    ("ic_voice_changer_mic", ic_voice_changer_mic),
    ("ic_shoulder_triggers", ic_shoulder_triggers),
    ("ic_4d_haptic_shock", ic_4d_haptic_shock),
    ("ic_scout_sniper_zoom", ic_scout_sniper_zoom),
    ("ic_crosshair_reticle", ic_crosshair_reticle),
    ("ic_floating_window", ic_floating_window),
    ("ic_handsfree_call", ic_handsfree_call),
    ("ic_screen_record", ic_screen_record),
    ("ic_screenshot_capture", ic_screenshot_capture),
    ("ic_wireless_cast", ic_wireless_cast),
    ("ic_battery_saver_leaf", ic_battery_saver_leaf),
    ("ic_charge_separation", ic_charge_separation),
    ("ic_rgb_edge_light", ic_rgb_edge_light),
    ("ic_dns_network", ic_dns_network),
    ("ic_timer_cooldown", ic_timer_cooldown),
    ("ic_afk_lock", ic_afk_lock),
    ("ic_sound_radar", ic_sound_radar),
    ("ic_fan_blades", ic_fan_blades),
]

# ----------------------------------------------------------------------------------------------
# utility glyph replacements: flat white strokes so VIcon can tint them with the HUD theme
# ----------------------------------------------------------------------------------------------

def W(d, sw=3.4, cap="square", join="miter", **kw):
    return E(d, stroke=WHITE, sw=sw, cap=cap, join=join, **kw)


def u_plus():
    return [W(lines((24, 9, 24, 39), (9, 24, 39, 24)))]


def u_minus():
    return [W(line(9, 24, 39, 24))]


def u_close():
    return [W(lines((11, 11, 37, 37), (37, 11, 11, 37)))]


def u_chev(a, b, c):
    return [W(poly([a, b, c], close=False), sw=3.6)]


def u_more():
    return [E(diamond(10, 24, 4.2), fill=WHITE), E(diamond(24, 24, 4.2), fill=WHITE), E(diamond(38, 24, 4.2), fill=WHITE)]


def u_check():
    return [W(poly([(9, 25), (19.5, 35.5), (39, 13)], close=False), sw=4.0, name="tick")]


def u_alert():
    return [W(poly([(24, 6), (43, 40), (5, 40)]), sw=3.0), W(line(24, 18, 24, 29), sw=3.4), E(rect(22, 32.5, 4, 4), fill=WHITE)]


def u_dash():
    return [W(line(14, 24, 34, 24), sw=3.4)]


def u_backspace():
    return [W(poly([(18, 10), (42, 10), (42, 38), (18, 38), (5, 24)]), sw=2.8),
            W(lines((24, 18, 34, 30), (34, 18, 24, 30)), sw=2.8)]


def u_divide():
    return [W(line(9, 24, 39, 24)), E(diamond(24, 11.5, 3.4), fill=WHITE), E(diamond(24, 36.5, 3.4), fill=WHITE)]


def u_multiply():
    return [W(lines((12, 12, 36, 36), (36, 12, 12, 36)), sw=3.4)]


def u_refresh():
    p = Path().arc(24, 24, 14, 14, -40, -320)
    head = poly([(30, 4), (40, 14), (27, 16)])
    return [W(str(p), sw=3.4, cap="butt"), E(head, fill=WHITE)]


UTILITY_ICONS = [
    ("ic_plus", u_plus), ("ic_minus", u_minus), ("ic_close", u_close),
    ("ic_chevron_left", lambda: u_chev((29, 9), (14, 24), (29, 39))),
    ("ic_chevron_right", lambda: u_chev((19, 9), (34, 24), (19, 39))),
    ("ic_chevron_up", lambda: u_chev((9, 29), (24, 14), (39, 29))),
    ("ic_chevron_down", lambda: u_chev((9, 19), (24, 34), (39, 19))),
    ("ic_more_dots", u_more), ("ic_check", u_check), ("ic_alert", u_alert), ("ic_dash", u_dash),
    ("ic_backspace", u_backspace), ("ic_op_divide", u_divide), ("ic_op_multiply", u_multiply),
    ("ic_refresh", u_refresh),
]

FEATURE_ICONS += PART5_ICONS
UTILITY_ICONS += PART5_UTILITY

# ----------------------------------------------------------------------------------------------
# XML writer
# ----------------------------------------------------------------------------------------------

NS = ('xmlns:android="http://schemas.android.com/apk/res/android"\n'
      '    xmlns:aapt="http://schemas.android.com/aapt"')


def grad_xml(g, attr, ind):
    pad = "    " * ind
    out = [pad + '<aapt:attr name="android:%s">' % attr,
           pad + '    <gradient',
           pad + '        android:startX="%s" android:startY="%s"' % (fmt(g["x1"]), fmt(g["y1"])),
           pad + '        android:endX="%s" android:endY="%s"' % (fmt(g["x2"]), fmt(g["y2"])),
           pad + '        android:type="linear">']
    for off, col in g["stops"]:
        out.append(pad + '        <item android:offset="%s" android:color="%s" />' % (fmt(off), col))
    out.append(pad + '    </gradient>')
    out.append(pad + '</aapt:attr>')
    return out


def el_xml(e, ind):
    pad = "    " * ind
    if e["k"] == "group":
        a = ""
        if e["name"]:
            a += ' android:name="%s"' % e["name"]
        if e["pivot"]:
            a += ' android:pivotX="%s" android:pivotY="%s"' % (fmt(e["pivot"][0]), fmt(e["pivot"][1]))
        for k in ("translateX", "translateY", "scaleX", "scaleY"):
            if e.get("tf") and k in e["tf"]:
                a += ' android:%s="%s"' % (k, fmt(e["tf"][k]))
        out = [pad + "<group" + a + ">"]
        for c in e["children"]:
            out += el_xml(c, ind + 1)
        out.append(pad + "</group>")
        return out
    attrs = []
    if e["name"]:
        attrs.append('android:name="%s"' % e["name"])
    attrs.append('android:pathData="%s"' % e["d"])
    child = []
    f, s = e["fill"], e["stroke"]
    if isinstance(f, str):
        attrs.append('android:fillColor="%s"' % f)
    elif f:
        child += grad_xml(f, "fillColor", ind + 1)
    if e["fa"] is not None:
        attrs.append('android:fillAlpha="%s"' % fmt(e["fa"]))
    if isinstance(s, str):
        attrs.append('android:strokeColor="%s"' % s)
    elif s:
        child += grad_xml(s, "strokeColor", ind + 1)
    if s:
        attrs.append('android:strokeWidth="%s"' % fmt(e["sw"]))
        if e["sa"] is not None:
            attrs.append('android:strokeAlpha="%s"' % fmt(e["sa"]))
        if e["cap"]:
            attrs.append('android:strokeLineCap="%s"' % e["cap"])
        if e["join"]:
            attrs.append('android:strokeLineJoin="%s"' % e["join"])
            if e["join"] == "miter":
                attrs.append('android:strokeMiterLimit="6"')
    if e["ft"]:
        attrs.append('android:fillType="%s"' % e["ft"])
    if not child:
        return [pad + "<path " + ("\n" + pad + "    ").join(attrs) + " />"]
    return [pad + "<path " + ("\n" + pad + "    ").join(attrs) + ">"] + child + [pad + "</path>"]


def vector_xml(title, els, size_dp=32, vp=48):
    out = ['<?xml version="1.0" encoding="utf-8"?>',
           "<!-- %s. Generated by tools/gen_icons.py; edit the generator, not this file. -->" % title,
           "<vector " + NS,
           '    android:width="%ddp"' % size_dp,
           '    android:height="%ddp"' % size_dp,
           '    android:viewportWidth="%d"' % vp,
           '    android:viewportHeight="%d"' % vp + ">"]
    for e in els:
        out += el_xml(e, 1)
    out.append("</vector>")
    return "\n".join(out) + "\n"



# ----------------------------------------------------------------------------------------------
# adaptive launcher icon (108 x 108 viewport; the visible/safe area is the centre 66-72)
# ----------------------------------------------------------------------------------------------

LTF = {"scaleX": 1.14, "scaleY": 1.14, "translateX": 26.64, "translateY": 26.64}   # 48-grid -> centred 54.7 units


def launcher_background():
    bg = grad(0, 0, 108, 108, "#FF05080D", "#FF14202E", "#FF0A1118")
    els = [E(rect(0, 0, 108, 108), fill=bg)]
    els.append(E(lines((0, 30, 30, 0), (0, 56, 56, 0), (52, 108, 108, 52), (78, 108, 108, 78)),
                 stroke=grad(0, 0, 108, 108, CYAN, VIOLET), sw=0.9, sa=0.35))
    els.append(E(poly([(6, 24), (6, 6), (24, 6)], close=False), stroke=CYAN, sw=1.2, sa=0.55, join="miter", cap="square"))
    els.append(E(poly([(102, 84), (102, 102), (84, 102)], close=False), stroke=ORANGE, sw=1.2, sa=0.55, join="miter", cap="square"))
    return els


def launcher_foreground():
    return [G(ic_wild_boost_turbine(), tf=LTF)]


def launcher_monochrome():
    return [G(ic_qs_wild_boost(), tf=LTF)]


def adaptive_xml(with_mono=True):
    out = ['<?xml version="1.0" encoding="utf-8"?>',
           "<!-- Adaptive launcher icon. Generated by tools/gen_icons.py. -->",
           '<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">',
           '    <background android:drawable="@drawable/ic_launcher_background" />',
           '    <foreground android:drawable="@drawable/ic_launcher_foreground" />']
    if with_mono:
        out.append('    <monochrome android:drawable="@drawable/ic_launcher_monochrome" />')
    out.append("</adaptive-icon>")
    return "\n".join(out) + "\n"

# ----------------------------------------------------------------------------------------------
# animated vector drawables
# ----------------------------------------------------------------------------------------------

def _anim(prop, frm, to, dur, repeat=True, reverse=False, interp="linear", vtype="floatType"):
    a = ['<objectAnimator',
         '    android:propertyName="%s"' % prop,
         '    android:valueFrom="%s"' % frm,
         '    android:valueTo="%s"' % to,
         '    android:valueType="%s"' % vtype,
         '    android:duration="%d"' % dur,
         '    android:interpolator="@android:interpolator/%s"' % interp]
    if repeat:
        a.append('    android:repeatCount="-1"')
    if reverse:
        a.append('    android:repeatMode="reverse"')
    a[-1] += " />"
    return a


def avd_xml(title, drawable, targets):
    out = ['<?xml version="1.0" encoding="utf-8"?>',
           "<!-- %s. Generated by tools/gen_icons.py. -->" % title,
           "<animated-vector " + NS,
           '    android:drawable="@drawable/%s">' % drawable]
    for tname, anims in targets:
        out.append('    <target android:name="%s">' % tname)
        out.append('        <aapt:attr name="android:animation">')
        if len(anims) > 1:
            out.append('            <set android:ordering="together">')
            for an in anims:
                out += ["                " + ln for ln in an]
            out.append("            </set>")
        else:
            out += ["            " + ln for ln in anims[0]]
        out.append("        </aapt:attr>")
        out.append("    </target>")
    out.append("</animated-vector>")
    return "\n".join(out) + "\n"


AVDS = [
    ("avd_wild_boost_turbine_spin", "ic_wild_boost_turbine",
     [("rotor", [_anim("rotation", 0, 360, 700)])]),
    ("avd_fan_blades_spin", "ic_fan_blades",
     [("rotor", [_anim("rotation", 0, 360, 520)])]),
    ("avd_sound_radar_sweep", "ic_sound_radar",
     [("sweep", [_anim("rotation", 0, 360, 2200)])]),
    ("avd_clip_rec_pulse", "ic_clip_buffer",
     [("rec_dot", [_anim("fillAlpha", 1, 0.2, 650, reverse=True, interp="fast_out_slow_in")])]),
    ("avd_screen_record_pulse", "ic_screen_record",
     [("rec_dot", [_anim("fillAlpha", 1, 0.2, 650, reverse=True, interp="fast_out_slow_in")])]),
    ("avd_low_latency_pulse", "ic_low_latency",
     [("glow", [_anim("strokeAlpha", 0.12, 0.7, 520, reverse=True, interp="fast_out_slow_in")])]),
    ("avd_hyperboost_trace", "ic_hyperboost_scale",
     [("trace", [_anim("trimPathEnd", 0, 1, 1100, interp="fast_out_slow_in")])]),
    ("avd_check_draw", "ic_check",
     [("tick", [_anim("trimPathEnd", 0, 1, 360, repeat=False, interp="fast_out_slow_in")])]),
    ("avd_refresh_rate_wave", "ic_refresh_rate_hz",
     [("wave", [_anim("trimPathEnd", 0, 1, 1100, interp="fast_out_slow_in")]),
      ("glow", [_anim("strokeAlpha", 0.12, 0.6, 1100, reverse=True, interp="fast_out_slow_in")])]),
    ("avd_max_boost_charge", "ic_max_hardware_boost",
     [("glow", [_anim("strokeAlpha", 0.12, 0.75, 480, reverse=True, interp="fast_out_slow_in")])]),
    ("avd_antutu_needle_sweep", "ic_antutu_benchmark",
     [("needle", [_anim("rotation", -62, 22, 900, reverse=True, interp="fast_out_slow_in")])]),
    ("avd_aot_compile_slash", "ic_aot_compile",
     [("slash", [_anim("strokeAlpha", 0.25, 1, 560, reverse=True, interp="fast_out_slow_in")])]),
    ("avd_thermal_shield_pulse", "ic_thermal_shield",
     [("glow", [_anim("strokeAlpha", 0.1, 0.65, 900, reverse=True, interp="fast_out_slow_in")])]),
    ("avd_ram_purge_drop", "ic_ram_purge",
     [("purge", [_anim("strokeAlpha", 1, 0.15, 520, reverse=True, interp="fast_out_slow_in")])]),
    ("avd_rom_lab_bubble", "ic_rom_lab",
     [("bubble", [_anim("fillAlpha", 0.95, 0.2, 700, reverse=True, interp="fast_out_slow_in")])]),
]

# ----------------------------------------------------------------------------------------------
# preview renderer (matplotlib) - not shipped, only used to eyeball the icon pack
# ----------------------------------------------------------------------------------------------

def render_sheet(all_icons, out_png, vp=48, cell=168, cols=8):
    import re
    import numpy as np
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    from matplotlib.patches import PathPatch
    from matplotlib.path import Path as MPath
    from PIL import Image, ImageDraw

    def hex2rgba(h):
        h = h.lstrip("#")
        if len(h) == 8:
            a = int(h[0:2], 16) / 255.0
            return (int(h[2:4], 16), int(h[4:6], 16), int(h[6:8], 16), a)
        return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), 1.0)

    def parse(d):
        toks = re.findall(r"[MLCQZ]|-?\d*\.?\d+", d)
        verts, codes, i, cur = [], [], 0, None
        while i < len(toks):
            c = toks[i]
            i += 1
            if c == "M":
                cur = (float(toks[i]), float(toks[i + 1])); i += 2
                verts.append(cur); codes.append(MPath.MOVETO)
            elif c == "L":
                cur = (float(toks[i]), float(toks[i + 1])); i += 2
                verts.append(cur); codes.append(MPath.LINETO)
            elif c == "C":
                for k in range(3):
                    verts.append((float(toks[i]), float(toks[i + 1]))); codes.append(MPath.CURVE4); i += 2
                cur = verts[-1]
            elif c == "Q":
                for k in range(2):
                    verts.append((float(toks[i]), float(toks[i + 1]))); codes.append(MPath.CURVE3); i += 2
                cur = verts[-1]
            elif c == "Z":
                verts.append(verts[0] if cur is None else cur); codes.append(MPath.CLOSEPOLY)
        return MPath(verts, codes)

    PX = 8 if vp == 48 else 5
    S = vp * PX
    yy, xx = np.mgrid[0:S, 0:S]
    U = (xx + 0.5) / PX
    V = (yy + 0.5) / PX

    def mask(mp, fill, sw, cap, join):
        fig = Figure(figsize=(vp * PX / 80.0, vp * PX / 80.0), dpi=80)
        FigureCanvasAgg(fig)
        ax = fig.add_axes([0, 0, 1, 1])
        ax.set_xlim(0, vp); ax.set_ylim(vp, 0); ax.axis("off")
        capm = {"butt": "butt", "square": "projecting", "round": "round", None: "butt"}[cap]
        joinm = {"miter": "miter", "round": "round", "bevel": "bevel", None: "miter"}[join]
        ax.add_patch(PathPatch(mp, facecolor="k" if fill else "none", edgecolor="k" if sw > 0 else "none",
                               linewidth=sw * PX * 72 / 80.0, capstyle=capm, joinstyle=joinm))
        fig.canvas.draw()
        arr = np.asarray(fig.canvas.buffer_rgba())[:, :, 0].astype(np.float32)
        return 1.0 - arr / 255.0

    def colour_field(c):
        if isinstance(c, str):
            r, g, b, a = hex2rgba(c)
            f = np.zeros((S, S, 3), np.float32)
            f[:] = (r, g, b)
            return f, np.full((S, S), a, np.float32)
        dx, dy = c["x2"] - c["x1"], c["y2"] - c["y1"]
        t = np.clip(((U - c["x1"]) * dx + (V - c["y1"]) * dy) / (dx * dx + dy * dy), 0, 1)
        offs = [s[0] for s in c["stops"]]
        cols = [hex2rgba(s[1]) for s in c["stops"]]
        f = np.zeros((S, S, 3), np.float32)
        al = np.zeros((S, S), np.float32)
        for ch in range(3):
            f[:, :, ch] = np.interp(t, offs, [col[ch] for col in cols])
        al[:] = np.interp(t, offs, [col[3] for col in cols])
        return f, al

    def draw_el(canvas, e, tf=(1.0, 0.0, 0.0)):
        if e["k"] == "group":
            g = e.get("tf")
            ntf = (g.get("scaleX", 1.0), g.get("translateX", 0.0), g.get("translateY", 0.0)) if g else tf
            for ch in e["children"]:
                draw_el(canvas, ch, ntf)
            return
        mp = parse(e["d"])
        sc, tx, ty = tf
        if tf != (1.0, 0.0, 0.0):
            mp = MPath([(x * sc + tx, y * sc + ty) for x, y in mp.vertices], mp.codes)
        for kind in ("fill", "stroke"):
            c = e[kind]
            if not c:
                continue
            m = mask(mp, kind == "fill", (e["sw"] * sc) if kind == "stroke" else 0.0,
                     e["cap"], e["join"]) if kind == "stroke" else mask(mp, True, 0.0, None, None)
            if tf != (1.0, 0.0, 0.0) and not isinstance(c, str):
                c = dict(c, x1=c["x1"] * sc + tx, y1=c["y1"] * sc + ty, x2=c["x2"] * sc + tx, y2=c["y2"] * sc + ty)
            f, al = colour_field(c)
            alpha = m * al * (e["sa"] if kind == "stroke" and e["sa"] is not None else 1.0) \
                * (e["fa"] if kind == "fill" and e["fa"] is not None else 1.0)
            canvas[:] = canvas * (1 - alpha[:, :, None]) + f * alpha[:, :, None]

    pad = 14
    rows = (len(all_icons) + cols - 1) // cols
    W_, H_ = cols * (cell + pad) + pad, rows * (cell + pad + 20) + pad
    sheet = Image.new("RGB", (W_, H_), (11, 18, 26))
    dr = ImageDraw.Draw(sheet)
    for i, (name, els) in enumerate(all_icons):
        canvas = np.zeros((S, S, 3), np.float32)
        canvas[:] = (22, 32, 44)
        for e in els:
            draw_el(canvas, e)
        img = Image.fromarray(np.clip(canvas, 0, 255).astype(np.uint8)).resize((cell, cell), Image.LANCZOS)
        cx, cy = pad + (i % cols) * (cell + pad), pad + (i // cols) * (cell + pad + 20)
        sheet.paste(img, (cx, cy))
        dr.text((cx + 2, cy + cell + 3), name.replace("ic_", ""), fill=(150, 170, 190))
    sheet.save(out_png)


def main():
    out_dir = sys.argv[1]
    sheet = sys.argv[2] if len(sys.argv) > 2 else None
    os.makedirs(out_dir, exist_ok=True)
    all_icons = []
    for name, fn in FEATURE_ICONS + UTILITY_ICONS:
        els = fn()
        all_icons.append((name, els))
        with open(os.path.join(out_dir, name + ".xml"), "w") as f:
            f.write(vector_xml(name, els))
    qs = ic_qs_wild_boost()
    all_icons.append(("ic_qs_wild_boost", qs))
    with open(os.path.join(out_dir, "ic_qs_wild_boost.xml"), "w") as f:
        f.write(vector_xml("ic_qs_wild_boost (Quick Settings tile, flat white)", qs, size_dp=24))
    for name, fn in (("ic_launcher_background", launcher_background), ("ic_launcher_foreground", launcher_foreground),
                     ("ic_launcher_monochrome", launcher_monochrome)):
        with open(os.path.join(out_dir, name + ".xml"), "w") as f:
            f.write(vector_xml(name, fn(), size_dp=108, vp=108))
    mip = os.path.join(os.path.dirname(out_dir.rstrip("/")), "mipmap-anydpi-v26")
    os.makedirs(mip, exist_ok=True)
    for name in ("ic_launcher", "ic_launcher_round"):
        with open(os.path.join(mip, name + ".xml"), "w") as f:
            f.write(adaptive_xml())
    for name, drawable, targets in AVDS:
        with open(os.path.join(out_dir, name + ".xml"), "w") as f:
            f.write(avd_xml(name, drawable, targets))
    print("wrote %d vectors, %d animated vectors" % (len(all_icons), len(AVDS)))
    if sheet:
        render_sheet(all_icons, sheet)
        print("sheet:", sheet)
        render_sheet([("launcher_fg_on_bg", launcher_background() + launcher_foreground()),
                      ("launcher_monochrome", [E(rect(0, 0, 108, 108), fill="#FF3A4A5A")] + launcher_monochrome())],
                     sheet.replace(".png", "_launcher.png"), vp=108, cell=300, cols=2)


if __name__ == "__main__":
    main()
