# =============================================================================================
# HyperEngine R8 / ProGuard rules. Only used when you build with -Phyper.minify=true
# (see app/build.gradle.kts). Not yet tested on a device: after a minified build, open every hub
# tab, restart the app and check that profiles, HyperLab settings and macros are still there.
# =============================================================================================

# Readable crash traces from a minified build
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# Generics + annotations Gson and Kotlin need at runtime
-keepattributes Signature,*Annotation*,InnerClasses,EnclosingMethod

# ---------------------------------------------------------------------------------------------
# Gson models. They have no @SerializedName, so the JSON keys ARE the Kotlin field names.
# If R8 renamed them, every saved profile, setting, macro and crash-recovery snapshot would
# stop loading. Keep the classes, their fields and their constructors.
# ---------------------------------------------------------------------------------------------
# GameProfile, GlobalSettings, SystemSnapshot, PingTarget, ScriptStore, AutoTouchScript, BackupBundle ...
-keep class com.hyperengine.gameturbo.data.** { *; }

# core/Phase2Store.kt (crash-recovery snapshot)
-keep class com.hyperengine.gameturbo.core.Phase2Snapshot { *; }
-keep class com.hyperengine.gameturbo.core.AppOpBackup { *; }
-keep class com.hyperengine.gameturbo.core.PropBackup { *; }
-keep class com.hyperengine.gameturbo.core.DeviceConfigBackup { *; }
-keep class com.hyperengine.gameturbo.core.ChargeBackup { *; }

# core/GameFilterMath.kt (per-game colour filter stored in SharedPreferences)
-keep class com.hyperengine.gameturbo.core.GameFilterConfig { *; }
-keep class com.hyperengine.gameturbo.core.ColorblindMode { *; }

# Enums are stored by name; keep their constants and valueOf() everywhere in the app
-keepclassmembers enum com.hyperengine.gameturbo.** {
    public static **[] values();
    public static ** valueOf(java.lang.String);
    <fields>;
}

# Gson's own reflection helpers
-keep class com.google.gson.reflect.TypeToken { *; }
-keep class * extends com.google.gson.reflect.TypeToken
-keep class * implements com.google.gson.TypeAdapterFactory
-keep class * implements com.google.gson.JsonSerializer
-keep class * implements com.google.gson.JsonDeserializer

# ---------------------------------------------------------------------------------------------
# Shizuku. SystemBridgeExecutor calls Shizuku.class.getDeclaredMethod(...) by name, and the
# binder / AIDL stubs must keep their exact names.
# ---------------------------------------------------------------------------------------------
-keep class rikka.shizuku.** { *; }
-keep class moe.shizuku.** { *; }
-keep class rikka.sui.** { *; }
-dontwarn rikka.shizuku.**
-dontwarn moe.shizuku.**
-dontwarn rikka.sui.**

# ---------------------------------------------------------------------------------------------
# HiddenApiBypass (InputManagerBridge). It reaches into its own helper classes through
# sun.misc.Unsafe, so renaming or removing members breaks it.
# ---------------------------------------------------------------------------------------------
-keep class org.lsposed.hiddenapibypass.** { *; }
-dontwarn org.lsposed.hiddenapibypass.**

# ---------------------------------------------------------------------------------------------
# Android framework classes the app calls by name through reflection (IInputManager$Stub,
# IAudioService$Stub, View.setRequestedFrameRate, ...) are part of the OS, not of this APK, so
# they need no rule. Components named in AndroidManifest.xml (activities, services, receivers,
# tiles, the accessibility and notification-listener services) are kept automatically by AGP.
# ---------------------------------------------------------------------------------------------

# Coroutines and AndroidX bring their own consumer rules; these only silence optional-dependency warnings
-dontwarn kotlinx.coroutines.debug.**
-dontwarn java.lang.invoke.StringConcatFactory
