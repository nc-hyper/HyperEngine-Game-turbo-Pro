package com.hyperengine.gameturbo.ui

import android.content.Context
import android.graphics.drawable.Drawable
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.LruCache
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.hyperengine.gameturbo.HyperApp
import com.hyperengine.gameturbo.core.AppEntry
import com.hyperengine.gameturbo.core.FreeformAppLauncher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

/**
 * Searchable grid of EVERY launcher app on the phone. Tap = open in a full-size floating window. Long-press =
 * pin to the top. "Split" opens it beside the game when the game is in split-screen.
 */
object AppsPanel {

    private val icons = object : LruCache<String, Drawable>(160) {}

    /**
     * [focus] asks the window that hosts this page for keyboard focus (true) or gives it back (false). The HUD
     * answers through HudBus; the slide bar passes its own. [onLaunched] fires after an app was started.
     */
    fun build(
        host: ToolHost,
        launcher: FreeformAppLauncher,
        focus: (Boolean) -> Unit = { HudBus.focusRequest?.invoke(it) },
        onLaunched: () -> Unit = {}
    ): View {
        val ctx = host.hostContext
        val theme = host.theme
        val repo = host.deps.repo
        val col = Ui.vbox(ctx)

        val all = launcher.loadAll()
        var filterKind = 0     // 0 all, 1 user, 2 system, 3 pinned
        var query = ""
        var shown: List<AppEntry> = all

        val status = Ui.label(ctx, "", 11f, theme.textSecondary)
        col.addView(
            ToolUi.note(
                host,
                all.size.toString() + " apps. Tap to open floating (" +
                    (if (launcher.freeformAvailable()) "this phone supports freeform windows" else "freeform not advertised by this ROM") +
                    "). Long-press to pin."
            )
        )

        // ---- search ----
        val search = EditText(ctx).apply {
            hint = "Search apps"
            textSize = 13f
            maxLines = 1
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_DONE
            setTextColor(theme.textPrimary)
            setHintTextColor(theme.textSecondary)
            setPadding(Ui.dp(ctx, 10), Ui.dp(ctx, 8), Ui.dp(ctx, 10), Ui.dp(ctx, 8))
            background = Ui.rounded(theme.tile, Ui.tileRadius(ctx, theme), theme.stroke, Ui.dp(ctx, 1))
        }
        // The HUD window never takes focus, so the keyboard cannot appear. Typing asks for focus, leaving gives it back.
        search.setOnTouchListener { v, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) {
                focus(true)
                v.post { v.requestFocus() }
            }
            false
        }
        search.setOnEditorActionListener { v, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                v.clearFocus()
                focus(false)
            }
            false
        }
        col.addView(search, Ui.lp(Ui.MATCH, Ui.WRAP))

        // ---- filter ----
        val grid = GridView(ctx)
        val adapter = object : BaseAdapter() {
            override fun getCount() = shown.size
            override fun getItem(position: Int) = shown[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val e = shown[position]
                val cell = (convertView as? LinearLayout) ?: Ui.vbox(ctx).apply {
                    gravity = Gravity.CENTER_HORIZONTAL
                    setPadding(Ui.dp(ctx, 2), Ui.dp(ctx, 6), Ui.dp(ctx, 2), Ui.dp(ctx, 4))
                    addView(ImageView(ctx).apply { scaleType = ImageView.ScaleType.FIT_CENTER }, Ui.lp(Ui.dp(ctx, 42), Ui.dp(ctx, 42)))
                    addView(
                        Ui.label(ctx, "", 9f, theme.textSecondary).apply {
                            gravity = Gravity.CENTER
                            maxLines = 2
                            ellipsize = android.text.TextUtils.TruncateAt.END
                        },
                        Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 3), 0, 0)
                    )
                }
                val img = cell.getChildAt(0) as ImageView
                val label = cell.getChildAt(1) as TextView
                val pinned = e.pkg in repo.global.value.apps.pinned
                label.text = e.label
                label.setTextColor(if (pinned) theme.accent else theme.textSecondary)
                cell.tag = e.pkg
                val cached = icons.get(e.pkg)
                if (cached != null) {
                    img.setImageDrawable(cached)
                } else {
                    img.setImageDrawable(null)
                    host.scope.launch {
                        val d = withContext(Dispatchers.Default) {
                            runCatching { ctx.packageManager.getApplicationIcon(e.pkg) }.getOrNull()
                        }
                        if (d != null) {
                            icons.put(e.pkg, d)
                            if (cell.tag == e.pkg) img.setImageDrawable(d)
                        }
                    }
                }
                return cell
            }
        }

        fun refilter() {
            val pinned = repo.global.value.apps.pinned
            val q = query.trim().lowercase(Locale.getDefault())
            shown = all.filter { e ->
                (q.isEmpty() || e.label.lowercase(Locale.getDefault()).contains(q) || e.pkg.contains(q)) &&
                    when (filterKind) {
                        1 -> !e.system
                        2 -> e.system
                        3 -> e.pkg in pinned
                        else -> true
                    }
            }.sortedWith(compareByDescending<AppEntry> { it.pkg in pinned })
            adapter.notifyDataSetChanged()
            status.text = shown.size.toString() + " shown"
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString().orEmpty()
                refilter()
            }
        })
        col.addView(
            ChipGroup(ctx, theme, listOf("All", "Installed", "System", "Pinned"), 0, 4) { i ->
                filterKind = i
                refilter()
            },
            Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 6), 0, 0)
        )

        grid.numColumns = 4
        grid.adapter = adapter
        grid.isVerticalScrollBarEnabled = false
        grid.selector = null
        grid.setOnTouchListener { v, e ->
            // The HUD page is itself scrollable; the grid scrolls its own rows.
            if (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE) {
                v.parent?.requestDisallowInterceptTouchEvent(true)
            }
            false
        }
        grid.setOnItemClickListener { _, _, position, _ ->
            val entry = shown.getOrNull(position) ?: return@setOnItemClickListener
            val cfg = repo.global.value.apps
            host.scope.launch {
                val r = launcher.launch(entry, cfg)
                status.setTextColor(if (r.ok) theme.good else theme.hot)
                status.text = r.message
                host.toast(r.message)
                if (r.ok) onLaunched()
            }
        }
        grid.setOnItemLongClickListener { _, _, position, _ ->
            val entry = shown.getOrNull(position) ?: return@setOnItemLongClickListener true
            repo.updateGlobal {
                val p = it.apps.pinned
                it.copy(apps = it.apps.copy(pinned = if (entry.pkg in p) p - entry.pkg else (p + entry.pkg).distinct()))
            }
            refilter()
            host.toast(entry.label + if (entry.pkg in repo.global.value.apps.pinned) " pinned" else " unpinned")
            true
        }
        col.addView(grid, Ui.lp(Ui.MATCH, Ui.dp(ctx, 250), 0f, 0, Ui.dp(ctx, 6), 0, 0))
        col.addView(status, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 4), 0, 0))

        // ---- window size ----
        col.addView(Ui.section(ctx, theme, "Floating window size"))
        val cfg = repo.global.value.apps
        col.addView(Ui.labeledSlider(ctx, theme, "Width (landscape)", "%", 25, 90, cfg.widthPct.coerceIn(25, 90)) { v ->
            repo.updateGlobal { it.copy(apps = it.apps.copy(widthPct = v)) }
        })
        col.addView(Ui.labeledSlider(ctx, theme, "Height (landscape)", "%", 40, 98, cfg.heightPct.coerceIn(40, 98)) { v ->
            repo.updateGlobal { it.copy(apps = it.apps.copy(heightPct = v)) }
        }, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 6), 0, 0))
        col.addView(
            ToolUi.note(host, "Portrait uses about 420 x 720 dp. Size applies to the next app you open."),
            Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 6), 0, 0)
        )

        // ---- ROM support ----
        col.addView(Ui.section(ctx, theme, "Freeform support"))
        val note = Ui.label(ctx, "", 11f, theme.textSecondary)
        val row = Ui.hbox(ctx)
        row.addView(Ui.button(ctx, theme, "Enable freeform", true) {
            host.scope.launch {
                val steps = launcher.setFreeformSupport(true)
                val (ok, text) = GameActions.summary(steps)
                note.setTextColor(if (ok) theme.good else theme.hot)
                note.text = if (ok) "Switched on. Some ROMs need a reboot before floating windows appear." else text
            }
        }, Ui.lp(0, Ui.WRAP, 1f, 0, 0, Ui.dp(ctx, 4), 0))
        row.addView(Ui.button(ctx, theme, "Disable") {
            host.scope.launch {
                val steps = launcher.setFreeformSupport(false)
                val (ok, text) = GameActions.summary(steps)
                note.setTextColor(if (ok) theme.good else theme.hot)
                note.text = if (ok) "Switched off" else text
            }
        }, Ui.lp(0, Ui.WRAP, 1f, Ui.dp(ctx, 4), 0, 0, 0))
        col.addView(row)
        col.addView(note, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 4), 0, 0))
        refilter()
        return col
    }
}
