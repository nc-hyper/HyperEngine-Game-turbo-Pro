package com.hyperengine.gameturbo.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Typeface
import android.os.Build
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.Toast
import com.hyperengine.gameturbo.core.DisplayModeLock
import com.hyperengine.gameturbo.core.FpsSource
import com.hyperengine.gameturbo.core.TelemetrySample
import com.hyperengine.gameturbo.data.PillConfig
import com.hyperengine.gameturbo.data.PillLayout
import java.text.DateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.max

// =============================================================================================
// The pill view: draws its own text, handles drag and long-press-to-pin
// =============================================================================================

class PillView(context: Context) : View(context) {

    /** [template] is the widest text the slot will ever hold, so the pill does not jitter every second. */
    class Item(val text: String, val template: String, val color: Int)

    // wired by the manager
    var positionProvider: () -> Point = { Point(0, 0) }
    var onMove: (Int, Int) -> Unit = { _, _ -> }
    var onDragEnd: () -> Unit = {}
    var onLongPress: () -> Unit = {}
    var pinned = false

    private var items: List<Item> = emptyList()
    private var layoutMode = PillLayout.HORIZONTAL
    private var bgAlphaPct = 60

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
    }
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val dividerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1f
        color = 0x44FFFFFF
    }

    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private var downRawX = 0f
    private var downRawY = 0f
    private var startX = 0
    private var startY = 0
    private var moved = false
    private val longPress = Runnable { onLongPress() }

    init {
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    fun update(newItems: List<Item>, mode: PillLayout, textSp: Int, bgAlpha: Int, isPinned: Boolean) {
        items = newItems
        layoutMode = mode
        bgAlphaPct = bgAlpha
        pinned = isPinned
        textPaint.textSize = textSp * resources.displayMetrics.scaledDensity
        if (mode == PillLayout.CORNER_TEXT) {
            textPaint.setShadowLayer(dp(2f), 0f, 0f, 0xDD000000.toInt())
        } else {
            textPaint.clearShadowLayer()
        }
        requestLayout()
        invalidate()
    }

    private fun dp(v: Float): Float = v * resources.displayMetrics.density

    private fun slotWidth(it: Item): Float = max(textPaint.measureText(it.text), textPaint.measureText(it.template))

    private fun lineHeight(): Float {
        val fm = textPaint.fontMetrics
        return fm.descent - fm.ascent
    }

    private fun padH(): Float = if (layoutMode == PillLayout.CORNER_TEXT) dp(2f) else dp(10f)
    private fun padV(): Float = when (layoutMode) {
        PillLayout.CORNER_TEXT -> dp(2f)
        PillLayout.HORIZONTAL -> dp(5f)
        PillLayout.VERTICAL_STACK -> dp(7f)
    }
    private fun itemGap(): Float = if (layoutMode == PillLayout.CORNER_TEXT) dp(8f) else dp(12f)
    private fun lineGap(): Float = dp(3f)

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val n = items.size
        var w = 0f
        var h = 0f
        if (n > 0) {
            val lh = lineHeight()
            if (layoutMode == PillLayout.VERTICAL_STACK) {
                w = items.maxOf { slotWidth(it) } + 2f * padH()
                h = n * lh + (n - 1) * lineGap() + 2f * padV()
            } else {
                w = items.fold(0f) { acc, it -> acc + slotWidth(it) } + (n - 1) * itemGap() + 2f * padH()
                h = lh + 2f * padV()
            }
        }
        setMeasuredDimension(ceil(w).toInt(), ceil(h).toInt())
    }

    override fun onDraw(c: Canvas) {
        val n = items.size
        if (n == 0) return
        val w = width.toFloat()
        val h = height.toFloat()

        if (layoutMode != PillLayout.CORNER_TEXT) {
            bgPaint.color = Color.argb(bgAlphaPct.coerceIn(0, 100) * 255 / 100, 0, 0, 0)
            val r = if (layoutMode == PillLayout.HORIZONTAL) h / 2f else dp(12f)
            c.drawRoundRect(0f, 0f, w, h, r, r, bgPaint)
        }

        val fm = textPaint.fontMetrics
        val lh = lineHeight()
        if (layoutMode == PillLayout.VERTICAL_STACK) {
            var y = padV() - fm.ascent
            for (item in items) {
                textPaint.color = item.color
                c.drawText(item.text, padH(), y, textPaint)
                y += lh + lineGap()
            }
        } else {
            val baseline = padV() - fm.ascent
            var x = padH()
            for (i in 0 until n) {
                val item = items[i]
                textPaint.color = item.color
                c.drawText(item.text, x, baseline, textPaint)
                val slot = slotWidth(item)
                x += slot
                if (i < n - 1) {
                    if (layoutMode == PillLayout.HORIZONTAL) {
                        val dx = x + itemGap() / 2f
                        c.drawLine(dx, h * 0.28f, dx, h * 0.72f, dividerPaint)
                    }
                    x += itemGap()
                }
            }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downRawX = e.rawX
                downRawY = e.rawY
                val p = positionProvider()
                startX = p.x
                startY = p.y
                moved = false
                postDelayed(longPress, LONG_PRESS_MS)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downRawX
                val dy = e.rawY - downRawY
                if (!moved && hypot(dx, dy) > slop) {
                    moved = true
                    removeCallbacks(longPress)
                }
                if (moved && !pinned) onMove((startX + dx).toInt(), (startY + dy).toInt())
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longPress)
                if (moved && !pinned) onDragEnd()
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    companion object {
        private const val LONG_PRESS_MS = 650L
    }
}

// =============================================================================================
// Window management
// =============================================================================================

/**
 * The detachable telemetry widget. It is its own overlay window, so it stays on screen with the
 * sidebar closed. Drag it anywhere; long-press it to pin (lock) or unpin its position. Values come
 * from the same TelemetryMonitor samples as the sidebar, so FPS is real (SurfaceFlinger) with
 * Shizuku/root and otherwise shown honestly as the display rate. Main thread only.
 */
class FloatingTelemetryPill(context: Context, private val wm: WindowManager) {

    private val ctx: Context = context.applicationContext

    var onPositionSaved: ((Int, Int) -> Unit)? = null
    var onPinChanged: ((Boolean) -> Unit)? = null
    var onAttached: (() -> Unit)? = null

    private var active = false
    private var cfg = PillConfig()
    private var sample = TelemetrySample()
    private var view: PillView? = null
    private var params: WindowManager.LayoutParams? = null
    private var attached = false

    fun show(c: PillConfig, s: TelemetrySample) {
        active = true
        sample = s
        apply(c)
    }

    fun apply(c: PillConfig) {
        cfg = c.copy(textSizeSp = c.textSizeSp.coerceIn(8, 16), bgAlphaPct = c.bgAlphaPct.coerceIn(0, 100))
        if (!active || !cfg.enabled) {
            detach()
            return
        }
        val v = view ?: PillView(ctx).also { wire(it); view = it }
        refresh(v)
        val p = params ?: buildParams().also { params = it }
        val pos = clamp(cfg.posX, cfg.posY)
        p.x = pos.x
        p.y = pos.y
        try {
            if (attached) {
                wm.updateViewLayout(v, p)
            } else {
                wm.addView(v, p)
                attached = true
                onAttached?.invoke()
            }
        } catch (_: Throwable) {
            attached = false
        }
    }

    fun onSample(s: TelemetrySample) {
        sample = s
        val v = view ?: return
        if (attached) refresh(v)
    }

    fun hide() {
        active = false
        detach()
    }

    /** Phase 2: re-stamps the window with the refresh rate the FPS enforcer is holding. */
    fun refreshDisplayMode() {
        val v = view ?: return
        val p = params ?: return
        if (!attached) return
        DisplayModeLock.applyCurrent(ctx, p)
        runCatching { wm.updateViewLayout(v, p) }
    }

    /** Call after rotation: keeps the pill on screen. */
    fun relayout() {
        val v = view ?: return
        val p = params ?: return
        if (!attached) return
        val pos = clamp(p.x, p.y)
        p.x = pos.x
        p.y = pos.y
        runCatching { wm.updateViewLayout(v, p) }
    }

    // ---- internals ----

    private fun wire(v: PillView) {
        v.positionProvider = { Point(params?.x ?: 0, params?.y ?: 0) }
        v.onMove = { x, y -> moveTo(x, y) }
        v.onDragEnd = {
            val p = params
            if (p != null) onPositionSaved?.invoke(p.x, p.y)
        }
        v.onLongPress = {
            val next = !cfg.pinned
            cfg = cfg.copy(pinned = next)
            view?.pinned = next
            Toast.makeText(ctx, if (next) "FPS pill pinned" else "FPS pill unpinned", Toast.LENGTH_SHORT).show()
            onPinChanged?.invoke(next)
        }
    }

    private fun moveTo(x: Int, y: Int) {
        val v = view ?: return
        val p = params ?: return
        if (!attached) return
        val pos = clamp(x, y)
        p.x = pos.x
        p.y = pos.y
        runCatching { wm.updateViewLayout(v, p) }
    }

    @Suppress("DEPRECATION")
    private fun clamp(x: Int, y: Int): Point {
        val scr = Point()
        wm.defaultDisplay.getRealSize(scr)
        val w = view?.width ?: 0
        val h = view?.height ?: 0
        return Point(x.coerceIn(0, max(0, scr.x - w)), y.coerceIn(0, max(0, scr.y - h)))
    }

    private fun buildParams(): WindowManager.LayoutParams {
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.LEFT
        p.title = "HyperEnginePill"
        if (Build.VERSION.SDK_INT >= 28) {
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        DisplayModeLock.applyCurrent(ctx, p)   // Phase 2, layer 5
        return p
    }

    private fun detach() {
        val v = view
        if (attached && v != null) runCatching { wm.removeViewImmediate(v) }
        attached = false
        view = null
        params = null
    }

    private fun refresh(v: PillView) {
        v.update(buildItems(), cfg.layout, cfg.textSizeSp, cfg.bgAlphaPct, cfg.pinned)
    }

    private fun buildItems(): List<PillView.Item> {
        val s = sample
        val base = HudThemes.parse(cfg.textColorHex, Color.WHITE)
        val out = ArrayList<PillView.Item>()

        if (cfg.showFps) {
            val txt: String
            val col: Int
            when (s.fpsSource) {
                FpsSource.SURFACE_FLINGER -> {
                    txt = String.format(Locale.US, "%.0f FPS", s.fps)
                    col = if (cfg.dynamicFpsColor) fpsColor(s.fps) else base
                }
                FpsSource.VSYNC -> {
                    // display refresh, not the game's frame rate: never dressed up as FPS
                    txt = String.format(Locale.US, "%.0f Hz", s.fps)
                    col = GRAY
                }
                FpsSource.NONE -> {
                    txt = "-- FPS"
                    col = base
                }
            }
            out += PillView.Item(txt, "000 FPS", col)
        }
        if (cfg.showCpu) {
            val txt = if (s.cpuPct >= 0f) String.format(Locale.US, "CPU %.0f%%", s.cpuPct) else "CPU --"
            out += PillView.Item(txt, "CPU 100%", base)
        }
        if (cfg.showCoreGhz) {
            val txt = if (s.peakCoreMhz > 0) String.format(Locale.US, "%.2f GHz", s.peakCoreGhz) else "-- GHz"
            out += PillView.Item(txt, "0.00 GHz", base)
        }
        if (cfg.showRam) {
            out += PillView.Item("Free " + s.availRamMb + " MB", "Free 00000 MB", base)
        }
        if (cfg.showTemp) {
            val txt = String.format(Locale.US, "%.1f\u00B0C", s.batteryTempC)
            out += PillView.Item(txt, "00.0\u00B0C", if (s.overTemp) HOT else base)
        }
        if (cfg.showPing) {
            val txt = if (s.ping.lastMs >= 0) s.ping.lastMs.toString() + " ms" else "-- ms"
            out += PillView.Item(txt, "000 ms", base)
        }
        if (cfg.showBattery) {
            val txt = if (s.batteryPct >= 0) "BAT " + s.batteryPct + "%" + (if (s.charging) " CHG" else "") else "BAT --"
            out += PillView.Item(txt, "BAT 100% CHG", base)
        }
        if (cfg.showClock) {
            out += PillView.Item(DateFormat.getTimeInstance(DateFormat.SHORT).format(Date()), "00:00 AM", base)
        }
        if (out.isEmpty()) out += PillView.Item("No metrics selected", "No metrics selected", GRAY)
        return out
    }

    private fun fpsColor(fps: Float): Int = when {
        fps >= 60f -> GOOD
        fps >= 30f -> WARN
        else -> HOT
    }

    companion object {
        private val GOOD = 0xFF39E27D.toInt()
        private val WARN = 0xFFFFD740.toInt()
        private val HOT = 0xFFFF3B3B.toInt()
        private val GRAY = 0xFFB0B8C0.toInt()
    }
}

// =============================================================================================
// FPS pill tool page
// =============================================================================================

class PillTool(private val pill: FloatingTelemetryPill) : HudTool("pill") {

    override fun isActive(host: ToolHost): Boolean =
        GameActions.profileFor(host.deps, host.game).pill.enabled

    override fun onTap(host: ToolHost) {
        val ctx = host.hostContext
        val theme = host.theme
        val repo = host.deps.repo
        var cfg = GameActions.profileFor(host.deps, host.game).pill
        val col = Ui.vbox(ctx)

        col.addView(ToolUi.note(host,
            "A small readout that stays on screen while you play, even with this sidebar closed. Drag it " +
                "anywhere. Long-press it to pin its position (long-press again to unpin). FPS is the real game " +
                "frame rate when Shizuku or root is available; without it the pill shows the display refresh " +
                "rate in grey instead."))

        fun commit(next: PillConfig, rebuild: Boolean = false) {
            cfg = next
            pill.apply(cfg)
            repo.update(host.game) { it.copy(pill = cfg) }
            host.refreshTiles()
            if (rebuild) onTap(host)
        }

        col.addView(ChipGroup(ctx, theme, listOf("Off", "On"), if (cfg.enabled) 1 else 0, 2) { i ->
            commit(cfg.copy(enabled = i == 1))
        })

        col.addView(Ui.section(ctx, theme, "Layout"))
        val layouts = PillLayout.values()
        col.addView(ChipGroup(
            ctx, theme, listOf("Horizontal pill", "Vertical stack", "Corner text"),
            layouts.indexOf(cfg.layout), 3
        ) { i -> commit(cfg.copy(layout = layouts[i], enabled = true)) })

        col.addView(Ui.section(ctx, theme, "Metrics"))
        col.addView(ToolUi.check(ctx, theme, "FPS", cfg.showFps) { commit(cfg.copy(showFps = it, enabled = true)) })
        col.addView(ToolUi.check(ctx, theme, "CPU usage %", cfg.showCpu) { commit(cfg.copy(showCpu = it, enabled = true)) })
        col.addView(ToolUi.check(ctx, theme, "Peak core clock (GHz)", cfg.showCoreGhz) { commit(cfg.copy(showCoreGhz = it, enabled = true)) })
        col.addView(ToolUi.check(ctx, theme, "Free RAM (MB)", cfg.showRam) { commit(cfg.copy(showRam = it, enabled = true)) })
        col.addView(ToolUi.check(ctx, theme, "Battery temperature", cfg.showTemp) { commit(cfg.copy(showTemp = it, enabled = true)) })
        col.addView(ToolUi.check(ctx, theme, "Ping (ms)", cfg.showPing) { commit(cfg.copy(showPing = it, enabled = true)) })
        col.addView(ToolUi.check(ctx, theme, "Battery %", cfg.showBattery) { commit(cfg.copy(showBattery = it, enabled = true)) })
        col.addView(ToolUi.check(ctx, theme, "System time", cfg.showClock) { commit(cfg.copy(showClock = it, enabled = true)) })

        col.addView(Ui.section(ctx, theme, "Style"))
        col.addView(ToolUi.liveSlider(ctx, theme, "Text size", " sp", 8, 16, cfg.textSizeSp,
            { pill.apply(cfg.copy(textSizeSp = it, enabled = true)) }, { commit(cfg.copy(textSizeSp = it, enabled = true)) }))
        col.addView(ToolUi.liveSlider(ctx, theme, "Background opacity", " %", 0, 100, cfg.bgAlphaPct,
            { pill.apply(cfg.copy(bgAlphaPct = it, enabled = true)) }, { commit(cfg.copy(bgAlphaPct = it, enabled = true)) }))
        col.addView(ToolUi.check(ctx, theme, "Colour the FPS by speed (green 60+, yellow 30-59, red below 30)", cfg.dynamicFpsColor) {
            commit(cfg.copy(dynamicFpsColor = it, enabled = true))
        })
        col.addView(Ui.label(ctx, "Text colour", 12f, theme.textPrimary), Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, Ui.dp(ctx, 8), 0, 0))
        col.addView(HexColorPicker(ctx, theme, cfg.textColorHex) { hex -> commit(cfg.copy(textColorHex = hex, enabled = true)) })

        col.addView(Ui.section(ctx, theme, "Position"))
        col.addView(ToolUi.check(ctx, theme, "Pin position (cannot be dragged)", cfg.pinned) {
            commit(cfg.copy(pinned = it, enabled = true))
        })
        col.addView(Ui.button(ctx, theme, "Reset position to top-left") {
            commit(cfg.copy(posX = PillConfig().posX, posY = PillConfig().posY, enabled = true))
        })

        host.openDetail("FPS pill", col)
    }
}
