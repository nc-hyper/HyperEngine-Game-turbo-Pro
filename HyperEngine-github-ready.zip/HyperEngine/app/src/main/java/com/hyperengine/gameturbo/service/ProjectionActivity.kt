package com.hyperengine.gameturbo.service

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle

/**
 * Last permission result from the system "start capturing your screen" dialog, kept so the Scout magnifier can
 * reuse it. A MediaProjection result is single use for the recorder (the service consumes it), so [data] is
 * handed to exactly one consumer.
 */
object ProjectionHolder {
    /** Fired on the main thread when the user approves a request made for [ProjectionActivity.PURPOSE_SCOUT]. */
    @Volatile
    var onScoutGranted: ((resultCode: Int, data: Intent) -> Unit)? = null

    @Volatile
    var onDenied: ((purpose: Int) -> Unit)? = null
}

/**
 * Invisible activity that shows Android's screen-capture consent dialog, because only an Activity can receive
 * that result. Used by the built-in screen recorder now and by the Scout magnifier later.
 */
class ProjectionActivity : Activity() {

    private var purpose = PURPOSE_RECORD
    private var withMic = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        purpose = intent.getIntExtra(EXTRA_PURPOSE, PURPOSE_RECORD)
        withMic = intent.getBooleanExtra(EXTRA_MIC, false)
        if (savedInstanceState != null) return
        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            @Suppress("DEPRECATION")
            startActivityForResult(mpm.createScreenCaptureIntent(), REQ)
        } catch (_: Throwable) {
            ProjectionHolder.onDenied?.invoke(purpose)
            finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ) {
            if (resultCode == RESULT_OK && data != null) {
                when (purpose) {
                    PURPOSE_SCOUT -> ProjectionHolder.onScoutGranted?.invoke(resultCode, data)
                    else -> ScreenRecordService.start(applicationContext, resultCode, data, withMic)
                }
            } else {
                ProjectionHolder.onDenied?.invoke(purpose)
            }
        }
        finish()
        overridePendingTransition(0, 0)
    }

    companion object {
        const val PURPOSE_RECORD = 1
        const val PURPOSE_SCOUT = 2
        private const val REQ = 4711
        private const val EXTRA_PURPOSE = "purpose"
        private const val EXTRA_MIC = "mic"

        fun request(ctx: Context, purpose: Int, withMic: Boolean = false) {
            ctx.startActivity(
                Intent(ctx, ProjectionActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                    .putExtra(EXTRA_PURPOSE, purpose)
                    .putExtra(EXTRA_MIC, withMic)
            )
        }
    }
}
