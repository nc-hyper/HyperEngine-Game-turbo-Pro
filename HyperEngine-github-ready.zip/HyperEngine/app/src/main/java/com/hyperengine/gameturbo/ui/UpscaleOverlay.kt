package com.hyperengine.gameturbo.ui

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Handler
import android.os.HandlerThread
import android.os.Process
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.hyperengine.gameturbo.core.InputManagerBridge

/**
 * The two windows of the virtual-display upscaler.
 *
 *  - A full-screen SurfaceView that shows the upscaled picture. It also OWNS the touch screen while the upscaler
 *    runs: the game is on another (virtual) display, so every touch that lands here is copied with its coordinates
 *    scaled down to the virtual display's pixels and injected into that display through Shizuku. Pointer ids are kept,
 *    so multi-touch, history samples and the synthetic fingers of the macro / auto-touch engines (which tap the
 *    phone screen and therefore hit this window first) all arrive in the game unchanged.
 *  - A small pill with Back and Stop. Back is needed because the system's back gesture goes to the phone screen,
 *    not to the virtual display. Stop is the always-there way out. The pill can be dragged by its grip.
 *
 * Injection runs on its own thread so a slow binder call never delays the UI thread. Everything else here is main thread.
 */
class UpscaleOverlay(
    private val ctx: Context,
    private val wm: WindowManager,
    private val outW: Int,
    private val outH: Int,
    private val srcW: Int,
    private val srcH: Int,
    private val input: InputManagerBridge,
    private val onSurface: (Surface) -> Unit,
    private val onSurfaceLost: () -> Unit,
    private val onStop: () -> Unit
) {
    @Volatile
    private var displayId = -1

    private var screen: ScreenView? = null
    private var pill: LinearLayout? = null
    private var pillParams: WindowManager.LayoutParams? = null

    private val inputThread = HandlerThread("HyperUpscaleInput", Process.THREAD_PRIORITY_URGENT_DISPLAY).also { it.start() }
    private val inputHandler = Handler(inputThread.looper)

    /** Where touches go. Set as soon as the virtual display exists; until then touches are dropped. */
    fun setTarget(id: Int) {
        displayId = id
    }

    /** Adds both windows. False when the system refused (overlay permission gone). */
    fun show(): Boolean {
        return try {
            val sv = ScreenView(ctx)
            wm.addView(sv, OverlayKit.params(outW, outH, "HyperUpscale", touchable = true))
            screen = sv

            val p = buildPill()
            val pp = OverlayKit.params(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, "HyperUpscalePill", touchable = true)
            pp.x = (outW / 2 - Ui.dp(ctx, 70)).coerceAtLeast(0)
            pp.y = Ui.dp(ctx, 6)
            pp.alpha = 0.6f
            wm.addView(p, pp)
            pill = p
            pillParams = pp

            // The HUD handle and panels must stay above the picture, or the HUD becomes unreachable.
            HudBus.raiseHud?.invoke()
            true
        } catch (_: Throwable) {
            hide()
            false
        }
    }

    fun hide() {
        pill?.let { v -> runCatching { wm.removeViewImmediate(v) } }
        screen?.let { v -> runCatching { wm.removeViewImmediate(v) } }
        pill = null
        screen = null
        pillParams = null
        displayId = -1
        inputHandler.removeCallbacksAndMessages(null)
        inputThread.quitSafely()
    }

    // ---------------------------------------------------------------------------------------------
    // Picture + touch
    // ---------------------------------------------------------------------------------------------

    private inner class ScreenView(c: Context) : SurfaceView(c), SurfaceHolder.Callback {
        init {
            setZOrderOnTop(true)
            holder.setFormat(PixelFormat.RGBA_8888)
            holder.addCallback(this)
            isClickable = true
        }

        override fun surfaceCreated(h: SurfaceHolder) {
            onSurface(h.surface)
        }

        override fun surfaceChanged(h: SurfaceHolder, format: Int, width: Int, height: Int) {}

        override fun surfaceDestroyed(h: SurfaceHolder) {
            onSurfaceLost()
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            forward(e, width, height)
            return true
        }
    }

    private fun forward(e: MotionEvent, viewW: Int, viewH: Int) {
        val id = displayId
        if (id < 0 || viewW <= 0 || viewH <= 0) return
        val sx = srcW.toFloat() / viewW
        val sy = srcH.toFloat() / viewH
        // Only ACTION_MOVE batches several samples; sending each one keeps fast swipes smooth.
        if (e.actionMasked == MotionEvent.ACTION_MOVE) {
            for (h in 0 until e.historySize) post(build(e, h, sx, sy), id)
        }
        post(build(e, -1, sx, sy), id)
    }

    private fun build(e: MotionEvent, hist: Int, sx: Float, sy: Float): MotionEvent {
        val n = e.pointerCount
        val props = Array(n) { MotionEvent.PointerProperties() }
        val coords = Array(n) { MotionEvent.PointerCoords() }
        for (i in 0 until n) {
            e.getPointerProperties(i, props[i])
            if (hist < 0) e.getPointerCoords(i, coords[i]) else e.getHistoricalPointerCoords(i, hist, coords[i])
            coords[i].x = coords[i].x * sx
            coords[i].y = coords[i].y * sy
        }
        val t = if (hist < 0) e.eventTime else e.getHistoricalEventTime(hist)
        // Device id 0 and SOURCE_TOUCHSCREEN: the same shape a screen mirroring tool sends to a secondary display.
        return MotionEvent.obtain(
            e.downTime, t, e.action, n, props, coords,
            e.metaState, e.buttonState, 1f, 1f, 0, e.edgeFlags, InputDevice.SOURCE_TOUCHSCREEN, 0
        )
    }

    private fun post(ev: MotionEvent, id: Int) {
        inputHandler.post {
            try {
                input.inject(ev, InputManagerBridge.MODE_ASYNC, id)
            } finally {
                ev.recycle()
            }
        }
    }

    // ---------------------------------------------------------------------------------------------
    // Pill: grip (drag), Back, Stop
    // ---------------------------------------------------------------------------------------------

    private fun buildPill(): LinearLayout {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = Ui.rounded(Color.argb(0xE6, 0x14, 0x16, 0x1C), Ui.dpf(ctx, 20f), Color.argb(0x66, 255, 255, 255), Ui.dp(ctx, 1))
        row.setPadding(Ui.dp(ctx, 4), 0, Ui.dp(ctx, 4), 0)

        fun chip(text: String, onClick: (() -> Unit)?): TextView = TextView(ctx).apply {
            this.text = text
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            minHeight = Ui.dp(ctx, 34)
            minWidth = Ui.dp(ctx, 34)
            setPadding(Ui.dp(ctx, 8), 0, Ui.dp(ctx, 8), 0)
            if (onClick != null) setOnClickListener { onClick() }
        }

        val grip = chip("\u2630", null)
        attachDrag(grip)
        row.addView(grip)
        row.addView(chip("Back") { pressBack() })
        row.addView(chip("Stop") { onStop() })
        return row
    }

    private fun pressBack() {
        val id = displayId
        if (id < 0) return
        inputHandler.post { input.pressKey(KeyEvent.KEYCODE_BACK, 30L, id) }
    }

    private fun attachDrag(grip: View) {
        val slop = ViewConfiguration.get(ctx).scaledTouchSlop
        var startRawX = 0f
        var startRawY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        grip.setOnTouchListener { _, e ->
            val pp = pillParams ?: return@setOnTouchListener false
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startRawX = e.rawX
                    startRawY = e.rawY
                    startX = pp.x
                    startY = pp.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - startRawX
                    val dy = e.rawY - startRawY
                    if (!moved && (dx * dx + dy * dy) > slop * slop) moved = true
                    if (moved) {
                        pp.x = (startX + dx).toInt().coerceIn(0, outW - Ui.dp(ctx, 40))
                        pp.y = (startY + dy).toInt().coerceIn(0, outH - Ui.dp(ctx, 40))
                        pill?.let { v -> runCatching { if (v.isAttachedToWindow) wm.updateViewLayout(v, pp) } }
                    }
                    true
                }
                else -> true
            }
        }
    }
}
