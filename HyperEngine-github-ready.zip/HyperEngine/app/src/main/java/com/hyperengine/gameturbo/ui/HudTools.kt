package com.hyperengine.gameturbo.ui

import android.content.Context
import android.view.View
import android.widget.TextView
import com.hyperengine.gameturbo.R
import com.hyperengine.gameturbo.core.ColorMath
import com.hyperengine.gameturbo.core.GameModeLevel
import com.hyperengine.gameturbo.core.Ns
import com.hyperengine.gameturbo.core.OptimizationEngine
import com.hyperengine.gameturbo.core.StepResult
import com.hyperengine.gameturbo.core.SystemBridgeExecutor
import com.hyperengine.gameturbo.core.TelemetryMonitor
import com.hyperengine.gameturbo.data.DnsPreset
import com.hyperengine.gameturbo.data.GameProfile
import com.hyperengine.gameturbo.data.GameProfileRepository
import com.hyperengine.gameturbo.data.VisualFilterConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import java.util.Locale

// ---------------------------------------------------------------------------------------------
// Contracts
// ---------------------------------------------------------------------------------------------

class SidebarDeps(
    val ctx: Context,
    val engine: OptimizationEngine,
    val telemetry: TelemetryMonitor,
    val repo: GameProfileRepository,
    val bridge: SystemBridgeExecutor
)

/** What a tool may ask of the sidebar that hosts it. */
interface ToolHost {
    val hostContext: Context
    val game: String
    val theme: HudTheme
    val deps: SidebarDeps
    val scope: CoroutineScope
    fun toast(msg: String)
    fun openDetail(title: String, content: View)
    fun refreshTiles()
}

abstract class HudTool(val id: String) {
    open fun isActive(host: ToolHost): Boolean = false
    abstract fun onTap(host: ToolHost)
}

/**
 * Tools register themselves here. A tile only appears for a registered tool, so there are no dead
 * buttons: later phases (crosshair, filter, macro, audio, timers ...) call ToolRegistry.register(..)
 * from their own managers and the tile shows up automatically.
 */
object ToolRegistry {
    private val tools = LinkedHashMap<String, HudTool>()
    fun register(tool: HudTool) { tools[tool.id] = tool }
    fun get(id: String): HudTool? = tools[id]
    fun has(id: String): Boolean = tools.containsKey(id)
}

data class ToolInfo(val id: String, val title: String, val code: String, val phase: Int, val iconRes: Int = 0)

object ToolCatalog {
    val all = listOf(
        ToolInfo("game_mode", "Game mode", "GM", 3),
        ToolInfo("boost", "Wild Boost", "WB", 3, R.drawable.ic_wild_boost_turbine),
        ToolInfo("freeze", "Freeze apps", "FZ", 3),
        ToolInfo("dns", "Gaming DNS", "DNS", 3, R.drawable.ic_dns_network),
        ToolInfo("refresh", "Refresh rate", "HZ", 3),
        ToolInfo("downscale", "Resolution", "RES", 3, R.drawable.ic_hyperboost_scale),
        ToolInfo("crosshair", "Crosshair", "XH", 4, R.drawable.ic_crosshair_reticle),
        ToolInfo("pill", "FPS pill", "FP", 4),
        ToolInfo("filter", "Visual filter", "VF", 3, R.drawable.ic_game_filters),
        ToolInfo("brightness", "Brightness lock", "BR", 3),
        ToolInfo("edge_guard", "Edge guard", "EG", 4),
        ToolInfo("pointer", "Touch response", "TS", 3),
        ToolInfo("macro", "Auto tapper", "AT", 5, R.drawable.ic_autotouch_target),
        ToolInfo("audio", "Audio EQ", "EQ", 5, R.drawable.ic_sound_radar),
        ToolInfo("voice", "Voice changer", "VC", 5, R.drawable.ic_voice_changer_mic),
        ToolInfo("timers", "Cooldown timers", "TM", 5, R.drawable.ic_timer_cooldown),
        ToolInfo("danmaku", "Danmaku", "DK", 5),
        ToolInfo("afk", "AFK lock", "AF", 5, R.drawable.ic_afk_lock),
        ToolInfo("turbo", "Turbo core", "TC", 2, R.drawable.ic_fan_blades),
        ToolInfo("lab", Brand.LAB_TILE, "HL", 3, R.drawable.ic_low_latency),
        ToolInfo("replay", Brand.REPLAY_TILE, "RP", 3, R.drawable.ic_clip_buffer),
        // Landscape HUD / system tools
        ToolInfo("shot", "Screenshot", "SS", 3, R.drawable.ic_screenshot_capture),
        ToolInfo("record", "Screen recorder", "RC", 3, R.drawable.ic_screen_record),
        ToolInfo("cast", "RedMagic Studio", "ST", 3, R.drawable.ic_wireless_cast),
        ToolInfo("kbm", "Keyboard and mouse", "KM", 3),
        ToolInfo("calls", "Call banner", "CB", 3, R.drawable.ic_handsfree_call),
        ToolInfo("console", "Console settings", "CS", 3, R.drawable.ic_shoulder_triggers),
        // UI redesign part 3: Apps, Chat apps, Browser, Notes and Calculator live in the slide bar
        ToolInfo("slidebar", "Slide bar", "SB", 3)
    )
    private val byId = all.associateBy { it.id }
    fun info(id: String): ToolInfo = byId[id] ?: ToolInfo(id, id, id.take(2).uppercase(Locale.US), 0)
}

// ---------------------------------------------------------------------------------------------
// Shared actions
// ---------------------------------------------------------------------------------------------

object GameActions {

    val MODES = listOf(GameModeLevel.BATTERY, GameModeLevel.STANDARD, GameModeLevel.PERFORMANCE)

    fun profileFor(deps: SidebarDeps, game: String): GameProfile =
        deps.repo.profile(game) ?: deps.repo.getOrCreate(game, game)

    /** Persists the mode in the game profile, then applies it with the real `cmd game mode` command. */
    suspend fun applyMode(deps: SidebarDeps, game: String, level: GameModeLevel): List<StepResult> {
        val p = profileFor(deps, game)
        deps.repo.update(game) { it.copy(gameMode = level) }
        return deps.engine.setGameTuning(game, level, p.downscale, p.targetFps, p.fpsCapViaDisplay, p.refreshHz)
    }

    /** Every step is listed, so a partial result (e.g. game setting refused but display lock worked) is visible. */
    fun summary(steps: List<StepResult>): Pair<Boolean, String> {
        val allOk = steps.none { !it.ok }
        if (allOk) {
            return true to steps.joinToString("\n") {
                if (it.detail.isBlank()) it.step else it.step + " (" + it.detail + ")"
            }
        }
        return false to steps.joinToString("\n") {
            if (it.ok) "[ok] " + it.step + (if (it.detail.isBlank()) "" else " (" + it.detail + ")")
            else "[failed] " + it.step + ": " + it.detail
        }
    }
}

private fun resultView(host: ToolHost): TextView =
    Ui.label(host.hostContext, "", 11f, host.theme.textSecondary).apply {
        setPadding(0, Ui.dp(host.hostContext, 10), 0, 0)
    }

private fun show(tv: TextView, host: ToolHost, ok: Boolean, text: String) {
    tv.setTextColor(if (ok) host.theme.good else host.theme.hot)
    tv.text = text
}

private fun note(host: ToolHost, text: String): TextView =
    Ui.label(host.hostContext, text, 11f, host.theme.textSecondary).apply {
        setPadding(0, 0, 0, Ui.dp(host.hostContext, 8))
    }

private fun profileOf(host: ToolHost): GameProfile = GameActions.profileFor(host.deps, host.game)

// ---------------------------------------------------------------------------------------------
// Built-in tools (Phase 3). Every one runs real commands through OptimizationEngine / the bridge.
// ---------------------------------------------------------------------------------------------

object BuiltinTools {

    fun register(deps: SidebarDeps) {
        ToolRegistry.register(GameModeTool())
        ToolRegistry.register(BoostTool())
        ToolRegistry.register(FreezeTool())
        ToolRegistry.register(DnsTool())
        ToolRegistry.register(RefreshTool())
        ToolRegistry.register(DownscaleTool())
        ToolRegistry.register(BrightnessTool())
        ToolRegistry.register(TouchTool())
        ToolRegistry.register(FilterTool())
    }

    // ---- Game mode: Battery / Balanced / Wild Boost ----
    private class GameModeTool : HudTool("game_mode") {
        override fun isActive(host: ToolHost) = profileOf(host).gameMode != GameModeLevel.STANDARD

        override fun onTap(host: ToolHost) {
            val ctx = host.hostContext
            val col = Ui.vbox(ctx)
            col.addView(note(host, "Battery saver limits clocks. Balanced is the system default. Wild Boost unlocks the " +
                "performance profile and the resolution downscaler."))
            val res = resultView(host)
            val chips = ChipGroup(
                ctx, host.theme, listOf("Battery saver", "Balanced", "Wild Boost"),
                GameActions.MODES.indexOf(profileOf(host).gameMode), 3
            ) { i ->
                host.scope.launch {
                    val (ok, msg) = GameActions.summary(GameActions.applyMode(host.deps, host.game, GameActions.MODES[i]))
                    show(res, host, ok, msg)
                    host.refreshTiles()
                }
            }
            col.addView(chips)
            col.addView(res)
            host.openDetail("Game mode", col)
        }
    }

    // ---- Wild Boost quick toggle ----
    private class BoostTool : HudTool("boost") {
        override fun isActive(host: ToolHost) = profileOf(host).gameMode == GameModeLevel.PERFORMANCE

        override fun onTap(host: ToolHost) {
            val target = if (isActive(host)) GameModeLevel.STANDARD else GameModeLevel.PERFORMANCE
            host.scope.launch {
                val (ok, msg) = GameActions.summary(GameActions.applyMode(host.deps, host.game, target))
                host.toast(if (ok) (if (target == GameModeLevel.PERFORMANCE) "Wild Boost on" else "Balanced mode") else msg)
                host.refreshTiles()
            }
        }
    }

    // ---- Freeze background apps now ----
    private class FreezeTool : HudTool("freeze") {
        override fun onTap(host: ToolHost) {
            val ctx = host.hostContext
            val col = Ui.vbox(ctx)
            val count = host.deps.repo.global.value.freezeList.size
            col.addView(note(host, "Freeze list: $count app(s). Each one gets RUN_ANY_IN_BACKGROUND set to ignore and is " +
                "force-stopped (needs Shizuku or root). Everything is switched back when the game closes."))
            val res = resultView(host)
            col.addView(Ui.button(ctx, host.theme, "Freeze now and measure RAM", true) {
                show(res, host, true, "Working...")
                host.scope.launch {
                    val r = host.deps.engine.freezeNow(host.game)
                    val ok = r.failed == 0
                    show(
                        res, host, ok,
                        "Frozen ${r.frozen}, protected ${r.skippedProtected}, already restricted " +
                            "${r.skippedAlreadyRestricted}, failed ${r.failed}.\nFree RAM ${r.availBeforeMb} MB -> " +
                            "${r.availAfterMb} MB (${r.reclaimedMb} MB)." +
                            (if (!r.usedShell) "\nNo shell: only background processes were killed." else "")
                    )
                }
            })
            col.addView(res)
            host.openDetail("Freeze apps", col)
        }
    }

    // ---- Private DNS ----
    private class DnsTool : HudTool("dns") {
        private val choices = listOf(
            DnsPreset.CLOUDFLARE, DnsPreset.GOOGLE, DnsPreset.QUAD9,
            DnsPreset.ADGUARD, DnsPreset.SYSTEM_DEFAULT, DnsPreset.OFF
        )

        override fun isActive(host: ToolHost) = profileOf(host).dns != DnsPreset.NO_CHANGE

        override fun onTap(host: ToolHost) {
            val ctx = host.hostContext
            val col = Ui.vbox(ctx)
            val (mode, spec) = host.deps.engine.currentDns()
            col.addView(note(host, "Current: ${mode ?: "unknown"}" + (spec?.let { " ($it)" } ?: "")))
            val res = resultView(host)
            val labels = choices.map { it.label } + "Restore original"
            val sel = choices.indexOf(profileOf(host).dns)
            val chips = ChipGroup(ctx, host.theme, labels, sel, 2) { i ->
                host.scope.launch {
                    if (i < choices.size) {
                        val preset = choices[i]
                        host.deps.repo.update(host.game) { it.copy(dns = preset) }
                        val r = host.deps.engine.setDns(preset)
                        show(res, host, r.ok, if (r.ok) preset.label + " active" else r.step + ": " + r.detail)
                    } else {
                        host.deps.repo.update(host.game) { it.copy(dns = DnsPreset.NO_CHANGE) }
                        val r = host.deps.engine.restoreDns()
                        show(res, host, r.ok, if (r.ok) "Original DNS restored" else r.step + ": " + r.detail)
                    }
                    host.refreshTiles()
                }
            }
            col.addView(chips)
            col.addView(res)
            host.openDetail("Gaming DNS", col)
        }
    }

    // ---- Refresh rate lock ----
    private class RefreshTool : HudTool("refresh") {
        override fun isActive(host: ToolHost) = profileOf(host).refreshHz != 0

        override fun onTap(host: ToolHost) {
            val ctx = host.hostContext
            val engine = host.deps.engine
            val rates = engine.supportedRefreshRates()
            val col = Ui.vbox(ctx)
            col.addView(note(
                host,
                if (rates.isEmpty()) "Display modes could not be read."
                else "Panel supports ${rates.joinToString(" / ")} Hz. Now running ${engine.currentRefreshRate()} Hz."
            ))
            val res = resultView(host)
            val labels = rates.map { "$it Hz" } + "Max supported" + "Unlock"
            val cur = profileOf(host).refreshHz
            val sel = when {
                cur == 0 -> -1
                cur < 0 -> rates.size
                else -> rates.indexOf(cur)
            }
            val chips = ChipGroup(ctx, host.theme, labels, sel, 3) { i ->
                host.scope.launch {
                    // Goes through the FPS enforcer so its watchdog and the overlay windows hold the SAME rate.
                    // Writing the settings alone let the watchdog / ROM put its own rate back.
                    val fps = com.hyperengine.gameturbo.HyperApp.instance.fps
                    if (i == rates.size + 1) {
                        host.deps.repo.update(host.game) { it.copy(refreshHz = 0) }
                        val r = fps.applyExplicitRate(host.game, 0)
                        show(res, host, r.ok, if (r.ok) "Refresh rate unlocked" else r.step + ": " + r.detail)
                    } else {
                        val hz = if (i == rates.size) -1 else rates[i]
                        host.deps.repo.update(host.game) { it.copy(refreshHz = hz) }
                        val r = fps.applyExplicitRate(host.game, hz)
                        show(res, host, r.ok, r.detail.ifBlank { r.step })
                    }
                    host.refreshTiles()
                }
            }
            col.addView(chips)
            col.addView(res)
            host.openDetail("Refresh rate", col)
        }
    }

    // ---- Resolution downscaler + FPS cap ----
    private class DownscaleTool : HudTool("downscale") {
        private val ratios = listOf<Float?>(null, 0.90f, 0.85f, 0.80f, 0.75f, 0.70f, 0.60f, 0.50f)
        private val ratioLabels = listOf("Off", "90%", "85%", "80%", "75%", "70%", "60%", "50%")
        private val fpsChoices = listOf(0, 30, 45, 60, 90, 120, 144)
        private val fpsLabels = listOf("Off", "30", "45", "60", "90", "120", "144")

        override fun isActive(host: ToolHost): Boolean {
            val p = profileOf(host)
            return p.downscale != null || p.targetFps > 0
        }

        override fun onTap(host: ToolHost) {
            val ctx = host.hostContext
            val col = Ui.vbox(ctx)
            col.addView(note(host, "Renders the game below native resolution and caps its frame rate. The cap is sent to " +
                "the system with 'cmd game set' (needs Shizuku or root). Not every game honours that, so by default the " +
                "panel refresh rate is also locked to the cap, which works in every game."))
            val res = resultView(host)
            val p0 = profileOf(host)
            var ds: Float? = p0.downscale
            var fps: Int = p0.targetFps
            var viaDisplay: Boolean = p0.fpsCapViaDisplay

            fun apply() {
                host.scope.launch {
                    var level = profileOf(host).gameMode
                    var switched = false
                    if (level == GameModeLevel.STANDARD && (ds != null || fps > 0)) {
                        level = GameModeLevel.PERFORMANCE
                        switched = true
                    }
                    host.deps.repo.update(host.game) {
                        it.copy(gameMode = level, downscale = ds, targetFps = fps, fpsCapViaDisplay = viaDisplay)
                    }
                    val steps = host.deps.engine.setGameTuning(
                        host.game, level, ds, fps, viaDisplay, profileOf(host).refreshHz
                    )
                    val (ok, msg) = GameActions.summary(steps)
                    show(res, host, ok, (if (switched) "Switched to Wild Boost (required). " else "") + msg)
                    host.refreshTiles()
                }
            }

            col.addView(Ui.section(ctx, host.theme, "Resolution scale"))
            val dsSel = ratios.indexOfFirst { it == ds }.let { if (it < 0) 0 else it }
            val dsChips = ChipGroup(ctx, host.theme, ratioLabels, dsSel, 4) { i -> ds = ratios[i]; apply() }
            col.addView(dsChips)
            col.addView(Ui.section(ctx, host.theme, "FPS cap"))
            val fpsSel = fpsChoices.indexOf(fps).let { if (it < 0) 0 else it }
            val fpsChips = ChipGroup(ctx, host.theme, fpsLabels, fpsSel, 4) { i -> fps = fpsChoices[i]; apply() }
            col.addView(fpsChips)
            col.addView(Ui.section(ctx, host.theme, "Cap method"))
            col.addView(ChipGroup(
                ctx, host.theme, listOf("Game setting + display lock", "Game setting only"),
                if (viaDisplay) 0 else 1, 1
            ) { i -> viaDisplay = i == 0; if (fps > 0) apply() })
            col.addView(Ui.button(ctx, host.theme, "Reset to game default") {
                host.scope.launch {
                    ds = null
                    fps = 0
                    dsChips.select(0)
                    fpsChips.select(0)
                    host.deps.repo.update(host.game) { it.copy(downscale = null, targetFps = 0) }
                    val (ok, msg) = GameActions.summary(host.deps.engine.resetGameTuning(host.game))
                    show(res, host, ok, msg)
                    host.refreshTiles()
                }
            })
            col.addView(res)
            host.openDetail("Resolution", col)
        }
    }

    // ---- Anti-mistouch brightness lock ----
    private class BrightnessTool : HudTool("brightness") {
        override fun isActive(host: ToolHost) = profileOf(host).filter.brightnessLock

        override fun onTap(host: ToolHost) {
            val ctx = host.hostContext
            val col = Ui.vbox(ctx)
            col.addView(note(host, "Locks brightness to manual mode so auto-brightness and accidental swipes cannot " +
                "change it. The level is scaled to this phone's real range (0-${host.deps.engine.brightnessMax()}) and " +
                "also applied as a window override. The original mode and level come back after the game."))
            val res = resultView(host)
            val p = profileOf(host)
            var level = p.filter.brightnessLevel
            var locked = p.filter.brightnessLock

            fun persist() {
                host.deps.repo.update(host.game) {
                    it.copy(filter = it.filter.copy(brightnessLock = locked, brightnessLevel = level))
                }
            }

            col.addView(ChipGroup(ctx, host.theme, listOf("Lock off", "Lock on"), if (locked) 1 else 0, 2) { i ->
                host.scope.launch {
                    locked = i == 1
                    persist()
                    val r = if (locked) host.deps.engine.lockBrightness(level) else host.deps.engine.unlockBrightness()
                    show(res, host, r.ok, if (r.ok) r.detail.ifBlank { "Done" } else r.step + ": " + r.detail)
                    host.refreshTiles()
                }
            })
            col.addView(Ui.labeledSlider(ctx, host.theme, "Brightness", " %", 1, 100, Math.round(level * 100f / 255f).coerceIn(1, 100)) { pct ->
                level = Math.round(pct * 255f / 100f).coerceIn(3, 255)
                persist()
                if (locked) {
                    host.scope.launch {
                        val r = host.deps.engine.lockBrightness(level)
                        show(res, host, r.ok, if (r.ok) r.detail.ifBlank { "Level $level" } else r.step + ": " + r.detail)
                    }
                }
            })
            col.addView(res)
            host.openDetail("Brightness lock", col)
        }
    }

    // ---- Touch response ----
    private class TouchTool : HudTool("pointer") {
        override fun isActive(host: ToolHost): Boolean {
            val p = profileOf(host)
            return p.pointerSpeed != null || p.longPressMs != null || p.touchSensitivity
        }

        override fun onTap(host: ToolHost) {
            val ctx = host.hostContext
            val engine = host.deps.engine
            val col = Ui.vbox(ctx)
            col.addView(note(host, "Android has no universal touch-sampling switch, so this page only offers settings that " +
                "really take effect: the long-press delay and, where the ROM has it, the high-sensitivity switch. " +
                "Pointer speed below only affects a mouse or trackpad, not finger touch. All of it is restored after the game."))
            val res = resultView(host)
            val p0 = profileOf(host)
            var longPress: Int? = p0.longPressMs
            var sens: Boolean = p0.touchSensitivity

            fun applyTouch() {
                host.scope.launch {
                    host.deps.repo.update(host.game) { it.copy(longPressMs = longPress, touchSensitivity = sens) }
                    val (ok, msg) = GameActions.summary(engine.setTouchTweaks(longPress, sens))
                    show(res, host, ok, msg.ifBlank { "Back to the original values" })
                    host.refreshTiles()
                }
            }

            val cur = host.deps.bridge.getSetting(Ns.SECURE, "long_press_timeout")
            col.addView(Ui.section(ctx, host.theme, "Long-press delay" + (cur?.let { "  (now $it ms)" } ?: "")))
            val lpValues = listOf<Int?>(null, 250, 350, 500)
            val lpSel = lpValues.indexOf(longPress).let { if (it < 0) 0 else it }
            col.addView(ChipGroup(ctx, host.theme, listOf("Default", "250 ms", "350 ms", "500 ms"), lpSel, 4) { i ->
                longPress = lpValues[i]
                applyTouch()
            })

            if (engine.hasTouchSensitivityKey()) {
                col.addView(Ui.section(ctx, host.theme, "Touch sensitivity"))
                col.addView(ChipGroup(ctx, host.theme, listOf("Normal", "High"), if (sens) 1 else 0, 2) { i ->
                    sens = i == 1
                    applyTouch()
                })
            }

            col.addView(Ui.section(ctx, host.theme, "Mouse / trackpad"))
            val curSpeed = p0.pointerSpeed ?: 0
            col.addView(Ui.labeledSlider(ctx, host.theme, "Pointer speed", "", -7, 7, curSpeed) { v ->
                host.scope.launch {
                    host.deps.repo.update(host.game) { it.copy(pointerSpeed = v) }
                    val r = engine.setPointerSpeed(v)
                    show(res, host, r.ok, if (r.ok) "Pointer speed $v (mouse / trackpad only)" else r.step + ": " + r.detail)
                    host.refreshTiles()
                }
            })
            col.addView(Ui.button(ctx, host.theme, "Restore original speed") {
                host.scope.launch {
                    host.deps.repo.update(host.game) { it.copy(pointerSpeed = null) }
                    val r = engine.restorePointerSpeed()
                    show(res, host, r.ok, if (r.ok) "Original speed restored" else r.step + ": " + r.detail)
                    host.refreshTiles()
                }
            })
            col.addView(res)
            host.openDetail("Touch response", col)
        }
    }

    // ---- Visual filter: saturation, colour balance, shadow boost, extra dimmer ----
    private class FilterTool : HudTool("filter") {
        override fun isActive(host: ToolHost) = profileOf(host).filter.enabled

        override fun onTap(host: ToolHost) {
            val ctx = host.hostContext
            val engine = host.deps.engine
            val col = Ui.vbox(ctx)
            val matrix = host.deps.bridge.hasShell()
            col.addView(note(host,
                if (matrix) "Real per-pixel colour grading through SurfaceFlinger (the same mechanism as Night Light): " +
                    "saturation, RGB balance, shadow lift and a dimmer that goes below the minimum brightness. Removed after the game."
                else "No Shizuku or root, so this runs in overlay mode: only the dimmer, a colour tint and a shadow lift work. " +
                    "Saturation needs Shizuku or root."
            ))
            val res = resultView(host)
            var cfg = profileOf(host).filter

            fun commit(next: VisualFilterConfig, rebuild: Boolean = false) {
                cfg = next.copy(enabled = !ColorMath.isIdentity(next))
                host.deps.repo.update(host.game) {
                    it.copy(filter = cfg.copy(brightnessLock = it.filter.brightnessLock, brightnessLevel = it.filter.brightnessLevel))
                }
                host.scope.launch {
                    val r = if (cfg.enabled) engine.setVisualFilter(cfg) else engine.clearVisualFilter()
                    show(res, host, r.ok, r.detail.ifBlank { r.step })
                    host.refreshTiles()
                }
                if (rebuild) onTap(host)
            }

            col.addView(Ui.section(ctx, host.theme, "Presets"))
            col.addView(ChipGroup(
                ctx, host.theme, listOf("Off", "Night vision", "Vibrant", "Warm", "Midnight"), -1, 3
            ) { i ->
                val base = VisualFilterConfig()
                commit(
                    when (i) {
                        1 -> base.copy(shadowBoostPct = 70, saturationPct = 120)
                        2 -> base.copy(saturationPct = 160, warmthPct = 55)
                        3 -> base.copy(warmthPct = 80)
                        4 -> base.copy(extraDimPct = 70, warmthPct = 75, saturationPct = 90)
                        else -> base
                    },
                    rebuild = true
                )
            })

            col.addView(Ui.labeledSlider(ctx, host.theme, "Saturation", " %", 0, 200, cfg.saturationPct) { v -> commit(cfg.copy(saturationPct = v)) })
            col.addView(Ui.labeledSlider(ctx, host.theme, "Warmth (cool to warm)", " %", 0, 100, cfg.warmthPct) { v -> commit(cfg.copy(warmthPct = v)) })
            col.addView(Ui.labeledSlider(ctx, host.theme, "Red", " %", 0, 100, cfg.redPct) { v -> commit(cfg.copy(redPct = v)) })
            col.addView(Ui.labeledSlider(ctx, host.theme, "Green", " %", 0, 100, cfg.greenPct) { v -> commit(cfg.copy(greenPct = v)) })
            col.addView(Ui.labeledSlider(ctx, host.theme, "Blue", " %", 0, 100, cfg.bluePct) { v -> commit(cfg.copy(bluePct = v)) })
            col.addView(Ui.labeledSlider(ctx, host.theme, "Shadow boost", " %", 0, 100, cfg.shadowBoostPct) { v -> commit(cfg.copy(shadowBoostPct = v)) })
            col.addView(Ui.labeledSlider(ctx, host.theme, "Extra dimmer", " %", 0, 85, cfg.extraDimPct) { v -> commit(cfg.copy(extraDimPct = v)) })
            col.addView(res)
            host.openDetail("Visual filter", col)
        }
    }
}
