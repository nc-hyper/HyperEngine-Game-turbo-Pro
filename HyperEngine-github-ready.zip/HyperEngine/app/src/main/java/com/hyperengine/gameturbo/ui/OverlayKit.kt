package com.hyperengine.gameturbo.ui

import android.graphics.PixelFormat
import android.graphics.Point
import android.os.Build
import android.view.Gravity
import android.view.WindowManager
import com.hyperengine.gameturbo.core.ColorMath

/** Window-parameter helpers shared by the Phase 5 overlays. Everything is positioned from the screen's top-left. */
object OverlayKit {

    @Suppress("DEPRECATION")
    fun realSize(wm: WindowManager): Point = Point().also { wm.defaultDisplay.getRealSize(it) }

    /**
     * [touchable] false = every touch goes to the app underneath. Such a window is pinned at alpha 0.79:
     * Android blocks touches that pass through an overlay above 0.8, which would break the game.
     */
    fun params(
        w: Int,
        h: Int,
        title: String,
        touchable: Boolean,
        focusable: Boolean = false
    ): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        if (!focusable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        val p = WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.LEFT
        p.title = title
        if (!touchable) p.alpha = ColorMath.MAX_OVERLAY_ALPHA
        if (Build.VERSION.SDK_INT >= 28) {
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return p
    }

    fun setFlag(p: WindowManager.LayoutParams, flag: Int, on: Boolean) {
        p.flags = if (on) p.flags or flag else p.flags and flag.inv()
    }

    /** Applies the touchable / focusable state to an existing params object. */
    fun setTouchable(p: WindowManager.LayoutParams, touchable: Boolean) {
        setFlag(p, WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, !touchable)
        p.alpha = if (touchable) 1f else ColorMath.MAX_OVERLAY_ALPHA
    }

    fun setFocusable(p: WindowManager.LayoutParams, focusable: Boolean) {
        setFlag(p, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, !focusable)
        p.softInputMode = if (focusable) WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN else 0
    }
}
