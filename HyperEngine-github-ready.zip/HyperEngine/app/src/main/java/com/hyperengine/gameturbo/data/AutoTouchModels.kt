package com.hyperengine.gameturbo.data

import java.util.Locale

// =============================================================================================
// Auto-Touch / Commands persistence models (Realme / OPPO Game Assistant style)
//
// Every field has a default so an older scripts.json keeps loading after fields are added.
// All coordinates that live on the game screen are stored as FRACTIONS (0..1) of the screen so a
// saved layout survives a resolution or orientation change; only floating-button positions are px.
// =============================================================================================

/** How the script fires. Matches the three Realme / OPPO trigger modes. */
enum class TriggerMode {
    /** Loops the numbered tap / swipe nodes until paused. */
    CONTINUOUS,

    /** Fires rapid taps at node 1 only while the auxiliary button (or volume key) is held. */
    HOLD_RAPID_FIRE,

    /** One tap on the auxiliary button replays a recorded multi-touch command at its recorded timings. */
    COMBO_MACRO
}

enum class NodeKind { TAP, SWIPE }

enum class LoopMode { INFINITE, COUNT, TIMER }

enum class MacroEventType { DOWN, MOVE, UP }

/** Anti-detection humanizer: random offset inside the target circle and random interval jitter. */
data class HumanizerConfig(
    val enabled: Boolean = true,
    val offsetPx: Int = 4,       // 0..12, +/- px around the node centre
    val jitterMs: Int = 8        // 0..50, +/- ms on every interval
) {
    fun clamped() = copy(offsetPx = offsetPx.coerceIn(0, 12), jitterMs = jitterMs.coerceIn(0, 50))
}

/** Speed, hold time and loop limits. Used globally per script and optionally overridden per node. */
data class TimingConfig(
    val useCps: Boolean = true,
    val cps: Int = 10,                 // 1..40 clicks per second
    val intervalMs: Int = 100,         // 20..10000 ms (used when useCps is false)
    val holdMs: Int = 20,              // 10..5000 ms touch hold (10 = instant tap, 5000 = long press)
    val loopMode: LoopMode = LoopMode.INFINITE,
    val loopCount: Int = 10,           // LoopMode.COUNT: stop after N cycles (1..100000)
    val timerSeconds: Int = 300,       // LoopMode.TIMER: stop after this long (1m = 60, 5m = 300, 30m = 1800)
    val humanizer: HumanizerConfig = HumanizerConfig()
) {
    /** Milliseconds between two taps, whichever of CPS / custom interval is selected. */
    fun effectiveIntervalMs(): Int =
        if (useCps) (1000 / cps.coerceIn(CPS_MIN, CPS_MAX)).coerceAtLeast(INTERVAL_MIN_MS)
        else intervalMs.coerceIn(INTERVAL_MIN_MS, INTERVAL_MAX_MS)

    fun clamped() = copy(
        cps = cps.coerceIn(CPS_MIN, CPS_MAX),
        intervalMs = intervalMs.coerceIn(INTERVAL_MIN_MS, INTERVAL_MAX_MS),
        holdMs = holdMs.coerceIn(HOLD_MIN_MS, HOLD_MAX_MS),
        loopCount = loopCount.coerceIn(1, 100_000),
        timerSeconds = timerSeconds.coerceIn(1, 24 * 3600),
        humanizer = humanizer.clamped()
    )

    companion object {
        const val CPS_MIN = 1
        const val CPS_MAX = 40
        const val INTERVAL_MIN_MS = 20
        const val INTERVAL_MAX_MS = 10_000
        const val HOLD_MIN_MS = 10
        const val HOLD_MAX_MS = 5_000
    }
}

/** One numbered target reticle (1..10). SWIPE nodes also carry the end point. */
data class TouchNode(
    val id: Int = 1,                       // 1..10, shown on the reticle
    val kind: NodeKind = NodeKind.TAP,
    val x: Float = 0.5f,
    val y: Float = 0.5f,
    val endX: Float = 0.5f,                // SWIPE only
    val endY: Float = 0.5f,
    val swipeDurationMs: Int = 300,        // 50..5000
    val enabled: Boolean = true,
    val timing: TimingConfig? = null       // null = use the script's timing
) {
    fun clamped() = copy(
        id = id.coerceIn(1, AutoTouchScript.MAX_NODES),
        x = x.coerceIn(0f, 1f), y = y.coerceIn(0f, 1f),
        endX = endX.coerceIn(0f, 1f), endY = endY.coerceIn(0f, 1f),
        swipeDurationMs = swipeDurationMs.coerceIn(50, 5_000),
        timing = timing?.clamped()
    )
}

/** One raw touch sample of a recorded command. tMs is the offset from the first sample. */
data class MacroEvent(
    val tMs: Long = 0L,
    val type: MacroEventType = MacroEventType.DOWN,
    val slot: Int = 0,                     // which finger of the recording (0..3)
    val x: Float = 0f,                     // fraction of screen width
    val y: Float = 0f                      // fraction of screen height
)

/** A recorded multi-touch "Command" (Realme Commands / combo macro). */
data class CommandMacro(
    val id: String = "",
    val name: String = "",
    val durationMs: Long = 0L,
    val events: List<MacroEvent> = emptyList(),
    val createdAt: Long = 0L
) {
    fun clamped(): CommandMacro {
        val ev = events.asSequence()
            .take(AutoTouchScript.MAX_EVENTS_PER_MACRO)
            .map { it.copy(tMs = it.tMs.coerceAtLeast(0L), slot = it.slot.coerceIn(0, 3), x = it.x.coerceIn(0f, 1f), y = it.y.coerceIn(0f, 1f)) }
            .toList()
        return copy(durationMs = (ev.lastOrNull()?.tMs ?: 0L), events = ev)
    }
}

/** The floating "1-tap Command trigger" button placed on the game screen. */
data class AuxButton(
    val id: String = "",
    val label: String = "",
    val x: Int = -1,                       // px, -1 = default spot
    val y: Int = -1,
    val sizeDp: Int = 56,                  // 40..96
    val mode: TriggerMode = TriggerMode.COMBO_MACRO,
    val macroId: String? = null,           // COMBO_MACRO: which recorded command to replay
    val nodeId: Int = 1                    // HOLD_RAPID_FIRE: which node to hammer
)

/** A named layout saved for one game package. A game can own many of these. */
data class AutoTouchScript(
    val id: String = "",
    val name: String = "",
    val packageName: String = "",
    val mode: TriggerMode = TriggerMode.CONTINUOUS,
    val nodes: List<TouchNode> = emptyList(),
    val timing: TimingConfig = TimingConfig(),
    val macros: List<CommandMacro> = emptyList(),
    val auxButtons: List<AuxButton> = emptyList(),
    val volumeKeyTrigger: Boolean = false, // physical volume key acts as the hold-to-fire trigger
    val dockX: Int = -1,                   // floating control dock position, px, -1 = default
    val dockY: Int = -1,
    val createdAt: Long = 0L,
    val updatedAt: Long = 0L
) {
    /** Returns a copy with every value forced into its legal range. */
    fun sanitized(): AutoTouchScript = copy(
        name = name.trim().take(MAX_NAME).ifBlank { "Layout" },
        nodes = nodes.take(MAX_NODES).mapIndexed { i, n -> n.copy(id = i + 1).clamped() },
        timing = timing.clamped(),
        macros = macros.take(MAX_MACROS).map { it.clamped() },
        auxButtons = auxButtons.take(MAX_AUX).map { it.copy(sizeDp = it.sizeDp.coerceIn(40, 96), nodeId = it.nodeId.coerceIn(1, MAX_NODES)) }
    )

    fun summary(): String = String.format(
        Locale.US, "%d point(s), %d command(s), %s",
        nodes.size, macros.size, mode.name.lowercase(Locale.US).replace('_', ' ')
    )

    companion object {
        const val MAX_NODES = 10
        const val MAX_MACROS = 16
        const val MAX_AUX = 6
        const val MAX_EVENTS_PER_MACRO = 12_000
        const val MAX_NAME = 40
        const val MAX_PER_GAME = 32
    }
}

/** On-disk shape of scripts.json. */
data class ScriptStore(
    val version: Int = 1,
    val scripts: LinkedHashMap<String, List<AutoTouchScript>> = LinkedHashMap(),   // package -> layouts
    val active: LinkedHashMap<String, String> = LinkedHashMap()                     // package -> active layout id
)
