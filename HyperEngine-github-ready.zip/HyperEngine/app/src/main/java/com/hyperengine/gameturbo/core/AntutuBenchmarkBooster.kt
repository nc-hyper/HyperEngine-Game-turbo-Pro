package com.hyperengine.gameturbo.core

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.StatFs
import android.os.SystemClock
import android.provider.Telephony
import android.telecom.TelecomManager
import com.hyperengine.gameturbo.HyperApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

// ───────────────────────────── Types ─────────────────────────────

data class BenchTarget(val pkg: String, val label: String)

/** What "Benchmark & Max Hardware Boost" does. Every switch is independent; [compile] is slow, so it is off by default. */
data class BoostOptions(
    /** Packages to uncap and compile. Empty = every known benchmark app that is installed. */
    val targets: List<String> = emptyList(),
    val compile: Boolean = false,       // AOT `cmd package compile -m speed -f` (minutes per app)
    val storage: Boolean = true,        // trim-caches + idle-maintenance + sm fstrim
    val purge: Boolean = true,          // am kill-all + force-stop of running, non-whitelisted user apps
    val network: Boolean = true,        // pause account sync + block background data
    val thermal: Boolean = true,        // cmd thermalservice override-status 0
    val performance: Boolean = true,    // fixed-performance mode, Battery Saver off, ROM performance keys
    val panel: Boolean = true,          // max refresh rate + GameManager fps override for every target
    val keep: Set<String> = emptySet(), // extra packages the purge must never stop
    val tempLimitC: Float = 45f         // battery temperature that ends the boost by itself
)

data class BoostReport(
    val steps: List<StepResult>,
    val ramFreeBeforeMb: Long,
    val ramFreeAfterMb: Long,
    val tempC: Float,
    val thermalBefore: String,
    val thermalAfter: String,
    val ms: Long
) {
    val failures: Int get() = steps.count { !it.ok }
    val ramGainedMb: Long get() = ramFreeAfterMb - ramFreeBeforeMb
}

data class BoostState(
    val active: Boolean = false,
    val busy: String? = null,
    val installed: List<BenchTarget> = emptyList(),
    val tempC: Float = 0f,                 // live battery temperature (0 = unknown)
    val limitC: Float = 45f,
    val thermalStatus: String = "",        // what Android's thermal framework reports right now
    val stopReason: String? = null,        // set when the safety limit (or another screen) ended the boost
    val report: BoostReport? = null
)

// ───────────────────────────── Engine ─────────────────────────────

/**
 * "Benchmark & Max Hardware Boost". Everything runs through Shizuku / root shell commands and public APIs, so it
 * works on a locked bootloader, and every change is undone by [release] (or [recoverPending] after a crash).
 *
 *  1. AOT:      `cmd package compile -m speed -f <pkg>` for the benchmark apps ([compile]).
 *  2. Storage:  `pm trim-caches 999G`, `cmd activity idle-maintenance`, `sm fstrim`.
 *  3. RAM:      `am kill-all` + force-stop of RUNNING third-party apps that are not whitelisted; the free-RAM
 *               gain is measured with ActivityManager.MemoryInfo, not estimated.
 *  4. Network:  account sync paused and background data blocked (both tracked by OptimizationEngine).
 *  5. Thermal:  `cmd thermalservice override-status 0`, reset on exit, and automatically when the battery reaches
 *               [BoostOptions.tempLimitC].
 *  6. Clocks:   `cmd power set-fixed-performance-mode-enabled true`, `cmd power set-mode 0` (Battery Saver off),
 *               plus the HyperOS / Realme performance keys.
 *  7. UX:       max panel refresh rate through [MaxPanelHzEngine] and a GameManager performance + fps override
 *               (cmd game + device_config game_overlay) for AnTuTu / 3DMark / Geekbench / PCMark.
 *
 * Honest limits, so nobody is surprised by a score:
 *  - The thermal override changes what Android REPORTS to apps and games (many games and benchmarks downclock
 *    themselves from that signal). The kernel / vendor thermal engine still protects the chip, which is why the
 *    battery-temperature cut-off exists.
 *  - Fixed-performance mode needs PowerHAL support; the step reports what the ROM answered.
 *  - The ROM performance keys are written, but only the ROM decides whether it reads them.
 *  - A score depends on the silicon. This removes the software reasons a phone scores lower than it could.
 */
class AntutuBenchmarkBooster private constructor(
    private val ctx: Context,
    private val bridge: SystemBridgeExecutor,
    private val engine: OptimizationEngine,
    private val fps: FpsRefreshRateEnforcer,
    private val maxHz: MaxPanelHzEngine
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val main = Handler(Looper.getMainLooper())
    private val mutex = Mutex()          // engage / release / recover
    private val compileMutex = Mutex()   // a long AOT compile must never block a safety release
    private val prefs = ctx.getSharedPreferences("hyper_bench", Context.MODE_PRIVATE)
    private val pm: PackageManager = ctx.packageManager
    private val power = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager

    private val _state = MutableStateFlow(BoostState())
    val state: StateFlow<BoostState> = _state.asStateFlow()

    @Volatile private var engagedFlag = false
    @Volatile private var engineHeld = false
    private var netHeld = false
    private var syncHeld = false
    private var watchJob: Job? = null

    init {
        _state.update { it.copy(installed = installedTargets(), tempC = batteryTempC(), thermalStatus = thermalLabel()) }
        // If the phone is restored from another screen (HUD "Restore"), our engine-tracked changes are gone: stand down too.
        scope.launch {
            var was = false
            engine.status.map { it.sessionActive }.distinctUntilChanged().collect { active ->
                if (was && !active && engagedFlag && engineHeld) {
                    release("the phone was restored from another screen", tripped = true)
                }
                was = active
            }
        }
    }

    // ───────────────────── Read-outs ─────────────────────

    /** Known benchmark apps that are installed (needs no privileges). */
    fun installedTargets(): List<BenchTarget> = KNOWN.filter { isInstalled(it.pkg) }

    /**
     * Packages the running boost uncapped (the GameManager overrides it recorded). Falls back to the installed benchmark apps
     * when none was recorded. [GameSessionGuard] uses it to see when the app the boost was for has been closed.
     */
    fun engagedTargets(): Set<String> = loadGames().toSet().ifEmpty { installedTargets().map { it.pkg }.toSet() }

    fun batteryTempC(): Float {
        val i = runCatching { ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) }.getOrNull()
            ?: return 0f
        val t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        return if (t == Int.MIN_VALUE) 0f else t / 10f
    }

    /** Android's thermal status as an app sees it (NONE .. SHUTDOWN); "n/a" below Android 10. */
    fun thermalLabel(): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return "n/a"
        return when (runCatching { power.currentThermalStatus }.getOrDefault(-1)) {
            0 -> "NONE"
            1 -> "LIGHT"
            2 -> "MODERATE"
            3 -> "SEVERE"
            4 -> "CRITICAL"
            5 -> "EMERGENCY"
            6 -> "SHUTDOWN"
            else -> "unknown"
        }
    }

    /** Refreshes the temperature / thermal / installed-app read-outs while the boost is off (call from the lobby). */
    fun refreshInfo() {
        _state.update { it.copy(installed = installedTargets(), tempC = batteryTempC(), thermalStatus = thermalLabel()) }
    }

    private fun availMb(): Long {
        val mi = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        return mi.availMem / 1_048_576L
    }

    private fun freeStorageMb(): Long =
        runCatching { StatFs(Environment.getDataDirectory().path).availableBytes / 1_048_576L }.getOrDefault(0L)

    private fun isInstalled(pkg: String): Boolean = try {
        @Suppress("DEPRECATION")
        pm.getPackageInfo(pkg, 0)
        true
    } catch (_: Throwable) {
        false
    }

    private fun labelOf(pkg: String): String = try {
        @Suppress("DEPRECATION")
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (_: Throwable) {
        pkg
    }

    private fun f1(v: Float) = String.format(Locale.US, "%.1f", v)

    private fun busy(text: String?) = _state.update { it.copy(busy = text) }

    private fun resolveTargets(opts: BoostOptions): List<BenchTarget> {
        if (opts.targets.isEmpty()) return installedTargets()
        return opts.targets.filter { Validators.PACKAGE.matches(it) && isInstalled(it) }
            .distinct().map { p -> KNOWN.firstOrNull { it.pkg == p } ?: BenchTarget(p, labelOf(p)) }
    }

    // ───────────────────── 1. AOT speed compile (standalone and part of engage) ─────────────────────

    /**
     * `cmd package compile -m speed -f` for each target, so every DEX method is native code before the run (no JIT
     * warm-up in the UX and CPU tests). Slow: minutes per app. Cancel the returned job to stop the running compile.
     */
    suspend fun compile(pkgs: List<String> = emptyList()): List<StepResult> = compileMutex.withLock {
        if (!bridge.hasShell()) return@withLock listOf(StepResult("AOT speed compile", false, "needs Shizuku or root"))
        val targets = resolveTargets(BoostOptions(targets = pkgs))
        if (targets.isEmpty()) {
            return@withLock listOf(StepResult("AOT speed compile", false, "no benchmark app is installed (AnTuTu, 3DMark, Geekbench ...)"))
        }
        val out = ArrayList<StepResult>()
        try {
            targets.forEachIndexed { i, t ->
                busy("AOT compiling ${t.label} (${i + 1}/${targets.size}), this can take minutes")
                val t0 = SystemClock.elapsedRealtime()
                val r = engine.compileGame(t.pkg, CompileMode.FULL)
                val sec = (SystemClock.elapsedRealtime() - t0) / 1000
                out += StepResult(
                    "AOT speed compile: ${t.label}", r.ok,
                    if (r.ok) "all DEX compiled to native code in ${sec}s" else r.detail
                )
            }
        } finally {
            busy(null)
        }
        out
    }

    fun compileAsync(pkgs: List<String> = emptyList(), onDone: ((List<StepResult>) -> Unit)? = null): Job = scope.launch {
        val r = compile(pkgs)
        if (onDone != null) main.post { onDone(r) }
    }

    // ───────────────────── 2. Storage ─────────────────────

    private suspend fun storageStep(): List<StepResult> {
        val out = ArrayList<StepResult>()
        val before = freeStorageMb()
        busy("Trimming caches and running idle maintenance")
        val trim = engine.trimShaderCaches(runIdleMaintenance = true) // pm trim-caches 999G + cmd activity idle-maintenance
        out += StepResult("Cache trim + idle maintenance", trim.ok, if (trim.ok) "free storage ${before} -> ${freeStorageMb()} MB" else trim.detail)

        busy("Running fstrim on flash storage")
        val r = bridge.shell("sm fstrim", 300_000L)
        val text = (r.stdout + " " + r.stderr).trim()
        val bad = (!r.ok && r.exitCode != -2) || text.contains("Exception", true) || text.startsWith("Error", true)
        out += StepResult(
            "sm fstrim", !bad,
            when {
                r.exitCode == -2 -> "still running after 5 min; vold finishes it in the background"
                bad -> text.ifBlank { "exit ${r.exitCode}" }.take(160)
                else -> "free flash blocks trimmed in ${r.ms} ms"
            }
        )
        return out
    }

    // ───────────────────── 3. RAM purge ─────────────────────

    private fun protectedSet(extra: Collection<String>): Set<String> {
        val set = hashSetOf(
            ctx.packageName, "android", "com.android.systemui", "com.android.phone", "com.android.server.telecom",
            "com.android.providers.telephony", "com.android.providers.settings",
            "moe.shizuku.privileged.api", "com.topjohnwu.magisk", "me.weishu.kernelsu"
        )
        set += extra
        runCatching {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            pm.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName?.let { set += it }
        }
        runCatching {
            bridge.getSetting(Ns.SECURE, "default_input_method")?.substringBefore('/')?.takeIf { it.isNotBlank() }?.let { set += it }
        }
        runCatching { (ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).defaultDialerPackage?.let { set += it } }
        runCatching { Telephony.Sms.getDefaultSmsPackage(ctx)?.let { set += it } }
        // accessibility services, notification listeners and the always-on VPN keep the phone usable: never stop them
        for (key in listOf("enabled_accessibility_services", "enabled_notification_listeners")) {
            bridge.getSetting(Ns.SECURE, key).orEmpty().split(':')
                .map { it.substringBefore('/') }.filter { it.isNotBlank() }.forEach { set += it }
        }
        bridge.getSetting(Ns.SECURE, "always_on_vpn_app")?.takeIf { it.isNotBlank() }?.let { set += it }
        return set
    }

    /** Third-party packages that have a live process right now; null when the process list cannot be read. */
    private suspend fun runningThirdParty(): Set<String>? {
        val list = bridge.shell("pm list packages -3", 15_000L)
        if (!list.ok) return null
        val third = list.stdout.lineSequence().map { it.trim().removePrefix("package:") }
            .filter { Validators.PACKAGE.matches(it) }.toSet()
        var ps = bridge.shell("ps -A -o NAME", 15_000L)
        if (!ps.ok || ps.stdout.isBlank()) ps = bridge.shell("ps -A", 15_000L)
        if (!ps.ok || ps.stdout.isBlank()) return null
        val running = ps.stdout.lineSequence().map { it.trim().substringAfterLast(' ').substringBefore(':') }
            .filter { Validators.PACKAGE.matches(it) }.toSet()
        return third.filter { it in running }.toSet()
    }

    private suspend fun purgeStep(keep: Set<String>, targets: List<BenchTarget>): StepResult {
        busy("Freeing RAM")
        val before = availMb()
        val live = runningThirdParty()
        val safe = protectedSet(keep + targets.map { it.pkg })
        val victims = (live ?: emptySet()).filter { it !in safe && !it.contains("shizuku", true) }.take(MAX_VICTIMS)
        val cmds = ArrayList<BatchCmd>()
        cmds += BatchCmd("am kill-all", "am kill-all")
        // `cmd activity force-stop` is what `am force-stop` runs, without starting a Java process per app
        victims.forEach {
            cmds += BatchCmd("force-stop $it", "cmd activity force-stop $it", invalid = if (Validators.PACKAGE.matches(it)) null else "package")
        }
        val b = bridge.runBatch(cmds, timeoutMs = 90_000L)
        delay(800L) // let the low-memory killer settle before measuring
        val after = availMb()
        val killAll = b["am kill-all"]?.ok == true
        val stopped = b.items.drop(1).count { it.result.ok }
        val ok = killAll || stopped > 0
        val note = if (live == null) "; running apps could not be listed, only cached processes were killed" else ""
        return StepResult(
            "RAM purge", ok,
            if (ok) "killed cached processes, stopped $stopped running app(s), free RAM $before -> $after MB$note"
            else (b["am kill-all"]?.message ?: "am kill-all failed")
        )
    }

    // ───────────────────── 5 + 6. Thermal, fixed performance, Battery Saver, ROM keys ─────────────────────

    private suspend fun thermalAndPowerStep(opts: BoostOptions): List<StepResult> {
        val out = ArrayList<StepResult>()
        val thermalBefore = thermalLabel()
        val saverWasOn = runCatching { power.isPowerSaveMode }.getOrDefault(false)
        // intent goes to disk BEFORE the commands run, so a crash can never leave the override behind unnoticed
        val e = prefs.edit()
        if (opts.thermal) e.putBoolean(K_THERMAL, true)
        if (opts.performance) e.putBoolean(K_FIXED, true).putBoolean(K_SAVER, saverWasOn)
        e.apply()

        busy("Applying thermal and performance modes")
        val b = bridge.runBatch {
            if (opts.thermal) cmd("thermalservice", "override-status", "0", strict = true)
            if (opts.performance) {
                cmd("power", "get-fixed-performance-mode-supported")
                cmd("power", "set-fixed-performance-mode-enabled", "true", strict = true)
                cmd("power", "set-mode", "0", strict = true)
            }
        }
        delay(300L)

        if (opts.thermal) {
            val r = b["cmd thermalservice override-status 0"]
            val now = thermalLabel()
            val ok = r?.ok == true
            if (!ok) prefs.edit().putBoolean(K_THERMAL, false).apply()
            out += StepResult(
                "Thermal override (status NONE)", ok && (now == "NONE" || now == "n/a"),
                when {
                    !ok -> r?.message ?: "not run"
                    now == "NONE" || now == "n/a" -> "Android reports thermal status NONE (was $thermalBefore); the vendor thermal engine still guards the chip"
                    else -> "command accepted but the status still reads $now; this ROM ignores the override"
                }
            )
        }
        if (opts.performance) {
            val sup = b["cmd power get-fixed-performance-mode-supported"]?.stdout?.trim().orEmpty()
            val fix = b["cmd power set-fixed-performance-mode-enabled true"]
            val fixOk = fix?.ok == true
            if (!fixOk) prefs.edit().putBoolean(K_FIXED, false).apply()
            val unsupported = sup.equals("false", true)
            out += StepResult(
                "Fixed performance mode", fixOk && !unsupported,
                when {
                    !fixOk -> fix?.message ?: "not run"
                    unsupported -> "accepted, but this phone's PowerHAL reports it is unsupported, so clocks are unchanged"
                    else -> "CPU / GPU fixed-performance mode on" + if (sup.isNotBlank()) " (supported: $sup)" else ""
                }
            )
            val saver = b["cmd power set-mode 0"]
            val saverNow = runCatching { power.isPowerSaveMode }.getOrDefault(false)
            if (saver?.ok != true || !saverWasOn) prefs.edit().putBoolean(K_SAVER, false).apply()
            out += StepResult(
                "Battery Saver off", saver?.ok == true && !saverNow,
                when {
                    saver?.ok != true -> saver?.message ?: "not run"
                    saverNow -> "command ran but Battery Saver is still on"
                    saverWasOn -> "turned off (will be switched back on at the end)"
                    else -> "already off"
                }
            )
            out += romPerformanceKeys()
        }
        return out
    }

    private suspend fun romPerformanceKeys(): List<StepResult> {
        val rom = maxHz.detectRom()
        val writes = when (rom) {
            RomFamily.XIAOMI -> listOf(SettingWrite(Ns.SYSTEM, "power_mode", "high"), SettingWrite(Ns.SYSTEM, "speed_mode", "1"))
            RomFamily.OPLUS -> listOf(
                SettingWrite(Ns.SYSTEM, "high_performance_mode_on", "1"),
                SettingWrite(Ns.GLOBAL, "high_performance_mode_on", "1")
            )
            RomFamily.STOCK -> emptyList()
        }
        if (writes.isEmpty()) return listOf(StepResult("ROM performance keys", true, "none for this ROM; the generic steps above apply"))
        // originals to disk before the first write; an original already on disk is never replaced by our own value
        val saved = loadSnaps()
        val fresh = bridge.snapshotSettings(writes.map { it.ns to it.key }).filter { n -> saved.none { it.ns == n.ns && it.key == n.key } }
        saveSnaps(saved + fresh)
        val res = bridge.applySettings(writes)
        return writes.mapIndexed { i, w ->
            StepResult(
                "${rom.label}: ${w.ns.cmd}/${w.key}=${w.value}", res[i].ok,
                if (res[i].ok) "written (the ROM decides whether it reads this key)" else res[i].message
            )
        }
    }

    // ───────────────────── 7. Panel + GameManager uncapper ─────────────────────

    private suspend fun panelStep(targets: List<BenchTarget>): List<StepResult> {
        val out = ArrayList<StepResult>()
        val hz = maxHz.caps()?.hzInt ?: 0
        // A lock the HUD already holds is not ours to release: reuse it and leave it alone at the end.
        val already = maxHz.state.value.engaged
        busy("Locking ${if (hz > 0) "$hz Hz" else "max refresh rate"}")
        if (already) {
            out += StepResult("Panel lock", true, "max refresh rate is already locked by the HUD; left as it is")
        } else {
            prefs.edit().putBoolean(K_PANEL, true).apply() // before the first change
            val rep = maxHz.engage(null) // panel keys + OEM throttler freeze + watchdog + Realme/OPPO keys
            out += rep.layers.map { it.copy(step = "Panel: ${it.step}") }
        }
        if (hz <= 0) return out
        for (t in targets) {
            addGame(t.pkg) // persisted before the first change
            out += engine.setGameMode(t.pkg, GameModeLevel.PERFORMANCE, null, hz).map { it.copy(step = "${t.label}: ${it.step}") }
            if (!already) { // its restore rides on our own panel release
                val o = fps.overrideGameOverlay(t.pkg, hz, null)
                out += o.copy(step = "${t.label}: ${o.step}")
            }
        }
        val shown = maxHz.currentHz()
        out += StepResult(
            "UX uncapper", shown >= hz - 1,
            "display reports $shown Hz of $hz Hz; " +
                (if (targets.isEmpty()) "no benchmark app installed, system-wide lock only"
                else targets.joinToString { it.label } + " requested at $hz Hz")
        )
        return out
    }

    // ───────────────────── Engage ─────────────────────

    /** Turns the whole boost on. Idempotent: calling it while engaged returns the last report. */
    suspend fun engage(opts: BoostOptions = BoostOptions()): BoostReport {
        val t0 = SystemClock.elapsedRealtime()
        val targets = resolveTargets(opts)
        val steps = ArrayList<StepResult>()

        // The long AOT compile runs first and outside the engage lock, so a safety release is never blocked by it.
        if (opts.compile && !engagedFlag) {
            steps += if (targets.isEmpty()) listOf(StepResult("AOT speed compile", false, "no benchmark app is installed (AnTuTu, 3DMark, Geekbench ...)"))
            else compile(targets.map { it.pkg })
        }

        return mutex.withLock {
            _state.value.report?.takeIf { engagedFlag }?.let { return@withLock it }
            val limit = opts.tempLimitC.coerceIn(35f, 50f)
            val ramBefore = availMb()
            val thermalBefore = thermalLabel()
            fun finish(ok: Boolean): BoostReport {
                val rep = BoostReport(
                    steps, ramBefore, availMb(), batteryTempC(), thermalBefore, thermalLabel(), SystemClock.elapsedRealtime() - t0
                )
                _state.update {
                    it.copy(
                        active = ok, busy = null, installed = installedTargets(), tempC = rep.tempC,
                        limitC = limit, thermalStatus = rep.thermalAfter, stopReason = null, report = rep
                    )
                }
                return rep
            }

            if (!bridge.hasShell()) {
                steps += StepResult("Benchmark boost", false, "needs Shizuku or root; nothing was changed")
                return@withLock finish(false)
            }
            val temp0 = batteryTempC()
            if (temp0 >= limit) {
                steps += StepResult("Safety check", false, "battery is ${f1(temp0)} °C, over the ${f1(limit)} °C limit; let it cool first, nothing was changed")
                return@withLock finish(false)
            }
            steps += StepResult("Safety check", true, "battery ${f1(temp0)} °C, auto-restore at ${f1(limit)} °C")
            // anything a crashed run left behind goes back first, so the snapshots below hold the true originals
            if (hasPending()) steps += restorePendingLocked(inProcess = false)

            try {
                _state.update { it.copy(busy = "Starting benchmark boost", limitC = limit) }
                if (opts.storage) steps += storageStep()
                if (opts.purge) steps += purgeStep(opts.keep, targets)
                if (opts.network) {
                    busy("Pausing sync and background data")
                    steps += engine.setBackgroundSyncPaused(true).also { syncHeld = it.ok }
                    steps += engine.setBackgroundDataBlock(true).also { netHeld = it.ok }
                }
                // storage and compile heat the phone: re-check before the modes that stop the thermal framework
                val temp1 = batteryTempC()
                if ((opts.thermal || opts.performance) && temp1 >= limit) {
                    steps += StepResult("Thermal + performance modes", false, "skipped: battery reached ${f1(temp1)} °C during preparation")
                } else if (opts.thermal || opts.performance) {
                    steps += thermalAndPowerStep(opts)
                }
                if (opts.panel) steps += panelStep(targets)
            } catch (t: kotlinx.coroutines.CancellationException) {
                engagedFlag = true // so the restore below runs as an in-process release
                withContext(kotlinx.coroutines.NonCancellable) { restorePendingLocked(inProcess = true) }
                engagedFlag = false
                throw t
            }

            engagedFlag = true
            engineHeld = engine.status.value.sessionActive
            startWatchdog(limit)
            finish(true)
        }
    }

    /** Ends the boost and puts everything back. [tripped] marks a stop that the user did not ask for. */
    suspend fun release(reason: String = "released", tripped: Boolean = false): List<StepResult> = mutex.withLock {
        engagedFlag = false // first, so the temperature watchdog and the engine collector never fight the release
        watchJob?.cancel()
        busy("Restoring the phone")
        val out = restorePendingLocked(inProcess = true)
        engineHeld = false
        _state.update {
            BoostState(
                installed = installedTargets(), tempC = batteryTempC(), limitC = it.limitC, thermalStatus = thermalLabel(),
                stopReason = if (tripped) reason else null, report = it.report
            )
        }
        out
    }

    /** Crash / restart recovery: undoes whatever a dead process left on. Call from app start. */
    suspend fun recoverPending(): List<StepResult> = mutex.withLock {
        if (engagedFlag || !hasPending()) emptyList() else restorePendingLocked(inProcess = false)
    }

    fun engageAsync(opts: BoostOptions = BoostOptions(), onDone: ((BoostReport) -> Unit)? = null): Job = scope.launch {
        val r = engage(opts)
        if (onDone != null) main.post { onDone(r) }
    }

    fun releaseAsync(reason: String = "released", onDone: ((List<StepResult>) -> Unit)? = null): Job = scope.launch {
        val r = release(reason)
        if (onDone != null) main.post { onDone(r) }
    }

    /** Opens a benchmark app. Falls back to `monkey` through the shell when Android blocks the background start. */
    suspend fun launchBenchmark(pkg: String): StepResult {
        if (!Validators.PACKAGE.matches(pkg)) return StepResult("Launch", false, "invalid package")
        val intent = pm.getLaunchIntentForPackage(pkg)
            ?: return StepResult("Launch", false, "${labelOf(pkg)} is not installed or has no launcher activity")
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        val direct = withContext(Dispatchers.Main) { runCatching { ctx.startActivity(intent) }.isSuccess }
        if (direct) return StepResult("Launch", true, "${labelOf(pkg)} opened")
        if (!bridge.hasShell()) return StepResult("Launch", false, "Android blocked the start and there is no shell to fall back on")
        val r = bridge.shell("monkey -p $pkg -c android.intent.category.LAUNCHER 1", 15_000L)
        return StepResult("Launch", r.ok && !r.stdout.contains("No activities found", true), if (r.ok) "${labelOf(pkg)} opened" else r.message)
    }

    // ───────────────────── Temperature watchdog ─────────────────────

    private fun startWatchdog(limitC: Float) {
        watchJob?.cancel()
        watchJob = scope.launch {
            while (isActive) {
                val t = batteryTempC()
                _state.update { it.copy(tempC = t, thermalStatus = thermalLabel()) }
                if (t >= limitC) {
                    // a separate coroutine: release() cancels this job, and a release must never cancel itself
                    scope.launch { release("battery ${f1(t)} °C reached the ${f1(limitC)} °C safety limit", tripped = true) }
                    return@launch
                }
                delay(WATCH_MS)
            }
        }
    }

    // ───────────────────── Restore (one code path for release and crash recovery) ─────────────────────

    private fun hasPending(): Boolean =
        prefs.getBoolean(K_THERMAL, false) || prefs.getBoolean(K_FIXED, false) || prefs.getBoolean(K_SAVER, false) ||
            prefs.getBoolean(K_PANEL, false) || loadGames().isNotEmpty() || loadSnaps().isNotEmpty()

    private suspend fun restorePendingLocked(inProcess: Boolean): List<StepResult> {
        val out = ArrayList<StepResult>()

        // panel first: it frees the refresh-rate keys before the per-game resets run
        if (prefs.getBoolean(K_PANEL, false)) {
            if (inProcess) {
                out += maxHz.release("benchmark boost ended") // also restores the game_overlay values via the FPS enforcer
            } else {
                out += maxHz.recoverPending()
                out += fps.releaseSoft("benchmark boost recovery")
            }
            prefs.edit().putBoolean(K_PANEL, false).apply()
        }
        for (g in loadGames()) {
            val r = engine.resetGameTuning(g)
            out += r.map { it.copy(step = "${labelOf(g)}: ${it.step}") }
            if (r.all { it.ok }) removeGame(g)
        }
        if (netHeld) {
            out += engine.setBackgroundDataBlock(false)
            netHeld = false
        }
        if (syncHeld) {
            out += engine.setBackgroundSyncPaused(false)
            syncHeld = false
        }

        val thermal = prefs.getBoolean(K_THERMAL, false)
        val fixed = prefs.getBoolean(K_FIXED, false)
        val saverFlag = prefs.getBoolean(K_SAVER, false)
        val saver = saverFlag && !runCatching { power.isPowerSaveMode }.getOrDefault(false)
        if (saverFlag && !saver) prefs.edit().putBoolean(K_SAVER, false).apply() // user already switched it back on
        if (thermal || fixed || saver) {
            if (!bridge.hasShell()) {
                out += StepResult("Thermal / power restore", false, "needs Shizuku or root; will retry")
            } else {
                val b = bridge.runBatch {
                    if (thermal) cmd("thermalservice", "reset", strict = true)
                    if (fixed) cmd("power", "set-fixed-performance-mode-enabled", "false", strict = true)
                    if (saver) cmd("power", "set-mode", "1", strict = true)
                }
                fun done(label: String, key: String, name: String, okText: String) {
                    val r = b[label] ?: return
                    if (r.ok) prefs.edit().putBoolean(key, false).apply()
                    out += StepResult(name, r.ok, if (r.ok) okText else r.message)
                }
                if (thermal) done("cmd thermalservice reset", K_THERMAL, "Thermal override reset", "framework thermal status is live again (${thermalLabel()})")
                if (fixed) done("cmd power set-fixed-performance-mode-enabled false", K_FIXED, "Fixed performance mode off", "clocks back under normal control")
                if (saver) done("cmd power set-mode 1", K_SAVER, "Battery Saver restored", "switched back on")
            }
        }
        restoreVendorLocked()?.let { out += it }
        return out
    }

    // ───────────────────── Persistence helpers ─────────────────────

    private suspend fun restoreVendorLocked(): StepResult? {
        val snaps = loadSnaps()
        if (snaps.isEmpty()) return null
        val res = bridge.restoreSnapshots(snaps)
        val remaining = snaps.filterIndexed { i, _ -> !res[i].ok }
        saveSnaps(remaining)
        return StepResult(
            "ROM performance keys restored", remaining.isEmpty(),
            if (remaining.isEmpty()) "${snaps.size} key(s) put back"
            else remaining.joinToString { it.key } + " could not be restored; will retry"
        )
    }

    private fun loadSnaps(): List<SettingSnapshot> = runCatching {
        val arr = JSONArray(prefs.getString(K_SNAPS, "[]"))
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val ns = Ns.values().firstOrNull { it.cmd == o.getString("ns") } ?: return@mapNotNull null
            SettingSnapshot(ns, o.getString("key"), if (o.isNull("orig")) null else o.getString("orig"))
        }
    }.getOrDefault(emptyList())

    private fun saveSnaps(list: List<SettingSnapshot>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("ns", it.ns.cmd).put("key", it.key).put("orig", it.original ?: JSONObject.NULL)) }
        prefs.edit().putString(K_SNAPS, arr.toString()).apply()
    }

    private fun loadGames(): List<String> = runCatching {
        val arr = JSONArray(prefs.getString(K_GAMES, "[]"))
        (0 until arr.length()).map { arr.getString(it) }
    }.getOrDefault(emptyList())

    private fun saveGames(list: List<String>) {
        prefs.edit().putString(K_GAMES, JSONArray(list).toString()).apply()
    }

    private fun addGame(pkg: String) = saveGames((loadGames() + pkg).distinct())

    private fun removeGame(pkg: String) = saveGames(loadGames() - pkg)

    companion object {
        private const val K_THERMAL = "thermal_override"
        private const val K_FIXED = "fixed_performance"
        private const val K_SAVER = "saver_was_on"
        private const val K_PANEL = "panel_locked"
        private const val K_SNAPS = "vendor_snapshots"
        private const val K_GAMES = "game_overrides"
        private const val WATCH_MS = 3_000L
        private const val MAX_VICTIMS = 150

        /** Benchmark apps the boost recognises. Others can be passed through [BoostOptions.targets]. */
        val KNOWN = listOf(
            BenchTarget("com.antutu.ABenchMark", "AnTuTu"),
            BenchTarget("com.antutu.benchmark.full", "AnTuTu (CN)"),
            BenchTarget("com.futuremark.dmandroid.application", "3DMark"),
            BenchTarget("com.primatelabs.geekbench6", "Geekbench 6"),
            BenchTarget("com.primatelabs.geekbench5", "Geekbench 5"),
            BenchTarget("com.futuremark.pcmark.android.benchmark", "PCMark")
        )

        @Volatile private var inst: AntutuBenchmarkBooster? = null

        /** App-wide instance built from the objects HyperApp already owns (no HyperApp edit needed). */
        fun from(ctx: Context): AntutuBenchmarkBooster = inst ?: synchronized(this) {
            inst ?: run {
                val app = HyperApp.instance
                AntutuBenchmarkBooster(ctx.applicationContext, app.bridge, app.engine, app.fps, MaxPanelHzEngine.from(ctx))
            }.also { inst = it }
        }
    }
}
