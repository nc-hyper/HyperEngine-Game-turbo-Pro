package com.hyperengine.gameturbo.core

import android.annotation.SuppressLint
import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.Window
import android.view.WindowManager
import com.hyperengine.gameturbo.HyperApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.lang.ref.WeakReference
import java.util.Locale
import kotlin.math.roundToInt

// ───────────────────────────── Types ─────────────────────────────

enum class RomFamily(val label: String) {
    XIAOMI("Xiaomi HyperOS / MIUI"),
    OPLUS("Realme UI / ColorOS / OxygenOS"),
    STOCK("Stock Android / other")
}

/**
 * What the panel offers at the resolution it is running now. [modeId] is the Display.Mode to request.
 * Resolution is kept on purpose: asking for a mode at another resolution makes the ROM switch resolution
 * (a visible blink and a re-layout), so the fastest mode of the CURRENT resolution is the target and
 * [fasterAtOtherRes] only tells you when a different resolution would be faster.
 */
data class PanelCaps(
    val modeId: Int,
    val hz: Float,
    val width: Int,
    val height: Int,
    val ratesAtRes: List<Int>,
    val nativeWidth: Int,
    val nativeHeight: Int,
    val fasterAtOtherRes: Float
) {
    val hzInt: Int get() = hz.roundToInt()
    val belowNativeRes: Boolean get() = width.toLong() * height < nativeWidth.toLong() * nativeHeight
}

data class MaxHzReport(
    val panelMaxHz: Int,
    val shownHz: Int,
    val rom: RomFamily,
    val layers: List<StepResult>
) {
    val failures: Int get() = layers.count { !it.ok }
    val reachedMax: Boolean get() = panelMaxHz > 0 && shownHz >= panelMaxHz - 1
}

data class MaxHzState(
    val engaged: Boolean = false,
    val game: String? = null,
    val panelMaxHz: Int = 0,
    val shownHz: Int = 0,               // live: what the display reports right now (drives the HUD badge)
    val rom: RomFamily = RomFamily.STOCK,
    val busy: String? = null,
    val lastReport: MaxHzReport? = null
) {
    val atMax: Boolean get() = panelMaxHz > 0 && shownHz >= panelMaxHz - 1
}

// ───────────────────────────── Engine ─────────────────────────────

/**
 * Holds the display at the panel's highest refresh rate, for this app's own windows and for the game.
 *
 *  1. Window lock (no privileges needed): `preferredDisplayModeId` + `preferredRefreshRate` on every bound
 *     activity window and, through [DisplayModeLock], on every HUD overlay (edge handle, HUD, FPS pill ...).
 *  2. Surface frame rate: `Surface.setFrameRate(maxHz, FIXED_SOURCE, ALWAYS)` for surfaces WE own
 *     (for example the upscaler output). Android gives apps no way to set it on another app's surface.
 *  3. System layers, delegated to the existing engines so nothing fights over the same settings:
 *       game  -> FpsRefreshRateEnforcer.enforce(): throttler freeze, `cmd game set --mode performance --fps`,
 *                `device_config game_overlay`, the four refresh-rate keys, lock window, watchdog.
 *       lobby -> OptimizationEngine.lockRefreshRate() + PowerKeeper / Oplus battery freeze + watchdog.
 *     Plus the Realme / OPPO / OnePlus keys, which no other engine owns. Their originals are saved to disk
 *     first and put back by [release] (or [recoverPending] after a crash).
 *
 * Limits: the panel is the ceiling, a game still decides its own FPS, and a ROM may ignore any one layer.
 * Every layer reports its real result and the display's read-back rate.
 */
class MaxPanelHzEngine private constructor(
    private val ctx: Context,
    private val bridge: SystemBridgeExecutor,
    private val engine: OptimizationEngine,
    private val fps: FpsRefreshRateEnforcer
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val main = Handler(Looper.getMainLooper())
    private val mutex = Mutex()
    private val prefs = ctx.getSharedPreferences("hyper_maxhz", Context.MODE_PRIVATE)
    private val dm = ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager

    private val _state = MutableStateFlow(MaxHzState())
    val state: StateFlow<MaxHzState> = _state.asStateFlow()

    @Volatile private var capsCache: PanelCaps? = null
    @Volatile private var engagedFlag = false
    @Volatile private var activeGame: String? = null
    @Volatile private var holdHz = 0
    private var ownsKeys = false          // we wrote the four refresh keys through the engine (lobby mode)
    private var lobbyThrottle = false     // we hold the OEM-throttler freeze under our own owner name

    /** Activity windows (main thread only). Weak, so a destroyed activity just drops out. */
    private val windows = ArrayList<WeakReference<Window>>()

    /**
     * The system reports a display change on every refresh-rate switch, and an adaptive (LTPO) panel switches many times a
     * second in a game. Rebuilding the panel capabilities and re-stamping windows for each one ran on the MAIN thread and
     * showed up as UI hitches. The work is now done once, 250 ms after the last event of a burst.
     */
    private val displayChanged = Runnable {
        capsCache = null
        val c = caps()
        _state.update { it.copy(shownHz = currentHz(), panelMaxHz = c?.hzInt ?: it.panelMaxHz) }
        restampDrifted() // only touches a window whose request was actually reset: no relayout storms
    }

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) {
            if (displayId != Display.DEFAULT_DISPLAY) return
            main.removeCallbacks(displayChanged)
            main.postDelayed(displayChanged, 250L)
        }
    }

    init {
        runCatching { dm.registerDisplayListener(displayListener, main) }
        _state.update { it.copy(panelMaxHz = caps()?.hzInt ?: 0, shownHz = currentHz(), rom = detectRom()) }
        // The existing enforcer zeroes DisplayModeLock when IT lets go. While we are engaged we put it back,
        // unless the engine itself was restored (user pressed Restore): then we stand down too.
        scope.launch {
            fps.lockedHz.collect { hz ->
                if (hz > 0 || !engagedFlag) return@collect
                if (ownsKeys && !engine.isTracked(Ns.SYSTEM, "peak_refresh_rate")) {
                    release("engine restored the settings")
                } else {
                    DisplayModeLock.currentHz = holdHz
                    main.post { fps.overlayRefresh?.invoke() }
                }
            }
        }
    }

    // ───────────────────── Panel detection ─────────────────────

    /** Cached until the display changes. Null when the platform reports no display or modes. */
    fun caps(): PanelCaps? {
        capsCache?.let { return it }
        val d = DisplayModeLock.defaultDisplay(ctx) ?: return null
        val modes = runCatching { d.supportedModes.toList() }.getOrDefault(emptyList())
        val cur = runCatching { d.mode }.getOrNull()
        if (modes.isEmpty() || cur == null) return null
        val native = modes.maxByOrNull { it.physicalWidth.toLong() * it.physicalHeight }!!
        val sameRes = modes.filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
            .ifEmpty { modes }
        val best = sameRes.maxByOrNull { it.refreshRate }!!
        val otherFaster = modes.filter { it !in sameRes }.maxOfOrNull { it.refreshRate } ?: 0f
        val c = PanelCaps(
            modeId = best.modeId,
            hz = best.refreshRate,
            width = best.physicalWidth,
            height = best.physicalHeight,
            ratesAtRes = sameRes.map { it.refreshRate.roundToInt() }.distinct().sorted(),
            nativeWidth = native.physicalWidth,
            nativeHeight = native.physicalHeight,
            fasterAtOtherRes = if (otherFaster > best.refreshRate + 0.5f) otherFaster else 0f
        )
        capsCache = c
        return c
    }

    fun currentHz(): Int = DisplayModeLock.defaultDisplay(ctx)?.refreshRate?.roundToInt() ?: 0

    fun detectRom(): RomFamily {
        val id = (Build.MANUFACTURER + " " + Build.BRAND).lowercase(Locale.US)
        return when {
            listOf("xiaomi", "redmi", "poco", "blackshark").any { id.contains(it) } ||
                bridge.getSetting(Ns.SECURE, "miui_refresh_rate") != null -> RomFamily.XIAOMI
            listOf("oppo", "realme", "oneplus", "oplus").any { id.contains(it) } ||
                bridge.getSetting(Ns.SECURE, "oplus_customize_screen_refresh_rate") != null -> RomFamily.OPLUS
            else -> RomFamily.STOCK
        }
    }

    // ───────────────────── 1. Window / overlay lock (works without Shizuku) ─────────────────────

    /** Stamps max-Hz preferences onto any WindowManager.LayoutParams (use for a new overlay's params). */
    fun stamp(p: WindowManager.LayoutParams) {
        val c = caps() ?: return
        p.preferredDisplayModeId = c.modeId
        p.preferredRefreshRate = c.hz
        setMinRate(p, c.hz)
    }

    /** Call from Activity.onCreate (and again from onResume if you like). Idempotent, safe from any thread. */
    fun bindWindow(window: Window) = onMain {
        if (windows.none { it.get() === window }) windows += WeakReference(window)
        lockWindow(window)
    }

    fun unbindWindow(window: Window) = onMain { windows.removeAll { it.get() == null || it.get() === window } }

    /** Re-stamps an already attached overlay (for views that were added before the lock existed). */
    fun restampOverlay(wm: WindowManager, view: View) = onMain {
        val p = view.layoutParams as? WindowManager.LayoutParams ?: return@onMain
        stamp(p)
        runCatching { wm.updateViewLayout(view, p) }
    }

    private fun lockWindow(window: Window) {
        val c = caps() ?: return
        val a = window.attributes
        a.preferredDisplayModeId = c.modeId
        a.preferredRefreshRate = c.hz
        setMinRate(a, c.hz)
        window.attributes = a
        requestViewRate(window.decorView, c.hz)
    }

    private fun restampWindows() {
        windows.removeAll { it.get() == null }
        windows.forEach { ref -> ref.get()?.let { lockWindow(it) } }
    }

    private fun restampDrifted() {
        val c = caps() ?: return
        windows.removeAll { it.get() == null }
        windows.forEach { ref ->
            val w = ref.get() ?: return@forEach
            if (w.attributes.preferredDisplayModeId != c.modeId) lockWindow(w)
        }
    }

    /** Android 14+ "at least this rate" hint on the params; absent on older SDKs, so reflection and ignore. */
    private fun setMinRate(p: WindowManager.LayoutParams, hz: Float) {
        runCatching {
            WindowManager.LayoutParams::class.java.getField("preferredMinDisplayRefreshRate").setFloat(p, hz)
        }
    }

    /** Android 15+ `View.setRequestedFrameRate(float)` for the whole view tree; no-op below that. */
    private fun requestViewRate(v: View, hz: Float) {
        runCatching {
            View::class.java.getMethod("setRequestedFrameRate", Float::class.javaPrimitiveType).invoke(v, hz)
        }
    }

    // ───────────────────── 2. Surface frame rate (surfaces this app owns) ─────────────────────

    /** `Surface.setFrameRate(maxHz, FIXED_SOURCE, CHANGE_FRAME_RATE_ALWAYS)`. False below Android 11 or on a dead surface. */
    @SuppressLint("NewApi")
    fun setSurfaceFrameRate(surface: Surface, hz: Float = caps()?.hz ?: 0f): Boolean {
        if (hz <= 0f || !surface.isValid) return false
        return runCatching {
            when {
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
                    surface.setFrameRate(hz, Surface.FRAME_RATE_COMPATIBILITY_FIXED_SOURCE, Surface.CHANGE_FRAME_RATE_ALWAYS)
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.R ->
                    surface.setFrameRate(hz, Surface.FRAME_RATE_COMPATIBILITY_FIXED_SOURCE)
                else -> return false
            }
            true
        }.getOrDefault(false)
    }

    /** Applies the frame rate now and again every time the SurfaceView's surface is (re)created or resized. */
    fun attachSurfaceView(sv: SurfaceView) {
        val applyRate = { setSurfaceFrameRate(sv.holder.surface) }
        sv.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) { applyRate() }
            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) { applyRate() }
            override fun surfaceDestroyed(holder: SurfaceHolder) {}
        })
        applyRate()
        requestViewRate(sv, caps()?.hz ?: 0f)
    }

    // ───────────────────── 3. System layers (Shizuku / root) ─────────────────────

    /**
     * Locks the panel at its maximum. [game] = package of the running game, or null for the app / lobby.
     * Safe to call repeatedly. Returns the per-layer report with the display's read-back rate.
     */
    suspend fun engage(game: String? = null): MaxHzReport = mutex.withLock {
        val rom = detectRom()
        val caps = caps()
        if (caps == null) {
            val r = MaxHzReport(0, 0, rom, listOf(StepResult("Panel detection", false, "the display reported no supported modes")))
            _state.update { it.copy(lastReport = r) }
            return@withLock r
        }
        val hz = caps.hzInt
        val steps = ArrayList<StepResult>()
        _state.update { it.copy(busy = "Locking $hz Hz", panelMaxHz = hz, rom = rom) }
        try {
            // Values left behind by a crash go back first, so the snapshot taken below holds the true originals.
            if (!engagedFlag) restoreVendorLocked()?.let { steps += it }

            val other = if (caps.fasterAtOtherRes > 0f) "; ${caps.fasterAtOtherRes.roundToInt()} Hz exists only at another resolution" else ""
            steps += StepResult(
                "Panel",
                true,
                "${caps.width}x${caps.height} offers ${caps.ratesAtRes.joinToString("/")} Hz, target $hz Hz (mode ${caps.modeId})" +
                    (if (caps.belowNativeRes) ", running below native resolution" else "") + other
            )

            // 1. windows + every HUD overlay (through DisplayModeLock)
            withContext(Dispatchers.Main) {
                restampWindows()
                DisplayModeLock.currentHz = hz
                fps.overlayRefresh?.invoke()
            }
            steps += StepResult("Window lock", true, "app windows and HUD overlays request mode ${caps.modeId} at $hz Hz")

            // 3. system layers
            if (game != null) {
                steps += fps.enforce(game, hz).layers
            } else {
                val tracked = engine.isTracked(Ns.SYSTEM, "peak_refresh_rate")
                val lock = engine.lockRefreshRate(hz)
                if (lock.ok && !tracked) ownsKeys = true
                steps += lock
                val th = fps.throttlers.acquire(OWNER)
                if (th.any { it.ok }) lobbyThrottle = true
                steps += th
                fps.holdRate(hz)
                steps += StepResult("Watchdog + lock window", true, "re-applies $hz Hz when the ROM resets it")
            }
            steps += applyVendor(rom)

            delay(700L) // let the panel settle before reading it back
            val shown = currentHz()
            steps += StepResult("Panel read-back", shown >= hz - 1, "display reports $shown Hz (target $hz Hz)")

            engagedFlag = true
            activeGame = game
            holdHz = hz
            val report = MaxHzReport(hz, shown, rom, steps)
            _state.update { it.copy(engaged = true, game = game, shownHz = shown, lastReport = report) }
            report
        } finally {
            _state.update { it.copy(busy = null) }
        }
    }

    /** Drops every lock this engine took and restores the vendor keys it changed. */
    suspend fun release(reason: String = "released"): List<StepResult> = mutex.withLock { releaseLocked(reason) }

    private suspend fun releaseLocked(reason: String): List<StepResult> {
        val out = ArrayList<StepResult>()
        engagedFlag = false // first, so the lockedHz collector never fights the release
        val g = activeGame
        out += if (g != null) fps.deactivate(g) else fps.releaseSoft("Max panel Hz: $reason")
        if (lobbyThrottle) {
            out += fps.throttlers.release(OWNER)
            lobbyThrottle = false
        }
        // only undo the keys if they are still ours: a Wild Boost session may have tracked them first
        if (ownsKeys) {
            if (engine.isTracked(Ns.SYSTEM, "peak_refresh_rate")) out += engine.unlockRefreshRate()
            ownsKeys = false
        }
        restoreVendorLocked()?.let { out += it }
        if (DisplayModeLock.currentHz == holdHz) DisplayModeLock.currentHz = 0
        withContext(Dispatchers.Main) { fps.overlayRefresh?.invoke() }
        activeGame = null
        holdHz = 0
        _state.update { it.copy(engaged = false, game = null, busy = null, shownHz = currentHz()) }
        return out
    }

    /** Crash / restart recovery: puts saved vendor values back when we are not engaged. Call from app start. */
    suspend fun recoverPending(): List<StepResult> = mutex.withLock {
        if (engagedFlag) emptyList() else listOfNotNull(restoreVendorLocked())
    }

    fun engageAsync(game: String? = null, onDone: ((MaxHzReport) -> Unit)? = null): Job = scope.launch {
        val r = engage(game)
        if (onDone != null) main.post { onDone(r) }
    }

    fun releaseAsync(reason: String = "released", onDone: ((List<StepResult>) -> Unit)? = null): Job = scope.launch {
        val r = release(reason)
        if (onDone != null) main.post { onDone(r) }
    }

    // ───────────────────── Vendor keys (Realme UI / ColorOS / OxygenOS) ─────────────────────

    private suspend fun applyVendor(rom: RomFamily): List<StepResult> = when (rom) {
        RomFamily.OPLUS -> {
            val writes = listOf(
                SettingWrite(Ns.SECURE, "oplus_customize_screen_refresh_rate", "3"),
                SettingWrite(Ns.GLOBAL, "oneplus_screen_refresh_rate", "0")
            )
            // originals to disk BEFORE the write; an already saved original is never replaced by our own value
            val saved = loadSnaps()
            val fresh = bridge.snapshotSettings(writes.map { it.ns to it.key })
                .filter { n -> saved.none { it.ns == n.ns && it.key == n.key } }
            saveSnaps(saved + fresh)
            val res = bridge.applySettings(writes)
            writes.mapIndexed { i, w ->
                StepResult("${rom.label}: ${w.ns.cmd}/${w.key}=${w.value}", res[i].ok, if (res[i].ok) "set" else res[i].message)
            }
        }
        RomFamily.XIAOMI -> listOf(
            StepResult(
                "${rom.label}: refresh keys", true,
                "peak / min / user / miui_refresh_rate and the PowerKeeper freeze run in the layers above"
            )
        )
        RomFamily.STOCK -> listOf(StepResult("Vendor keys", true, "none for this ROM; GameManager and window lock apply"))
    }

    private suspend fun restoreVendorLocked(): StepResult? {
        val snaps = loadSnaps()
        if (snaps.isEmpty()) return null
        val res = bridge.restoreSnapshots(snaps)
        val remaining = snaps.filterIndexed { i, _ -> !res[i].ok }
        saveSnaps(remaining)
        return StepResult(
            "Vendor refresh keys restored", remaining.isEmpty(),
            if (remaining.isEmpty()) "${snaps.size} key(s) put back"
            else remaining.joinToString { it.key } + " could not be restored; will retry"
        )
    }

    private fun loadSnaps(): List<SettingSnapshot> = runCatching {
        val arr = JSONArray(prefs.getString(KEY_SNAPS, "[]"))
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val ns = Ns.values().firstOrNull { it.cmd == o.getString("ns") } ?: return@mapNotNull null
            SettingSnapshot(ns, o.getString("key"), if (o.isNull("orig")) null else o.getString("orig"))
        }
    }.getOrDefault(emptyList())

    private fun saveSnaps(list: List<SettingSnapshot>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("ns", it.ns.cmd).put("key", it.key).put("orig", it.original ?: JSONObject.NULL))
        }
        prefs.edit().putString(KEY_SNAPS, arr.toString()).apply()
    }

    private fun onMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else main.post(block)
    }

    companion object {
        private const val OWNER = "max-panel-hz"
        private const val KEY_SNAPS = "vendor_snapshots"

        @Volatile private var inst: MaxPanelHzEngine? = null

        /** App-wide instance, built on first use from the objects HyperApp already owns (no HyperApp edit needed). */
        fun from(ctx: Context): MaxPanelHzEngine = inst ?: synchronized(this) {
            inst ?: run {
                val app = HyperApp.instance
                MaxPanelHzEngine(ctx.applicationContext, app.bridge, app.engine, app.fps)
            }.also { inst = it }
        }
    }
}
