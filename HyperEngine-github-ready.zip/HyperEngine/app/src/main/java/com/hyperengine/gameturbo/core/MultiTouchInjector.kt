package com.hyperengine.gameturbo.core

import android.content.Context
import android.graphics.Point
import android.os.SystemClock
import android.view.WindowManager
import com.hyperengine.gameturbo.service.TouchMacroService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.CopyOnWriteArrayList

/** Which engine the user allows. AUTO = Shizuku when it works, accessibility otherwise. */
enum class TouchEnginePref(val label: String) {
    AUTO("Automatic"),
    SHIZUKU_ONLY("Shizuku only"),
    ACCESSIBILITY_ONLY("Accessibility only")
}

/** The engine that is actually carrying touches right now. */
enum class TouchEngine(val label: String) {
    SHIZUKU_MULTI_POINTER("Shizuku multi-pointer"),
    ACCESSIBILITY("Accessibility gestures"),
    NONE("None")
}

data class InjectorStatus(
    val engine: TouchEngine = TouchEngine.NONE,
    val shizukuReady: Boolean = false,
    val accessibilityReady: Boolean = false,
    val detail: String = "No engine yet"
)

/**
 * A finger that stays down until [MultiTouchInjector.endHold]. Used for hold-to-scope, hold-to-fire,
 * press-and-release shoulder triggers and recorded multi-touch commands.
 */
class TouchHandle internal constructor(
    val owner: String,
    internal val engine: TouchEngine,
    internal val slot: Int,
    internal val lane: AccessibilityGestureLane.Hold?
) {
    @Volatile
    internal var open: Boolean = true

    val isOpen: Boolean get() = open
}

/**
 * The single door every Phase 4 feature touches the screen through (auto tapper, Commands macros, L1 / R1
 * shoulder triggers, keyboard / mouse mapper later).
 *
 * ENGINE A, Shizuku hardware multi-pointer injection (primary, zero conflict)
 *   Uses [SyntheticPointerTable] from Phase 1: MotionEvents with SOURCE_TOUCHSCREEN built from synthetic
 *   pointer ids 3, 4, 5 and 6 and injected through IInputManager.injectInputEvent (ASYNC). Pointer ids 0, 1
 *   and 2 stay reserved for the player's real fingers, so the thumb that aims and the thumb on the joystick
 *   keep their own pointers while the synthetic fingers tap beside them.
 *
 * ENGINE B, accessibility fallback ([AccessibilityGestureLane])
 *   8 ms tap strokes and chained `willContinue` strokes for fingers that stay down. Used automatically when
 *   Shizuku is not running or refuses, and as a per-call fallback when engine A fails mid-session.
 *
 * Slot map: the pool has 4 synthetic fingers. Auto-touch, macros and shoulder triggers take free slots from
 * the top (3, 2, 1, 0), the keyboard mapper keeps slot 0 for its joystick and picks key slots from the
 * bottom, and every grab checks [SyntheticPointerTable.isDown], so the two never write the same finger.
 *
 * Nothing here is faked: a call returns false (or null) when nothing could be injected.
 */
class MultiTouchInjector(context: Context, private val bridge: SystemBridgeExecutor) {

    private val app: Context = context.applicationContext
    private val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val lane = AccessibilityGestureLane(scope)

    private val _status = MutableStateFlow(InjectorStatus())
    val status: StateFlow<InjectorStatus> = _status.asStateFlow()

    @Volatile
    var preference: TouchEnginePref = readPreference()
        set(value) {
            field = value
            prefs.edit().putString(KEY_PREF, value.name).apply()
            refreshStatus()
        }

    private fun readPreference(): TouchEnginePref =
        runCatching { TouchEnginePref.valueOf(prefs.getString(KEY_PREF, null) ?: "AUTO") }
            .getOrDefault(TouchEnginePref.AUTO)

    // ---------------------------------------------------------------------------------------------
    // Engine selection
    // ---------------------------------------------------------------------------------------------

    private var lastBindAttempt = 0L

    private fun shizukuReady(): Boolean {
        if (bridge.input.isConnected) return true
        if (!bridge.state.value.shizukuGranted) return false
        val now = SystemClock.uptimeMillis()
        // a failed bind is a reflective call chain: do not repeat it at 30 taps per second
        if (now - lastBindAttempt < BIND_RETRY_MS) return false
        lastBindAttempt = now
        return runCatching { bridge.input.connect() }.getOrDefault(false)
    }

    private fun accessibilityReady(): Boolean = TouchMacroService.instance != null

    fun activeEngine(): TouchEngine {
        val p = preference
        if (p != TouchEnginePref.ACCESSIBILITY_ONLY && shizukuReady()) return TouchEngine.SHIZUKU_MULTI_POINTER
        if (p != TouchEnginePref.SHIZUKU_ONLY && accessibilityReady()) return TouchEngine.ACCESSIBILITY
        return TouchEngine.NONE
    }

    private fun canFallBack(): Boolean = preference != TouchEnginePref.SHIZUKU_ONLY && accessibilityReady()

    /** Re-evaluates the engines (call when Shizuku or the accessibility service changed) and publishes [status]. */
    fun refreshStatus(): InjectorStatus {
        val shizuku = shizukuReady()
        val a11y = accessibilityReady()
        val engine = activeEngine()
        val detail = when (engine) {
            TouchEngine.SHIZUKU_MULTI_POINTER ->
                "Hardware multi-pointer injection, pointer ids 3 to 6 (" + bridge.input.description + ")"
            TouchEngine.ACCESSIBILITY ->
                if (preference == TouchEnginePref.AUTO && !shizuku)
                    "Accessibility gestures. Shizuku: " + (bridge.input.lastError ?: "not running")
                else "Accessibility gestures"
            TouchEngine.NONE ->
                "No engine: start Shizuku or enable the accessibility service"
        }
        val s = InjectorStatus(engine, shizuku, a11y, detail)
        _status.value = s
        return s
    }

    // ---------------------------------------------------------------------------------------------
    // Screen
    // ---------------------------------------------------------------------------------------------

    /** Real screen size in pixels for the current rotation. */
    @Suppress("DEPRECATION")
    fun screenSize(): Point {
        val p = Point()
        runCatching { wm.defaultDisplay.getRealSize(p) }
        if (p.x <= 0 || p.y <= 0) {
            val m = app.resources.displayMetrics
            p.set(m.widthPixels, m.heightPixels)
        }
        return p
    }

    // ---------------------------------------------------------------------------------------------
    // Slots
    // ---------------------------------------------------------------------------------------------

    private val slotOwner = arrayOfNulls<String>(SyntheticPointerTable.MAX_SLOTS)

    @Synchronized
    private fun acquireSlot(owner: String): Int {
        for (s in SLOT_ORDER) {
            if (slotOwner[s] == null && !bridge.pointers.isDown(s)) {
                slotOwner[s] = owner
                return s
            }
        }
        return -1
    }

    @Synchronized
    private fun releaseSlot(slot: Int) {
        if (slot in slotOwner.indices) slotOwner[slot] = null
    }

    // ---------------------------------------------------------------------------------------------
    // One-shot gestures
    // ---------------------------------------------------------------------------------------------

    /** Tap at screen pixel (x, y), finger down for [holdMs]. Returns true when the system took it. */
    suspend fun tap(x: Float, y: Float, holdMs: Long, owner: String = "auto"): Boolean {
        val hold = holdMs.coerceIn(1L, 60_000L)
        val engine = activeEngine()
        if (engine == TouchEngine.NONE) return false
        if (engine == TouchEngine.SHIZUKU_MULTI_POINTER) {
            val slot = acquireSlot(owner)
            if (slot >= 0) {
                try {
                    if (bridge.pointers.tap(slot, x, y, hold)) return true
                } finally {
                    releaseSlot(slot)
                }
            }
            if (!canFallBack()) return false
        }
        // accessibility: a plain instant tap becomes the 8 ms stroke, a long press keeps its length
        val ms = if (hold <= INSTANT_TAP_MS) AccessibilityGestureLane.TAP_MS else hold
        return lane.tap(x, y, ms)
    }

    /** Straight drag from (x1, y1) to (x2, y2) over [durationMs]. */
    suspend fun swipe(
        x1: Float, y1: Float, x2: Float, y2: Float,
        durationMs: Long, owner: String = "auto"
    ): Boolean {
        val dur = durationMs.coerceIn(20L, 60_000L)
        val engine = activeEngine()
        if (engine == TouchEngine.NONE) return false
        if (engine == TouchEngine.SHIZUKU_MULTI_POINTER) {
            val slot = acquireSlot(owner)
            if (slot >= 0) {
                try {
                    if (bridge.pointers.swipe(slot, x1, y1, x2, y2, dur)) return true
                } finally {
                    releaseSlot(slot)
                }
            }
            if (!canFallBack()) return false
        }
        return lane.swipe(x1, y1, x2, y2, dur)
    }

    // ---------------------------------------------------------------------------------------------
    // Fingers that stay down
    // ---------------------------------------------------------------------------------------------

    private val handles = CopyOnWriteArrayList<TouchHandle>()

    /** Number of fingers this injector currently holds down. */
    val heldCount: Int get() = handles.size

    /** Puts a finger down at (x, y) and keeps it there. Null when no finger or engine is available. */
    fun beginHold(x: Float, y: Float, owner: String): TouchHandle? {
        val engine = activeEngine()
        if (engine == TouchEngine.NONE) return null
        if (engine == TouchEngine.SHIZUKU_MULTI_POINTER) {
            val slot = acquireSlot(owner)
            if (slot >= 0) {
                if (bridge.pointers.down(slot, x, y)) {
                    return TouchHandle(owner, engine, slot, null).also { handles.add(it) }
                }
                releaseSlot(slot)
            }
            if (!canFallBack()) return null
        }
        val h = lane.beginHold(x, y) ?: return null
        return TouchHandle(owner, TouchEngine.ACCESSIBILITY, -1, h).also { handles.add(it) }
    }

    /** Drags a held finger to (x, y). */
    fun moveHold(handle: TouchHandle, x: Float, y: Float) {
        if (!handle.open) return
        if (handle.engine == TouchEngine.SHIZUKU_MULTI_POINTER) {
            bridge.pointers.move(handle.slot, x, y)
        } else {
            handle.lane?.let { lane.moveHold(it, x, y) }
        }
    }

    /** Lifts a held finger. Safe to call twice. */
    fun endHold(handle: TouchHandle) {
        if (!handle.open) return
        handle.open = false
        handles.remove(handle)
        if (handle.engine == TouchEngine.SHIZUKU_MULTI_POINTER) {
            runCatching { bridge.pointers.up(handle.slot) }
            releaseSlot(handle.slot)
        } else {
            handle.lane?.let { lane.endHold(it) }
        }
    }

    /** Lifts every finger that belongs to [owner]. */
    fun releaseOwner(owner: String) {
        for (h in handles) if (h.owner == owner) endHold(h)
    }

    /**
     * Panic stop: lifts everything, including fingers the keyboard mapper holds, and clears the accessibility
     * queue. Use for "stop all" and when the overlay closes, not for a single feature.
     */
    fun releaseAll() {
        for (h in handles) endHold(h)
        runCatching { bridge.pointers.releaseAll() }
        lane.releaseAll()
        synchronized(this) { for (i in slotOwner.indices) slotOwner[i] = null }
    }

    fun destroy() {
        releaseAll()
        scope.cancel()
    }

    companion object {
        private const val PREFS = "hyper_touch"
        private const val KEY_PREF = "engine_pref"
        private const val BIND_RETRY_MS = 2_000L

        /** A configured hold at or below this is an "instant tap" (8 ms stroke on the accessibility engine). */
        const val INSTANT_TAP_MS = 20L

        /** Slots are taken from the top so the keyboard mapper's joystick (slot 0) is the last one disturbed. */
        private val SLOT_ORDER = intArrayOf(3, 2, 1, 0)
    }
}
