package com.hyperengine.gameturbo.core

import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.KeyCharacterMap
import android.view.KeyEvent
import android.view.MotionEvent
import kotlinx.coroutines.delay
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper
import java.lang.reflect.InvocationTargetException
import java.lang.reflect.Method

// =============================================================================================
// Hidden API access
// =============================================================================================

/**
 * Android 9+ blocks reflection on non-SDK members such as IInputManager$Stub.asInterface. The LSPosed
 * HiddenApiBypass library lifts that block for this process. Below Android 9 nothing is blocked.
 */
object HiddenApiUnlock {

    @Volatile
    private var done = false

    @Volatile
    var lastError: String? = null
        private set

    val unlocked: Boolean get() = done

    fun ensure(): Boolean {
        if (done) return true
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            done = true
            return true
        }
        return try {
            val ok = org.lsposed.hiddenapibypass.HiddenApiBypass.addHiddenApiExemptions("L")
            done = ok
            if (!ok) lastError = "HiddenApiBypass refused the exemption on this Android build"
            ok
        } catch (t: Throwable) {
            lastError = t.javaClass.simpleName + ": " + (t.message ?: "")
            false
        }
    }
}

// =============================================================================================
// IInputManager binder bridge
// =============================================================================================

/** Which input device id injected touches claim to come from. */
enum class TouchDeviceStrategy {
    /** The phone's real touchscreen id: the dispatcher treats our pointers as extra fingers on it. */
    PHYSICAL_TOUCHSCREEN,

    /** The virtual device id (-1), the same one `input tap` and scrcpy use. */
    VIRTUAL
}

/**
 * Talks to the system `input` service through Shizuku, exactly like the shell does, so that
 * [InputEvent]s can be injected with shell privileges (INJECT_EVENTS) without an accessibility service.
 *
 *   IInputManager.Stub.asInterface(ShizukuBinderWrapper(SystemServiceHelper.getSystemService("input")))
 *
 * Everything is done by reflection (no hidden-API stubs are compiled in) and every call is wrapped,
 * so a ROM that renamed or removed the method gives [lastError] and `false`, never a crash.
 * The AIDL signature of injectInputEvent changed between Android releases; all three known shapes are
 * discovered at connect time:
 *   injectInputEvent(InputEvent, int)
 *   injectInputEvent(InputEvent, int, int targetUid)
 *   injectInputEventToTarget(InputEvent, int, int targetUid)
 */
class InputManagerBridge {

    private enum class Shape { EVENT_MODE, EVENT_MODE_UID, TO_TARGET }

    private val lock = Any()

    @Volatile
    private var service: Any? = null

    @Volatile
    private var inject: Method? = null

    @Volatile
    private var shape: Shape = Shape.EVENT_MODE

    @Volatile
    private var rawBinder: IBinder? = null

    private var setDisplayId: Method? = null

    private val death = IBinder.DeathRecipient { invalidate("The system input binder died") }

    /** Last reason a connect or inject failed. Real exception text, never invented. */
    @Volatile
    var lastError: String? = null
        private set

    /** Optional hook for live user feedback (the executor routes it to a throttled Toast). */
    @Volatile
    var onProblem: ((String) -> Unit)? = null

    @Volatile
    var touchDevice: TouchDeviceStrategy = TouchDeviceStrategy.PHYSICAL_TOUCHSCREEN

    val isConnected: Boolean
        get() = service != null && rawBinder?.isBinderAlive == true

    /** Human readable description of the bound method shape, for the diagnostics screen. */
    val description: String
        get() = if (!isConnected) "not connected" else when (shape) {
            Shape.EVENT_MODE -> "injectInputEvent(event, mode)"
            Shape.EVENT_MODE_UID -> "injectInputEvent(event, mode, uid)"
            Shape.TO_TARGET -> "injectInputEventToTarget(event, mode, uid)"
        }

    /** Drops the cached binder. The next inject reconnects (Shizuku restarted, binder died...). */
    fun invalidate(reason: String? = null) {
        synchronized(lock) {
            runCatching { rawBinder?.unlinkToDeath(death, 0) }
            service = null
            inject = null
            rawBinder = null
            if (reason != null) lastError = reason
        }
    }

    /**
     * Binds the `input` service. Needs Shizuku running AND permitted. Returns true when ready.
     * Safe to call repeatedly and from any thread.
     */
    fun connect(): Boolean {
        if (isConnected) return true
        return synchronized(lock) {
            if (isConnected) {
                true
            } else {
                try {
                    bind()
                    lastError = null
                    true
                } catch (t: Throwable) {
                    val c = (t as? InvocationTargetException)?.targetException ?: t
                    lastError = c.javaClass.simpleName + ": " + (c.message ?: "no message")
                    service = null
                    inject = null
                    false
                }
            }
        }
    }

    private fun bind() {
        check(Shizuku.pingBinder()) { "Shizuku is not running" }
        check(!Shizuku.isPreV11()) { "Shizuku is too old (pre v11)" }
        check(Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            "Shizuku permission not granted to Hyper Engine"
        }
        check(HiddenApiUnlock.ensure()) { "Hidden API access unavailable: " + (HiddenApiUnlock.lastError ?: "unknown") }

        val raw = SystemServiceHelper.getSystemService("input") ?: error("The system 'input' service was not found")
        val wrapped = ShizukuBinderWrapper(raw)

        val stub = Class.forName("android.hardware.input.IInputManager\$Stub")
        val iface = Class.forName("android.hardware.input.IInputManager")
        val asInterface = stub.getMethod("asInterface", IBinder::class.java)
        val svc = asInterface.invoke(null, wrapped) ?: error("IInputManager.Stub.asInterface returned null")

        val int = Int::class.javaPrimitiveType!!
        var method: Method? = null
        var found = Shape.EVENT_MODE
        for (m in iface.methods) {
            val p = m.parameterTypes
            when {
                m.name == "injectInputEvent" && p.size == 2 && InputEvent::class.java.isAssignableFrom(p[0]) && p[1] == int -> {
                    method = m; found = Shape.EVENT_MODE
                }
                method == null && m.name == "injectInputEvent" && p.size == 3 && InputEvent::class.java.isAssignableFrom(p[0]) && p[1] == int && p[2] == int -> {
                    method = m; found = Shape.EVENT_MODE_UID
                }
                method == null && m.name == "injectInputEventToTarget" && p.size == 3 && InputEvent::class.java.isAssignableFrom(p[0]) && p[1] == int && p[2] == int -> {
                    method = m; found = Shape.TO_TARGET
                }
            }
            // the plain two-argument shape is the best one: stop as soon as it is found
            if (method != null && found == Shape.EVENT_MODE) break
        }
        val chosen = method ?: error("No injectInputEvent method on IInputManager (Android ${Build.VERSION.SDK_INT})")

        setDisplayId = runCatching { InputEvent::class.java.getMethod("setDisplayId", int) }.getOrNull()

        runCatching { raw.linkToDeath(death, 0) }
        rawBinder = raw
        shape = found
        inject = chosen
        service = svc
    }

    /**
     * Injects one event with shell privileges. Returns true when the system accepted it.
     * [mode] 0 = ASYNC (default, never blocks), 1 = WAIT_FOR_RESULT, 2 = WAIT_FOR_FINISH.
     * [displayId] the display the event is delivered to: 0 is the phone screen, anything else is a secondary or
     * virtual display (the virtual-display upscaler injects into its own display this way).
     */
    fun inject(event: InputEvent, mode: Int = MODE_ASYNC, displayId: Int = 0): Boolean {
        if (!connect()) {
            report("Input injection unavailable: " + (lastError ?: "unknown"))
            return false
        }
        val svc = service
        val m = inject
        if (svc == null || m == null) return false
        return try {
            runCatching { setDisplayId?.invoke(event, displayId) }
            val r = when (shape) {
                Shape.EVENT_MODE -> m.invoke(svc, event, mode)
                Shape.EVENT_MODE_UID, Shape.TO_TARGET -> m.invoke(svc, event, mode, INVALID_UID)
            }
            (r as? Boolean) ?: true
        } catch (t: Throwable) {
            val c = (t as? InvocationTargetException)?.targetException ?: t
            lastError = c.javaClass.simpleName + ": " + (c.message ?: "no message")
            // a dead or revoked binder will never recover on its own: force a clean reconnect next time
            if (c is android.os.DeadObjectException || c is SecurityException || c is android.os.RemoteException) {
                invalidate(lastError)
            }
            report("Input injection failed: " + lastError)
            false
        }
    }

    /** Presses and releases a key through the input service (same effect as `input keyevent N`). */
    fun pressKey(keyCode: Int, holdMs: Long = 20L, displayId: Int = 0): Boolean {
        val down = SystemClock.uptimeMillis()
        val d = KeyEvent(
            down, down, KeyEvent.ACTION_DOWN, keyCode, 0, 0,
            KeyCharacterMap.VIRTUAL_KEYBOARD, 0, 0, InputDevice.SOURCE_KEYBOARD
        )
        if (!inject(d, MODE_ASYNC, displayId)) return false
        if (holdMs > 0) SystemClock.sleep(holdMs)
        val u = KeyEvent(
            down, SystemClock.uptimeMillis(), KeyEvent.ACTION_UP, keyCode, 0, 0,
            KeyCharacterMap.VIRTUAL_KEYBOARD, 0, 0, InputDevice.SOURCE_KEYBOARD
        )
        return inject(u, MODE_ASYNC, displayId)
    }

    /** Device id the injected touches should carry (see [TouchDeviceStrategy]). */
    fun touchDeviceId(): Int {
        if (touchDevice == TouchDeviceStrategy.VIRTUAL) return VIRTUAL_DEVICE_ID
        return try {
            InputDevice.getDeviceIds().firstOrNull { id ->
                val d = InputDevice.getDevice(id)
                d != null && !d.isVirtual && (d.sources and InputDevice.SOURCE_TOUCHSCREEN) == InputDevice.SOURCE_TOUCHSCREEN
            } ?: VIRTUAL_DEVICE_ID
        } catch (_: Throwable) {
            VIRTUAL_DEVICE_ID
        }
    }

    private var lastReport = 0L

    private fun report(msg: String) {
        val now = SystemClock.uptimeMillis()
        if (now - lastReport < 3_000L) return
        lastReport = now
        runCatching { onProblem?.invoke(msg) }
    }

    companion object {
        const val MODE_ASYNC = 0
        const val MODE_WAIT_FOR_RESULT = 1
        const val MODE_WAIT_FOR_FINISH = 2
        private const val INVALID_UID = -1
        private const val VIRTUAL_DEVICE_ID = -1
    }
}

// =============================================================================================
// Synthetic multi-pointer table
// =============================================================================================

/**
 * The global multi-pointer state table for injected fingers.
 *
 * Pointer ids 0, 1 and 2 are RESERVED for the player's real fingers (joystick thumb, camera thumb, a
 * third finger). They are never written by this class. Our synthetic fingers use ids 3, 4, 5 and 6
 * (slots 0..3), so an injected pointer can never collide with a physical one inside the same window.
 *
 * Each call builds a MotionEvent (SOURCE_TOUCHSCREEN) with the full list of currently-down synthetic
 * pointers and the right action:
 *   first finger down        ACTION_DOWN
 *   further finger down      ACTION_POINTER_DOWN | (index << ACTION_POINTER_INDEX_SHIFT)
 *   finger moved             ACTION_MOVE
 *   finger up, others down   ACTION_POINTER_UP | (index << ACTION_POINTER_INDEX_SHIFT)
 *   last finger up           ACTION_UP
 * and injects it ASYNC through [InputManagerBridge]. ACTION_CANCEL is deliberately never used: it
 * would cancel the player's own gesture in the same window.
 *
 * Be aware that how a given game merges injected pointers with real ones is decided by the
 * InputDispatcher of that Android build and by the game's own touch code. Injection works on every
 * Android 8+ build with Shizuku; "no aim stutter" is the intended result, not something an app can
 * guarantee on every ROM.
 */
class SyntheticPointerTable(private val input: InputManagerBridge) {

    private class Finger(val slot: Int, val pointerId: Int, var x: Float, var y: Float)

    private val fingers = ArrayList<Finger>(MAX_SLOTS)
    private var downTime = 0L

    /** True while at least one synthetic finger is down. */
    @Synchronized
    fun isActive(): Boolean = fingers.isNotEmpty()

    @Synchronized
    fun isDown(slot: Int): Boolean = fingers.any { it.slot == slot }

    /** Puts synthetic finger [slot] (0..3) down at screen pixel (x, y). */
    @Synchronized
    fun down(slot: Int, x: Float, y: Float): Boolean {
        if (slot !in 0 until MAX_SLOTS) return false
        if (fingers.any { it.slot == slot }) return move(slot, x, y)
        val now = SystemClock.uptimeMillis()
        if (fingers.isEmpty()) downTime = now
        val f = Finger(slot, SYNTHETIC_IDS[slot], x, y)
        fingers += f
        val index = fingers.size - 1
        val action = if (fingers.size == 1) MotionEvent.ACTION_DOWN
        else MotionEvent.ACTION_POINTER_DOWN or (index shl MotionEvent.ACTION_POINTER_INDEX_SHIFT)
        val ok = dispatch(action, now)
        if (!ok) {
            fingers.remove(f)
            if (fingers.isEmpty()) downTime = 0L
        }
        return ok
    }

    /** Moves a finger that is already down. */
    @Synchronized
    fun move(slot: Int, x: Float, y: Float): Boolean {
        val f = fingers.firstOrNull { it.slot == slot } ?: return false
        f.x = x
        f.y = y
        return dispatch(MotionEvent.ACTION_MOVE, SystemClock.uptimeMillis())
    }

    /** Lifts one finger. Always removes it from the table, even when the injection was refused. */
    @Synchronized
    fun up(slot: Int): Boolean {
        val index = fingers.indexOfFirst { it.slot == slot }
        if (index < 0) return false
        val action = if (fingers.size == 1) MotionEvent.ACTION_UP
        else MotionEvent.ACTION_POINTER_UP or (index shl MotionEvent.ACTION_POINTER_INDEX_SHIFT)
        val ok = dispatch(action, SystemClock.uptimeMillis())
        fingers.removeAt(index)
        if (fingers.isEmpty()) downTime = 0L
        return ok
    }

    /** Lifts every synthetic finger one by one. Call when auto-touch stops or an overlay closes. */
    @Synchronized
    fun releaseAll() {
        while (fingers.isNotEmpty()) {
            val slot = fingers.last().slot
            if (!up(slot)) fingers.removeAll { it.slot == slot }
        }
    }

    /** Down, hold for [holdMs], up. The finger is always lifted, even if the coroutine is cancelled. */
    suspend fun tap(slot: Int, x: Float, y: Float, holdMs: Long): Boolean {
        if (!down(slot, x, y)) return false
        try {
            delay(holdMs.coerceAtLeast(1L))
        } finally {
            up(slot)
        }
        return true
    }

    /** Straight-line drag with intermediate MOVE events every [stepMs]. */
    suspend fun swipe(slot: Int, x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long, stepMs: Long = 8L): Boolean {
        if (!down(slot, x1, y1)) return false
        try {
            val total = durationMs.coerceAtLeast(stepMs)
            val steps = (total / stepMs).toInt().coerceAtLeast(1)
            for (i in 1..steps) {
                delay(stepMs)
                val t = i / steps.toFloat()
                move(slot, x1 + (x2 - x1) * t, y1 + (y2 - y1) * t)
            }
        } finally {
            up(slot)
        }
        return true
    }

    private fun dispatch(action: Int, eventTime: Long): Boolean {
        val n = fingers.size
        if (n == 0) return false
        val props = Array(n) { i ->
            MotionEvent.PointerProperties().apply {
                id = fingers[i].pointerId
                toolType = MotionEvent.TOOL_TYPE_FINGER
            }
        }
        val coords = Array(n) { i ->
            MotionEvent.PointerCoords().apply {
                x = fingers[i].x
                y = fingers[i].y
                pressure = 1f
                size = 1f
            }
        }
        val ev = MotionEvent.obtain(
            downTime, eventTime, action, n, props, coords,
            0, 0, 1f, 1f, input.touchDeviceId(), 0, InputDevice.SOURCE_TOUCHSCREEN, 0
        )
        return try {
            input.inject(ev, InputManagerBridge.MODE_ASYNC)
        } finally {
            ev.recycle()
        }
    }

    companion object {
        /** Real fingers: never touched by this class. */
        val RESERVED_PHYSICAL_IDS = intArrayOf(0, 1, 2)

        /** Pointer ids used by injected fingers, indexed by slot. */
        val SYNTHETIC_IDS = intArrayOf(3, 4, 5, 6)

        const val MAX_SLOTS = 4
    }
}
