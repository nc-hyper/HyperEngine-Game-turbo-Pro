package com.hyperengine.gameturbo.hub

import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import com.hyperengine.gameturbo.service.GameDetectorService
import com.hyperengine.gameturbo.ui.Brand
import com.hyperengine.gameturbo.ui.ChipGroup
import com.hyperengine.gameturbo.ui.LabPanel
import com.hyperengine.gameturbo.ui.Ui
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Game Space tab "HyperLab": the same controls as the in-game HUD tab, for any game in the library.
 * Pick a game, then set the colour filters, refresh-rate matching, the HyperBoost quality and the replay buffer.
 * Low-latency mode and the HyperBoost on/off switch only appear when the picked game is the one running right now.
 */
class LabPage(private val host: HubHost) : HubPage {

    override val id = "lab"
    override val title = Brand.LAB_TAB
    override val glyph = ""

    private val ctx = host.activity
    private val theme = host.theme

    private lateinit var picker: LinearLayout
    private lateinit var panelHolder: LinearLayout

    private var entries: List<GameEntry> = emptyList()
    private var selected: String? = null
    private var scanJob: Job? = null

    override fun createView(): View {
        val scroll = ScrollView(ctx)
        val root = Ui.vbox(ctx)
        root.setPadding(0, 0, 0, host.dp(12))
        scroll.addView(root, FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        root.addView(Ui.section(ctx, theme, "Game"))
        picker = Ui.vbox(ctx)
        root.addView(picker, Ui.lp(Ui.MATCH, Ui.WRAP))

        panelHolder = Ui.vbox(ctx)
        root.addView(panelHolder, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(6), 0, 0))
        return scroll
    }

    override fun onShow() {
        scanJob?.cancel()
        scanJob = host.scope.launch {
            entries = host.library.scan(GameSort.RECENT).take(MAX_GAMES)
            val running = GameDetectorService.state.value.game
            if (selected == null || entries.none { it.pkg == selected }) {
                selected = running?.takeIf { r -> entries.any { it.pkg == r } } ?: entries.firstOrNull()?.pkg
            }
            renderPicker()
            renderPanel()
        }
    }

    override fun onHide() {
        scanJob?.cancel()
    }

    override fun onDestroy() {
        scanJob?.cancel()
        panelHolder.removeAllViews()
    }

    private fun renderPicker() {
        picker.removeAllViews()
        if (entries.isEmpty()) {
            picker.addView(Forms.note(host, "No games yet. Add one in the Games tab, then come back here."))
            return
        }
        val idx = entries.indexOfFirst { it.pkg == selected }.coerceAtLeast(0)
        picker.addView(ChipGroup(ctx, theme, entries.map { it.label }, idx, 2) { i ->
            selected = entries[i].pkg
            renderPanel()
        })
    }

    private fun renderPanel() {
        panelHolder.removeAllViews()
        val pkg = selected ?: return
        val live = GameDetectorService.state.value.game == pkg
        val panel = LabPanel(ctx, theme, pkg, live) { msg, err -> host.toast(msg, err) }
        panelHolder.addView(panel.build(), Ui.lp(Ui.MATCH, Ui.WRAP))
    }

    private companion object {
        const val MAX_GAMES = 10
    }
}
