package com.hyperengine.gameturbo.ui

import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.provider.Settings
import android.view.Choreographer
import android.view.View
import android.view.WindowManager
import com.hyperengine.gameturbo.core.SystemBridgeExecutor
import com.hyperengine.gameturbo.data.DanmakuConfig
import com.hyperengine.gameturbo.data.EdgeLightConfig
import com.hyperengine.gameturbo.service.DanmakuMessage
import com.hyperengine.gameturbo.service.DanmakuNotificationService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max

private fun DanmakuConfig.clean(): DanmakuConfig = copy(
    speedDpPerSec = speedDpPerSec.coerceIn(60, 400),
    fontSp = fontSp.coerceIn(10, 24),
    lanes = lanes.coerceIn(1, 5),
    textAlphaPct = textAlphaPct.coerceIn(30, 100),
    topOffsetDp = topOffsetDp.coerceIn(0, 200),
    blockMode = blockMode.coerceIn(0, 2)
)

// =============================================================================================
// The scrolling strip
// =============================================================================================

class DanmakuView(context: Context) : View(context) {

    private class Item(val text: String, val lane: Int, var x: Float, val width: Float, val color: Int)
    private class Pending(val text: String, val color: Int)

    private var cfg = DanmakuConfig()
    private val items = ArrayList<Item>()
    private val pending = ArrayDeque<Pending>()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD }
    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.DEFAULT_BOLD
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
    }
    private var last = 0L
    private var running = false
    private val frame = Choreographer.FrameCallback { t -> step(t) }

    init {
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
        apply(cfg)
    }

    private fun dp(v: Float) = v * resources.displayMetrics.density

    fun apply(c: DanmakuConfig) {
        cfg = c
        val px = c.fontSp * resources.displayMetrics.scaledDensity
        fill.textSize = px
        outline.textSize = px
        outline.strokeWidth = dp(2.5f)
        invalidate()
    }

    fun lineHeightPx(): Float {
        val fm = fill.fontMetrics
        return (fm.descent - fm.ascent) + dp(6f)
    }

    fun totalHeightPx(): Int = (lineHeightPx() * cfg.lanes + dp(4f)).toInt()

    fun push(text: String, color: Int) {
        while (pending.size >= 24) pending.removeFirst()
        pending.addLast(Pending(text, color))
        if (!running) {
            running = true
            last = 0L
            Choreographer.getInstance().postFrameCallback(frame)
        }
    }

    fun clearAll() {
        items.clear()
        pending.clear()
        invalidate()
    }

    override fun onDetachedFromWindow() {
        Choreographer.getInstance().removeFrameCallback(frame)
        running = false
        super.onDetachedFromWindow()
    }

    private fun step(t: Long) {
        if (last == 0L) last = t
        val dt = ((t - last) / 1_000_000_000f).coerceIn(0f, 0.1f)
        last = t
        val speed = cfg.speedDpPerSec * resources.displayMetrics.density
        for (it in items) it.x -= speed * dt
        items.removeAll { it.x + it.width < 0f }
        dispatchPending()
        invalidate()
        if (items.isNotEmpty() || pending.isNotEmpty()) {
            Choreographer.getInstance().postFrameCallback(frame)
        } else {
            running = false
            last = 0L
        }
    }

    private fun dispatchPending() {
        val w = width.toFloat()
        if (w <= 0f) return
        val gap = dp(40f)
        while (pending.isNotEmpty()) {
            var lane = -1
            for (l in 0 until cfg.lanes) {
                var tail = Float.NEGATIVE_INFINITY
                for (it in items) if (it.lane == l) tail = max(tail, it.x + it.width)
                if (tail < w - gap) { lane = l; break }
            }
            if (lane < 0) return
            val p = pending.removeFirst()
            items += Item(p.text, lane, w, fill.measureText(p.text), p.color)
        }
    }

    override fun onDraw(c: Canvas) {
        val fm = fill.fontMetrics
        val lh = lineHeightPx()
        val alpha = cfg.textAlphaPct * 255 / 100
        for (it in items) {
            val y = dp(2f) + it.lane * lh + dp(3f) - fm.ascent
            outline.color = Color.argb(alpha, 0, 0, 0)
            c.drawText(it.text, it.x, y, outline)
            fill.color = Color.argb(alpha, Color.red(it.color), Color.green(it.color), Color.blue(it.color))
            c.drawText(it.text, it.x, y, fill)
        }
    }
}

// =============================================================================================
// Pop-up blocking through Do Not Disturb
// =============================================================================================

/**
 * Silences heads-up pop-ups while you play by switching Do Not Disturb on, then puts it back. The
 * notification listener still receives everything, so the bullets keep coming.
 * The original DND state is written to disk before it is changed, so it is restored even if the
 * app is killed (see [stop], also called at start-up).
 */
class HeadsUpBlocker(private val ctx: Context, private val bridge: SystemBridgeExecutor) {

    private val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private val prefs = ctx.getSharedPreferences("hyper_phase5", Context.MODE_PRIVATE)

    // One background thread runs every save-then-change and change-then-forget step, in the order they were asked for.
    // The original DND state is still written to disk (commit, not apply) before it is changed, which is what makes the
    // restore survive a kill; the write just no longer blocks the main thread. A daemon thread, so it never keeps the
    // process alive.
    private val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "hyper-dnd").apply { isDaemon = true } }
    private val io = executor.asCoroutineDispatcher()
    private val ioScope = CoroutineScope(SupervisorJob() + io)

    fun hasAccess(): Boolean = nm.isNotificationPolicyAccessGranted

    /** Uses Shizuku or root to grant the app DND access when it does not have it. */
    suspend fun ensureAccess(): Boolean {
        if (hasAccess()) return true
        if (bridge.hasShell()) {
            bridge.shell("cmd notification allow_dnd ${ctx.packageName}")
        }
        return hasAccess()
    }

    /**
     * [mode] 1 = priority only, 2 = alarms only. False when access is missing, when the original state could not be
     * saved (then DND is left alone, because it could not be put back after a kill) or when Android refuses the change.
     */
    suspend fun start(mode: Int): Boolean = withContext(io) {
        if (!hasAccess()) return@withContext false
        if (!prefs.contains(KEY_ORIGINAL)) {
            val saved = prefs.edit().putInt(KEY_ORIGINAL, nm.currentInterruptionFilter).commit()
            if (!saved) return@withContext false
        }
        val target = if (mode == 2) NotificationManager.INTERRUPTION_FILTER_ALARMS
        else NotificationManager.INTERRUPTION_FILTER_PRIORITY
        try {
            nm.setInterruptionFilter(target)
            true
        } catch (_: Throwable) {
            false
        }
    }

    /** Puts DND back if this app changed it. Returns at once; the work runs in order after any earlier [start]. */
    fun stop() {
        ioScope.launch { restore() }
    }

    /**
     * Same as [stop], but waits (at most [timeoutMs]) until DND is back. Use it on teardown, where the process may be
     * killed right after: it is queued behind any [start] still running, so the order is always start, then restore.
     */
    fun stopAndWait(timeoutMs: Long = 1500L) {
        try {
            executor.submit { restore() }.get(timeoutMs, TimeUnit.MILLISECONDS)
        } catch (_: Throwable) {
            // timed out or interrupted: the restore stays queued, and start-up recovery retries it if the process dies
        }
    }

    private fun restore() {
        if (!prefs.contains(KEY_ORIGINAL)) return
        if (!hasAccess()) return
        val original = prefs.getInt(KEY_ORIGINAL, NotificationManager.INTERRUPTION_FILTER_ALL)
        try {
            nm.setInterruptionFilter(original)
            prefs.edit().remove(KEY_ORIGINAL).commit()
        } catch (_: Throwable) {
        }
    }

    companion object {
        private const val KEY_ORIGINAL = "dnd_original"
    }
}

// =============================================================================================
// Manager
// =============================================================================================

/** Owns the ticker window and connects it to [DanmakuNotificationService]. Main thread only. */
class DanmakuTicker(context: Context, private val wm: WindowManager, bridge: SystemBridgeExecutor) {

    private val ctx: Context = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val blocker = HeadsUpBlocker(ctx, bridge)

    var onAttached: (() -> Unit)? = null

    /** The light that runs around the screen edge together with every bullet (UI redesign, part 1). */
    val edgeLight = EdgeLighting(ctx, wm)

    private var active = false
    private var cfg = DanmakuConfig()
    private var view: DanmakuView? = null
    private var params: WindowManager.LayoutParams? = null
    private var attached = false
    private var lastBlockMode = -1
    private var syncJob: Job? = null
    private val recent = HashMap<String, Long>()

    private val _blockStatus = MutableStateFlow("")
    val blockStatus: StateFlow<String> = _blockStatus.asStateFlow()

    val dndAccess: Boolean get() = blocker.hasAccess()

    fun show(c: DanmakuConfig) {
        active = true
        edgeLight.start()
        // The light is fed straight from the notification listener, so it works with the ticker switched off.
        DanmakuNotificationService.edgeSink = { m -> edgeLight.pulse(m.color) }
        apply(c)
    }

    fun applyEdge(c: EdgeLightConfig) {
        edgeLight.apply(c)
    }

    fun apply(c: DanmakuConfig) {
        cfg = c.clean()
        if (!active || !cfg.enabled) {
            detach()
            DanmakuNotificationService.sink = null
            cancelSync()
            blocker.stop()
            lastBlockMode = -1
            _blockStatus.value = ""
            return
        }
        val v = view ?: DanmakuView(ctx).also { view = it }
        v.apply(cfg)
        val scr = OverlayKit.realSize(wm)
        val p = params ?: OverlayKit.params(scr.x, v.totalHeightPx(), "HyperEngineDanmaku", touchable = false)
            .also { params = it }
        p.width = scr.x
        p.height = v.totalHeightPx()
        p.x = 0
        p.y = Ui.dp(ctx, cfg.topOffsetDp)
        try {
            if (attached) {
                wm.updateViewLayout(v, p)
            } else {
                wm.addView(v, p)
                attached = true
                onAttached?.invoke()
            }
        } catch (_: Throwable) {
            attached = false
        }

        DanmakuNotificationService.snoozeOriginals = cfg.snoozeOriginals
        DanmakuNotificationService.sink = { m -> accept(m) }

        if (cfg.blockMode != lastBlockMode) {
            lastBlockMode = cfg.blockMode
            syncJob?.cancel()
            syncJob = scope.launch { syncBlocker(cfg.blockMode) }
        }
    }

    fun hide() {
        active = false
        DanmakuNotificationService.edgeSink = null
        edgeLight.stop()
        detach()
        DanmakuNotificationService.sink = null
        // Cancel first: a sync still in flight must not switch DND on after this restore has run. Any start that was
        // already running on the DND thread finishes before the restore below, because that thread runs one job at a time.
        cancelSync()
        blocker.stopAndWait()
        lastBlockMode = -1
        _blockStatus.value = ""
    }

    fun relayout() {
        val v = view ?: return
        val p = params ?: return
        if (!attached) return
        p.width = OverlayKit.realSize(wm).x
        runCatching { wm.updateViewLayout(v, p) }
    }

    /** Puts Do Not Disturb back if an earlier run was killed before it could. Safe to call any time. */
    fun recoverPending() {
        blocker.stop()
    }

    fun destroy() {
        hide()
        scope.cancel()
    }

    /** Scrolls a real bullet so the look can be judged without waiting for a notification. */
    fun sendTest() {
        val v = view ?: return
        v.push("[HyperEngine] Test bullet: this is how your notifications will scroll", 0xFF7CF5FF.toInt())
        edgeLight.pulse(0xFF2E7BFF.toInt())
    }

    // ---- internals ----

    private fun accept(m: DanmakuMessage): Boolean {
        val c = cfg
        if (!active || !c.enabled) return false
        if (c.whitelist.isNotEmpty() && m.packageName !in c.whitelist) return false
        val body = buildString {
            if (c.showAppName) append('[').append(m.appLabel).append("] ")
            if (m.title.isNotEmpty()) {
                append(m.title)
                if (m.text.isNotEmpty()) append(": ")
            }
            append(m.text)
        }
        if (body.isBlank()) return false
        val now = System.currentTimeMillis()
        val key = m.packageName + "|" + body
        val prev = recent[key]
        if (prev != null && now - prev < 3000L) return false
        recent[key] = now
        if (recent.size > 60) recent.entries.removeAll { now - it.value > 10_000L }
        view?.push(body, colorFor(m))
        return true
    }

    private fun colorFor(m: DanmakuMessage): Int {
        if (m.color != 0) {
            // same hue as the edge light, softened so the text stays readable
            val hsv = FloatArray(3)
            Color.colorToHSV(m.color, hsv)
            hsv[1] = hsv[1].coerceAtMost(0.55f)
            hsv[2] = 1f
            return Color.HSVToColor(hsv)
        }
        val hue = (abs(m.packageName.hashCode()) % 360).toFloat()
        return Color.HSVToColor(floatArrayOf(hue, 0.35f, 1f))
    }

    private suspend fun syncBlocker(mode: Int) {
        if (mode == 0) {
            blocker.stop()
            _blockStatus.value = ""
            return
        }
        if (!blocker.ensureAccess()) {
            _blockStatus.value = "Pop-up blocking needs Do Not Disturb access"
            return
        }
        _blockStatus.value = if (blocker.start(mode)) {
            if (mode == 2) "Pop-ups blocked (Do Not Disturb: alarms only, calls are silenced too)"
            else "Pop-ups blocked (Do Not Disturb: priority only)"
        } else {
            "Could not switch Do Not Disturb on"
        }
    }

    private fun cancelSync() {
        syncJob?.cancel()
        syncJob = null
    }

    private fun detach() {
        val v = view
        if (attached && v != null) runCatching { wm.removeViewImmediate(v) }
        attached = false
        view = null
        params = null
    }
}

// =============================================================================================
// Sidebar tool page
// =============================================================================================

class DanmakuTool(private val ticker: DanmakuTicker) : HudTool("danmaku") {

    override fun isActive(host: ToolHost): Boolean = host.deps.repo.global.value.danmaku.enabled

    override fun onTap(host: ToolHost) {
        val ctx = host.hostContext
        val theme = host.theme
        val repo = host.deps.repo
        var cfg = repo.global.value.danmaku
        val col = Ui.vbox(ctx)

        col.addView(ToolUi.note(host,
            "Scrolls incoming notifications across the top of the game as bullets, so you can read them " +
                "without leaving. It needs Notification access. The settings here apply to every game. " +
                "Edge lighting at the bottom of this page works with or without the ticker."))

        fun commit(next: DanmakuConfig, rebuild: Boolean = false) {
            cfg = next
            repo.updateGlobal { it.copy(danmaku = cfg) }
            ticker.apply(cfg)
            host.refreshTiles()
            if (rebuild) onTap(host)
        }

        // ---- notification access ----
        val access = Ui.label(ctx, "", 11f, theme.textSecondary)
        col.addView(access)
        val grant = Ui.button(ctx, theme, "Grant notification access", true) {
            host.scope.launch {
                val cn = ComponentName(ctx, DanmakuNotificationService::class.java)
                val r = host.deps.bridge.enableNotificationListener(cn)
                if (r.ok) {
                    host.toast("Notification access enabled")
                } else {
                    host.toast("Could not enable it automatically: " + r.message)
                    runCatching {
                        ctx.startActivity(
                            Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                }
            }
        }
        col.addView(grant, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 4), 0, Ui.dp(ctx, 6)))
        host.scope.launch {
            DanmakuNotificationService.connected.collect { on ->
                access.text = if (on) "Notification access: granted"
                else "Notification access: not granted. Without it there is nothing to show."
                access.setTextColor(if (on) theme.good else theme.warn)
                grant.visibility = if (on) View.GONE else View.VISIBLE
            }
        }

        col.addView(Hyper.switchRow(
            ctx, theme, "Danmaku ticker", "Scroll incoming notifications across the top of the game", cfg.enabled
        ) { commit(cfg.copy(enabled = it), rebuild = true) })

        if (cfg.enabled) {
            col.addView(Ui.section(ctx, theme, "Look"))
            col.addView(ToolUi.liveSlider(ctx, theme, "Scroll speed", " dp/s", 60, 400, cfg.speedDpPerSec,
                { ticker.apply(cfg.copy(speedDpPerSec = it)) }, { commit(cfg.copy(speedDpPerSec = it)) }))
            col.addView(ToolUi.liveSlider(ctx, theme, "Font size", " sp", 10, 24, cfg.fontSp,
                { ticker.apply(cfg.copy(fontSp = it)) }, { commit(cfg.copy(fontSp = it)) }))
            col.addView(ToolUi.liveSlider(ctx, theme, "Lines", "", 1, 5, cfg.lanes,
                { ticker.apply(cfg.copy(lanes = it)) }, { commit(cfg.copy(lanes = it)) }))
            col.addView(ToolUi.liveSlider(ctx, theme, "Opacity", " %", 30, 100, cfg.textAlphaPct,
                { ticker.apply(cfg.copy(textAlphaPct = it)) }, { commit(cfg.copy(textAlphaPct = it)) }))
            col.addView(ToolUi.liveSlider(ctx, theme, "Distance from top", " dp", 0, 200, cfg.topOffsetDp,
                { ticker.apply(cfg.copy(topOffsetDp = it)) }, { commit(cfg.copy(topOffsetDp = it)) }))
            col.addView(ToolUi.check(ctx, theme, "Show the app name", cfg.showAppName) { commit(cfg.copy(showAppName = it)) })
            col.addView(Ui.button(ctx, theme, "Send a test bullet") { ticker.sendTest() },
                Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 4), 0, 0))

            // ---- pop-up blocking ----
            col.addView(Ui.section(ctx, theme, "Block pop-ups while playing"))
            col.addView(ToolUi.note(host,
                "Uses Do Not Disturb so heads-up banners stay away while the bullets still scroll. Your original " +
                    "Do Not Disturb setting comes back when the game closes. 'Alarms only' silences calls as well."))
            col.addView(ChipGroup(
                ctx, theme, listOf("Off", "Priority only", "Alarms only"), cfg.blockMode.coerceIn(0, 2), 3
            ) { i -> commit(cfg.copy(blockMode = i), rebuild = true) })
            if (cfg.blockMode != 0 && !ticker.dndAccess) {
                col.addView(Ui.button(ctx, theme, "Allow Do Not Disturb control", true) {
                    host.scope.launch {
                        val bridge = host.deps.bridge
                        var ok = false
                        if (bridge.hasShell()) {
                            bridge.shell("cmd notification allow_dnd ${ctx.packageName}")
                            ok = ticker.dndAccess
                        }
                        if (ok) {
                            commit(cfg, rebuild = true)
                        } else {
                            runCatching {
                                ctx.startActivity(
                                    Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            }
                            host.toast("Allow HyperEngine there, then pick the mode again")
                        }
                    }
                }, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 4), 0, Ui.dp(ctx, 4)))
            }
            val blockStatus = Ui.label(ctx, "", 11f, theme.textSecondary)
            col.addView(blockStatus)
            host.scope.launch { ticker.blockStatus.collect { blockStatus.text = it } }
            col.addView(ToolUi.check(ctx, theme, "Also hide the original notification for 15 minutes", cfg.snoozeOriginals) {
                commit(cfg.copy(snoozeOriginals = it))
            })
            col.addView(ToolUi.note(host,
                "Hidden originals are snoozed, not deleted: Android shows them again after 15 minutes. They may " +
                    "flash for an instant before they disappear."))

            // ---- whitelist ----
            col.addView(Ui.section(ctx, theme, "Apps shown"))
            col.addView(ToolUi.note(host, "Tick the apps whose notifications should scroll. With nothing ticked, every app does."))
            col.addView(Ui.button(ctx, theme, "Clear selection (all apps)") {
                commit(cfg.copy(whitelist = emptyList()), rebuild = true)
            })
            val listBox = Ui.vbox(ctx)
            col.addView(listBox)
            host.scope.launch {
                val apps = withContext(Dispatchers.Default) { launchableApps(ctx) }
                apps.forEach { (pkg, label) ->
                    listBox.addView(ToolUi.check(ctx, theme, label, pkg in cfg.whitelist) { on ->
                        val next = if (on) (cfg.whitelist + pkg).distinct() else cfg.whitelist - pkg
                        commit(cfg.copy(whitelist = next))
                    })
                }
            }
        }

        // ---- edge lighting: independent of the ticker, so it is reachable (and works) with the ticker off ----
        col.addView(EdgeLightPanel.build(host, ticker.edgeLight) { onTap(host) })

        host.openDetail("Danmaku ticker", col)
    }

    /** Installed apps with a launcher icon, sorted by name. */
    private fun launchableApps(ctx: Context): List<Pair<String, String>> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .mapNotNull { ri ->
                val pkg = ri.activityInfo?.packageName ?: return@mapNotNull null
                if (pkg == ctx.packageName) null else pkg to ri.loadLabel(pm).toString()
            }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
    }
}
