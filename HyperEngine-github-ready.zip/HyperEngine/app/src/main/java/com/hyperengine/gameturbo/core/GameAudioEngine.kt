package com.hyperengine.gameturbo.core

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AudioEffect
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import android.os.Build
import com.hyperengine.gameturbo.data.AudioConfig
import com.hyperengine.gameturbo.data.AudioPreset
import com.hyperengine.gameturbo.data.VoicePreset
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Random
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

// =============================================================================================
// Presets
// =============================================================================================

object AudioPresets {

    /** The 10 bands shown in the UI. */
    val BAND_HZ = intArrayOf(31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)
    val BAND_LABELS = listOf("31", "62", "125", "250", "500", "1k", "2k", "4k", "8k", "16k")
    const val GAIN_LIMIT_DB = 12f

    class Settings(val bands: List<Float>, val bass: Int, val virtualizer: Int, val loudnessMb: Int)

    private val FOOTSTEP = Settings(
        // cuts the sub-120 Hz rumble, lifts 1.5 kHz - 4 kHz where footsteps and reloads sit
        bands = listOf(-12f, -12f, -7f, -2f, 0f, 2f, 6f, 6f, 2f, 0f),
        bass = 0, virtualizer = 250, loudnessMb = 300
    )
    private val GUNFIRE_DAMPER = Settings(
        // takes the bite out of the 2 kHz - 8 kHz crack of gunshots, keeps the low end
        bands = listOf(0f, 0f, 0f, 0f, 0f, -2f, -5f, -6f, -5f, -3f),
        bass = 150, virtualizer = 0, loudnessMb = 0
    )
    private val ORCHESTRAL = Settings(
        // gentle smile curve with extra width
        bands = listOf(3f, 2f, 1f, 0f, -1f, 0f, 1f, 2f, 3f, 3f),
        bass = 300, virtualizer = 600, loudnessMb = 0
    )

    fun settingsFor(cfg: AudioConfig): Settings? = when (cfg.preset) {
        AudioPreset.OFF -> null
        AudioPreset.FPS_FOOTSTEP -> FOOTSTEP
        AudioPreset.BR_GUNFIRE_DAMPER -> GUNFIRE_DAMPER
        AudioPreset.RPG_ORCHESTRAL -> ORCHESTRAL
        AudioPreset.CUSTOM -> Settings(
            bands = List(10) { cfg.bandGainsDb.getOrElse(it) { 0f } },
            bass = cfg.bassBoost, virtualizer = cfg.virtualizer, loudnessMb = cfg.loudnessMb
        )
    }

    /** Starting point when the user moves from a preset to hand tuning: the preset's own values. */
    fun toCustom(cfg: AudioConfig): AudioConfig {
        val s = settingsFor(cfg) ?: return cfg.copy(preset = AudioPreset.CUSTOM)
        return cfg.copy(
            preset = AudioPreset.CUSTOM,
            bandGainsDb = s.bands, bassBoost = s.bass, virtualizer = s.virtualizer, loudnessMb = s.loudnessMb
        )
    }

    /**
     * Gain at [hz], interpolated between the 10 UI bands on a log-frequency axis. This is how 10
     * bands are mapped onto however many bands the phone's equalizer really has (usually 5).
     */
    fun gainAt(hz: Float, bands: List<Float>): Float {
        if (hz <= BAND_HZ.first()) return bands.first()
        if (hz >= BAND_HZ.last()) return bands.last()
        for (i in 0 until BAND_HZ.size - 1) {
            val lo = BAND_HZ[i].toFloat()
            val hi = BAND_HZ[i + 1].toFloat()
            if (hz in lo..hi) {
                val t = (ln(hz) - ln(lo)) / (ln(hi) - ln(lo))
                return bands[i] + (bands[i + 1] - bands[i]) * t
            }
        }
        return 0f
    }
}

// =============================================================================================
// Equalizer / effects on the global output mix
// =============================================================================================

data class AudioEngineState(
    val active: Boolean = false,
    val message: String = "Off",
    val deviceBands: Int = 0,
    val sessions: Int = 0
)

/**
 * Equalizer + BassBoost + Virtualizer + LoudnessEnhancer, attached to the global output mix
 * (audio session 0) and, when the game announces its own audio session, to that session too.
 *
 *  - The phone's equalizer usually has 5 bands, so the 10-band curve is interpolated onto them.
 *  - A positive preamp is realised by the LoudnessEnhancer; a negative preamp lowers every band.
 *  - Android deprecated session-0 effects and some ROMs ignore them. The engine reports exactly which
 *    effects the system accepted; it cannot hear the result, so "active" means "accepted", not "audible".
 *
 * Main thread only. Effects are released when the game closes.
 */
class GameAudioEngine(context: Context) {

    private val ctx: Context = context.applicationContext

    private class Chain(val session: Int) {
        var eq: Equalizer? = null
        var bass: BassBoost? = null
        var virt: Virtualizer? = null
        var loud: LoudnessEnhancer? = null

        fun release() {
            runCatching { eq?.release() }
            runCatching { bass?.release() }
            runCatching { virt?.release() }
            runCatching { loud?.release() }
            eq = null; bass = null; virt = null; loud = null
        }
    }

    private val _state = MutableStateFlow(AudioEngineState())
    val state: StateFlow<AudioEngineState> = _state.asStateFlow()

    private val chains = LinkedHashMap<Int, Chain>()
    private var cfg = AudioConfig()
    private var game: String? = null
    private var receiverRegistered = false
    private var lastNotes = ""

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val session = i.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, -1)
            if (session <= 0) return
            when (i.action) {
                AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION -> {
                    val pkg = i.getStringExtra(AudioEffect.EXTRA_PACKAGE_NAME)
                    if (pkg != null && pkg == game && cfg.preset != AudioPreset.OFF && !chains.containsKey(session)) {
                        val ch = Chain(session)
                        chains[session] = ch
                        program(ch, cfg)
                        publish()
                    }
                }
                AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION -> {
                    if (session != 0) chains.remove(session)?.release()
                    publish()
                }
            }
        }
    }

    /** Applies [c]. Cheap when only values changed (it reprograms the live effects). */
    fun apply(c: AudioConfig, gamePackage: String?) {
        game = gamePackage
        val s = AudioPresets.settingsFor(c)
        if (s == null) {
            cfg = c
            release()
            return
        }
        cfg = c
        registerReceiver()
        val global = chains.getOrPut(0) { Chain(0) }
        program(global, c)
        chains.values.filter { it.session != 0 }.forEach { program(it, c) }
        publish()
    }

    fun release() {
        unregisterReceiver()
        chains.values.forEach { it.release() }
        chains.clear()
        lastNotes = ""
        _state.value = AudioEngineState(false, "Off")
    }

    // ---- internals ----

    private fun publish() {
        val live = chains.values.count { it.eq != null || it.bass != null || it.virt != null || it.loud != null }
        val bands = chains[0]?.eq?.numberOfBands?.toInt() ?: chains.values.firstNotNullOfOrNull { it.eq?.numberOfBands?.toInt() } ?: 0
        _state.value = if (live > 0) {
            AudioEngineState(true, lastNotes, bands, live)
        } else {
            AudioEngineState(false, lastNotes.ifBlank { "The system refused every audio effect" }, bands, 0)
        }
    }

    private fun program(ch: Chain, c: AudioConfig) {
        val s = AudioPresets.settingsFor(c) ?: return
        val ok = ArrayList<String>()
        val bad = ArrayList<String>()

        // ---- equalizer ----
        try {
            val eq = ch.eq ?: Equalizer(0, ch.session).also { ch.eq = it }
            val range = eq.bandLevelRange
            val minMb = range[0].toInt()
            val maxMb = range[1].toInt()
            val n = eq.numberOfBands.toInt()
            val bandsCut = min(c.preampDb, 0f)
            for (b in 0 until n) {
                val hz = eq.getCenterFreq(b.toShort()) / 1000f
                val db = AudioPresets.gainAt(hz, s.bands) + bandsCut
                val mb = (db * 100f).roundToInt().coerceIn(minMb, maxMb)
                eq.setBandLevel(b.toShort(), mb.toShort())
            }
            val rc = eq.setEnabled(true)
            if (rc == AudioEffect.SUCCESS) ok += "equalizer ($n bands)" else bad += "equalizer (error $rc)"
        } catch (t: Throwable) {
            runCatching { ch.eq?.release() }
            ch.eq = null
            bad += "equalizer (${t.javaClass.simpleName})"
        }

        // ---- bass boost ----
        try {
            if (s.bass > 0) {
                val bb = ch.bass ?: BassBoost(0, ch.session).also { ch.bass = it }
                if (bb.strengthSupported) {
                    bb.setStrength(s.bass.coerceIn(0, 1000).toShort())
                    val rc = bb.setEnabled(true)
                    if (rc == AudioEffect.SUCCESS) ok += "bass boost" else bad += "bass boost (error $rc)"
                } else {
                    bad += "bass boost (not supported)"
                }
            } else {
                ch.bass?.let { runCatching { it.setEnabled(false) } }
            }
        } catch (t: Throwable) {
            runCatching { ch.bass?.release() }
            ch.bass = null
            bad += "bass boost (${t.javaClass.simpleName})"
        }

        // ---- virtualizer ----
        try {
            if (s.virtualizer > 0) {
                val v = ch.virt ?: Virtualizer(0, ch.session).also { ch.virt = it }
                if (v.strengthSupported) {
                    v.setStrength(s.virtualizer.coerceIn(0, 1000).toShort())
                    val rc = v.setEnabled(true)
                    if (rc == AudioEffect.SUCCESS) ok += "virtualizer" else bad += "virtualizer (error $rc)"
                } else {
                    bad += "virtualizer (not supported)"
                }
            } else {
                ch.virt?.let { runCatching { it.setEnabled(false) } }
            }
        } catch (t: Throwable) {
            runCatching { ch.virt?.release() }
            ch.virt = null
            bad += "virtualizer (${t.javaClass.simpleName})"
        }

        // ---- loudness (also carries a positive preamp) ----
        try {
            val gainMb = (s.loudnessMb + max(c.preampDb, 0f) * 100f).roundToInt().coerceIn(0, 3000)
            if (gainMb > 0) {
                val le = ch.loud ?: LoudnessEnhancer(ch.session).also { ch.loud = it }
                le.setTargetGain(gainMb)
                val rc = le.setEnabled(true)
                if (rc == AudioEffect.SUCCESS) ok += "loudness +${gainMb / 100f} dB" else bad += "loudness (error $rc)"
            } else {
                ch.loud?.let { runCatching { it.setEnabled(false) } }
            }
        } catch (t: Throwable) {
            runCatching { ch.loud?.release() }
            ch.loud = null
            bad += "loudness (${t.javaClass.simpleName})"
        }

        val where = if (ch.session == 0) "global mix" else "game session ${ch.session}"
        if (ch.session == 0) {
            lastNotes = buildString {
                if (ok.isNotEmpty()) append("Accepted on the ").append(where).append(": ").append(ok.joinToString(", "))
                if (bad.isNotEmpty()) {
                    if (isNotEmpty()) append(". ")
                    append("Refused: ").append(bad.joinToString(", "))
                }
            }
        }
    }

    private fun registerReceiver() {
        if (receiverRegistered) return
        val f = IntentFilter().apply {
            addAction(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION)
            addAction(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION)
        }
        receiverRegistered = try {
            if (Build.VERSION.SDK_INT >= 33) ctx.registerReceiver(receiver, f, Context.RECEIVER_EXPORTED)
            else ctx.registerReceiver(receiver, f)
            true
        } catch (_: Throwable) {
            false
        }
    }

    private fun unregisterReceiver() {
        if (!receiverRegistered) return
        runCatching { ctx.unregisterReceiver(receiver) }
        receiverRegistered = false
    }
}

// =============================================================================================
// Voice changer DSP
// =============================================================================================

/**
 * Pitch shifter built from two crossfading read heads on a delay line (no FFT, no latency beyond
 * the 40 ms window). The ratio changes pitch and formants together, which is what gives the
 * chipmunk / deep-giant character of the presets.
 */
class PitchShifter(private val ratio: Float, sampleRate: Int) {
    private val win = (sampleRate * 0.04f).toInt().coerceAtLeast(64)
    private val size = win + 8
    private val buf = FloatArray(size)
    private var w = 0
    private var phase = 0f

    fun process(x: Float): Float {
        buf[w] = x
        phase += (1f - ratio) / win
        if (phase >= 1f) phase -= 1f
        if (phase < 0f) phase += 1f
        val phaseB = (phase + 0.5f) % 1f
        val yA = read(phase * win)
        val yB = read(phaseB * win)
        val gA = 1f - abs(2f * phase - 1f)
        val gB = 1f - abs(2f * phaseB - 1f)
        w = (w + 1) % size
        return yA * gA + yB * gB
    }

    private fun read(delay: Float): Float {
        var pos = w - delay
        while (pos < 0f) pos += size
        val i0 = pos.toInt() % size
        val frac = pos - pos.toInt()
        val i1 = (i0 + 1) % size
        return buf[i0] * (1f - frac) + buf[i1] * frac
    }
}

/** One voice effect. Create a new instance per recording or stream: it keeps filter state. */
class VoiceDsp(private val preset: VoicePreset, private val sampleRate: Int) {

    private val shifter: PitchShifter? = when (preset) {
        VoicePreset.CYBORG -> PitchShifter(0.92f, sampleRate)
        VoicePreset.DEEP_TITAN -> PitchShifter(0.72f, sampleRate)
        VoicePreset.HELIUM -> PitchShifter(1.65f, sampleRate)
        VoicePreset.ANIME_GIRL -> PitchShifter(1.35f, sampleRate)
        else -> null
    }

    private fun alpha(fc: Float): Float = 1f - exp(-2.0 * PI * fc / sampleRate).toFloat()

    private val a200 = alpha(200f)
    private val a350 = alpha(350f)
    private val a2800 = alpha(2800f)
    private val a3000 = alpha(3000f)
    private var lpA = 0f
    private var lpB = 0f
    private var phase = 0.0
    private val noise = Random(7)

    fun process(buf: ShortArray, len: Int) {
        if (preset == VoicePreset.ORIGINAL) return
        for (i in 0 until len) {
            var x = buf[i] / 32768f
            x = shifter?.process(x) ?: x
            x = when (preset) {
                VoicePreset.CYBORG -> {
                    val carrier = sin(phase).toFloat()
                    phase += 2.0 * PI * 55.0 / sampleRate
                    if (phase > 2.0 * PI) phase -= 2.0 * PI
                    val ring = x * (0.35f + 0.9f * carrier)
                    (ring * 24f).roundToInt() / 24f            // light bit-crush
                }
                VoicePreset.DEEP_TITAN -> {
                    lpA += a200 * (x - lpA)
                    softClip((x + lpA * 0.8f) * 1.3f)
                }
                VoicePreset.HELIUM -> {
                    lpA += a200 * (x - lpA)
                    x - lpA                                    // remove rumble
                }
                VoicePreset.ANIME_GIRL -> {
                    lpA += a3000 * (x - lpA)
                    x + 0.6f * (x - lpA)                       // presence / air
                }
                VoicePreset.WALKIE_TALKIE -> {
                    lpA += a350 * (x - lpA)
                    val hp = x - lpA                           // 350 Hz high-pass
                    lpB += a2800 * (hp - lpB)                  // 2.8 kHz low-pass
                    softClip(lpB * 3.2f) * 0.9f + (noise.nextFloat() - 0.5f) * 0.02f
                }
                else -> x
            }
            buf[i] = (x.coerceIn(-1f, 1f) * 32767f).roundToInt().toShort()
        }
    }

    fun processAll(src: ShortArray): ShortArray {
        val out = src.copyOf()
        process(out, out.size)
        return out
    }

    private fun softClip(v: Float): Float = v / (1f + abs(v))
}

// The voice recorder / live monitor (VoiceStudio, VoiceState) now lives in ReliableVoiceChangerEngine.kt.
