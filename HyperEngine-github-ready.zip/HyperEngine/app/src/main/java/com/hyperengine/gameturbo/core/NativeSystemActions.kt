package com.hyperengine.gameturbo.core

import android.content.Context
import android.content.Intent
import android.hardware.input.InputManager
import android.net.ConnectivityManager
import android.provider.Settings
import android.view.InputDevice
import com.hyperengine.gameturbo.service.ProjectionActivity
import com.hyperengine.gameturbo.service.ScreenRecordService
import com.hyperengine.gameturbo.service.TouchMacroService
import com.hyperengine.gameturbo.ui.HudBus
import kotlinx.coroutines.delay
import java.net.Inet4Address
import java.net.NetworkInterface

/** Outcome of one native action. [engine] says which route was used. */
data class ActionResult(val ok: Boolean, val message: String, val engine: String = "")

/** A keyboard or mouse that Android currently sees. */
data class HidDevice(val id: Int, val name: String, val keyboard: Boolean, val mouse: Boolean, val bluetoothOrUsb: String)

/**
 * The phone's own tools, used instead of re-implementing them:
 *
 *  screenshot   the system screenshot action (accessibility global action, else KEYCODE_SYSRQ through the shell),
 *               taken with the HUD hidden so it is not in the picture
 *  recorder     the manufacturer's screen recorder when one is installed (Xiaomi, OPPO / Realme, Samsung, vivo ...),
 *               otherwise the built-in MediaProjection recorder ([ScreenRecordService])
 *  cast         Android's cast screen, Xiaomi MiPlay where it exists
 *  Studio       ADB-over-network helper for scrcpy and the live Wi-Fi address; keyboard / mouse detection
 */
class NativeSystemActions(
    context: Context,
    private val bridge: SystemBridgeExecutor
) {

    private val ctx: Context = context.applicationContext

    // =========================================================================================
    // Screenshot
    // =========================================================================================

    /**
     * Hides the HUD, waits 150 ms, takes the phone's own screenshot, then brings the HUD back. The screenshot is
     * saved by the system exactly where a hardware-button screenshot would go (Gallery / Pictures / Screenshots).
     */
    suspend fun screenshot(): ActionResult {
        HudBus.captureHider?.invoke(true)
        try {
            delay(150L)
            val svc = TouchMacroService.instance
            if (svc != null && svc.takeScreenshot()) {
                delay(700L)   // the system captures asynchronously; keep the HUD hidden until it has
                return ActionResult(true, "Screenshot taken. Find it in Gallery, Screenshots.", "accessibility")
            }
            if (bridge.hasShell()) {
                val r = bridge.pressKey(120)   // KEYCODE_SYSRQ: the system screenshot key
                if (r.ok) {
                    delay(700L)
                    return ActionResult(true, "Screenshot taken through Shizuku. Find it in Gallery, Screenshots.", "shell key")
                }
                return ActionResult(false, "Shell screenshot failed: " + r.message, "shell key")
            }
            return ActionResult(
                false,
                "Turn on the HyperEngine accessibility service (or start Shizuku) so the phone's own screenshot can be triggered.",
                "none"
            )
        } finally {
            HudBus.captureHider?.invoke(false)
        }
    }

    // =========================================================================================
    // Screen recorder
    // =========================================================================================

    /** Package names of manufacturer screen recorders, most specific first. */
    private val oemRecorders = listOf(
        "com.miui.screenrecorder",
        "com.oplus.screenrecorder",
        "com.coloros.screenrecorder",
        "com.samsung.android.app.smartcapture",
        "com.vivo.screenrecorder",
        "com.android.systemui.screenrecord",
        "com.huawei.screenrecorder",
        "com.oneplus.screenrecord",
        "com.asus.screenrecorder",
        "com.nothing.screenrecorder"
    )

    /** The installed manufacturer recorder that has a launchable screen, or null. */
    fun oemRecorderPackage(): String? = oemRecorders.firstOrNull { pkg ->
        runCatching {
            ctx.packageManager.getPackageInfo(pkg, 0)
            ctx.packageManager.getLaunchIntentForPackage(pkg) != null
        }.getOrDefault(false)
    }

    /** Opens the phone's own recorder. Its floating controls then appear over the game. */
    fun openOemRecorder(): ActionResult {
        val pkg = oemRecorderPackage()
            ?: return ActionResult(false, "No manufacturer screen recorder found on this phone. Use the built-in recorder.", "none")
        return try {
            val i = ctx.packageManager.getLaunchIntentForPackage(pkg)!!.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            ActionResult(true, "Opened the phone's screen recorder ($pkg). Start recording from its own controls.", pkg)
        } catch (t: Throwable) {
            ActionResult(false, "Could not open $pkg: " + (t.message ?: t.javaClass.simpleName), pkg)
        }
    }

    /**
     * Starts the built-in MediaProjection recorder. Android asks the user to approve screen capture once per
     * recording (a system dialog over the game), then [ScreenRecordService] records to Movies/HyperEngine.
     */
    fun startBuiltInRecorder(withMic: Boolean): ActionResult {
        return try {
            ProjectionActivity.request(ctx, ProjectionActivity.PURPOSE_RECORD, withMic)
            ActionResult(true, "Approve the screen capture prompt to start recording.", "MediaProjection")
        } catch (t: Throwable) {
            ActionResult(false, "Could not start the recorder: " + (t.message ?: t.javaClass.simpleName), "MediaProjection")
        }
    }

    fun stopBuiltInRecorder(): ActionResult {
        ctx.startService(Intent(ctx, ScreenRecordService::class.java).setAction(ScreenRecordService.ACTION_STOP))
        return ActionResult(true, "Stopping and saving the recording.", "MediaProjection")
    }

    // =========================================================================================
    // Cast
    // =========================================================================================

    /** Opens the phone's cast picker over the game. Xiaomi MiPlay is tried first where it exists. */
    fun openCast(): ActionResult {
        val candidates = listOf(
            Intent("miui.intent.action.MIPLAY") to "Xiaomi MiPlay",
            Intent(Settings.ACTION_CAST_SETTINGS) to "Cast screen"
        )
        for ((intent, name) in candidates) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val resolvable = ctx.packageManager.resolveActivity(intent, 0) != null
            if (!resolvable) continue
            try {
                ctx.startActivity(intent)
                return ActionResult(true, "Opened $name.", name)
            } catch (_: Throwable) {
                // try the next one
            }
        }
        return ActionResult(false, "This phone has no cast screen. Look for Smart View, Screen Mirroring or Wireless display in Quick Settings.", "none")
    }

    // =========================================================================================
    // Studio: ADB over network helper, address, keyboard / mouse
    // =========================================================================================

    /** The phone's current IPv4 address on Wi-Fi / Ethernet / hotspot, or null when offline. */
    fun localIp(): String? = runCatching {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val lp = cm.getLinkProperties(cm.activeNetwork)
        lp?.linkAddresses?.map { it.address }?.firstOrNull { it is Inet4Address && !it.isLoopbackAddress }?.hostAddress
            ?: NetworkInterface.getNetworkInterfaces().toList()
                .filter { it.isUp && !it.isLoopback && !it.name.startsWith("rmnet") && !it.name.startsWith("ccmni") }
                .flatMap { it.inetAddresses.toList() }
                .firstOrNull { it is Inet4Address && !it.isLoopbackAddress }?.hostAddress
    }.getOrNull()

    data class AdbBridgeInfo(
        val tcpPort: Int,            // value of service.adb.tcp.port (-1 / 0 = not set)
        val wirelessDebugging: Boolean,
        val usbDebugging: Boolean,
        val ip: String?
    ) {
        val connectCommand: String? get() = if (tcpPort > 0 && ip != null) "adb connect $ip:$tcpPort" else null
    }

    suspend fun adbBridgeInfo(): AdbBridgeInfo {
        val port = if (bridge.hasShell()) bridge.shell("getprop service.adb.tcp.port", 4_000L).stdout.trim().toIntOrNull() ?: -1 else -1
        val wifi = runCatching { Settings.Global.getInt(ctx.contentResolver, "adb_wifi_enabled", 0) == 1 }.getOrDefault(false)
        val usb = runCatching { Settings.Global.getInt(ctx.contentResolver, Settings.Global.ADB_ENABLED, 0) == 1 }.getOrDefault(false)
        return AdbBridgeInfo(port, wifi, usb, localIp())
    }

    /**
     * Sets `service.adb.tcp.port` so a PC can `adb connect <ip>:5555` for scrcpy. The property only takes effect
     * when adbd next restarts (toggle USB debugging, or reboot). It is deliberately NOT restarted from here:
     * Shizuku runs as a child of adbd, so restarting it would stop Shizuku and every feature that needs it.
     */
    suspend fun setAdbTcpPort(port: Int): ActionResult {
        if (!bridge.hasShell()) return ActionResult(false, "Needs Shizuku or root to set the adb port.", "none")
        val r = bridge.setProp("service.adb.tcp.port", port.toString())
        return if (r.ok) {
            ActionResult(true, "Port $port saved. It becomes active the next time USB debugging is toggled or the phone restarts.", "setprop")
        } else {
            ActionResult(false, "setprop failed: " + r.message, "setprop")
        }
    }

    /** Opens Developer options so Wireless debugging (the pairing based, restart-free way) can be switched on. */
    fun openDeveloperSettings(): ActionResult = try {
        ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        ActionResult(true, "Opened Developer options.", "settings")
    } catch (t: Throwable) {
        ActionResult(false, "Developer options not available: " + (t.message ?: ""), "settings")
    }

    /** Hardware keyboards and mice Android sees right now (USB OTG, Bluetooth). Virtual and built-in keys are skipped. */
    fun hidDevices(): List<HidDevice> = runCatching<List<HidDevice>> {
        InputDevice.getDeviceIds().toList().mapNotNull { id ->
            val d = InputDevice.getDevice(id) ?: return@mapNotNull null
            if (d.isVirtual) return@mapNotNull null
            val src = d.sources
            val keyboard = (src and InputDevice.SOURCE_KEYBOARD) == InputDevice.SOURCE_KEYBOARD &&
                d.keyboardType == InputDevice.KEYBOARD_TYPE_ALPHABETIC
            val mouse = (src and InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE
            if (!keyboard && !mouse) return@mapNotNull null
            HidDevice(id, d.name, keyboard, mouse, if (d.isExternalCompat()) "external" else "connected")
        }
    }.getOrDefault(emptyList())

    @Suppress("DEPRECATION")
    private fun InputDevice.isExternalCompat(): Boolean = runCatching {
        val m = InputDevice::class.java.getMethod("isExternal")
        m.invoke(this) as? Boolean ?: false
    }.getOrDefault(false)

    /** Calls [onChange] whenever a keyboard or mouse is plugged in or removed. Returns the unregister function. */
    fun watchHid(onChange: () -> Unit): () -> Unit {
        val im = ctx.getSystemService(Context.INPUT_SERVICE) as InputManager
        val l = object : InputManager.InputDeviceListener {
            override fun onInputDeviceAdded(deviceId: Int) = onChange()
            override fun onInputDeviceRemoved(deviceId: Int) = onChange()
            override fun onInputDeviceChanged(deviceId: Int) = onChange()
        }
        im.registerInputDeviceListener(l, null)
        return { runCatching { im.unregisterInputDeviceListener(l) } }
    }

    /** Component name of the OEM recorder's launcher, for diagnostics. */
    fun recorderDebug(): String = oemRecorders.joinToString { pkg ->
        pkg + "=" + (runCatching { ctx.packageManager.getLaunchIntentForPackage(pkg)?.component?.flattenToShortString() }.getOrNull() ?: "no")
    }
}
