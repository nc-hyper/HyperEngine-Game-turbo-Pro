package com.hyperengine.gameturbo.ui

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ClipDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.ceil
import java.util.Locale

/** Small programmatic-view helpers. The HUD is built in code so it works inside overlay windows. */
object Ui {

    const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()
    fun dpf(ctx: Context, v: Float): Float = v * ctx.resources.displayMetrics.density

    fun label(ctx: Context, text: String, sp: Float, color: Int, bold: Boolean = false): TextView =
        TextView(ctx).apply {
            this.text = text
            textSize = sp
            setTextColor(color)
            includeFontPadding = false
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    fun rounded(fill: Int, radiusPx: Float, stroke: Int = 0, strokePx: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = radiusPx
            if (strokePx > 0) setStroke(strokePx, stroke)
        }

    fun vbox(ctx: Context): LinearLayout = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    fun hbox(ctx: Context): LinearLayout = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }

    fun lp(w: Int, h: Int, weight: Float = 0f, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(w, h, weight).apply { setMargins(l, t, r, b) }

    fun tileRadius(ctx: Context, theme: HudTheme): Float = when (theme.style) {
        PanelStyle.GLASS -> dpf(ctx, 18f)          // HyperOS squircle-ish tiles
        PanelStyle.CYBER_ANGULAR -> dpf(ctx, 2f)
        PanelStyle.MECHA -> dpf(ctx, 6f)
        PanelStyle.FLAT -> dpf(ctx, 14f)
    }

    /** HyperOS / AMOLED themes use soft pill shapes; RedMagic and Realme keep their hard edges. */
    fun isSoft(theme: HudTheme): Boolean = theme.style == PanelStyle.GLASS || theme.style == PanelStyle.FLAT

    /**
     * Group heading. HyperOS themes: small grey sentence-case title. RedMagic / Realme: loud accent capitals.
     */
    fun section(ctx: Context, theme: HudTheme, text: String): TextView {
        val loud = !isSoft(theme)
        return label(ctx, if (loud) text.uppercase(Locale.US) else text, if (loud) 11f else 12f,
            if (loud) theme.accent else theme.textSecondary, true).apply {
            letterSpacing = if (loud) 0.12f else 0.02f
            setPadding(dp(ctx, 4), dp(ctx, 16), 0, dp(ctx, 6))
        }
    }

    /** Pill button (soft themes) or hard-edged outlined button (RedMagic / Realme). */
    fun button(ctx: Context, theme: HudTheme, text: String, filled: Boolean = false, onClick: () -> Unit): TextView =
        TextView(ctx).apply {
            this.text = text
            textSize = 12f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            minimumHeight = dp(ctx, 40)
            setPadding(dp(ctx, 14), dp(ctx, 10), dp(ctx, 14), dp(ctx, 10))
            setTextColor(if (filled) HudThemes.onAccent(theme.accent) else theme.textPrimary)
            background = if (isSoft(theme)) {
                rounded(if (filled) theme.accent else theme.tile, dpf(ctx, 26f))   // GradientDrawable clamps to a full pill
            } else {
                rounded(if (filled) theme.accent else theme.tile, tileRadius(ctx, theme), theme.accent, dp(ctx, 1))
            }
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
        }

    fun slider(
        ctx: Context,
        theme: HudTheme,
        min: Int,
        max: Int,
        value: Int,
        onPreview: (Int) -> Unit,
        onCommit: (Int) -> Unit
    ): SeekBar = SeekBar(ctx).apply {
        this.max = (max - min).coerceAtLeast(1)
        progress = (value - min).coerceIn(0, this.max)

        // HyperOS look: thick rounded track that fills with the accent colour, white knob with an accent ring.
        val trackH = dp(ctx, 8)
        val track = rounded(theme.knobOff, dpf(ctx, 8f)).apply { setSize(0, trackH) }
        val fill = ClipDrawable(
            rounded(theme.accent, dpf(ctx, 8f)).apply { setSize(0, trackH) },
            Gravity.START, ClipDrawable.HORIZONTAL
        )
        progressDrawable = LayerDrawable(arrayOf(track, fill)).apply {
            setId(0, android.R.id.background)
            setId(1, android.R.id.progress)
        }
        thumb = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.WHITE)
            setStroke(dp(ctx, 2), theme.accent)
            setSize(dp(ctx, 22), dp(ctx, 22))
        }
        splitTrack = false
        setPadding(dp(ctx, 12), dp(ctx, 8), dp(ctx, 12), dp(ctx, 8))

        // keep the parent ScrollView from stealing horizontal drags
        setOnTouchListener { v, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) v.parent?.requestDisallowInterceptTouchEvent(true)
            false
        }
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) onPreview(p + min)
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {
                onCommit(sb.progress + min)
            }
        })
    }

    /** Title + live value + slider. onCommit fires when the finger lifts. */
    fun labeledSlider(
        ctx: Context,
        theme: HudTheme,
        title: String,
        unit: String,
        min: Int,
        max: Int,
        value: Int,
        onCommit: (Int) -> Unit
    ): LinearLayout = vbox(ctx).apply {
        val row = hbox(ctx)
        val name = label(ctx, title, 12f, theme.textPrimary)
        val valueView = label(ctx, "$value$unit", 12f, theme.accent, true)
        row.addView(name, lp(0, WRAP, 1f))
        row.addView(valueView, lp(WRAP, WRAP))
        addView(row, lp(MATCH, WRAP, 0f, 0, dp(ctx, 4), 0, 0))
        addView(slider(ctx, theme, min, max, value, { valueView.text = "$it$unit" }, onCommit), lp(MATCH, WRAP))
    }

    fun hexOf(color: Int): String = String.format(Locale.US, "#%06X", color and 0xFFFFFF)
}

/** Grid of selectable chips (single choice). selected may be -1 for "none". */
class ChipGroup(
    ctx: Context,
    private val theme: HudTheme,
    private val labels: List<String>,
    private var selected: Int,
    private val cols: Int,
    private val onSelect: (Int) -> Unit
) : LinearLayout(ctx) {

    private val chips = ArrayList<TextView>()

    init {
        orientation = VERTICAL
        val rows = ceil(labels.size / cols.toFloat()).toInt()
        for (r in 0 until rows) {
            val row = Ui.hbox(ctx)
            for (c in 0 until cols) {
                val i = r * cols + c
                if (i < labels.size) {
                    val chip = TextView(ctx).apply {
                        text = labels[i]
                        textSize = 12f
                        gravity = Gravity.CENTER
                        maxLines = 2
                        setPadding(Ui.dp(ctx, 6), Ui.dp(ctx, 10), Ui.dp(ctx, 6), Ui.dp(ctx, 10))
                        setOnClickListener {
                            select(i)
                            onSelect(i)
                        }
                    }
                    chips += chip
                    row.addView(chip, Ui.lp(0, Ui.WRAP, 1f, Ui.dp(ctx, 3), Ui.dp(ctx, 3), Ui.dp(ctx, 3), Ui.dp(ctx, 3)))
                } else {
                    row.addView(View(ctx), Ui.lp(0, 1, 1f, Ui.dp(ctx, 3), 0, Ui.dp(ctx, 3), 0))
                }
            }
            addView(row, Ui.lp(Ui.MATCH, Ui.WRAP))
        }
        restyle()
    }

    fun select(i: Int) {
        selected = i
        restyle()
    }

    private fun restyle() {
        val soft = Ui.isSoft(theme)
        val radius = if (soft) Ui.dpf(context, 22f) else Ui.tileRadius(context, theme)
        chips.forEachIndexed { i, chip ->
            val on = i == selected
            chip.setTextColor(if (on) HudThemes.onAccent(theme.accent) else theme.textPrimary)
            chip.typeface = if (on) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            chip.isClickable = true
            chip.isFocusable = true
            chip.background = if (soft) {
                Ui.rounded(if (on) theme.accent else theme.tile, radius)
            } else {
                Ui.rounded(
                    if (on) theme.accent else theme.tile, radius,
                    if (on) theme.accent else theme.stroke, Ui.dp(context, 1)
                )
            }
        }
    }
}

/** HEX accent picker: preset swatches plus Hue / Saturation / Value sliders, reports "#RRGGBB" on release. */
class HexColorPicker(
    ctx: Context,
    private val theme: HudTheme,
    initialHex: String,
    private val onColor: (String) -> Unit
) : LinearLayout(ctx) {

    private val hsv = FloatArray(3)
    private val hexLabel = Ui.label(ctx, "", 12f, theme.textPrimary, true)
    private val preview = View(ctx)
    private lateinit var hueBar: SeekBar
    private lateinit var satBar: SeekBar
    private lateinit var valBar: SeekBar

    init {
        orientation = VERTICAL
        Color.colorToHSV(HudThemes.parse(initialHex, theme.accent), hsv)

        val top = Ui.hbox(ctx)
        top.gravity = Gravity.CENTER_VERTICAL
        top.addView(preview, Ui.lp(Ui.dp(ctx, 28), Ui.dp(ctx, 28), 0f, 0, 0, Ui.dp(ctx, 10), 0))
        top.addView(hexLabel, Ui.lp(0, Ui.WRAP, 1f))
        addView(top, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 4), 0, Ui.dp(ctx, 4)))

        val swatches = Ui.hbox(ctx)
        for (c in PRESETS) {
            val sw = View(ctx)
            sw.background = Ui.rounded(c, Ui.dpf(ctx, 6f), theme.stroke, Ui.dp(ctx, 1))
            sw.setOnClickListener {
                Color.colorToHSV(c, hsv)
                syncBars()
                refreshPreview()
                onColor(Ui.hexOf(c))
            }
            swatches.addView(sw, Ui.lp(0, Ui.dp(ctx, 26), 1f, Ui.dp(ctx, 2), 0, Ui.dp(ctx, 2), 0))
        }
        addView(swatches, Ui.lp(Ui.MATCH, Ui.WRAP))

        hueBar = bar(ctx, 360, (hsv[0]).toInt()) { hsv[0] = it.toFloat() }
        satBar = bar(ctx, 100, (hsv[1] * 100).toInt()) { hsv[1] = it / 100f }
        valBar = bar(ctx, 100, (hsv[2] * 100).toInt()) { hsv[2] = it / 100f }
        addView(Ui.label(ctx, "Hue", 10f, theme.textSecondary), Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, Ui.dp(ctx, 6), 0, 0))
        addView(hueBar, Ui.lp(Ui.MATCH, Ui.WRAP))
        addView(Ui.label(ctx, "Saturation", 10f, theme.textSecondary))
        addView(satBar, Ui.lp(Ui.MATCH, Ui.WRAP))
        addView(Ui.label(ctx, "Brightness", 10f, theme.textSecondary))
        addView(valBar, Ui.lp(Ui.MATCH, Ui.WRAP))
        refreshPreview()
    }

    private fun bar(ctx: Context, max: Int, value: Int, set: (Int) -> Unit): SeekBar =
        Ui.slider(ctx, theme, 0, max, value, { set(it); refreshPreview() }, { set(it); refreshPreview(); onColor(currentHex()) })

    private fun currentColor(): Int = Color.HSVToColor(hsv)
    private fun currentHex(): String = Ui.hexOf(currentColor())

    private fun syncBars() {
        hueBar.progress = hsv[0].toInt().coerceIn(0, 360)
        satBar.progress = (hsv[1] * 100).toInt().coerceIn(0, 100)
        valBar.progress = (hsv[2] * 100).toInt().coerceIn(0, 100)
    }

    private fun refreshPreview() {
        preview.background = Ui.rounded(currentColor(), Ui.dpf(context, 6f), theme.stroke, Ui.dp(context, 1))
        hexLabel.text = currentHex()
    }

    companion object {
        private val PRESETS = listOf(
            0xFF00E5FF.toInt(), 0xFFFFD600.toInt(), 0xFFE5173F.toInt(), 0xFFFF6D00.toInt(),
            0xFF69F0AE.toInt(), 0xFF7C4DFF.toInt(), 0xFFFF4081.toInt(), 0xFFFFFFFF.toInt()
        )
    }
}
