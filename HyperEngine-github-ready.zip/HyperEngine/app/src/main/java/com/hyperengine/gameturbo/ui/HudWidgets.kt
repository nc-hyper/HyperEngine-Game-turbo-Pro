package com.hyperengine.gameturbo.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.LinearGradient
import android.graphics.Typeface
import android.os.SystemClock
import android.view.View
import com.hyperengine.gameturbo.core.GameModeLevel
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Boost turbine. Spin speed and colour follow the active game mode:
 * Battery = slow green, Balanced = medium accent (cyan), Wild Boost = fast orange pulsing to red.
 * With animations disabled (AMOLED theme) it is drawn static, with no frame callbacks at all.
 */
class TurbineView(context: Context) : View(context) {

    private var main = 0xFF00E5FF.toInt()
    private var alt = main
    private var spin = 0f
    private var animated = true
    private var angle = 0f
    private var lastTick = 0L

    /** Virtual rotor speed from the fan controller. Above zero it can spin the blades faster than the mode alone. */
    var rpm: Int = 0
        set(v) {
            if (field == v) return
            field = v
            invalidate()
        }

    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val bladePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val hub = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val halo = Paint(Paint.ANTI_ALIAS_FLAG)
    private val blade = Path()

    fun setMode(level: GameModeLevel, theme: HudTheme) {
        when (level) {
            GameModeLevel.BATTERY -> configure(theme.good, theme.good, 50f, theme.animations)
            GameModeLevel.STANDARD -> configure(theme.accent, theme.accent, 240f, theme.animations)
            GameModeLevel.PERFORMANCE -> configure(theme.accent2, theme.hot, 760f, theme.animations)
        }
    }

    private fun configure(mainColor: Int, altColor: Int, degPerSec: Float, animate: Boolean) {
        main = mainColor
        alt = altColor
        spin = degPerSec
        animated = animate
        lastTick = 0L
        rebuildShader()
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val r = min(w, h) / 2f * 0.80f
        blade.reset()
        blade.moveTo(0f, -r * 0.20f)
        blade.cubicTo(r * 0.52f, -r * 0.28f, r * 0.62f, -r * 0.70f, r * 0.14f, -r * 0.96f)
        blade.cubicTo(r * 0.18f, -r * 0.62f, r * 0.06f, -r * 0.40f, -r * 0.10f, -r * 0.20f)
        blade.close()
        ring.strokeWidth = max(2f, min(w, h) * 0.03f)
        rebuildShader()
    }

    private fun rebuildShader() {
        val s = min(width, height) / 2f
        if (s <= 0f) return
        halo.shader = RadialGradient(
            width / 2f, height / 2f, s,
            intArrayOf(HudThemes.withAlpha(main, 120), HudThemes.withAlpha(main, 0)),
            floatArrayOf(0.55f, 1f), Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f * 0.80f
        if (r <= 0f) return

        val now = SystemClock.uptimeMillis()
        val effSpin = if (rpm > 0) max(spin, rpm / 20_000f * 760f) else spin
        val running = animated && effSpin > 0f
        if (running) {
            if (lastTick != 0L) angle = (angle + effSpin * (now - lastTick) / 1000f) % 360f
            lastTick = now
        } else {
            lastTick = 0L
        }

        c.drawCircle(cx, cy, min(width, height) / 2f, halo)
        ring.color = main
        c.drawCircle(cx, cy, r * 0.97f, ring)

        val pulse = if (running && alt != main) (0.5f + 0.5f * sin(now / 160.0)).toFloat() else 0f
        bladePaint.color = HudThemes.blend(main, alt, pulse)
        c.save()
        c.translate(cx, cy)
        c.rotate(angle)
        for (i in 0 until 6) {
            c.drawPath(blade, bladePaint)
            c.rotate(60f)
        }
        c.restore()

        hub.color = 0xFF0B0F14.toInt()
        c.drawCircle(cx, cy, r * 0.20f, hub)
        hub.color = main
        c.drawCircle(cx, cy, r * 0.09f, hub)

        // Angle is time based, so redrawing at ~60 fps looks identical to 120/144 fps and costs half as much.
        if (running) postInvalidateDelayed(16L)
    }
}

/** Mini line chart with auto scale. Values below zero are treated as gaps (lost ping probes). */
class MiniChartView(context: Context) : View(context) {

    var title = ""
    var lineColor = 0xFF00E5FF.toInt()
    var textColor = 0xFFFFFFFF.toInt()
    var subColor = 0xFF9FB1C2.toInt()
    var gridColor = 0x22FFFFFF
    var minRange = 1f
    var fixedMin: Float? = null
    var fixedMax: Float? = null
    private var data: List<Float> = emptyList()
    private var valueText = "--"

    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * resources.displayMetrics.density
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val grid = Paint().apply { strokeWidth = 1f }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG)

    fun update(values: List<Float>, valueLabel: String) {
        data = values
        valueText = valueLabel
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val d = resources.displayMetrics.density
        val w = width.toFloat()
        val h = height.toFloat()
        val headH = 16f * d
        val left = 2f * d
        val right = w - 2f * d
        val top = headH + 4f * d
        val bottom = h - 3f * d
        if (right <= left || bottom <= top) return

        text.color = subColor
        text.textSize = 10f * d
        text.typeface = Typeface.DEFAULT
        text.textAlign = Paint.Align.LEFT
        c.drawText(title, left, 11f * d, text)
        text.color = textColor
        text.textSize = 13f * d
        text.typeface = Typeface.DEFAULT_BOLD
        text.textAlign = Paint.Align.RIGHT
        c.drawText(valueText, right, 12f * d, text)

        grid.color = gridColor
        for (i in 0..2) {
            val y = top + (bottom - top) * i / 2f
            c.drawLine(left, y, right, y, grid)
        }

        val valid = data.filter { it >= 0f }
        if (valid.isEmpty()) return
        var lo = fixedMin ?: valid.min()
        var hi = fixedMax ?: valid.max()
        if (hi - lo < minRange) {
            val mid = (hi + lo) / 2f
            lo = mid - minRange / 2f
            hi = mid + minRange / 2f
        }
        if (fixedMin == null && lo < 0f) { hi -= lo; lo = 0f }

        val n = data.size
        val step = (right - left) / (HISTORY - 1)
        fun xAt(i: Int) = right - (n - 1 - i) * step
        fun yAt(v: Float) = bottom - (v.coerceIn(lo, hi) - lo) / (hi - lo) * (bottom - top)

        fill.shader = LinearGradient(
            0f, top, 0f, bottom,
            HudThemes.withAlpha(lineColor, 90), HudThemes.withAlpha(lineColor, 0), Shader.TileMode.CLAMP
        )
        line.color = lineColor
        val stroke = Path()
        val area = Path()
        var open = false
        var segStartX = 0f
        var lastX = 0f
        for (i in 0 until n) {
            val v = data[i]
            if (v < 0f) {
                if (open) { area.lineTo(lastX, bottom); area.lineTo(segStartX, bottom); area.close() }
                open = false
                continue
            }
            val x = xAt(i)
            val y = yAt(v)
            if (!open) {
                stroke.moveTo(x, y)
                area.moveTo(x, bottom)
                area.lineTo(x, y)
                segStartX = x
                open = true
            } else {
                stroke.lineTo(x, y)
                area.lineTo(x, y)
            }
            lastX = x
        }
        if (open) { area.lineTo(lastX, bottom); area.lineTo(segStartX, bottom); area.close() }
        c.drawPath(area, fill)
        c.drawPath(stroke, line)
    }

    companion object {
        private const val HISTORY = 60
    }
}

/** Gauge whose shape follows the theme: ring (HyperOS/AMOLED), segments (Realme GT), hexagon (RedMagic). */
class GaugeView(context: Context) : View(context) {

    var style = GaugeStyle.RING
    var color = 0xFF00E5FF.toInt()
    var trackColor = 0x33FFFFFF
    var textColor = 0xFFFFFFFF.toInt()
    var subColor = 0xFF9FB1C2.toInt()
    private var value = 0f
    private var center = "--"
    private var caption = ""

    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val rect = RectF()
    private val hexPath = Path()
    private val seg = Path()

    fun set(valueFraction: Float, centerText: String, captionText: String, progressColor: Int) {
        value = valueFraction.coerceIn(0f, 1f)
        center = centerText
        caption = captionText
        color = progressColor
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val d = resources.displayMetrics.density
        val capH = 14f * d
        val size = min(width.toFloat(), height - capH)
        if (size <= 0f) return
        val cx = width / 2f
        val cy = size / 2f
        val sw = max(3f * d, size * 0.09f)
        val r = size / 2f - sw
        arc.strokeWidth = sw

        when (style) {
            GaugeStyle.RING -> {
                rect.set(cx - r, cy - r, cx + r, cy + r)
                arc.color = trackColor
                c.drawArc(rect, 135f, 270f, false, arc)
                arc.color = color
                if (value > 0f) c.drawArc(rect, 135f, 270f * value, false, arc)
            }
            GaugeStyle.SEGMENTS -> {
                rect.set(cx - r, cy - r, cx + r, cy + r)
                arc.strokeCap = Paint.Cap.BUTT
                val count = 14
                val each = 270f / count
                val lit = (value * count + 0.5f).toInt()
                for (i in 0 until count) {
                    arc.color = if (i < lit) color else trackColor
                    c.drawArc(rect, 135f + i * each + 1.5f, each - 3f, false, arc)
                }
                arc.strokeCap = Paint.Cap.ROUND
            }
            GaugeStyle.HEX -> {
                hexPath.reset()
                for (k in 0 until 6) {
                    val a = Math.toRadians(-90.0 + 60.0 * k)
                    val x = (cx + r * cos(a)).toFloat()
                    val y = (cy + r * sin(a)).toFloat()
                    if (k == 0) hexPath.moveTo(x, y) else hexPath.lineTo(x, y)
                }
                hexPath.close()
                arc.strokeJoin = Paint.Join.MITER
                arc.color = trackColor
                c.drawPath(hexPath, arc)
                if (value > 0f) {
                    val pm = PathMeasure(hexPath, false)
                    seg.reset()
                    pm.getSegment(0f, pm.length * value, seg, true)
                    arc.color = color
                    c.drawPath(seg, arc)
                }
            }
        }

        txt.color = textColor
        txt.typeface = Typeface.DEFAULT_BOLD
        txt.textSize = size * 0.21f
        c.drawText(center, cx, cy + txt.textSize * 0.35f, txt)
        txt.color = subColor
        txt.typeface = Typeface.DEFAULT
        txt.textSize = 9.5f * d
        c.drawText(caption, cx, height - 3f * d, txt)
    }
}
