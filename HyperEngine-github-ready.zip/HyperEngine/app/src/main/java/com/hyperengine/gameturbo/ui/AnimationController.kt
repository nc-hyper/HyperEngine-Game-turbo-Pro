package com.hyperengine.gameturbo.ui

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ArgbEvaluator
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.drawable.Drawable
import android.os.Build
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.TextView
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.FloatValueHolder
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import com.hyperengine.gameturbo.R
import com.hyperengine.gameturbo.core.GameModeLevel
import com.hyperengine.gameturbo.data.EdgeSide
import java.util.WeakHashMap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Physics-based motion for the HUD and the Game Space lobby. Everything here moves RenderNode properties
 * (translation, scale, rotation, alpha, elevation) through SpringAnimation / ValueAnimator /
 * ObjectAnimator / ViewPropertyAnimator, so frames are produced by the render thread at whatever rate the
 * display is held at (120 / 144 Hz) and the main thread only steps the physics.
 *
 * What is in here:
 *  - [openWing] / [closeWing] / [openWings]  spring slide-in with a staggered child fade (30 ms per icon)
 *  - [carouselTransform] / [enableCardGlow]  3D perspective tilt, scale, alpha and elevation glow for the
 *                                            lobby carousel; [NeonBorderPulse] for the selected card
 *  - [SmoothGauge]                           animated arc sweep for GaugeView
 *  - [FanSpinner]                            continuous rotation whose speed follows the RPM mode, with
 *                                            inertia when the speed changes
 *  - [slideSwap] / [pop] / [springTo]        page transitions, tile / toggle feedback, raw spring helper
 *  - [hintHighRate]                          asks the platform for the panel's top refresh rate while a view animates
 *                                            (View.setRequestedFrameRate on Android 15+, frame-content velocity on 14)
 *  - [SpringValue] / [NumberRoll]            spring-chased float and rolling integer for telemetry readouts
 *  - [HzBadge]                               live "144 Hz" badge: rolling number, green / amber / red, pop at the top rate
 *  - [attachPressSpring] / [shake]           press squash and error kick for tiles and buttons
 *  - [staggerIn] / [Shockwave] / [BusyShimmer]  lab-card cascade, "boost on" ring burst, in-progress sweep
 *
 * Every entry point honours the theme's "animations" switch and the system animator scale: when motion is
 * off the view jumps straight to its end state and callbacks still fire. Main thread only.
 */
object AnimationController {

    /** Delay between one child icon starting and the next, in a wing. */
    const val STAGGER_MS = 30L

    /** True when motion should play: the theme allows it and the system has not switched animators off. */
    fun enabled(theme: HudTheme? = null): Boolean =
        (theme?.animations ?: true) && ValueAnimator.areAnimatorsEnabled()

    // =========================================================================================
    // Spring helper
    // =========================================================================================

    private val running = WeakHashMap<View, HashMap<DynamicAnimation.ViewProperty, SpringAnimation>>()

    /**
     * Springs [prop] of [view] to [to]. Any spring already running on the same property is cancelled
     * first (its end callback gets cancelled = true). [from] jumps the property first. [onEnd] receives
     * true when the spring was cancelled instead of settling.
     */
    fun springTo(
        view: View,
        prop: DynamicAnimation.ViewProperty,
        to: Float,
        damping: Float = SpringForce.DAMPING_RATIO_MEDIUM_BOUNCY,
        stiffness: Float = SpringForce.STIFFNESS_MEDIUM,
        velocity: Float = 0f,
        from: Float? = null,
        onEnd: ((cancelled: Boolean) -> Unit)? = null
    ): SpringAnimation {
        hintHighRate(view)
        val perView = running.getOrPut(view) { HashMap() }
        perView[prop]?.let { prev -> runCatching { prev.cancel() } }
        if (from != null) prop.setValue(view, from)
        val anim = SpringAnimation(view, prop)
        anim.setSpring(SpringForce(to).setDampingRatio(damping).setStiffness(stiffness))
        anim.setStartVelocity(velocity)
        anim.addEndListener { _, cancelled, _, _ ->
            if (perView[prop] === anim) perView.remove(prop)
            onEnd?.invoke(cancelled)
        }
        perView[prop] = anim
        anim.start()
        return anim
    }

    /** Stops every spring this controller started on [view]. */
    fun cancelSprings(view: View) {
        val perView = running.remove(view) ?: return
        for (a in perView.values.toList()) runCatching { a.cancel() }
    }

    // =========================================================================================
    // HUD wings
    // =========================================================================================

    /**
     * A panel that slides in from [side], with child views (usually tool icons) that cascade in behind it.
     * The wing's window / view must already be laid out at its resting position; [openWing] animates
     * translation only.
     */
    class Wing(val view: View, val side: EdgeSide, val children: List<View> = emptyList())

    private val alphaAnims = WeakHashMap<View, ObjectAnimator>()

    private fun slideProp(side: EdgeSide): DynamicAnimation.ViewProperty =
        if (side == EdgeSide.TOP) DynamicAnimation.TRANSLATION_Y else DynamicAnimation.TRANSLATION_X

    private fun offscreen(side: EdgeSide, distancePx: Float): Float =
        if (side == EdgeSide.RIGHT) distancePx else -distancePx

    private fun applySlide(view: View, side: EdgeSide, value: Float) {
        if (side == EdgeSide.TOP) view.translationY = value else view.translationX = value
    }

    private fun cancelChildAnims(c: View) {
        c.animate().cancel()
        alphaAnims.remove(c)?.cancel()
    }

    /**
     * Slides [wing] in with SpringForce.DAMPING_RATIO_LOW_BOUNCY / STIFFNESS_MEDIUM and fades its children
     * in 30 ms apart, each with an overshoot pop.
     * [distancePx] is how far off the edge it starts (default: its own size plus a small gap).
     */
    fun openWing(
        wing: Wing,
        theme: HudTheme? = null,
        distancePx: Float = defaultDistance(wing),
        onEnd: (() -> Unit)? = null
    ) {
        val v = wing.view
        cancelSprings(v)
        wing.children.forEach { cancelChildAnims(it) }

        if (!enabled(theme)) {
            applySlide(v, wing.side, 0f)
            wing.children.forEach { restoreChild(it) }
            onEnd?.invoke()
            return
        }

        val d = v.resources.displayMetrics.density
        v.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        applySlide(v, wing.side, offscreen(wing.side, distancePx))
        springTo(
            v, slideProp(wing.side), 0f,
            damping = SpringForce.DAMPING_RATIO_LOW_BOUNCY,
            stiffness = SpringForce.STIFFNESS_MEDIUM
        ) { cancelled ->
            v.setLayerType(View.LAYER_TYPE_NONE, null)
            if (!cancelled) onEnd?.invoke()
        }

        val shift = 14f * d * (if (wing.side == EdgeSide.RIGHT) 1f else -1f)
        wing.children.forEachIndexed { i, c ->
            val delay = 70L + i * STAGGER_MS
            c.alpha = 0f
            c.scaleX = 0.55f
            c.scaleY = 0.55f
            if (wing.side == EdgeSide.TOP) c.translationY = shift else c.translationX = shift
            c.animate()
                .scaleX(1f).scaleY(1f).translationX(0f).translationY(0f)
                .setStartDelay(delay)
                .setDuration(260L)
                .setInterpolator(OvershootInterpolator(1.9f))
                .withLayer()
                .start()
            val fade = ObjectAnimator.ofFloat(c, View.ALPHA, 0f, 1f)
            fade.startDelay = delay
            fade.duration = 150L
            fade.interpolator = DecelerateInterpolator()
            alphaAnims[c] = fade
            fade.start()
        }
    }

    /**
     * Slides [wing] back off its edge with a critically damped spring (no bounce on the way out) while
     * its children fade out in reverse order. [onEnd] runs once the spring has settled; remove the
     * window there.
     */
    fun closeWing(
        wing: Wing,
        theme: HudTheme? = null,
        distancePx: Float = defaultDistance(wing),
        onEnd: (() -> Unit)? = null
    ) {
        val v = wing.view
        cancelSprings(v)
        wing.children.forEach { cancelChildAnims(it) }
        val target = offscreen(wing.side, distancePx)

        if (!enabled(theme)) {
            applySlide(v, wing.side, target)
            onEnd?.invoke()
            return
        }

        v.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        val n = wing.children.size
        wing.children.forEachIndexed { i, c ->
            c.animate()
                .alpha(0f).scaleX(0.6f).scaleY(0.6f)
                .setStartDelay((n - 1 - i) * 18L)
                .setDuration(110L)
                .setInterpolator(DecelerateInterpolator())
                .withLayer()
                .start()
        }
        springTo(
            v, slideProp(wing.side), target,
            damping = SpringForce.DAMPING_RATIO_NO_BOUNCY,
            stiffness = SpringForce.STIFFNESS_MEDIUM
        ) { cancelled ->
            v.setLayerType(View.LAYER_TYPE_NONE, null)
            if (!cancelled) {
                wing.children.forEach { restoreChild(it) }
                onEnd?.invoke()
            }
        }
    }

    /** Opens several wings together (left and right wings of a dual-wing HUD); the second trails by 40 ms. */
    fun openWings(wings: List<Wing>, theme: HudTheme? = null) {
        wings.forEachIndexed { i, w ->
            if (i == 0) openWing(w, theme) else w.view.postDelayed({ openWing(w, theme) }, 40L * i)
        }
    }

    fun closeWings(wings: List<Wing>, theme: HudTheme? = null, onAllClosed: (() -> Unit)? = null) {
        if (wings.isEmpty()) {
            onAllClosed?.invoke()
            return
        }
        var left = wings.size
        for (w in wings) {
            closeWing(w, theme) {
                left--
                if (left == 0) onAllClosed?.invoke()
            }
        }
    }

    private fun restoreChild(c: View) {
        c.alpha = 1f
        c.scaleX = 1f
        c.scaleY = 1f
        c.translationX = 0f
        c.translationY = 0f
    }

    private fun defaultDistance(wing: Wing): Float {
        val v = wing.view
        val d = v.resources.displayMetrics.density
        val size = if (wing.side == EdgeSide.TOP) v.height else v.width
        return (if (size > 0) size.toFloat() else 360f * d) + 16f * d
    }

    // =========================================================================================
    // Lobby carousel
    // =========================================================================================

    /**
     * Per-frame transform for a carousel card at signed distance [d] from the centre (0 = centred,
     * -1 = one card to the left). Leaves translationX to the carousel, which owns the spacing.
     * Same tilt / scale / fade maths as the carousel's own updateTransforms, plus a deep camera distance
     * (real perspective instead of the default flat-looking one) and an elevation glow that peaks on the
     * centre card. The pivot stays at the card's centre so the carousel's spacing is unchanged.
     *
     * [tiltSign] is Carousel3DView.tiltSign (-1 turns faces toward the middle).
     */
    fun carouselTransform(card: View, d: Float, tiltSign: Float, glowColor: Int) {
        val ad = abs(d)
        val density = card.resources.displayMetrics.density
        val dist = density * 9000f
        if (abs(card.cameraDistance - dist) > 1f) card.cameraDistance = dist

        card.rotationY = tiltSign * d.coerceIn(-1.5f, 1.5f) * 42f
        val scale = (1f - 0.16f * min(ad, 2.5f)).coerceAtLeast(0.55f)
        card.scaleX = scale
        card.scaleY = scale
        card.alpha = (1f - 0.30f * ad).coerceIn(0.25f, 1f)

        val focus = 1f - min(1f, ad)
        card.translationZ = focus * 16f * density
        if (Build.VERSION.SDK_INT >= 28) {
            card.outlineSpotShadowColor = glowColor
            card.outlineAmbientShadowColor = glowColor
        }
    }

    /**
     * Gives a card a rounded outline so [carouselTransform]'s elevation casts a (coloured, API 28+) glow
     * that follows the card's corners. Call once when the card is created. The card's parent must not clip
     * its children (Carousel3DView already doesn't).
     */
    fun enableCardGlow(card: View, cornerRadiusPx: Float, baseElevationDp: Float = 4f) {
        card.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, cornerRadiusPx)
            }
        }
        card.clipToOutline = false
        card.elevation = baseElevationDp * card.resources.displayMetrics.density
    }

    /**
     * Animated neon border for the selected game card: a steady ring whose brightness and glow breathe, with a
     * bright comet orbiting it. Draws into the card's ViewOverlay, so the card's own drawing is untouched.
     * Call [start] when the card becomes the centre card and [stop] when it leaves (or is detached).
     */
    class NeonBorderPulse(
        private val host: View,
        private var color: Int,
        private val cornerRadiusPx: Float,
        private val strokePx: Float = 2f * host.resources.displayMetrics.density
    ) : Drawable() {

        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val comet = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
        }
        private val rect = RectF()
        private val matrix = Matrix()
        private var sweep: SweepGradient? = null
        private var phase = 0f
        private var attached = false

        private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1800L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                phase = it.animatedFraction
                invalidateSelf()
            }
        }

        private val layoutListener = View.OnLayoutChangeListener { _, l, t, r, b, _, _, _, _ ->
            setBounds(0, 0, r - l, b - t)
        }

        val isRunning: Boolean get() = attached

        fun setColor(c: Int) {
            color = c
            rebuildSweep()
            invalidateSelf()
        }

        fun start() {
            if (attached) return
            attached = true
            hintHighRate(host)
            host.overlay.add(this)
            host.addOnLayoutChangeListener(layoutListener)
            setBounds(0, 0, host.width, host.height)
            if (ValueAnimator.areAnimatorsEnabled()) animator.start() else invalidateSelf()
        }

        fun stop() {
            if (!attached) return
            attached = false
            animator.cancel()
            host.removeOnLayoutChangeListener(layoutListener)
            host.overlay.remove(this)
        }

        override fun onBoundsChange(bounds: android.graphics.Rect) {
            super.onBoundsChange(bounds)
            rebuildSweep()
        }

        private fun rebuildSweep() {
            val b = bounds
            if (b.isEmpty) return
            val clear = (color and 0x00FFFFFF)
            sweep = SweepGradient(
                b.exactCenterX(), b.exactCenterY(),
                intArrayOf(clear, clear or (0xD0 shl 24), 0xFFFFFFFF.toInt(), clear, clear),
                floatArrayOf(0f, 0.12f, 0.20f, 0.2001f, 1f)
            )
        }

        override fun draw(canvas: Canvas) {
            val b = bounds
            if (b.isEmpty) return
            val pulse = 0.5f + 0.5f * sin(phase * 2f * Math.PI.toFloat())
            val inset = strokePx * 3.5f
            rect.set(b.left + inset, b.top + inset, b.right - inset, b.bottom - inset)
            val r = max(0f, cornerRadiusPx - inset)

            glow.color = color
            glow.strokeWidth = strokePx * (2.6f + 2.2f * pulse)
            glow.alpha = (36f + 56f * pulse).toInt()
            canvas.drawRoundRect(rect, r, r, glow)

            ring.color = color
            ring.strokeWidth = strokePx
            ring.alpha = (150f + 105f * pulse).toInt()
            canvas.drawRoundRect(rect, r, r, ring)

            val s = sweep ?: return
            matrix.setRotate(phase * 360f, b.exactCenterX(), b.exactCenterY())
            s.setLocalMatrix(matrix)
            comet.shader = s
            comet.strokeWidth = strokePx * 1.8f
            canvas.drawRoundRect(rect, r, r, comet)
        }

        override fun setAlpha(alpha: Int) {}
        override fun setColorFilter(colorFilter: ColorFilter?) {}
        @Suppress("OVERRIDE_DEPRECATION")
        override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
    }

    // =========================================================================================
    // Gauges
    // =========================================================================================

    /**
     * Wraps a [GaugeView] so its arc glides to each new value instead of jumping. A spring chases the target:
     * rising values overshoot slightly (the drawn arc is clamped), and a new sample arriving mid-sweep
     * retargets with the current velocity kept, so 1 Hz telemetry still moves smoothly at 120 / 144 Hz.
     */
    class SmoothGauge(private val gauge: GaugeView) {

        private var text = ""
        private var cap = ""
        private var col = 0

        private val value = SpringValue(0f, damping = 0.80f, stiffness = 420f, minVisibleChange = 0.002f) { paint(it) }

        private fun paint(v: Float) = gauge.set(v.coerceIn(0f, 1f), text, cap, col)

        fun set(target: Float, centerText: String, caption: String, color: Int, theme: HudTheme? = null) {
            text = centerText
            cap = caption
            col = color
            hintHighRate(gauge)
            val to = target.coerceIn(0f, 1f)
            if (!enabled(theme) || (!value.isRunning && abs(to - value.value) < 0.004f)) {
                value.jumpTo(to)
                return
            }
            value.animateTo(to, theme)
        }

        fun release() = value.release()
    }

    // =========================================================================================
    // Fan
    // =========================================================================================

    /** Visual spin speeds in degrees per second. Real RPM would alias into a blur; these read as speed. */
    enum class FanSpeed(val degPerSec: Float) {
        OFF(0f), IDLE(90f), LOW(240f), MID(520f), HIGH(1000f), WILD(1800f);

        companion object {
            fun forMode(level: GameModeLevel): FanSpeed = when (level) {
                GameModeLevel.BATTERY -> LOW
                GameModeLevel.STANDARD -> MID
                GameModeLevel.PERFORMANCE -> WILD
            }

            /** Speed from CPU load in percent; negative (unknown) idles. */
            fun forLoad(cpuPct: Float): FanSpeed = when {
                cpuPct < 0f -> IDLE
                cpuPct < 25f -> LOW
                cpuPct < 55f -> MID
                cpuPct < 85f -> HIGH
                else -> WILD
            }
        }
    }

    /** Creates the fan-blade vector (res/drawable/ic_fan_blades) as an ImageView ready for [FanSpinner]. */
    fun fanBlades(ctx: Context, sizeDp: Int): ImageView = VIcon.view(ctx, R.drawable.ic_fan_blades, sizeDp)

    /**
     * Keeps [target] spinning with ObjectAnimator.ofFloat(target, ROTATION, a, a + 360) at the chosen speed.
     * Changing speed does not snap: one transition revolution accelerates (or brakes) smoothly from the
     * current speed to the new one - constant angular acceleration - and then the steady loop continues
     * from the same angle. The animation pauses while the view is detached and resumes when it returns.
     */
    class FanSpinner(private val target: View) {

        private var speed = 0f            // wanted, degrees per second
        private var current = 0f          // best estimate of the actual speed right now
        private var anim: ObjectAnimator? = null

        private val attachListener = object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) {
                if (speed > 0f && anim == null) startLoop(speed)
            }

            override fun onViewDetachedFromWindow(v: View) {
                stopAnim()
                current = 0f
            }
        }

        init {
            target.addOnAttachStateChangeListener(attachListener)
        }

        fun setSpeed(s: FanSpeed, theme: HudTheme? = null) = setDegPerSec(s.degPerSec, theme)

        fun setDegPerSec(newSpeed: Float, theme: HudTheme? = null) {
            val to = max(0f, newSpeed)
            if (to == speed && (anim != null || to == 0f)) return
            speed = to
            if (!enabled(theme)) {
                stopAnim()
                current = 0f
                return
            }
            if (!target.isAttachedToWindow) return   // attach listener starts it
            val from = current
            stopAnim()
            val start = target.rotation % 360f
            target.rotation = start
            if (from <= 0f && to <= 0f) return
            if (abs(from - to) < 1f) {
                startLoop(to)
                return
            }
            transition(start, from, to)
        }

        fun release() {
            stopAnim()
            target.removeOnAttachStateChangeListener(attachListener)
        }

        /** One revolution with a linear speed ramp v0 -> v1: p(t) = (2*v0*t + (v1 - v0)*t^2) / (v0 + v1). */
        private fun transition(start: Float, v0: Float, v1: Float) {
            hintHighRate(target)
            val sum = v0 + v1
            val a = ObjectAnimator.ofFloat(target, View.ROTATION, start, start + 360f)
            a.duration = (720000f / sum).toLong().coerceIn(160L, 2600L)
            a.interpolator = android.animation.TimeInterpolator { x -> (2f * v0 * x + (v1 - v0) * x * x) / sum }
            a.addUpdateListener {
                val tf = if (a.duration > 0) (a.currentPlayTime.toFloat() / a.duration).coerceIn(0f, 1f) else 1f
                current = v0 + (v1 - v0) * tf
            }
            a.addListener(object : AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(animation: Animator) {
                    cancelled = true
                }

                override fun onAnimationEnd(animation: Animator) {
                    if (cancelled || anim !== animation) return
                    anim = null
                    current = v1
                    if (v1 > 0f) startLoop(v1)
                }
            })
            anim = a
            a.start()
        }

        private fun startLoop(degPerSec: Float) {
            hintHighRate(target)
            val a = target.rotation % 360f
            val loop = ObjectAnimator.ofFloat(target, View.ROTATION, a, a + 360f)
            loop.duration = (360000f / degPerSec).toLong().coerceAtLeast(60L)
            loop.interpolator = LinearInterpolator()
            loop.repeatCount = ValueAnimator.INFINITE
            loop.repeatMode = ValueAnimator.RESTART
            anim = loop
            current = degPerSec
            loop.start()
        }

        private fun stopAnim() {
            val a = anim ?: return
            anim = null
            a.cancel()
        }
    }

    // =========================================================================================
    // Transitions and feedback
    // =========================================================================================

    /**
     * Screen / page change inside one container: [inV] springs in from the side while fading up, [outV]
     * springs away while fading out. [forward] true = new page arrives from the right. [onDone] runs when
     * the outgoing page is gone (remove it there). Both views must already be children of the container.
     */
    fun slideSwap(outV: View?, inV: View, forward: Boolean, theme: HudTheme? = null, onDone: (() -> Unit)? = null) {
        if (!enabled(theme)) {
            inV.alpha = 1f
            inV.translationX = 0f
            outV?.alpha = 0f
            onDone?.invoke()
            return
        }
        val d = inV.resources.displayMetrics.density
        val travel = 56f * d * (if (forward) 1f else -1f)

        inV.animate().cancel()
        inV.alpha = 0f
        inV.translationX = travel
        inV.animate().alpha(1f).setDuration(180L).setInterpolator(DecelerateInterpolator()).withLayer().start()
        springTo(
            inV, DynamicAnimation.TRANSLATION_X, 0f,
            damping = SpringForce.DAMPING_RATIO_LOW_BOUNCY,
            stiffness = SpringForce.STIFFNESS_MEDIUM
        )

        if (outV == null) {
            onDone?.invoke()
            return
        }
        outV.animate().cancel()
        outV.animate().alpha(0f).setDuration(140L).setInterpolator(DecelerateInterpolator()).withLayer().start()
        springTo(
            outV, DynamicAnimation.TRANSLATION_X, -travel,
            damping = SpringForce.DAMPING_RATIO_NO_BOUNCY,
            stiffness = SpringForce.STIFFNESS_MEDIUM
        ) { cancelled -> if (!cancelled) onDone?.invoke() }
    }

    /** Toggle / tile feedback: the view squashes to [fromScale] and springs back with a bounce. */
    fun pop(view: View, fromScale: Float = 0.86f, theme: HudTheme? = null) {
        if (!enabled(theme)) {
            view.scaleX = 1f
            view.scaleY = 1f
            return
        }
        springTo(view, DynamicAnimation.SCALE_X, 1f, SpringForce.DAMPING_RATIO_MEDIUM_BOUNCY, SpringForce.STIFFNESS_MEDIUM, from = fromScale)
        springTo(view, DynamicAnimation.SCALE_Y, 1f, SpringForce.DAMPING_RATIO_MEDIUM_BOUNCY, SpringForce.STIFFNESS_MEDIUM, from = fromScale)
    }

    /** Colour-state flip that reads as a mode switch: a quick scale kick plus a cross-fade of the whole view. */
    fun modeSwitch(view: View, theme: HudTheme? = null, apply: () -> Unit) {
        if (!enabled(theme)) {
            apply()
            return
        }
        view.animate().cancel()
        view.animate().alpha(0.35f).setDuration(70L).withLayer().withEndAction {
            apply()
            view.animate().alpha(1f).setDuration(140L).setInterpolator(DecelerateInterpolator()).withLayer().start()
            pop(view, 0.92f, theme)
        }.start()
    }

    // =========================================================================================
    // High refresh rate hints
    // =========================================================================================

    /** Master switch for [hintHighRate]. */
    @Volatile
    var highRateHints: Boolean = true

    private var panelMaxHz = 0f
    private var setFrameRateMethod: java.lang.reflect.Method? = null
    private var setFrameRateLooked = false
    private val hinted = WeakHashMap<View, Boolean>()

    /** Highest refresh rate the display [v] sits on supports; 0 while the view is detached. */
    fun panelMaxHz(v: View): Float {
        if (panelMaxHz > 0f) return panelMaxHz
        val d = v.display ?: return 0f
        val hz = runCatching { d.supportedModes.maxOfOrNull { it.refreshRate } }.getOrNull() ?: 0f
        if (hz > 0f) panelMaxHz = hz
        return hz
    }

    /**
     * Tells the platform this view animates and should be drawn at the panel's top rate, so a variable
     * refresh (LTPO) panel does not settle at 60 / 90 Hz while a spring is running.
     *  - Android 15+: View.setRequestedFrameRate(maxHz) (reflection, the project compiles against 34).
     *  - Android 14: View.setFrameContentVelocity(...), a high "content speed" that VRR panels read as
     *    "needs the top rate".
     *  - Older, or a 60 Hz panel: nothing to ask for.
     * Applied once per view; safe to call every time an animation starts. Called by every entry point here.
     */
    @SuppressLint("NewApi")
    fun hintHighRate(v: View) {
        if (!highRateHints || hinted[v] == true) return
        val hz = panelMaxHz(v)
        if (hz <= 61f) return
        val ok = when {
            Build.VERSION.SDK_INT >= 35 -> {
                if (!setFrameRateLooked) {
                    setFrameRateLooked = true
                    setFrameRateMethod = runCatching {
                        View::class.java.getMethod("setRequestedFrameRate", Float::class.javaPrimitiveType)
                    }.getOrNull()
                }
                val m = setFrameRateMethod
                m != null && runCatching { m.invoke(v, hz) }.isSuccess
            }
            Build.VERSION.SDK_INT >= 34 ->
                runCatching { v.setFrameContentVelocity(4000f * v.resources.displayMetrics.density) }.isSuccess
            else -> false
        }
        if (ok) hinted[v] = true
    }

    // =========================================================================================
    // Spring-chased values and rolling numbers
    // =========================================================================================

    /**
     * A float that chases a moving target with spring physics. Retargeting mid-flight keeps the current
     * velocity, so a 1 Hz telemetry feed still reads as continuous motion at 144 Hz. Unlike a ValueAnimator
     * it never restarts from zero and never has a fixed duration. Main thread only.
     */
    class SpringValue(
        initial: Float = 0f,
        damping: Float = SpringForce.DAMPING_RATIO_NO_BOUNCY,
        stiffness: Float = SpringForce.STIFFNESS_LOW,
        private val minVisibleChange: Float = 0.01f,
        private val onValue: (Float) -> Unit
    ) {
        private val holder = FloatValueHolder(initial)
        private val spring = SpringAnimation(holder).apply {
            setSpring(SpringForce(initial).setDampingRatio(damping).setStiffness(stiffness))
            setMinimumVisibleChange(minVisibleChange)
            addUpdateListener { _, v, _ ->
                value = v
                onValue(v)
            }
            addEndListener { _, cancelled, v, _ ->
                if (!cancelled) {
                    value = v
                    onValue(v)
                }
            }
        }

        var value: Float = initial
            private set

        val isRunning: Boolean get() = spring.isRunning

        fun animateTo(target: Float, theme: HudTheme? = null) {
            if (!enabled(theme) || (!spring.isRunning && abs(target - value) <= minVisibleChange)) {
                jumpTo(target)
                return
            }
            spring.animateToFinalPosition(target)
        }

        fun jumpTo(v: Float) {
            if (spring.isRunning) spring.cancel()
            holder.value = v
            spring.spring.setFinalPosition(v)
            value = v
            onValue(v)
        }

        fun release() {
            if (spring.isRunning) spring.cancel()
        }
    }

    /**
     * Counts a number up or down instead of jumping: Hz readouts, an AnTuTu-style score, MB of RAM freed,
     * battery temperature. A new target mid-count restarts from the number currently shown.
     * [render] receives each intermediate integer.
     */
    class NumberRoll(initial: Int = 0, private val render: (Int) -> Unit) {
        var shown: Int = initial
            private set
        private var anim: ValueAnimator? = null

        fun set(target: Int, theme: HudTheme? = null) {
            val old = anim
            anim = null
            old?.cancel()
            if (!enabled(theme) || target == shown) {
                shown = target
                render(shown)
                return
            }
            val a = ValueAnimator.ofInt(shown, target)
            a.duration = (180L + 4L * abs(target - shown)).coerceAtMost(650L)
            a.interpolator = DecelerateInterpolator(1.6f)
            a.addUpdateListener {
                shown = it.animatedValue as Int
                render(shown)
            }
            a.addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    if (anim === animation) {
                        anim = null
                        shown = target
                        render(shown)
                    }
                }
            })
            anim = a
            a.start()
        }

        fun release() {
            val old = anim
            anim = null
            old?.cancel()
        }
    }

    /**
     * Live refresh-rate badge for the HUD ("144 Hz"): the number rolls to each new rate, the colour fades
     * green (at the panel's top rate) / amber (above 75% of it) / red (below), and the badge pops when it
     * reaches the top rate. Feed it MaxHzState.shownHz and panelMaxHz.
     */
    class HzBadge(private val label: TextView, private val suffix: String = " Hz") {
        private val roll = NumberRoll { label.text = "$it$suffix" }
        private var colorAnim: ValueAnimator? = null
        private var color = 0
        private var target = 0
        private var hasColor = false
        private var wasAtMax = false

        fun set(hz: Int, maxHz: Int, theme: HudTheme? = null) {
            hintHighRate(label)
            roll.set(hz, theme)
            val atMax = maxHz > 0 && hz >= maxHz - 1
            val to = when {
                atMax -> HZ_OK
                maxHz > 0 && hz * 4 >= maxHz * 3 -> HZ_WARN
                else -> HZ_BAD
            }
            tint(to, theme)
            if (atMax && !wasAtMax) pop(label, 0.88f, theme)
            wasAtMax = atMax
        }

        private fun tint(to: Int, theme: HudTheme?) {
            if (hasColor && to == target) return
            target = to
            colorAnim?.cancel()
            colorAnim = null
            if (!hasColor || !enabled(theme)) {
                hasColor = true
                color = to
                label.setTextColor(to)
                return
            }
            val a = ValueAnimator.ofObject(ArgbEvaluator(), color, to)
            a.duration = 220L
            a.addUpdateListener {
                color = it.animatedValue as Int
                label.setTextColor(color)
            }
            colorAnim = a
            a.start()
        }

        fun release() {
            roll.release()
            colorAnim?.cancel()
            colorAnim = null
        }

        private companion object {
            val HZ_OK = 0xFF00E676.toInt()
            val HZ_WARN = 0xFFFFEA00.toInt()
            val HZ_BAD = 0xFFFF5252.toInt()
        }
    }

    // =========================================================================================
    // Feedback: press, shake, shockwave, shimmer, cascade
    // =========================================================================================

    /**
     * Press feedback for any tile / button: squashes to [pressedScale] on touch-down and springs back with
     * a bounce on release. The listener never consumes the event, so click handling is unchanged - but it
     * replaces any OnTouchListener already set on [view].
     */
    @SuppressLint("ClickableViewAccessibility")
    fun attachPressSpring(view: View, pressedScale: Float = 0.94f, theme: HudTheme? = null) {
        view.setOnTouchListener { v, e ->
            if (enabled(theme)) {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        springTo(v, DynamicAnimation.SCALE_X, pressedScale, SpringForce.DAMPING_RATIO_NO_BOUNCY, SpringForce.STIFFNESS_HIGH)
                        springTo(v, DynamicAnimation.SCALE_Y, pressedScale, SpringForce.DAMPING_RATIO_NO_BOUNCY, SpringForce.STIFFNESS_HIGH)
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        springTo(v, DynamicAnimation.SCALE_X, 1f, SpringForce.DAMPING_RATIO_MEDIUM_BOUNCY, SpringForce.STIFFNESS_MEDIUM)
                        springTo(v, DynamicAnimation.SCALE_Y, 1f, SpringForce.DAMPING_RATIO_MEDIUM_BOUNCY, SpringForce.STIFFNESS_MEDIUM)
                    }
                }
            }
            false
        }
    }

    /** Error feedback (a failed command, a refused toggle): a horizontal kick that rings out and settles. */
    fun shake(view: View, theme: HudTheme? = null) {
        if (!enabled(theme)) return
        val amp = 10f * view.resources.displayMetrics.density
        springTo(
            view, DynamicAnimation.TRANSLATION_X, 0f,
            damping = 0.22f, stiffness = 900f, from = amp
        )
    }

    /**
     * Cascades [views] in (lab cards, a page's buttons): each rises from [riseDp] below while fading up,
     * [stepMs] apart. Views are left at their end state when motion is off.
     */
    fun staggerIn(views: List<View>, theme: HudTheme? = null, riseDp: Float = 18f, stepMs: Long = STAGGER_MS) {
        if (!enabled(theme)) {
            views.forEach { restoreChild(it) }
            return
        }
        views.forEachIndexed { i, v ->
            hintHighRate(v)
            cancelChildAnims(v)
            v.alpha = 0f
            v.translationY = riseDp * v.resources.displayMetrics.density
            v.animate()
                .alpha(1f).translationY(0f)
                .setStartDelay(i * stepMs)
                .setDuration(320L)
                .setInterpolator(DecelerateInterpolator(2f))
                .withLayer()
                .start()
        }
    }

    /**
     * One-shot "ignite" for a toggle that just switched on (Max Hardware Boost, AnTuTu prep): [rings] rounded
     * outlines expand from the middle of [host] to its edge and fade, 130 ms apart. Drawn in the host's
     * ViewOverlay, so nothing in the layout changes and the rings are gone when they finish.
     */
    object Shockwave {
        fun play(host: View, color: Int, rings: Int = 2, theme: HudTheme? = null) {
            if (!enabled(theme) || host.width == 0 || host.height == 0) return
            hintHighRate(host)
            val stroke = 2f * host.resources.displayMetrics.density
            repeat(rings) { i ->
                val ring = Ring(color, stroke)
                ring.setBounds(0, 0, host.width, host.height)
                val a = ValueAnimator.ofFloat(0f, 1f)
                a.duration = 560L
                a.startDelay = i * 130L
                a.interpolator = DecelerateInterpolator(1.8f)
                a.addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationStart(animation: Animator) {
                        host.overlay.add(ring)
                    }

                    override fun onAnimationEnd(animation: Animator) {
                        host.overlay.remove(ring)
                    }
                })
                a.addUpdateListener {
                    ring.t = it.animatedFraction
                    ring.invalidateSelf()
                }
                a.start()
            }
        }

        private class Ring(private val color: Int, private val stroke: Float) : Drawable() {
            var t = -1f
            private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
            private val r = RectF()

            override fun draw(canvas: Canvas) {
                if (t < 0f) return
                val b = bounds
                val s = 0.35f + 0.65f * t
                val hw = (b.width() / 2f - stroke * 2f) * s
                val hh = (b.height() / 2f - stroke * 2f) * s
                r.set(b.exactCenterX() - hw, b.exactCenterY() - hh, b.exactCenterX() + hw, b.exactCenterY() + hh)
                p.color = color
                p.alpha = ((1f - t) * (1f - t) * 230f).toInt()
                p.strokeWidth = stroke * (1f + 2f * (1f - t))
                val corner = min(hw, hh)
                canvas.drawRoundRect(r, corner, corner, p)
            }

            override fun setAlpha(alpha: Int) {}
            override fun setColorFilter(colorFilter: ColorFilter?) {}
            @Suppress("OVERRIDE_DEPRECATION")
            override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
        }
    }

    /**
     * "Working" sweep for a button whose command takes a while (AOT compile, storage trim): a soft highlight
     * band glides across the view in a loop. Draws into the host's ViewOverlay. [start] when the job begins,
     * [stop] when it ends (or the view is detached).
     */
    class BusyShimmer(
        private val host: View,
        private val cornerRadiusPx: Float = 0f,
        private val tint: Int = 0x66FFFFFF
    ) : Drawable() {

        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val matrix = Matrix()
        private val rect = RectF()
        private var shader: LinearGradient? = null
        private var band = 1f
        private var phase = 0f
        private var attached = false

        private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1100L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                phase = it.animatedFraction
                invalidateSelf()
            }
        }

        private val layoutListener = View.OnLayoutChangeListener { _, l, t, r, b, _, _, _, _ ->
            setBounds(0, 0, r - l, b - t)
        }

        val isRunning: Boolean get() = attached

        fun start() {
            if (attached) return
            attached = true
            hintHighRate(host)
            host.overlay.add(this)
            host.addOnLayoutChangeListener(layoutListener)
            setBounds(0, 0, host.width, host.height)
            if (ValueAnimator.areAnimatorsEnabled()) animator.start()
        }

        fun stop() {
            if (!attached) return
            attached = false
            animator.cancel()
            host.removeOnLayoutChangeListener(layoutListener)
            host.overlay.remove(this)
        }

        override fun onBoundsChange(bounds: android.graphics.Rect) {
            super.onBoundsChange(bounds)
            band = max(1f, bounds.width() * 0.5f)
            val clear = tint and 0x00FFFFFF
            shader = LinearGradient(
                0f, 0f, band, 0f,
                intArrayOf(clear, tint, clear), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
        }

        override fun draw(canvas: Canvas) {
            val b = bounds
            val s = shader ?: return
            if (b.isEmpty) return
            matrix.setTranslate(b.left + (-band + phase * (b.width() + band)), 0f)
            s.setLocalMatrix(matrix)
            paint.shader = s
            rect.set(b)
            canvas.drawRoundRect(rect, cornerRadiusPx, cornerRadiusPx, paint)
        }

        override fun setAlpha(alpha: Int) {}
        override fun setColorFilter(colorFilter: ColorFilter?) {}
        @Suppress("OVERRIDE_DEPRECATION")
        override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
    }
}
