package com.hyperengine.gameturbo.core

import android.content.Context
import com.google.gson.Gson
import com.hyperengine.gameturbo.data.GameProfileRepository
import com.hyperengine.gameturbo.data.VisualFilterConfig
import com.hyperengine.gameturbo.service.WildBoostController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.math.abs
import kotlin.math.roundToInt

data class LowLatencyState(val on: Boolean = false, val game: String? = null, val layers: List<StepResult> = emptyList())

data class GameFilterState(val active: Boolean = false, val game: String? = null, val config: GameFilterConfig = GameFilterConfig())

/** [fps] smoothed frame rate, [hz] display rate chosen for it, [note] why nothing is happening (empty when fine). */
data class RefreshSyncState(val on: Boolean = false, val fps: Int = 0, val hz: Int = 0, val note: String = "")

/**
 * HyperLab: low-latency mode, the clip buffer, game colour filters and the refresh-rate matching
 * frame stabilizer.
 *
 * Game colour filters: a real per-pixel colour matrix through SurfaceFlinger (needs Shizuku or root), saved per game, combined
 * with the profile's Visual filter, removed with the rest of the session. It cannot sharpen (no neighbour pixels),
 * so "Clarity" is contrast.
 *
 * Refresh-rate matching: Android has no variable refresh rate API for apps. This watches the game's real FPS and moves
 * the panel to the smallest supported mode that is a whole multiple of it (45 fps on 90 Hz, 60 on 120, 100 on 120),
 * so every frame is held for the same number of refreshes, which is what removes judder and tearing. Panels switch
 * modes in about a frame (LTPO) or with a brief blank (others); changes are damped so it never ping-pongs.
 *
 *
 * What low-latency mode really does here, step by step (each reports its own result):
 *  - `debug.sf.latch_unsignaled 1`: SurfaceFlinger latches a buffer before its GPU fence signals, so a frame can
 *    reach the screen a vsync earlier. Crash-safe via the enforcer's store; ROM dependent.
 *  - `long_press_timeout 200`: the long-press delay drops, so held touches register sooner. Tracked, restored with
 *    the rest of the session.
 *  - CPU never idles between frames: that is Wild Boost's fixed-performance mode. Low-latency mode rides along with Wild Boost
 *    and does not switch it on by itself.
 *
 * Not done, because Android has no API for it: flushing queued input buffers or raising the input dispatcher's
 * priority. Nothing here pretends to.
 *
 * [latencyMs] is an ESTIMATE, not a measurement: frame time (1000 / FPS) + half a display refresh + the average wait
 * for the next touch sample (assumes a 120 Hz touch panel, 4.2 ms).
 */
class GamingSuiteManager(
    context: Context,
    private val bridge: SystemBridgeExecutor,
    private val engine: OptimizationEngine,
    private val fps: FpsRefreshRateEnforcer,
    private val repo: GameProfileRepository,
    private val telemetry: TelemetryMonitor
) {
    private val ctx = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val gson = Gson()
    private val prefs = ctx.getSharedPreferences("hyper_game_filters", Context.MODE_PRIVATE)
    @Volatile private var activeGame: String? = null
    private val mutex = Mutex()
    private var wantedWindowSec = 0     // set while waiting for the user's screen-capture consent
    private val _lowLatency = MutableStateFlow(LowLatencyState())
    val lowLatency: StateFlow<LowLatencyState> = _lowLatency.asStateFlow()

    /** Makes Wild Boost switch low-latency mode on and off with it. Call once after both exist. */
    fun registerWith(controller: WildBoostController) {
        controller.registerBooster(WildBoostController.Booster(WildBoostController.ID_LOW_LATENCY) { game, on ->
            val steps = if (on) lowLatencyOn(game) else lowLatencyOff()
            val bad = steps.filter { !it.ok }
            StepResult(
                "Low-latency mode", steps.isNotEmpty() && bad.isEmpty(),
                if (bad.isEmpty()) (if (on) "on" else "off") else bad.joinToString(" | ") { it.detail }
            )
        })
    }

    suspend fun lowLatencyOn(game: String): List<StepResult> = mutex.withLock {
        if (!bridge.hasShell()) return@withLock listOf(StepResult("Low-latency mode", false, "needs Shizuku or root"))
        val out = ArrayList<StepResult>()
        out += fps.setPropTracked("debug.sf.latch_unsignaled", "1")
        out += engine.putTracked(Ns.SECURE, "long_press_timeout", "200").copy(step = "Long-press delay 200 ms")
        _lowLatency.value = LowLatencyState(on = out.any { it.ok }, game = game, layers = out)
        out
    }

    suspend fun lowLatencyOff(): List<StepResult> = mutex.withLock {
        if (!_lowLatency.value.on) return@withLock emptyList()
        val out = ArrayList<StepResult>()
        out += fps.restoreProps(listOf("debug.sf.latch_unsignaled"))
        out += engine.releaseTracked(listOf(Ns.SECURE to "long_press_timeout"))
        _lowLatency.value = LowLatencyState()
        out
    }

    // ---- game lifecycle (GameDetectorService calls these) ----------------------------------------

    fun onGameForeground(game: String) {
        activeGame = game
        scope.launch {
            // The profile engine applies (or, when switching games, first RESTORES) in parallel. A restore removes the
            // colour matrix, so a filter applied before it finished was silently lost. Wait for the engine to go idle.
            waitForEngineIdle()
            if (gameFilter(game).enabled && activeGame == game) applyGameFilter(game)
            if (refreshSyncEnabled(game) && activeGame == game) startRefreshSync(game)
        }
    }

    /** Gives the engine a moment to start its apply/restore, then waits (max ~10 s) until it reports idle. */
    private suspend fun waitForEngineIdle() {
        delay(700L)
        var waited = 0
        while (engine.status.value.busy != null && waited < 10_000) {
            delay(250L)
            waited += 250
        }
    }

    fun onGameBackground() {
        activeGame = null
        stopKeeper()
        stopRefreshSync()
    }

    // ---- Colour filters -------------------------------------------------------------------------------

    private val _gameFilter = MutableStateFlow(GameFilterState())
    val gameFilterState: StateFlow<GameFilterState> = _gameFilter.asStateFlow()

    fun gameFilter(pkg: String): GameFilterConfig =
        runCatching { gson.fromJson(prefs.getString("fs.$pkg", null), GameFilterConfig::class.java) }.getOrNull()
            ?: GameFilterConfig()

    /** Saves [cfg] for [pkg] and applies it at once when that game is the one in front. */
    /**
     * Saves [cfg] for [pkg] and applies it at once when that game is the one in front. [live] is true when the caller
     * (the in-game HUD) knows the game is running: the foreground watcher may not have reported it yet, or at all
     * when the game was started from the lobby, and the filter used to be saved but never applied in that case.
     */
    suspend fun setGameFilter(pkg: String, cfg: GameFilterConfig, live: Boolean = false): StepResult {
        val next = cfg.copy(enabled = cfg.enabled && !cfg.isNeutral)
        prefs.edit().putString("fs.$pkg", gson.toJson(next)).apply()
        if (live && activeGame != pkg) activeGame = pkg
        return if (pkg == activeGame) applyGameFilter(pkg)
        else StepResult("Colour filter", true, "saved, applies when the game is in front")
    }

    private var keeper: Job? = null
    private var keeperGame: String? = null

    /** While the filter is on, re-sends the matrix every few seconds: the compositor drops it on screen off/on and mode switches. */
    private fun ensureKeeper(pkg: String) {
        if (keeper?.isActive == true && keeperGame == pkg) return
        keeper?.cancel()
        keeperGame = pkg
        keeper = scope.launch {
            while (isActive) {
                delay(6_000L)
                if (activeGame != pkg || !gameFilter(pkg).enabled) break
                if (!engine.reassertColorMatrix()) {
                    // Nothing to re-send: the session was restored under us (profile re-applied, game switch).
                    // Build and install the filter again instead of quietly giving up.
                    val r = applyGameFilter(pkg, fromKeeper = true)
                    if (!r.ok) break
                }
            }
            if (keeperGame == pkg) { keeper = null; keeperGame = null }
        }
    }

    private fun stopKeeper() {
        keeper?.cancel()
        keeper = null
        keeperGame = null
    }

    private suspend fun applyGameFilter(pkg: String, fromKeeper: Boolean = false): StepResult {
        val cfg = gameFilter(pkg)
        val base = repo.profile(pkg)?.filter ?: VisualFilterConfig()
        val m = if (cfg.enabled) GameFilterMath.build(cfg) else null
        val fallback = if (m != null) ColorMath.overlayForGameFilter(cfg) else null
        val r = engine.setGameFilterMatrix(m, base, fallback)
        _gameFilter.value = GameFilterState(active = m != null && r.ok, game = pkg, config = cfg)
        if (m != null && r.ok) { if (!fromKeeper) ensureKeeper(pkg) } else stopKeeper()
        return r.copy(step = "Colour filter")
    }

    // ---- Refresh-rate matching -----------------------------------------------------------------

    private val _refreshSync = MutableStateFlow(RefreshSyncState())
    val refreshSyncState: StateFlow<RefreshSyncState> = _refreshSync.asStateFlow()
    private var refreshSyncJob: Job? = null

    fun refreshSyncEnabled(pkg: String): Boolean = prefs.getBoolean("gs.$pkg", false)

    suspend fun setRefreshSync(pkg: String, on: Boolean): StepResult {
        prefs.edit().putBoolean("gs.$pkg", on).apply()
        if (pkg != activeGame) return StepResult("Refresh matching", true, "saved, starts with the game")
        if (on) startRefreshSync(pkg) else stopRefreshSync()
        return StepResult("Refresh matching", true, if (on) "on" else "off")
    }

    private fun startRefreshSync(game: String) {
        refreshSyncJob?.cancel()
        refreshSyncJob = scope.launch {
            telemetry.acquire(OWNER_REFRESH_SYNC, game)
            var startHz = 0
            try {
                val rates = engine.supportedRefreshRates().sorted()
                if (rates.size < 2) {
                    _refreshSync.value = RefreshSyncState(note = "this panel has a single refresh rate")
                    return@launch
                }
                if (!fps.state.value.active || fps.state.value.game != game) {
                    // Needs the lock for the watchdog; the cap is the panel's top rate, i.e. no cap.
                    fps.enforce(game, rates.max())
                }
                startHz = fps.lockedHz.value
                var smooth = 0f
                var candidate = 0
                var votes = 0
                var lastChange = 0L
                while (isActive) {
                    delay(1_000L)
                    val sample = telemetry.sample.value
                    val f = sample.fps
                    if (f <= 0f || sample.fpsSource != FpsSource.SURFACE_FLINGER) {
                        // The vsync fallback only echoes the panel's refresh rate: matching on it would lock the panel to itself.
                        _refreshSync.update {
                            it.copy(on = true, note = "this game's FPS cannot be read on this ROM, so the panel stays where it is")
                        }
                        continue
                    }
                    smooth = if (smooth == 0f) f else smooth * 0.7f + f * 0.3f
                    val target = pickRate(smooth, rates)
                    val now = fps.lockedHz.value
                    votes = if (target == candidate) votes + 1 else 1
                    candidate = target
                    val calm = System.currentTimeMillis() - lastChange > 4_000L
                    if (target != now && votes >= 3 && calm) {
                        val r = fps.retargetDisplay(target)
                        if (r.ok) lastChange = System.currentTimeMillis()
                    }
                    _refreshSync.value = RefreshSyncState(on = true, fps = smooth.roundToInt(), hz = fps.lockedHz.value)
                }
            } finally {
                telemetry.release(OWNER_REFRESH_SYNC)
                if (startHz > 0 && fps.state.value.active && fps.lockedHz.value != startHz) {
                    runCatching { fps.retargetDisplay(startHz) }
                }
                _refreshSync.value = RefreshSyncState()
            }
        }
    }

    private fun stopRefreshSync() {
        refreshSyncJob?.cancel()
        refreshSyncJob = null
    }

    /** Smallest panel rate that is a whole multiple of the game's frame rate; else the next one up; else the top. */
    private fun pickRate(fps: Float, rates: List<Int>): Int {
        val tier = TIERS.firstOrNull { abs(it - fps) / it < 0.07f } ?: fps.roundToInt().coerceAtLeast(20)
        return rates.firstOrNull { it >= tier && it % tier == 0 }
            ?: rates.firstOrNull { it >= tier }
            ?: rates.max()
    }

    // ---- Clip buffer ---------------------------------------------------------------

    val replay = ClipBufferEngine(ctx)

    init {
        // onReady / onLost arrive on the main thread; opening the H.264 encoder and tearing it down take 100-500 ms, so
        // both go to the worker scope instead of freezing the UI (and the game overlay) while the consent dialog closes.
        ProjectionHub.onReady = {
            val p = ProjectionHub.projection
            val sec = wantedWindowSec
            if (sec > 0 && p != null) scope.launch { replay.start(p, sec) }
        }
        ProjectionHub.onLost = {
            // The grant ended (the user tapped "stop sharing", the service stopped): forget the pending request, otherwise the
            // next unrelated screen-capture grant would silently start the buffer.
            wantedWindowSec = 0
            scope.launch { replay.stop() }
        }
    }

    /**
     * Starts the replay buffer for the last [seconds] (15, 30 or 60). The first time, Android asks for screen-capture
     * consent; the buffer starts the moment the user accepts. Returns true if it is already running.
     */
    fun startReplay(seconds: Int): Boolean {
        wantedWindowSec = seconds
        val p = ProjectionHub.projection
        if (p == null) { ProjectionHub.request(ctx); return false }
        return replay.start(p, seconds)
    }

    /** "Save last clip": returns where the clip went, or null if there was nothing buffered yet. */
    suspend fun saveReplay(): String? = replay.save()

    fun stopReplay() {
        wantedWindowSec = 0
        replay.stop()
        ProjectionHub.release(ctx)
    }

    /** The three parts of the latency estimate in ms (frame time, half a refresh, touch wait), or null without FPS. */
    fun latencyParts(sample: TelemetrySample, displayHz: Int): Triple<Float, Float, Float>? {
        if (sample.fps <= 0f) return null
        return Triple(1000f / sample.fps, 500f / displayHz.coerceAtLeast(30), TOUCH_WAIT_MS)
    }

    /** Estimated touch-to-photon latency in ms, or null while FPS is unavailable. */
    fun latencyMs(sample: TelemetrySample, displayHz: Int): Int? =
        latencyParts(sample, displayHz)?.let { (frame, half, touch) -> (frame + half + touch).roundToInt() }

    // Last in the class body: it starts a coroutine, and every property above must exist before that runs.
    init {
        // When the engine restores the phone (game ended, Restore button) the colour matrix is gone, so are we.
        scope.launch {
            var sawActive = false
            engine.status.collect { st ->
                if (st.sessionActive) sawActive = true
                else if (sawActive) {
                    sawActive = false
                    _gameFilter.value = GameFilterState()
                }
            }
        }
    }

    private companion object {
        const val TOUCH_WAIT_MS = 4.2f
        const val OWNER_REFRESH_SYNC = "refreshsync"
        val TIERS = listOf(30, 40, 45, 48, 60, 72, 90, 120, 144)
    }
}
