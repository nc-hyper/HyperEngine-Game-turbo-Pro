package com.hyperengine.gameturbo.ui

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import android.widget.Switch
import android.widget.TextView
import com.hyperengine.gameturbo.core.CustomWildBoostEngine
import com.hyperengine.gameturbo.core.FpsRefreshRateEnforcer
import com.hyperengine.gameturbo.core.PerfTier
import com.hyperengine.gameturbo.core.StepResult
import com.hyperengine.gameturbo.data.DnsPreset
import com.hyperengine.gameturbo.data.FanMode
import com.hyperengine.gameturbo.data.GameProfile
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Spinning RGB turbine. The blade speed follows the engine's virtual rotor RPM (real controller state:
 * battery temperature and the selected fan mode), capped to what a 60 fps screen can draw.
 */
class FanTurbineView(ctx: Context) : View(ctx) {

    var rpm: Int = 0
        set(v) {
            field = v
            if (v == 0) invalidate()
        }

    private var angle = 0f
    private var hue = 0f
    private var running = false
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val oval = RectF()
    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val step = (rpm / 20_000f * 38f).coerceAtMost(38f)
            if (step > 0f) {
                angle = (angle + step) % 360f
                hue = (hue + 1f + step / 4f) % 360f
                invalidate()
            }
            postOnAnimation(this)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        running = true
        postOnAnimation(tick)
    }

    override fun onDetachedFromWindow() {
        running = false
        removeCallbacks(tick)
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(cx, cy) - 3f
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f
        paint.color = Color.argb(120, 255, 255, 255)
        c.drawCircle(cx, cy, r, paint)
        paint.style = Paint.Style.FILL
        oval.set(cx - r + 4f, cy - r + 4f, cx + r - 4f, cy + r - 4f)
        for (i in 0 until 6) {
            paint.color = Color.HSVToColor(220, floatArrayOf((hue + i * 60f) % 360f, 0.9f, 1f))
            c.drawArc(oval, angle + i * 60f, 36f, true, paint)
        }
        paint.color = Color.argb(255, 20, 20, 24)
        c.drawCircle(cx, cy, r * 0.22f, paint)
    }
}

/**
 * Sidebar tool "Turbo core": every control here runs a real command through [FpsRefreshRateEnforcer] or
 * [CustomWildBoostEngine] and shows the real per-step result, including the ones that failed.
 */
class TurboTool(
    private val fps: FpsRefreshRateEnforcer,
    private val wild: CustomWildBoostEngine
) : HudTool("turbo") {

    override fun isActive(host: ToolHost): Boolean {
        val w = wild.state.value
        return fps.state.value.active || w.active || w.fanMode != FanMode.OFF || w.chargeSeparation.on || w.batterySaverOn
    }

    override fun onTap(host: ToolHost) {
        val ctx = host.hostContext
        val theme = host.theme
        val game = host.game
        val repo = host.deps.repo
        fun profile(): GameProfile = repo.profile(game) ?: repo.getOrCreate(game, game)
        fun saveTurbo(block: (com.hyperengine.gameturbo.data.TurboConfig) -> com.hyperengine.gameturbo.data.TurboConfig) =
            repo.update(game) { it.copy(turbo = block(it.turbo)) }

        val col = Ui.vbox(ctx)
        val result = Ui.label(ctx, "", 11f, theme.textSecondary).apply { setPadding(0, Ui.dp(ctx, 10), 0, 0) }
        fun show(steps: List<StepResult>) {
            val (ok, text) = GameActions.summary(steps)
            result.setTextColor(if (ok) theme.good else theme.hot)
            result.text = text
            host.refreshTiles()
        }
        fun showOne(ok: Boolean, text: String) {
            result.setTextColor(if (ok) theme.good else theme.hot)
            result.text = text
            host.refreshTiles()
        }

        // ---- live status ----
        val status = Ui.label(ctx, "", 11f, theme.textSecondary).apply { setPadding(0, 0, 0, Ui.dp(ctx, 6)) }
        col.addView(status)
        val turbine = FanTurbineView(ctx)
        val rpmLabel = Ui.label(ctx, "", 12f, theme.accent, true)
        val fanRow = Ui.hbox(ctx)
        fanRow.gravity = android.view.Gravity.CENTER_VERTICAL
        fanRow.addView(turbine, Ui.lp(Ui.dp(ctx, 84), Ui.dp(ctx, 84)))
        fanRow.addView(rpmLabel, Ui.lp(0, Ui.WRAP, 1f, Ui.dp(ctx, 12), 0, 0, 0))

        // ---- performance tier ----
        col.addView(Ui.section(ctx, theme, "Performance tier"))
        val t = profile().turbo
        val tierSel = when {
            t.nativeBatterySaver -> 0
            t.wildBoost -> 2
            else -> 1
        }
        col.addView(ChipGroup(ctx, theme, listOf("Battery saver", "Balanced", "Wild Boost"), tierSel, 3) { i ->
            host.scope.launch {
                val tier = PerfTier.values()[i]
                saveTurbo {
                    it.copy(nativeBatterySaver = tier == PerfTier.ECO, wildBoost = tier == PerfTier.WILDBOOST)
                }
                // Wild Boost is one thing everywhere (see WildBoostController): the engine steps, the 5-layer FPS
                // lock and the boosters, with the ignition playing when it goes from off to on.
                val boost = com.hyperengine.gameturbo.HyperApp.instance.wildBoost
                if (tier == PerfTier.WILDBOOST) {
                    if (!wild.state.value.active) boost.ignite()
                    show(boost.boostOn(game, persistMode = true))
                } else {
                    val steps = ArrayList<StepResult>()
                    steps += boost.releaseExtras(game)      // takes back the FPS lock a Wild Boost added
                    steps += wild.setTier(game, tier)
                    show(steps)
                }
            }
        })
        val diablo = switchRow(ctx, theme, "Diablo mode", "Wild Boost plus: apps are told the phone is not throttled", t.diablo) { on ->
            host.scope.launch {
                saveTurbo { it.copy(diablo = on) }
                if (wild.state.value.active) {
                    val steps = ArrayList<StepResult>()
                    steps += wild.deactivate(game)
                    steps += wild.activate(game, on)
                    show(steps)
                } else {
                    showOne(true, if (on) "Diablo saved. It starts with Wild Boost." else "Diablo off")
                }
            }
        }
        col.addView(diablo.first)

        // ---- FPS unlock ----
        col.addView(Ui.section(ctx, theme, "FPS unlocker (5 layers)"))
        val rates = host.deps.engine.supportedRefreshRates()
        col.addView(Ui.label(ctx, if (rates.isEmpty()) "Panel modes could not be read." else "Panel supports ${rates.joinToString(" / ")} Hz. The panel sets the ceiling.", 11f, theme.textSecondary))
        val fpsChoices = listOf(0, 90, 120, 144)
        col.addView(ChipGroup(ctx, theme, listOf("Off", "90", "120", "144"), fpsChoices.indexOf(t.unlockFps).coerceAtLeast(0), 4) { i ->
            host.scope.launch {
                val v = fpsChoices[i]
                if (v > 0) {
                    val rep = fps.enforce(game, v).also { saveTurbo { c -> c.copy(unlockFps = v) } }
                    val note = if (rep.panelTooSlow) "Panel tops out at ${rep.panelHz} Hz, so ${rep.panelHz} is what you get.\n" else ""
                    val (ok, text) = GameActions.summary(rep.layers)
                    result.setTextColor(if (ok && !rep.panelTooSlow) theme.good else theme.warn)
                    result.text = note + "Display now reports ${rep.displayHzNow} Hz\n" + text
                    host.refreshTiles()
                } else {
                    show(fps.setUnlock(game, 0))
                }
            }
        })

        // ---- motion smoothing ----
        val bfiChoices = listOf(0, 15, 30, 45)
        var smooth = t.motionSmoothing
        var bfi = t.bfiPct
        col.addView(switchRow(ctx, theme, "Motion smoothing", "Locks the panel to its maximum rate and tunes frame pacing. Does not add frames.", smooth) { on ->
            smooth = on
            host.scope.launch {
                saveTurbo { it.copy(motionSmoothing = on) }
                show(fps.setMotionSmoothing(game, on, bfi))
            }
        }.first)
        col.addView(Ui.label(ctx, "Black-frame insertion (needs 90 Hz or more, lowers brightness, may flicker)", 11f, theme.textSecondary))
        col.addView(ChipGroup(ctx, theme, listOf("Off", "15%", "30%", "45%"), bfiChoices.indexOf(bfi).coerceAtLeast(0), 4) { i ->
            bfi = bfiChoices[i]
            host.scope.launch {
                saveTurbo { it.copy(bfiPct = bfi) }
                if (smooth) show(fps.setMotionSmoothing(game, true, bfi)) else showOne(true, "Saved. Turn Motion smoothing on to use it.")
            }
        })

        // ---- turbo fan ----
        col.addView(Ui.section(ctx, theme, "Turbo fan and thermal"))
        col.addView(fanRow)
        col.addView(Ui.label(ctx, "The turbine shows the thermal controller. Real cooling: fewer background apps, backlight -10%, no background sync.", 11f, theme.textSecondary))
        val fanModes = FanMode.values().toList()
        col.addView(ChipGroup(ctx, theme, fanModes.map { it.label }, fanModes.indexOf(t.fan), 2) { i ->
            host.scope.launch { show(wild.setFan(game, fanModes[i])) }
        })
        val sounds = Ui.hbox(ctx)
        sounds.addView(Ui.button(ctx, theme, "Spin-up sound", false) {
            host.scope.launch { val r = wild.playTurbineSpinUp(); showOne(r.ok, r.detail.ifBlank { r.step }) }
        }, Ui.lp(0, Ui.WRAP, 1f, 0, Ui.dp(ctx, 6), Ui.dp(ctx, 4), 0))
        sounds.addView(Ui.button(ctx, theme, "Eject pulse 165 Hz", false) {
            host.scope.launch { val r = wild.playSonicEject(); showOne(r.ok, r.detail.ifBlank { r.step }) }
        }, Ui.lp(0, Ui.WRAP, 1f, Ui.dp(ctx, 4), Ui.dp(ctx, 6), 0, 0))
        col.addView(sounds)

        // ---- charge separation ----
        col.addView(Ui.section(ctx, theme, "Charge separation"))
        var floor = t.chargeFloorPct
        var softOk = t.softwareUnplugFallback
        val floors = listOf(20, 30, 40, 50)
        val chargeLabel = Ui.label(ctx, "", 11f, theme.textSecondary)
        val chargeRow = switchRow(ctx, theme, "Stop charging while playing", "Charging resumes when the game exits, the charger is unplugged or the level reaches the floor", t.chargeSeparation) { on ->
            host.scope.launch {
                if (on) {
                    val st = wild.setChargeSeparation(true, floor, softOk, game)
                    showOne(st.on || st.wanted, st.detail.ifBlank { "armed" })
                } else {
                    val st = wild.disableChargeSeparation(game)
                    showOne(true, st.detail.ifBlank { "charging restored" })
                }
            }
        }
        col.addView(chargeRow.first)
        col.addView(Ui.label(ctx, "Resume charging below:", 11f, theme.textSecondary))
        col.addView(ChipGroup(ctx, theme, floors.map { "$it%" }, floors.indexOf(floor).coerceAtLeast(0), 4) { i ->
            floor = floors[i]
            host.scope.launch {
                saveTurbo { it.copy(chargeFloorPct = floor) }
                if (wild.state.value.chargeSeparation.wanted) wild.setChargeSeparation(true, floor, softOk, game)
            }
        })
        col.addView(switchRow(ctx, theme, "Allow software-only unplug", "Used when no charge-control node is writable. Android is told the charger is gone; the charger still charges.", softOk) { on ->
            softOk = on
            host.scope.launch { saveTurbo { it.copy(softwareUnplugFallback = on) } }
        }.first)
        col.addView(chargeLabel)

        // ---- battery saver (real state) ----
        col.addView(Ui.section(ctx, theme, "Battery Saver"))
        var syncing = false
        val saver = switchRow(ctx, theme, "Phone's Battery Saver", "The real system Battery Saver, kept in sync. Also sets Battery game mode and 60 Hz.", wild.state.value.batterySaverOn) { on ->
            if (syncing) return@switchRow
            host.scope.launch {
                saveTurbo { it.copy(nativeBatterySaver = on, wildBoost = if (on) false else it.wildBoost) }
                show(wild.setBatterySaver(on, game))
            }
        }
        col.addView(saver.first)

        // ---- DNS ----
        col.addView(Ui.section(ctx, theme, "Gaming DNS"))
        val dns = listOf(DnsPreset.NO_CHANGE, DnsPreset.CLOUDFLARE, DnsPreset.GOOGLE, DnsPreset.ADGUARD)
        col.addView(ChipGroup(ctx, theme, listOf("Default", "Cloudflare 1.1.1.1", "Google", "AdGuard"), dns.indexOf(profile().dns).coerceAtLeast(0), 2) { i ->
            host.scope.launch {
                val p = dns[i]
                repo.update(game) { it.copy(dns = p) }
                val r = if (p == DnsPreset.NO_CHANGE) wild.restoreDns() else wild.setGamingDns(p)
                showOne(r.ok, if (r.ok) (if (p == DnsPreset.NO_CHANGE) "DNS restored" else p.label + " active") else r.detail)
            }
        })

        // ---- maintenance ----
        col.addView(Ui.section(ctx, theme, "Maintenance"))
        val maint = Ui.hbox(ctx)
        maint.addView(Ui.button(ctx, theme, "Clean RAM now", false) {
            host.scope.launch {
                val c = wild.cleanRam(game)
                showOne(true, "RAM ${c.availBeforeMb} -> ${c.availAfterMb} MB free (${c.reclaimedMb} MB)" +
                    if (c.usedShell) ", ${c.stopped} of ${c.running} running apps stopped" else ", background processes trimmed (no shell)")
            }
        }, Ui.lp(0, Ui.WRAP, 1f, 0, 0, Ui.dp(ctx, 4), 0))
        maint.addView(Ui.button(ctx, theme, "Compile game", false) {
            host.scope.launch {
                showOne(true, "Compiling in the background. Doing this while the game runs can cause stutter, so prefer Boost & Play from the hub.")
                val r = wild.compileDex(game, force = true)
                showOne(r.ok, if (r.ok) "Compiled" else r.detail)
            }
        }, Ui.lp(0, Ui.WRAP, 1f, Ui.dp(ctx, 4), 0, 0, 0))
        col.addView(maint)
        col.addView(result)

        // live updates while this page is open
        var job: Job? = null
        col.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) {
                job = host.scope.launch {
                    combine(fps.state, wild.state) { f, w -> f to w }.collect { (f, w) ->
                        turbine.rpm = w.fanRpm
                        rpmLabel.text = if (w.fanMode == FanMode.OFF) "Fan off" else
                            String.format(Locale.US, "%,d RPM  |  %s  |  battery %.1f °C", w.fanRpm, w.fanMode.label, w.batteryTempC)
                        status.text = buildString {
                            append("Tier: ").append(w.tier.label)
                            if (f.lockedHz > 0) append("   |   lock ${f.lockedHz} Hz, display ${f.displayHzNow} Hz")
                            if (f.reapplyCount > 0) append("   |   watchdog fixed it ${f.reapplyCount}x")
                            if (w.thermalTripped) append("\n").append(w.thermalNote)
                        }
                        status.setTextColor(if (w.thermalTripped) theme.hot else theme.textSecondary)
                        chargeLabel.text = w.chargeSeparation.detail
                        chargeLabel.setTextColor(
                            if (w.chargeSeparation.on && !w.chargeSeparation.hardware) theme.warn else theme.textSecondary
                        )
                        if (saver.second.isChecked != w.batterySaverOn) {
                            syncing = true
                            saver.second.isChecked = w.batterySaverOn
                            syncing = false
                        }
                    }
                }
            }

            override fun onViewDetachedFromWindow(v: View) {
                job?.cancel()
                job = null
            }
        })

        host.openDetail("Turbo core", col)
    }

    private fun switchRow(
        ctx: Context,
        theme: HudTheme,
        title: String,
        sub: String,
        checked: Boolean,
        onChange: (Boolean) -> Unit
    ): Pair<View, Switch> {
        val row = Ui.hbox(ctx)
        row.gravity = android.view.Gravity.CENTER_VERTICAL
        row.setPadding(0, Ui.dp(ctx, 6), 0, Ui.dp(ctx, 6))
        val text = Ui.vbox(ctx)
        text.addView(Ui.label(ctx, title, 12f, theme.textPrimary, true))
        text.addView(Ui.label(ctx, sub, 10f, theme.textSecondary))
        row.addView(text, Ui.lp(0, Ui.WRAP, 1f))
        val sw = Switch(ctx).apply {
            val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
            thumbTintList = ColorStateList(states, intArrayOf(theme.accent, theme.textSecondary))
            trackTintList = ColorStateList(
                states, intArrayOf(HudThemes.withAlpha(theme.accent, 0x80), HudThemes.withAlpha(theme.textSecondary, 0x55))
            )
            isChecked = checked
            setOnCheckedChangeListener { _, on -> onChange(on) }
        }
        row.addView(sw, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, Ui.dp(ctx, 8), 0, 0, 0))
        return row to sw
    }
}
