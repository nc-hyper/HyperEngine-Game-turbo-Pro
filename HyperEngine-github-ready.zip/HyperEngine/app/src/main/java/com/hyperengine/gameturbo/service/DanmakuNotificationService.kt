package com.hyperengine.gameturbo.service

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.view.WindowManager
import com.hyperengine.gameturbo.ui.EdgeLighting
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** One notification, flattened for the ticker. */
data class DanmakuMessage(
    val key: String,
    val packageName: String,
    val appLabel: String,
    val title: String,
    val text: String,
    /** The app's own colour (notification colour, else its icon's dominant hue). 0 = none found. */
    val color: Int = 0
)

/**
 * Listens to notifications so the Danmaku ticker can scroll them across the top of the game.
 * Nothing is recorded or sent anywhere: each notification is handed to the ticker (when it is on)
 * and forgotten. Ongoing notifications (music, calls, downloads) and group summaries are skipped.
 */
class DanmakuNotificationService : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        _connected.value = true
    }

    private var standaloneEdge: EdgeLighting? = null

    override fun onListenerDisconnected() {
        standaloneEdge?.stop()
        standaloneEdge = null
        if (instance === this) instance = null
        _connected.value = false
        super.onListenerDisconnected()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val s = sbn ?: return
        reportCallNotification(s)
        val handler = sink
        val edge = edgeSink
        val edgeCfg = runCatching { com.hyperengine.gameturbo.HyperApp.instance.repository.global.value.edgeLight }.getOrNull()
        // In a game the HUD's light takes it; otherwise the service lights the edge itself (when "also outside games" is on).
        val standalone = edge == null && edgeCfg != null && edgeCfg.enabled && edgeCfg.everywhere
        if (handler == null && edge == null && !standalone) return
        if (s.packageName == packageName) return
        val n = s.notification ?: return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if (s.isOngoing) return
        val category = n.category
        if (category == Notification.CATEGORY_TRANSPORT ||
            category == Notification.CATEGORY_PROGRESS ||
            category == Notification.CATEGORY_SERVICE ||
            category == Notification.CATEGORY_CALL ||
            category == Notification.CATEGORY_ALARM
        ) return

        val extras = n.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty().trim()
        val body = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: extras.getCharSequence(Notification.EXTRA_TEXT))
            ?.toString().orEmpty().trim()
        val hasText = title.isNotEmpty() || body.isNotEmpty()
        if (!hasText && handler != null && edge == null && !standalone) return

        val label = try {
            val ai = packageManager.getApplicationInfo(s.packageName, 0)
            packageManager.getApplicationLabel(ai).toString()
        } catch (_: Throwable) {
            s.packageName
        }
        val msg = DanmakuMessage(
            key = s.key,
            packageName = s.packageName,
            appLabel = label,
            title = title.replace('\n', ' ').take(60),
            text = body.replace('\n', ' ').take(140),
            color = runCatching {
                com.hyperengine.gameturbo.ui.EdgeLightColors.appColor(applicationContext, s.packageName, n.color)
            }.getOrDefault(0)
        )
        if (edge != null) edge(msg)
        else if (standalone && edgeCfg != null) {
            val light = standaloneEdge ?: EdgeLighting(
                applicationContext, getSystemService(WINDOW_SERVICE) as WindowManager
            ).also { standaloneEdge = it }
            light.pulseStandalone(edgeCfg, msg.color)
        }
        val shown = if (handler != null && hasText) handler(msg) else false
        if (shown && snoozeOriginals) {
            // Takes the original out of the shade and the heads-up; Android brings it back after 15 minutes.
            try {
                snoozeNotification(s.key, 15 * 60 * 1000L)
            } catch (_: Throwable) {
            }
        }
    }

    companion object {
        @Volatile
        var instance: DanmakuNotificationService? = null
            private set

        private val _connected = MutableStateFlow(false)
        val connected: StateFlow<Boolean> = _connected.asStateFlow()

        /** Set by the ticker while it is on. Returns true when the message was actually shown. */
        @Volatile
        var sink: ((DanmakuMessage) -> Boolean)? = null

        @Volatile
        var snoozeOriginals: Boolean = false

        /** Set by the HUD while a game is in front: lights the HUD's own edge. Null = no game, the service lights it. */
        @Volatile
        var edgeSink: ((DanmakuMessage) -> Unit)? = null
    }

    /**
     * The dialer's incoming-call notification carries the caller's name. It is handed to the in-game call banner
     * only; nothing is stored. Dialers differ on whether the name is the title or the text, so a title that just
     * says "call" falls back to the text line.
     */
    private fun reportCallNotification(s: StatusBarNotification) {
        val n = s.notification ?: return
        if (n.category != Notification.CATEGORY_CALL || s.packageName == packageName) return
        val extras = n.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty().trim()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty().trim()
        val who = if (title.contains("call", ignoreCase = true) && text.isNotEmpty()) text else title
        if (who.isNotEmpty()) runCatching { com.hyperengine.gameturbo.HyperApp.instance.calls.onCallNotification(who) }
    }
}
