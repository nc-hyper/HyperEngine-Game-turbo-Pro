package com.hyperengine.gameturbo.core

import android.content.Context
import com.google.gson.Gson
import java.io.File
import java.io.FileOutputStream

// ---------------------------------------------------------------------------------------------
// Everything Phase 2 changes that is NOT a plain `settings put` key (those are tracked by
// OptimizationEngine.putTracked and restored by its own snapshot). Each entry stores the ORIGINAL
// value, written to disk (fsync) BEFORE the change is made, so the phone can be put back after the
// app process was killed or the phone rebooted.
// ---------------------------------------------------------------------------------------------

/** `cmd appops set <pkg> <op> <mode>` that we changed. original = the mode we must go back to. */
data class AppOpBackup(val pkg: String = "", val op: String = "", val original: String = "default")

/** `setprop <key> <value>` that we changed. original may be empty ("was unset"). */
data class PropBackup(val key: String = "", val original: String = "")

/** `device_config put <ns> <key> ...` that we changed. original == null means "was unset" (delete on restore). */
data class DeviceConfigBackup(val ns: String = "", val key: String = "", val original: String? = null)

/** Charge Separation state. node empty + software true = `cmd battery unplug` was used. */
data class ChargeBackup(val node: String = "", val restoreValue: String = "", val software: Boolean = false)

data class Phase2Snapshot(
    val appOps: List<AppOpBackup> = emptyList(),
    val props: List<PropBackup> = emptyList(),
    val deviceConfig: List<DeviceConfigBackup> = emptyList(),
    val charge: ChargeBackup? = null,
    val fixedPerformance: Boolean = false,      // `cmd power set-fixed-performance-mode-enabled true` is on
    val thermalOverride: Boolean = false,       // `cmd thermalservice override-status` is active
    val batterySaverOriginal: Boolean? = null,  // non-null while WE switched battery saver on; value = state before
    val savedAt: Long = 0L
) {
    fun isEmpty(): Boolean =
        appOps.isEmpty() && props.isEmpty() && deviceConfig.isEmpty() && charge == null &&
            !fixedPerformance && !thermalOverride && batterySaverOriginal == null
}

/**
 * Tiny JSON file in filesDir. Writes are atomic (temp file + fsync + rename). All access goes through
 * [update], which is synchronized, so the in-memory copy and the file never disagree.
 */
class Phase2Store(context: Context) {

    private val dir: File = context.applicationContext.filesDir
    private val gson = Gson()
    private val lock = Any()

    @Volatile
    var snapshot: Phase2Snapshot = read()
        private set

    /** Applies [block] to the current snapshot and persists the result before returning it. */
    fun update(block: (Phase2Snapshot) -> Phase2Snapshot): Phase2Snapshot = synchronized(lock) {
        val next = block(snapshot).copy(savedAt = System.currentTimeMillis())
        snapshot = next
        if (next.isEmpty()) delete() else write(next)
        next
    }

    fun clear() {
        synchronized(lock) {
            snapshot = Phase2Snapshot()
            delete()
        }
    }

    private fun read(): Phase2Snapshot = synchronized(lock) {
        val f = File(dir, FILE)
        if (!f.exists()) return@synchronized Phase2Snapshot()
        try {
            gson.fromJson(f.readText(Charsets.UTF_8), Phase2Snapshot::class.java) ?: Phase2Snapshot()
        } catch (_: Throwable) {
            // keep the unreadable file for manual recovery instead of silently losing it
            f.renameTo(File(dir, "$FILE.bad"))
            Phase2Snapshot()
        }
    }

    private fun write(s: Phase2Snapshot) {
        runCatching {
            val target = File(dir, FILE)
            val tmp = File(dir, "$FILE.tmp")
            FileOutputStream(tmp).use { out ->
                out.write(gson.toJson(s).toByteArray(Charsets.UTF_8))
                out.fd.sync()
            }
            if (!tmp.renameTo(target)) {
                target.delete()
                tmp.renameTo(target)
            }
        }
    }

    private fun delete() {
        runCatching { File(dir, FILE).delete() }
    }

    private companion object {
        const val FILE = "phase2_state.json"
    }
}
