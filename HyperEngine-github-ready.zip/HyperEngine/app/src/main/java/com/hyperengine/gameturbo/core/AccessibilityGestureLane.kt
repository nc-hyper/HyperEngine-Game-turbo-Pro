package com.hyperengine.gameturbo.core

import android.accessibilityservice.GestureDescription
import android.graphics.Path
import com.hyperengine.gameturbo.service.TouchMacroService
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Engine B of the multi-touch injector: the accessibility fallback used when Shizuku is not available.
 *
 * `dispatchGesture` is the only way an unprivileged app can touch the screen, and Android treats every new
 * gesture as a fresh touch sequence. Two things keep it from freezing the player's own thumbs more than
 * necessary:
 *
 *  1. Taps are ultra short strokes (see [TAP_MS]) that lift almost at once.
 *  2. A finger that has to stay down (hold-to-scope, hold-to-fire, a recorded drag) is sent as a CHAIN of
 *     `willContinue = true` strokes of [SEGMENT_MS] each, every one continuing the previous with
 *     `StrokeDescription.continueStroke`. Android keeps that pointer down between the segments.
 *
 * Everything that has to happen at the same moment (all open holds plus the taps that arrived meanwhile) is
 * packed into ONE gesture, because strokes of one gesture run as simultaneous fingers. A single pump
 * coroutine owns the dispatching, so two callers can never cancel each other's gesture by dispatching
 * at the same time.
 *
 * Honest limit: this engine goes through the accessibility framework, not the hardware input queue. On some
 * ROMs a gesture still interrupts a physical finger that is already down. That is exactly why Shizuku
 * multi-pointer injection is the primary engine.
 */
internal class AccessibilityGestureLane(private val scope: CoroutineScope) {

    /** One finger that stays down across gestures. */
    internal class Hold(var x: Float, var y: Float) {
        @Volatile var targetX: Float = x
        @Volatile var targetY: Float = y
        @Volatile var releasing: Boolean = false
        @Volatile var dead: Boolean = false
        var stroke: GestureDescription.StrokeDescription? = null
    }

    private class Pending(
        val x1: Float, val y1: Float, val x2: Float, val y2: Float,
        val durationMs: Long,
        val done: CompletableDeferred<Boolean> = CompletableDeferred()
    ) {
        @Volatile var cancelled: Boolean = false
    }

    private class Batch(
        val builder: GestureDescription.Builder,
        val holds: List<Hold>,
        val finishing: List<Hold>,
        val taps: List<Pending>
    )

    private val lock = Any()
    private val holds = ArrayList<Hold>()
    private val queue = java.util.ArrayDeque<Pending>()
    private val wake = Channel<Unit>(Channel.CONFLATED)
    private var pump: Job? = null

    // ---------------------------------------------------------------------------------------------
    // API
    // ---------------------------------------------------------------------------------------------

    suspend fun tap(x: Float, y: Float, holdMs: Long): Boolean =
        submit(Pending(x, y, x, y, holdMs.coerceAtLeast(1L)))

    suspend fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long): Boolean =
        submit(Pending(x1, y1, x2, y2, durationMs.coerceAtLeast(1L)))

    /** Puts a finger down and keeps it down until [endHold]. Null when too many fingers are already held. */
    fun beginHold(x: Float, y: Float): Hold? {
        val h = Hold(x, y)
        synchronized(lock) {
            if (holds.count { !it.dead && !it.releasing } >= MAX_HOLDS) return null
            holds.add(h)
            ensurePump()
        }
        wake.trySend(Unit)
        return h
    }

    fun moveHold(h: Hold, x: Float, y: Float) {
        h.targetX = x
        h.targetY = y
    }

    fun endHold(h: Hold) {
        h.releasing = true
        wake.trySend(Unit)
    }

    /** Lifts every held finger and drops every queued tap. */
    fun releaseAll() {
        synchronized(lock) {
            holds.forEach { it.releasing = true }
            queue.forEach {
                it.cancelled = true
                it.done.complete(false)
            }
            queue.clear()
        }
        wake.trySend(Unit)
    }

    // ---------------------------------------------------------------------------------------------
    // Pump
    // ---------------------------------------------------------------------------------------------

    private suspend fun submit(p: Pending): Boolean {
        synchronized(lock) {
            queue.add(p)
            ensurePump()
        }
        wake.trySend(Unit)
        return try {
            p.done.await()
        } catch (e: CancellationException) {
            p.cancelled = true
            throw e
        }
    }

    // caller holds [lock]
    private fun ensurePump() {
        if (pump?.isActive == true) return
        pump = scope.launch { run() }
    }

    private suspend fun run() {
        val me = currentCoroutineContext()[Job]
        while (me == null || me.isActive) {
            val batch = synchronized(lock) { build() }
            if (batch == null) {
                wake.receive()
                continue
            }
            val gesture = try {
                batch.builder.build()
            } catch (_: Throwable) {
                null
            }
            val svc = TouchMacroService.instance
            val ok = if (gesture != null && svc != null) svc.dispatchGestureAwait(gesture) else false
            synchronized(lock) {
                if (!ok) batch.holds.forEach { it.dead = true }
                holds.removeAll { it.dead || it in batch.finishing }
            }
            batch.taps.forEach { it.done.complete(ok) }
        }
    }

    // caller holds [lock]
    private fun build(): Batch? {
        holds.removeAll { it.dead }
        while (true) {
            val p = queue.peek() ?: break
            if (p.cancelled) queue.poll() else break
        }
        if (holds.isEmpty() && queue.isEmpty()) return null

        val b = GestureDescription.Builder()
        val max = GestureDescription.getMaxStrokeCount()
        var strokes = 0
        val usedHolds = ArrayList<Hold>()
        val finishing = ArrayList<Hold>()

        for (h in holds) {
            if (strokes >= max) break
            val releasing = h.releasing
            val path = Path().apply {
                moveTo(h.x, h.y)
                if (h.targetX != h.x || h.targetY != h.y) lineTo(h.targetX, h.targetY)
            }
            val last = h.stroke
            val duration = if (releasing) TAP_MS else SEGMENT_MS
            val stroke = try {
                if (last == null) GestureDescription.StrokeDescription(path, 0L, duration, !releasing)
                else last.continueStroke(path, 0L, duration, !releasing)
            } catch (_: Throwable) {
                h.dead = true
                continue
            }
            b.addStroke(stroke)
            strokes++
            h.stroke = stroke
            h.x = h.targetX
            h.y = h.targetY
            usedHolds.add(h)
            if (releasing) finishing.add(h)
        }

        val taps = ArrayList<Pending>()
        while (strokes < max) {
            val p = queue.poll() ?: break
            if (p.cancelled) continue
            val path = Path().apply {
                moveTo(p.x1, p.y1)
                if (p.x2 != p.x1 || p.y2 != p.y1) lineTo(p.x2, p.y2)
            }
            b.addStroke(GestureDescription.StrokeDescription(path, 0L, p.durationMs, false))
            strokes++
            taps.add(p)
        }

        if (strokes == 0) return null
        return Batch(b, usedHolds, finishing, taps)
    }

    companion object {
        /** Length of the "instant tap" stroke. */
        const val TAP_MS = 8L

        /** Length of one segment of a held finger. Also the worst-case delay before a queued tap goes out. */
        const val SEGMENT_MS = 60L

        /** Simultaneous held fingers on this engine (the gesture API allows 10 strokes in total). */
        const val MAX_HOLDS = 4
    }
}
