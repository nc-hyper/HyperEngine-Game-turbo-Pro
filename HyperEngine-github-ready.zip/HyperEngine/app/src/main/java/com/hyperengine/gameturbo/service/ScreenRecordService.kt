package com.hyperengine.gameturbo.service

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Point
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.view.WindowManager
import androidx.core.content.ContextCompat
import com.hyperengine.gameturbo.R
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class RecordingState(
    val recording: Boolean = false,
    val startedAt: Long = 0L,
    val where: String = "",        // where the finished video was saved
    val error: String = "",
    val notice: String = ""        // shown while recording, e.g. that the microphone was dropped
)

/**
 * Built-in screen recorder (MediaProjection + MediaRecorder), used when the phone has no recorder of its own or
 * the user prefers this one. H.264 video at 60 fps, optional microphone, saved to Movies/HyperEngine.
 * Game audio is not captured: Android only allows that to apps that opt in, and MediaRecorder cannot record it.
 */
class ScreenRecordService : Service() {

    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var recorder: MediaRecorder? = null
    private var pfd: ParcelFileDescriptor? = null
    private var mediaUri: android.net.Uri? = null
    private var file: File? = null
    private var label = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val cmd = intent ?: return START_NOT_STICKY
        when (cmd.action) {
            ACTION_STOP -> {
                stopRecording()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                // startForegroundService() obliges this service to call startForeground() within a few seconds, whatever
                // happens next. It therefore goes first, before every early return below: a start that bailed out without
                // it (no capture data, or a second start while already recording) crashed the whole app.
                val micRequested = cmd.getBooleanExtra(EXTRA_MIC, false)
                val micWanted = micRequested && micPermitted()
                val mode = enterForeground(micWanted)
                if (mode == Foreground.NONE) {
                    // a recording already under way keeps going; only a start that has nothing to lose is reported
                    if (!_state.value.recording) fail("Android would not let the recorder run in the foreground. Open the app and try again")
                    return START_NOT_STICKY
                }
                if (_state.value.recording) return START_NOT_STICKY
                val code = cmd.getIntExtra(EXTRA_CODE, 0)
                @Suppress("DEPRECATION")
                val data: Intent? = cmd.getParcelableExtra(EXTRA_DATA)
                if (data == null) {
                    fail("No capture permission was passed to the recorder")
                    return START_NOT_STICKY
                }
                // the recording still goes ahead without the microphone, but the person is told instead of finding out later
                val micNotice = when {
                    !micRequested || mode == Foreground.WITH_MIC -> ""
                    !micWanted -> "Microphone permission is missing, so this recording has no sound"
                    else -> "Android would not let the recorder use the microphone, so this recording has no sound"
                }
                begin(code, data, mode == Foreground.WITH_MIC, micNotice)
            }
        }
        return START_NOT_STICKY
    }

    /** [mic] is already true only when RECORD_AUDIO is granted and the foreground service accepted the mic type. */
    private fun begin(code: Int, data: Intent, mic: Boolean, notice: String = "") {
        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val proj = mpm.getMediaProjection(code, data) ?: throw IllegalStateException("Android returned no projection")
            projection = proj
            proj.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    main.post { stopRecording() }
                }
            }, main)

            @Suppress("DEPRECATION")
            val size = Point().also { (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealSize(it) }
            val dpi = resources.displayMetrics.densityDpi
            // keep the long side at 1920 or below and both sides even: encoders reject odd sizes
            val scale = minOf(1f, 1920f / maxOf(size.x, size.y))
            val w = ((size.x * scale).toInt() / 2) * 2
            val h = ((size.y * scale).toInt() / 2) * 2

            val rec = MediaRecorder()
            recorder = rec
            if (mic) rec.setAudioSource(MediaRecorder.AudioSource.MIC)
            rec.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            openOutput(rec)
            rec.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            if (mic) {
                rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                rec.setAudioEncodingBitRate(128_000)
                rec.setAudioSamplingRate(44_100)
            }
            rec.setVideoSize(w, h)
            rec.setVideoFrameRate(60)
            rec.setVideoEncodingBitRate(if (w * h > 1_500_000) 16_000_000 else 10_000_000)
            rec.prepare()

            display = proj.createVirtualDisplay(
                "HyperEngineRecorder", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rec.surface, null, main
            )
            rec.start()
            _state.value = RecordingState(recording = true, startedAt = System.currentTimeMillis(), notice = notice)
        } catch (t: Throwable) {
            cleanup(false)
            fail("Recorder could not start: " + (t.message ?: t.javaClass.simpleName))
        }
    }

    /** Output goes to Movies/HyperEngine (MediaStore on Android 10+, the app's own movies folder before that). */
    private fun openOutput(rec: MediaRecorder) {
        val name = "HyperEngine_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        label = "$name.mp4"
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, label)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/HyperEngine")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Could not create the video file")
            mediaUri = uri
            pfd = contentResolver.openFileDescriptor(uri, "w")
            rec.setOutputFile(pfd!!.fileDescriptor)
        } else {
            val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir
            dir.mkdirs()
            val f = File(dir, label)
            file = f
            rec.setOutputFile(f.absolutePath)
        }
    }

    private fun stopRecording() {
        if (recorder == null && projection == null) {
            stopForegroundCompat()
            stopSelf()
            return
        }
        var error = ""
        try {
            recorder?.stop()
        } catch (t: Throwable) {
            // MediaRecorder throws when stopped within a second or so of starting: nothing usable was written
            error = "Recording was too short to save"
        }
        val savedUri = mediaUri
        val savedFile = file
        cleanup(error.isEmpty())
        val where = when {
            error.isNotEmpty() -> ""
            savedUri != null -> "Movies/HyperEngine/$label"
            else -> savedFile?.absolutePath.orEmpty()
        }
        _state.value = RecordingState(recording = false, where = where, error = error)
        stopForegroundCompat()
        stopSelf()
    }

    private fun cleanup(save: Boolean) {
        runCatching { display?.release() }
        runCatching { recorder?.release() }
        runCatching { projection?.stop() }
        runCatching { pfd?.close() }
        val uri = mediaUri
        if (uri != null) {
            if (save) {
                runCatching {
                    val v = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                    contentResolver.update(uri, v, null, null)
                }
            } else {
                runCatching { contentResolver.delete(uri, null, null) }
            }
        } else if (!save) {
            file?.delete()
        }
        display = null
        recorder = null
        projection = null
        pfd = null
        mediaUri = null
        file = null
    }

    private fun fail(message: String) {
        _state.value = RecordingState(recording = false, error = message)
        stopForegroundCompat()
        stopSelf()
    }

    // ---- notification ----

    private enum class Foreground { NONE, VIDEO_ONLY, WITH_MIC }

    private fun micPermitted(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    /**
     * Enters the foreground without ever letting an exception escape: Android throws SecurityException (a missing
     * permission, or a type the app may not use right now) and ForegroundServiceStartNotAllowedException (a blocked
     * background start), and either one used to crash the app.
     * With the microphone on, the microphone type is tried first; if Android refuses it the recorder falls back to
     * screen-only rather than failing the whole recording.
     */
    private fun enterForeground(withMic: Boolean): Foreground {
        if (withMic && tryForeground(true)) return Foreground.WITH_MIC
        return if (tryForeground(false)) Foreground.VIDEO_ONLY else Foreground.NONE
    }

    @Suppress("DEPRECATION")
    private fun tryForeground(withMic: Boolean): Boolean = try {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Screen recording", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 1, Intent(this, ScreenRecordService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_qs_wild_boost)
            .setContentTitle("HyperEngine is recording the screen")
            .setContentText("Tap Stop to save the video")
            .setOngoing(true)
            .addAction(Notification.Action.Builder(R.drawable.ic_close, "Stop", stop).build())
            .build()
        when {
            // the microphone type exists from Android 11; before that the mic needs no foreground type
            Build.VERSION.SDK_INT >= 30 && withMic -> startForeground(
                NOTIF_ID, n,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
            Build.VERSION.SDK_INT >= 29 -> startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
            else -> startForeground(NOTIF_ID, n)
        }
        true
    } catch (_: Throwable) {
        false
    }

    @Suppress("DEPRECATION")
    private fun stopForegroundCompat() {
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
    }

    override fun onDestroy() {
        if (recorder != null || projection != null) cleanup(false)
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.hyperengine.gameturbo.record.START"
        const val ACTION_STOP = "com.hyperengine.gameturbo.record.STOP"
        private const val EXTRA_CODE = "code"
        private const val EXTRA_DATA = "data"
        private const val EXTRA_MIC = "mic"
        private const val CHANNEL = "hyperengine_recording"
        private const val NOTIF_ID = 4712

        private val _state = MutableStateFlow(RecordingState())
        val state: StateFlow<RecordingState> = _state.asStateFlow()

        fun start(ctx: Context, resultCode: Int, data: Intent, mic: Boolean) {
            val i = Intent(ctx, ScreenRecordService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_CODE, resultCode)
                .putExtra(EXTRA_DATA, data)
                .putExtra(EXTRA_MIC, mic)
            try {
                ContextCompat.startForegroundService(ctx, i)
            } catch (_: Throwable) {
                // blocked background start (Android 12+) or a ROM that refuses it: report it, do not crash the caller
                _state.value = RecordingState(error = "Android blocked the screen recorder from starting. Open the app and try again")
            }
        }
    }
}
