package com.hyperengine.gameturbo.ui

import android.content.Context
import android.media.AudioManager
import android.os.Build
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.hyperengine.gameturbo.HyperApp
import com.hyperengine.gameturbo.R
import com.hyperengine.gameturbo.core.AntutuBenchmarkBooster
import com.hyperengine.gameturbo.core.BoostOptions
import com.hyperengine.gameturbo.core.BoostState
import com.hyperengine.gameturbo.core.EngineStatus
import com.hyperengine.gameturbo.core.FrameStats
import com.hyperengine.gameturbo.core.FpsSource
import com.hyperengine.gameturbo.core.GameModeLevel
import com.hyperengine.gameturbo.core.HardwareFrameSmoother
import com.hyperengine.gameturbo.core.MaxHzState
import com.hyperengine.gameturbo.core.MaxPanelHzEngine
import com.hyperengine.gameturbo.core.Ns
import com.hyperengine.gameturbo.core.PerfTier
import com.hyperengine.gameturbo.core.TelemetrySample
import com.hyperengine.gameturbo.core.WildBoostState
import com.hyperengine.gameturbo.data.GameProfile
import com.hyperengine.gameturbo.data.GlobalSettings
import com.hyperengine.gameturbo.data.ToolIds
import com.hyperengine.gameturbo.service.ScreenRecordService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.min

/**
 * The landscape console HUD (UI redesign, part 2): HyperOS Game Turbo structure with RedMagic console touches.
 *
 *   top status bar     clock, game, FPS / CPU / GPU / RAM / temperature / ping / network / battery,
 *                      ECO-BAL-WILD switch, Shizuku badge, detach-FPS-pill, settings, close
 *   left quick rail    round toggles (Wild Boost, FPS pill, crosshair, danmaku, edge guard, screenshot ...),
 *                      tap flips, long-press opens the page; the "All tools" button is pinned at the bottom
 *   centre dashboard   two tabs: Dashboard (boost state and live charts) and All tools (every registered tool);
 *                      any tool page opens here as a workspace with a back button
 *   right control wing the Energy Cube, brightness and volume
 *   key hints          B Back, Y Console settings, X Dashboard / All tools, L1 / R1 Cube face
 *
 * It is hosted in one full-screen overlay window and implements [ToolHost], so every tool written for the
 * sidebar works unchanged. Nothing from the old wings was removed: the tool grid moved into the All tools tab and
 * Restore moved to the centre header.
 */
class GameTurboLandscapeHudView(
    context: Context,
    override val deps: SidebarDeps,
    override var theme: HudTheme,
    private var global: GlobalSettings,
    override var game: String,
    private val onClose: () -> Unit
) : FrameLayout(context), ToolHost, HudPanel {

    override val view: View get() = this
    override val isFullScreen: Boolean get() = true
    override val hostContext: Context get() = context
    override val scope: CoroutineScope = MainScope()

    private val app get() = HyperApp.instance
    private val d = resources.displayMetrics.density

    private enum class Page { MAIN, DETAIL }

    private var page = Page.MAIN
    private var tab = global.hudLayout.centerTab.coerceIn(0, 1)
    private var detailTitle = ""
    private var detailContent: View? = null
    private var lastSample: TelemetrySample? = null
    private var lastEngine = EngineStatus()
    private var wildState = WildBoostState()
    private var job: Job? = null

    // safe-area insets (display cutout)
    private var insetL = 0
    private var insetT = 0
    private var insetR = 0
    private var insetB = 0

    // geometry, recomputed by layoutParts()
    private var railW = 0
    private var wingW = 0
    private var barH = 0
    private var centerW = 0
    private var lastCols = 0

    // panels
    private var scrim = View(context)
    private lateinit var bar: ConsolePanel
    private lateinit var rail: ConsolePanel
    private lateinit var right: ConsolePanel
    private lateinit var center: ConsolePanel
    private var hints: KeyHintBar? = null

    // status bar widgets
    private lateinit var clockView: TextView
    private lateinit var fpsCell: StatChip
    private lateinit var cpuCell: StatChip
    private lateinit var gpuCell: StatChip
    private lateinit var ramCell: StatChip
    private lateinit var tempCell: StatChip
    private lateinit var pingCell: StatChip
    private lateinit var netCell: StatChip
    private lateinit var battCell: StatChip
    private lateinit var modeSwitch: ModeSwitch
    private lateinit var badge: TextView
    private lateinit var pillButton: FrameLayout
    private lateinit var gearButton: FrameLayout

    // Part 6: refresh-rate badge, frame-stability chip, Max Hardware Boost
    private val hzEngine by lazy { MaxPanelHzEngine.from(context) }
    private val smoother by lazy { HardwareFrameSmoother.from(context) }
    private val booster by lazy { AntutuBenchmarkBooster.from(context) }
    private lateinit var hzLabel: TextView
    private lateinit var lowCell: StatChip
    private var hzBadge: AnimationController.HzBadge? = null
    private var lastHz = MaxHzState()
    private var lastStats = FrameStats()
    private var lastBoost = BoostState()
    private var boostWasActive = false
    private var boostCard: View? = null
    private var boostIcon: ImageView? = null
    private var boostSub: TextView? = null
    private var boostButton: TextView? = null
    private var boostShimmer: AnimationController.BusyShimmer? = null

    // rail, centre and wing widgets
    private val railButtons = ArrayList<RailButton>()
    private lateinit var centerBody: FrameLayout
    private lateinit var footer: TextView
    private var tabBody: FrameLayout? = null
    private var tabChips: ChipGroup? = null
    private var toolsHolder: LinearLayout? = null
    private var cube: EnergyCubeView? = null
    private var turbine: TurbineView? = null
    private var modeLabel: TextView? = null
    private var modeSub: TextView? = null
    private var fpsChart: MiniChartView? = null
    private var pingChart: MiniChartView? = null
    private var tempChart: MiniChartView? = null
    private var statLine: TextView? = null
    private var firstFocus: View? = null

    private val extras = QuickExtras(
        wildActive = { wildState.active },
        toggleWild = { toggleWild() },
        togglePill = { togglePill() }
    )

    private val gpu = GpuLoadReader(deps.bridge)
    private val clockFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val clockTick = object : Runnable {
        override fun run() {
            if (!::clockView.isInitialized) return
            clockView.text = clockFormat.format(Date())
            postDelayed(this, 1000L)
        }
    }
    private val footerReset = Runnable { updateFooter() }

    init {
        setWillNotDraw(true)
        clipChildren = false
        buildAll()
    }

    // =========================================================================================
    // HudPanel
    // =========================================================================================

    override fun restyle(newTheme: HudTheme, newGlobal: GlobalSettings) {
        val oldTheme = theme
        val oldGlobal = global
        theme = newTheme
        global = newGlobal
        val sameShell = newTheme == oldTheme && shellKey(newGlobal) == shellKey(oldGlobal)
        if (sameShell && ::rail.isInitialized) {
            // Only something unrelated changed (danmaku flag, cube face, centre tab ...): keep the open page.
            refreshRail()
            return
        }
        // Keep an open tool page (for example Console settings) while the shell is rebuilt around it.
        val keepDetail = newTheme == oldTheme && page == Page.DETAIL && detailContent != null
        if (!keepDetail) {
            page = Page.MAIN
            detailContent = null
        }
        buildAll()
        lastSample?.let { onSample(it) }
        refreshMode()
    }

    /** Everything that changes the geometry or the content of the shell. A change here rebuilds the HUD. */
    private fun shellKey(g: GlobalSettings): List<Any> = listOf(
        g.hudLayout.scrimPct, g.hudLayout.wingWidthDp, g.hudLayout.railItems, g.hudLayout.hintMode,
        g.sidebar.toolOrder, g.sidebar.hiddenTools
    )

    override fun changeGame(pkg: String) {
        if (pkg == game) return
        game = pkg
        page = Page.MAIN
        detailContent = null
        buildAll()
        lastSample?.let { onSample(it) }
    }

    override fun onProfile(p: GameProfile) {
        if (p.packageName != game) return
        fillTools()
        refreshMode()
        refreshRail()
        refreshPillButton(p)
    }

    override fun onEngine(st: EngineStatus) {
        lastEngine = st
        updateFooter()
    }

    override fun onSample(s: TelemetrySample) {
        lastSample = s
        if (!::fpsCell.isInitialized) return
        val limit = global.tempAlertC

        when (s.fpsSource) {
            FpsSource.SURFACE_FLINGER -> fpsCell.set(
                String.format(Locale.US, "%.0f", s.fps),
                when { s.fps >= 60f -> theme.good; s.fps >= 30f -> theme.warn; else -> theme.hot },
                "FPS"
            )
            FpsSource.VSYNC -> fpsCell.set(String.format(Locale.US, "%.0f", s.fps), theme.textSecondary, "HZ (not FPS)")
            FpsSource.NONE -> fpsCell.set("--", theme.textSecondary, "FPS")
        }
        cpuCell.set(
            String.format(Locale.US, "%.1fG", s.peakCoreGhz),
            if (s.cpuPct > 85f) theme.hot else theme.textPrimary,
            if (s.cpuPct >= 0f) String.format(Locale.US, "CPU %.0f%%", s.cpuPct) else "CPU"
        )
        val usedFrac = if (s.totalRamMb > 0) s.usedRamMb.toFloat() / s.totalRamMb else 0f
        ramCell.set(String.format(Locale.US, "%.0f%%", usedFrac * 100f), if (usedFrac > 0.9f) theme.hot else theme.textPrimary, "RAM")
        val t = s.batteryTempC
        tempCell.set(
            String.format(Locale.US, "%.1f", t),
            when { t >= limit -> theme.hot; t >= limit - 4 -> theme.warn; else -> theme.good },
            "TEMP C"
        )
        val p = s.ping
        pingCell.set(if (p.lastMs >= 0) "${p.lastMs}" else "--", if (p.lastMs > 120) theme.warn else theme.textPrimary, "PING MS")
        battCell.set(
            if (s.batteryPct >= 0) "${s.batteryPct}%" else "--",
            if (s.batteryPct in 0..15 && !s.charging) theme.hot else theme.textPrimary,
            if (s.charging) (if (s.powerW >= 0f) String.format(Locale.US, "CHG %.1fW", s.powerW) else "CHARGING") else "BATT"
        )

        if (page == Page.MAIN) {
            fpsChart?.update(s.fpsHistory, if (s.fps >= 0f) String.format(Locale.US, "%.0f", s.fps) else "--")
            pingChart?.update(p.history.map { it.toFloat() }, if (p.lastMs >= 0) "${p.lastMs} ms" else "--")
            tempChart?.update(s.tempHistory, String.format(Locale.US, "%.1f C", t))
            val power = if (s.powerW >= 0f) String.format(Locale.US, "%.1f W", s.powerW) else "n/a"
            statLine?.text = "Power $power   Jitter " + String.format(Locale.US, "%.1f ms", p.jitterMs) +
                "   " + String.format(Locale.US, "%,d", s.availRamMb) + " MB RAM free"
        }
        cube?.onSample(s)
    }

    override fun dispose() {
        removeCallbacks(clockTick)
        removeCallbacks(footerReset)
        hzBadge?.release()
        boostShimmer?.stop()
        job?.cancel()
        scope.cancel()
    }

    override fun playOpen(): Boolean {
        if (!theme.animations) return false
        val gap = (16 * d)
        scrim.alpha = 0f
        scrim.animate().alpha(1f).setDuration(200L).start()
        rail.translationX = -(railW + gap)
        right.translationX = wingW + gap
        bar.translationY = -(barH + gap)
        hints?.alpha = 0f
        center.alpha = 0f
        center.scaleX = 0.96f
        center.scaleY = 0.96f
        val ip = DecelerateInterpolator()
        rail.animate().translationX(0f).setDuration(230L).setInterpolator(ip).start()
        right.animate().translationX(0f).setDuration(230L).setInterpolator(ip).start()
        bar.animate().translationY(0f).setDuration(230L).setInterpolator(ip).start()
        hints?.animate()?.alpha(1f)?.setDuration(260L)?.start()
        center.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(260L).setInterpolator(ip).start()
        return true
    }

    override fun playClose(done: () -> Unit): Boolean {
        if (!theme.animations) return false
        val gap = (16 * d)
        scrim.animate().alpha(0f).setDuration(150L).start()
        rail.animate().translationX(-(railW + gap)).setDuration(160L).start()
        right.animate().translationX(wingW + gap).setDuration(160L).start()
        bar.animate().translationY(-(barH + gap)).setDuration(160L).start()
        hints?.animate()?.alpha(0f)?.setDuration(120L)?.start()
        center.animate().alpha(0f).scaleX(0.96f).scaleY(0.96f).setDuration(150L).withEndAction { done() }.start()
        return true
    }

    // =========================================================================================
    // ToolHost
    // =========================================================================================

    override fun toast(msg: String) {
        footer.setTextColor(theme.accent)
        footer.text = msg
        removeCallbacks(footerReset)
        postDelayed(footerReset, 3500L)
    }

    override fun openDetail(title: String, content: View) {
        page = Page.DETAIL
        detailTitle = title
        detailContent = content
        renderCenter()
        refreshRail()
    }

    override fun refreshTiles() {
        fillTools()
        refreshMode()
        refreshRail()
        app.repository.profile(game)?.let { refreshPillButton(it) }
    }

    // =========================================================================================
    // Lifecycle
    // =========================================================================================

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        removeCallbacks(clockTick)
        post(clockTick)
        smoother.startMonitor("hud")
        job = scope.launch {
            launch { app.wild.state.collect { wildState = it; refreshMode(); refreshRail() } }
            launch { deps.bridge.state.collect { refreshBadge() } }
            launch { ScreenRecordService.state.collect { refreshRail() } }
            launch {
                hzEngine.state.collect {
                    lastHz = it
                    hzBadge?.set(it.shownHz, it.panelMaxHz, theme)
                    refreshBoostCard()
                }
            }
            launch { smoother.stats.collect { lastStats = it; updateLow(it) } }
            launch { booster.state.collect { lastBoost = it; refreshBoostCard() } }
            launch {
                while (isActive) {
                    val g = gpu.read()
                    gpuCell.set(if (g >= 0) "$g%" else "--", if (g > 90) theme.hot else theme.textPrimary, if (g >= 0) "GPU" else "GPU n/a")
                    val n = SignalReader.read(context)
                    netCell.set(n.label, signalColor(n.level), if (n.level >= 0) "SIGNAL ${n.level}/4" else "NET")
                    netCell.icon(if (n.label == "Wi-Fi") IconKind.WIFI else IconKind.SIGNAL)
                    delay(2000L)
                }
            }
        }
        firstFocus?.let { f -> post { f.requestFocus() } }
        requestApplyInsets()
        // Keep this overlay window itself on the panel's top refresh rate.
        post {
            AnimationController.hintHighRate(this)
            (context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager)?.let { hzEngine.restampOverlay(it, this) }
        }
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(clockTick)
        smoother.stopMonitor("hud")
        boostShimmer?.stop()
        job?.cancel()
        job = null
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        layoutParts()
    }

    @Suppress("DEPRECATION")
    override fun onApplyWindowInsets(insets: WindowInsets): WindowInsets {
        var l = 0
        var t = 0
        var r = 0
        var b = 0
        if (Build.VERSION.SDK_INT >= 28) {
            insets.displayCutout?.let {
                l = it.safeInsetLeft; t = it.safeInsetTop; r = it.safeInsetRight; b = it.safeInsetBottom
            }
        }
        if (l != insetL || t != insetT || r != insetR || b != insetB) {
            insetL = l; insetT = t; insetR = r; insetB = b
            layoutParts()
        }
        return super.onApplyWindowInsets(insets)
    }

    // =========================================================================================
    // Gamepad / keyboard
    // =========================================================================================

    override fun dispatchKeyEvent(ev: KeyEvent): Boolean {
        if (ev.action == KeyEvent.ACTION_DOWN) {
            when (ev.keyCode) {
                KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_ESCAPE -> {
                    if (page == Page.DETAIL) goMain() else onClose()
                    return true
                }
                KeyEvent.KEYCODE_BUTTON_Y -> {
                    openDetail("Console settings", ConsoleSettings.build(this))
                    return true
                }
                KeyEvent.KEYCODE_BUTTON_X -> {
                    showTab(1 - tab)
                    return true
                }
                else -> if (cube?.handleKey(ev.keyCode) == true) return true
            }
        }
        return super.dispatchKeyEvent(ev)
    }

    // =========================================================================================
    // Build
    // =========================================================================================

    private fun dp(v: Int): Int = Ui.dp(context, v)

    private fun hintsVisible(): Boolean = when (global.hudLayout.hintMode) {
        1 -> true
        2 -> false
        else -> inputDeviceAttached()
    }

    private fun buildAll() {
        removeAllViews()
        hzBadge?.release()
        hzBadge = null
        railButtons.clear()
        cube = null
        turbine = null
        modeLabel = null
        modeSub = null
        fpsChart = null
        pingChart = null
        tempChart = null
        statLine = null
        toolsHolder = null
        tabBody = null
        tabChips = null
        firstFocus = null
        tab = global.hudLayout.centerTab.coerceIn(0, 1)

        scrim = View(context).apply {
            setBackgroundColor(HudThemes.withAlpha(0xFF000000.toInt(), global.hudLayout.scrimPct.coerceIn(0, 80) * 255 / 100))
            setOnClickListener { onClose() }
        }
        addView(scrim, LayoutParams(Ui.MATCH, Ui.MATCH))

        bar = ConsolePanel(context, theme, dp(8))
        rail = ConsolePanel(context, theme, dp(6))
        right = ConsolePanel(context, theme, dp(10))
        center = ConsolePanel(context, theme, dp(10))
        buildBar()
        buildRail()
        buildRight()
        buildCenter()
        for (p in listOf(bar, rail, right, center)) addView(p, LayoutParams(0, 0))
        hints = if (hintsVisible()) KeyHintBar(context, theme).also { addView(it, LayoutParams(0, 0)) } else null
        layoutParts()
        renderCenter()
        refreshMode()
        refreshBadge()
        updateFooter()
        refreshRail()
        firstFocus = railButtons.firstOrNull() ?: gearButton
    }

    /** Sizes and places the panels. Called whenever the window size or the safe area changes. */
    private fun layoutParts() {
        if (!::bar.isInitialized) return
        val dm = resources.displayMetrics
        val w = if (width > 0) width else dm.widthPixels
        val h = if (height > 0) height else dm.heightPixels
        val m = dp(8)
        val x0 = insetL + m
        val x1 = w - insetR - m
        val y0 = insetT + m
        val y1 = h - insetB - m
        barH = dp(46)
        val hintH = if (hints != null) dp(24) else 0
        railW = dp(76)
        wingW = min(dp(global.hudLayout.wingWidthDp.coerceIn(240, 380)), ((x1 - x0) * 0.31f).toInt()).coerceAtLeast(dp(190))
        val bodyTop = y0 + barH + m
        val bodyBottom = y1 - hintH
        val bodyH = (bodyBottom - bodyTop).coerceAtLeast(dp(120))
        centerW = (x1 - x0 - railW - wingW - 2 * m).coerceAtLeast(dp(200))

        place(bar, x0, y0, x1 - x0, barH)
        place(rail, x0, bodyTop, railW, bodyH)
        place(right, x1 - wingW, bodyTop, wingW, bodyH)
        place(center, x0 + railW + m, bodyTop, centerW, bodyH)
        hints?.let { place(it, x0, bodyTop + bodyH, x1 - x0, hintH) }

        // A different width can mean a different number of columns in the All tools grid.
        if (toolsHolder != null && toolCols() != lastCols) fillTools()
    }

    private fun place(v: View, x: Int, y: Int, w: Int, h: Int) {
        val lp = (v.layoutParams as? LayoutParams) ?: LayoutParams(w, h)
        lp.width = w
        lp.height = h
        lp.gravity = Gravity.TOP or Gravity.START
        lp.leftMargin = x
        lp.topMargin = y
        v.layoutParams = lp
    }

    // ---- status bar ----

    private fun buildBar() {
        val row = Ui.hbox(context)
        row.gravity = Gravity.CENTER_VERTICAL

        clockView = Ui.label(context, clockFormat.format(Date()), 15f, theme.textPrimary, true)
        row.addView(clockView, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, dp(6), 0, dp(10), 0))
        row.addView(
            Ui.label(context, gameLabel(), 11f, theme.textSecondary).apply {
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                maxWidth = dp(110)
            },
            Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, 0, dp(6), 0)
        )

        val cells = Ui.hbox(context)
        cells.gravity = Gravity.CENTER_VERTICAL
        fpsCell = StatChip(context, theme, IconKind.GAUGE, "FPS")
        cpuCell = StatChip(context, theme, IconKind.CHIP, "CPU")
        gpuCell = StatChip(context, theme, IconKind.GPU, "GPU")
        ramCell = StatChip(context, theme, IconKind.RAM, "RAM")
        tempCell = StatChip(context, theme, IconKind.THERMO, "TEMP C")
        pingCell = StatChip(context, theme, IconKind.PING, "PING MS")
        netCell = StatChip(context, theme, IconKind.WIFI, "NET")
        battCell = StatChip(context, theme, IconKind.BATTERY, "BATT")
        lowCell = StatChip(context, theme, IconKind.GAUGE, "1% LOW")
        lowCell.setOnClickListener { showFrameDetail() }
        val chips = listOf(fpsCell, lowCell, cpuCell, gpuCell, ramCell, tempCell, pingCell, netCell, battCell)
        chips.forEachIndexed { i, c ->
            if (i > 0) {
                cells.addView(
                    View(context).apply { setBackgroundColor(theme.divider) },
                    Ui.lp(1, dp(18), 0f, dp(1), 0, dp(1), 0)
                )
            }
            cells.addView(c, Ui.lp(Ui.WRAP, Ui.MATCH))
        }
        // FPS chip doubles as the detach button for the floating pill
        fpsCell.setOnClickListener { togglePill() }

        val hs = HorizontalScrollView(context)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(cells, ViewGroup.LayoutParams(Ui.WRAP, Ui.MATCH))
        row.addView(hs, Ui.lp(0, Ui.MATCH, 1f))

        hzLabel = Ui.label(context, "", 11f, theme.good, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(4), dp(8), dp(4))
            background = Ui.rounded(HudThemes.withAlpha(theme.textPrimary, 24), Ui.dpf(context, 20f))
            isClickable = true
            setOnClickListener { toggleMaxHz() }
        }
        hzBadge = AnimationController.HzBadge(hzLabel).also {
            it.set(hzEngine.currentHz(), hzEngine.caps()?.hzInt ?: 0, theme)
        }
        row.addView(hzLabel, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, dp(6), 0, 0, 0))
        updateLow(lastStats)

        modeSwitch = ModeSwitch(context, theme) { applyTier(it) }
        row.addView(modeSwitch, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, dp(6), 0, 0, 0))

        badge = Ui.label(context, "", 9f, theme.textPrimary, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(9), dp(4), dp(9), dp(4))
        }
        row.addView(badge, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, dp(8), 0, 0, 0))

        pillButton = ConsoleKit.iconButton(context, theme, IconKind.PILL, false) { togglePill() }
        row.addView(pillButton, Ui.lp(dp(34), dp(34), 0f, dp(8), 0, 0, 0))
        gearButton = ConsoleKit.iconButton(context, theme, IconKind.GEAR, false) {
            openDetail("Console settings", ConsoleSettings.build(this))
        }
        row.addView(gearButton, Ui.lp(dp(34), dp(34), 0f, dp(4), 0, 0, 0))
        row.addView(ConsoleKit.iconButton(context, theme, IconKind.CLOSE, false) { onClose() }, Ui.lp(dp(34), dp(34), 0f, dp(4), 0, 0, 0))

        bar.addView(row, LayoutParams(Ui.MATCH, Ui.MATCH))
        app.repository.profile(game)?.let { refreshPillButton(it) }
    }

    // ---- left quick rail ----

    private fun buildRail() {
        val col = Ui.vbox(context)

        val scroll = ScrollView(context)
        scroll.isVerticalScrollBarEnabled = false
        val list = Ui.vbox(context)
        list.gravity = Gravity.CENTER_HORIZONTAL
        val ids = global.hudLayout.railItems.filter { it in QuickCatalog.IDS }.distinct()
        for (id in ids) {
            val quick = QuickCatalog.create(this, id, extras) ?: continue
            val b = RailButton(context, theme, quick)
            railButtons += b
            list.addView(b, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, dp(1), 0, dp(1)))
        }
        if (railButtons.isEmpty()) {
            list.addView(
                Ui.label(context, "Add quick toggles in Console settings", 9f, theme.textSecondary).apply { gravity = Gravity.CENTER },
                Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, dp(8), 0, 0)
            )
        }
        scroll.addView(list, ViewGroup.LayoutParams(Ui.MATCH, Ui.WRAP))
        col.addView(scroll, Ui.lp(Ui.MATCH, 0, 1f))

        col.addView(
            View(context).apply { setBackgroundColor(theme.divider) },
            Ui.lp(Ui.MATCH, 1, 0f, dp(6), dp(2), dp(6), dp(2))
        )
        val hw = RailButton(
            context, theme,
            QuickItem("hw_boost", "Max HW", IconKind.CHIP, { lastBoost.active }, { toggleHardwareBoost() })
        )
        railButtons += hw
        col.addView(hw, Ui.lp(Ui.MATCH, Ui.WRAP))
        val all = RailButton(
            context, theme,
            QuickItem("all_tools", "All tools", IconKind.GRID, { page == Page.MAIN && tab == 1 }, { showTab(1) })
        )
        railButtons += all
        col.addView(all, Ui.lp(Ui.MATCH, Ui.WRAP))

        rail.addView(col, LayoutParams(Ui.MATCH, Ui.MATCH))
    }

    private fun refreshRail() {
        for (b in railButtons) b.refresh()
    }

    // ---- tools grid (All tools tab) ----

    private fun order(): List<String> {
        val known = ToolIds.ALL.toSet()
        val saved = global.sidebar.toolOrder.filter { it in known }.distinct()
        return saved + ToolIds.ALL.filter { it !in saved }
    }

    private fun toolCols(): Int = ((centerW - dp(48)) / dp(72)).coerceIn(3, 8)

    private fun fillTools() {
        val holder = toolsHolder ?: return
        holder.removeAllViews()
        val hidden = global.sidebar.hiddenTools.toSet()
        val shown = order().filter { it !in hidden && ToolRegistry.has(it) }
        if (shown.isEmpty()) {
            holder.addView(Ui.label(context, "No tools shown. Open Console settings.", 11f, theme.textSecondary))
            return
        }
        val cols = toolCols()
        lastCols = cols
        val card = Hyper.card(context, theme)
        for (chunk in shown.chunked(cols)) {
            val row = Ui.hbox(context)
            for (id in chunk) row.addView(tile(id), Ui.lp(0, Ui.WRAP, 1f, dp(2), dp(3), dp(2), dp(3)))
            for (i in chunk.size until cols) row.addView(View(context), Ui.lp(0, 1, 1f))
            card.addView(row, Ui.lp(Ui.MATCH, Ui.WRAP))
        }
        holder.addView(card, Ui.lp(Ui.MATCH, Ui.WRAP))
    }

    private fun tile(id: String): View {
        val info = ToolCatalog.info(id)
        val tool = ToolRegistry.get(id)
        val active = tool?.isActive(this) == true
        val radius = Ui.tileRadius(context, theme)
        val box = FrameLayout(context)
        box.background = if (Ui.isSoft(theme)) {
            Ui.rounded(if (active) theme.accent else theme.tile, radius)
        } else {
            Ui.rounded(if (active) theme.accent else theme.tile, radius, if (active) theme.accent else theme.stroke, dp(1))
        }
        val kind = HudIcons.forTool(id)
        val fg = if (active) HudThemes.onAccent(theme.accent) else theme.textPrimary
        if (kind != null) {
            box.addView(IconView(context, kind, fg).apply { fillFraction = 0.58f }, LayoutParams(Ui.MATCH, Ui.MATCH))
        } else if (info.iconRes != 0) {
            // Tools that only exist as a vector drawable (HyperLab, clip buffer)
            val icon = VIcon.view(context, info.iconRes, 28)
            VIcon.start(icon.drawable)
            box.addView(icon, LayoutParams(dp(28), dp(28), Gravity.CENTER))
        } else {
            box.addView(Ui.label(context, info.code, 13f, fg, true).apply { gravity = Gravity.CENTER }, LayoutParams(Ui.MATCH, Ui.MATCH))
        }
        val cap = Ui.label(context, info.title, 9f, theme.textSecondary).apply {
            gravity = Gravity.CENTER
            maxLines = 2
        }
        val cell = Ui.vbox(context)
        cell.gravity = Gravity.CENTER_HORIZONTAL
        cell.addView(box, Ui.lp(dp(46), dp(46)))
        cell.addView(cap, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, dp(3), 0, 0))
        cell.isClickable = true
        cell.isFocusable = true
        cell.onFocusChangeListener = View.OnFocusChangeListener { v, has ->
            v.foreground = if (has) Ui.rounded(0, radius, theme.accent2, dp(2)) else null
        }
        cell.setOnClickListener { tool?.onTap(this) }
        return cell
    }

    // ---- right control wing ----

    private fun buildRight() {
        val col = Ui.vbox(context)
        val cubeView = EnergyCubeView(context, scope, theme, game, global.hudLayout.cubeFace) { face ->
            deps.repo.updateGlobal { it.copy(hudLayout = it.hudLayout.copy(cubeFace = face)) }
        }
        cube = cubeView
        col.addView(cubeView, Ui.lp(Ui.MATCH, 0, 1f))
        val sliders = Hyper.card(context, theme)
        sliders.setPadding(dp(10), dp(4), dp(10), dp(4))
        sliders.addView(brightnessRow(), Ui.lp(Ui.MATCH, dp(30)))
        sliders.addView(volumeRow(), Ui.lp(Ui.MATCH, dp(30), 0f, 0, dp(2), 0, 0))
        col.addView(sliders, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, dp(6), 0, 0))
        right.addView(col, LayoutParams(Ui.MATCH, Ui.MATCH))
    }

    private fun brightnessRow(): View {
        val row = Ui.hbox(context)
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(IconView(context, IconKind.SUN, theme.textPrimary), Ui.lp(dp(22), dp(22)))
        val max = deps.bridge.brightnessMax().coerceAtLeast(255)
        val cur = runCatching { Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS) }
            .getOrDefault(max / 2).coerceIn(1, max)
        val bar = Ui.slider(context, theme, 1, max, cur, {}, { v ->
            scope.launch {
                // Tracked, so leaving the game puts the user's own brightness and mode back.
                deps.engine.putTracked(Ns.SYSTEM, "screen_brightness_mode", "0")
                val r = deps.engine.putTracked(Ns.SYSTEM, "screen_brightness", v.toString())
                if (!r.ok) toast("Brightness: " + r.detail)
            }
        })
        row.addView(bar, Ui.lp(0, Ui.WRAP, 1f))
        return row
    }

    private fun volumeRow(): View {
        val row = Ui.hbox(context)
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(IconView(context, IconKind.VOLUME, theme.textPrimary), Ui.lp(dp(22), dp(22)))
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val maxV = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC).coerceIn(0, maxV)
        val bar = Ui.slider(context, theme, 0, maxV, cur, { v ->
            runCatching { am.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0) }
        }, { v ->
            runCatching { am.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0) }
        })
        row.addView(bar, Ui.lp(0, Ui.WRAP, 1f))
        return row
    }

    // ---- centre ----

    private fun buildCenter() {
        val col = Ui.vbox(context)
        centerBody = FrameLayout(context)
        col.addView(centerBody, Ui.lp(Ui.MATCH, 0, 1f))
        footer = Ui.label(context, "", 10f, theme.textSecondary).apply {
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }
        col.addView(footer, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, dp(4), 0, 0))
        center.addView(col, LayoutParams(Ui.MATCH, Ui.MATCH))
    }

    private fun clearCenterRefs() {
        turbine = null; modeLabel = null; modeSub = null
        fpsChart = null; pingChart = null; tempChart = null; statLine = null
        toolsHolder = null
        boostShimmer?.stop()
        boostShimmer = null
        boostCard = null; boostIcon = null; boostSub = null; boostButton = null
    }

    private fun renderCenter() {
        if (!::centerBody.isInitialized) return
        centerBody.removeAllViews()
        tabBody = null
        tabChips = null
        clearCenterRefs()
        val v: View = when (page) {
            Page.MAIN -> buildMainBody()
            Page.DETAIL -> buildDetail(detailContent ?: run { page = Page.MAIN; buildMainBody() })
        }
        (v.parent as? ViewGroup)?.removeView(v)
        centerBody.addView(v, LayoutParams(Ui.MATCH, Ui.MATCH))
        refreshMode()
        lastSample?.let { onSample(it) }
    }

    /** Tab strip (Dashboard / All tools) with Restore on the right, and the tab's content underneath. */
    private fun buildMainBody(): View {
        val col = Ui.vbox(context)
        val head = Ui.hbox(context)
        head.gravity = Gravity.CENTER_VERTICAL
        val chips = ChipGroup(context, theme, listOf("Dashboard", "All tools"), tab, 2) { i -> showTab(i) }
        tabChips = chips
        head.addView(chips, Ui.lp(dp(230), Ui.WRAP))
        head.addView(View(context), Ui.lp(0, 1, 1f))
        head.addView(Ui.button(context, theme, "Restore") {
            scope.launch {
                val rep = deps.engine.restoreAll("HUD button")
                toast(if (rep.complete) "All settings restored" else "Some items could not be restored yet")
            }
        }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, dp(6), 0, 0, 0))
        col.addView(head, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, 0, 0, dp(6)))

        val body = FrameLayout(context)
        tabBody = body
        col.addView(body, Ui.lp(Ui.MATCH, 0, 1f))
        renderTab()
        return col
    }

    private fun renderTab() {
        val body = tabBody ?: return
        body.removeAllViews()
        clearCenterRefs()
        val v = if (tab == 0) buildDashboard() else buildToolsTab()
        body.addView(v, LayoutParams(Ui.MATCH, Ui.MATCH))
        refreshMode()
        lastSample?.let { onSample(it) }
    }

    private fun buildToolsTab(): View {
        val scroll = ScrollView(context)
        scroll.isVerticalScrollBarEnabled = false
        val holder = Ui.vbox(context)
        toolsHolder = holder
        scroll.addView(holder, ViewGroup.LayoutParams(Ui.MATCH, Ui.WRAP))
        fillTools()
        return scroll
    }

    private fun showTab(i: Int) {
        tab = i.coerceIn(0, 1)
        deps.repo.updateGlobal { it.copy(hudLayout = it.hudLayout.copy(centerTab = tab)) }
        if (page == Page.DETAIL) {
            page = Page.MAIN
            detailContent = null
            renderCenter()
        } else {
            tabChips?.select(tab)
            renderTab()
        }
        refreshRail()
    }

    private fun goMain() {
        page = Page.MAIN
        detailContent = null
        renderCenter()
        refreshRail()
    }

    private fun buildDetail(content: View): View {
        val col = Ui.vbox(context)
        val head = Ui.hbox(context)
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(ConsoleKit.iconButton(context, theme, IconKind.BACK, false) { goMain() }, Ui.lp(dp(32), dp(32)))
        head.addView(
            Ui.label(context, detailTitle, 14f, theme.textPrimary, true).apply {
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            },
            Ui.lp(0, Ui.WRAP, 1f, dp(8), 0, 0, 0)
        )
        col.addView(head, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, 0, 0, dp(6)))
        val scroll = ScrollView(context)
        scroll.isVerticalScrollBarEnabled = false
        (content.parent as? ViewGroup)?.removeView(content)
        scroll.addView(content, ViewGroup.LayoutParams(Ui.MATCH, Ui.WRAP))
        col.addView(scroll, Ui.lp(Ui.MATCH, 0, 1f))
        return col
    }

    private fun buildDashboard(): View {
        val col = Ui.vbox(context)

        // hero card: turbine, game, current mode
        val hero = Hyper.card(context, theme)
        val top = Ui.hbox(context)
        top.gravity = Gravity.CENTER_VERTICAL
        val tv = TurbineView(context)
        tv.setOnClickListener { toggleWild() }
        turbine = tv
        top.addView(tv, Ui.lp(dp(64), dp(64), 0f, 0, 0, dp(12), 0))
        val info = Ui.vbox(context)
        info.addView(Ui.label(context, gameLabel(), 17f, theme.textPrimary, true).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        })
        val ml = Ui.label(context, "", 13f, theme.textPrimary, true)
        val ms = Ui.label(context, "", 10f, theme.textSecondary)
        modeLabel = ml
        modeSub = ms
        info.addView(ml, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, dp(2), 0, 0))
        info.addView(ms, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, dp(2), 0, 0))
        top.addView(info, Ui.lp(0, Ui.WRAP, 1f))
        hero.addView(top, Ui.lp(Ui.MATCH, Ui.WRAP))
        col.addView(hero, Ui.lp(Ui.MATCH, Ui.WRAP))
        col.addView(buildBoostCard(), Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, dp(8), 0, 0))

        // charts card
        fun chart(title: String, color: Int): MiniChartView = MiniChartView(context).apply {
            this.title = title
            lineColor = color
            textColor = theme.textPrimary
            subColor = theme.textSecondary
            gridColor = HudThemes.withAlpha(theme.textPrimary, 30)
        }
        val c1 = chart("FPS", theme.accent).apply { fixedMin = 0f; minRange = 30f }
        val c2 = chart("PING", theme.accent2).apply { minRange = 20f }
        val c3 = chart("BATTERY TEMP", theme.warn).apply { minRange = 6f }
        fpsChart = c1; pingChart = c2; tempChart = c3
        val charts = Ui.hbox(context)
        for (c in listOf(c1, c2, c3)) charts.addView(c, Ui.lp(0, Ui.MATCH, 1f, dp(2), 0, dp(2), 0))
        val chartCard = Hyper.card(context, theme)
        chartCard.minimumHeight = dp(96)
        val sl = Ui.label(context, "", 10f, theme.textSecondary)
        statLine = sl
        chartCard.addView(charts, Ui.lp(Ui.MATCH, 0, 1f))
        chartCard.addView(sl, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, dp(6), 0, 0))
        col.addView(chartCard, Ui.lp(Ui.MATCH, 0, 1f, 0, dp(8), 0, 0))
        return col
    }

    // =========================================================================================
    // State refresh
    // =========================================================================================

    private fun gameLabel(): String = GameActions.profileFor(deps, game).label.ifBlank { game }

    private fun updateFooter() {
        if (!::footer.isInitialized) return
        footer.setTextColor(theme.textSecondary)
        footer.text = buildString {
            append(
                when (deps.bridge.state.value.provider) {
                    com.hyperengine.gameturbo.core.ShellProvider.SHIZUKU -> "Shizuku"
                    com.hyperengine.gameturbo.core.ShellProvider.ROOT -> "Root"
                    com.hyperengine.gameturbo.core.ShellProvider.NONE -> "No privileged shell"
                }
            )
            if (lastEngine.sessionActive) append("  |  tweaks active")
            lastEngine.restoreCountdownSec?.let { append("  |  restore in ${it}s") }
            lastEngine.busy?.let { append("  |  $it") }
        }
    }

    private fun refreshMode() {
        if (!::fpsCell.isInitialized) return
        val p = GameActions.profileFor(deps, game)
        val w = wildState
        val tier = when {
            w.batterySaverOn -> PerfTier.ECO
            w.active || p.gameMode == GameModeLevel.PERFORMANCE && w.tier == PerfTier.WILDBOOST -> PerfTier.WILDBOOST
            p.gameMode == GameModeLevel.BATTERY -> PerfTier.ECO
            else -> w.tier
        }
        val colors = listOf(theme.good, theme.accent, theme.accent2)
        modeSwitch.select(tier.ordinal)
        turbine?.setMode(
            when (tier) { PerfTier.ECO -> GameModeLevel.BATTERY; PerfTier.BALANCED -> GameModeLevel.STANDARD; PerfTier.WILDBOOST -> GameModeLevel.PERFORMANCE },
            theme
        )
        turbine?.rpm = w.fanRpm
        modeLabel?.text = when {
            w.active && w.diablo -> "DIABLO MODE"
            tier == PerfTier.ECO -> "BATTERY SAVER"
            tier == PerfTier.BALANCED -> "BALANCED"
            else -> "WILD BOOST"
        }
        modeLabel?.setTextColor(colors[tier.ordinal])
        val ds = p.downscale?.let { String.format(Locale.US, "render %.0f%%", it * 100f) }
        val fps = if (p.turbo.unlockFps > 0) "FPS unlock ${p.turbo.unlockFps}" else if (p.targetFps > 0) "FPS cap ${p.targetFps}" else null
        modeSub?.text = listOfNotNull(ds, fps).joinToString("   ").ifBlank { "No downscale or FPS cap" }
    }

    private fun refreshBadge() {
        if (!::badge.isInitialized) return
        val st = deps.bridge.state.value
        val (text, color) = when {
            st.shizukuGranted -> "SHIZUKU" to theme.good
            st.rootGranted -> "ROOT" to theme.good
            st.writeSecureSettings -> "ADB GRANT" to theme.warn
            else -> "LIMITED" to theme.hot
        }
        badge.text = text
        badge.setTextColor(color)
        badge.background = if (Ui.isSoft(theme)) {
            Ui.rounded(HudThemes.withAlpha(color, 38), Ui.dpf(context, 20f))
        } else {
            Ui.rounded(HudThemes.withAlpha(color, 40), Ui.tileRadius(context, theme), color, dp(1))
        }
    }

    private fun refreshPillButton(p: GameProfile) {
        if (!::pillButton.isInitialized) return
        ConsoleKit.styleIconButton(pillButton, theme, IconKind.PILL, p.pill.enabled)
    }

    private fun signalColor(level: Int): Int = when {
        level < 0 -> theme.textSecondary
        level <= 1 -> theme.hot
        level == 2 -> theme.warn
        else -> theme.good
    }

    // =========================================================================================
    // Actions
    // =========================================================================================

    private fun applyTier(i: Int) {
        scope.launch {
            val tr = PerfTier.values()[i]
            deps.repo.update(game) {
                it.copy(turbo = it.turbo.copy(nativeBatterySaver = tr == PerfTier.ECO, wildBoost = tr == PerfTier.WILDBOOST))
            }
            // Same full boost as the Quick Settings tile and the sidebar chip (see WildBoostController).
            val boost = app.wildBoost
            val steps = ArrayList<com.hyperengine.gameturbo.core.StepResult>()
            if (tr == PerfTier.WILDBOOST) {
                if (!app.wild.state.value.active) boost.ignite()
                steps += boost.boostOn(game, persistMode = true)
            } else {
                steps += boost.releaseExtras(game)      // takes back the FPS lock a Wild Boost added
                steps += app.wild.setTier(game, tr)
            }
            val (ok, text) = GameActions.summary(steps)
            toast(if (ok) tr.label + " active" else text.lineSequence().firstOrNull { it.startsWith("[failed]") } ?: text)
        }
    }

    private fun toggleWild() {
        val on = wildState.active
        applyTier(if (on) PerfTier.BALANCED.ordinal else PerfTier.WILDBOOST.ordinal)
    }

    /** Detach the FPS readout into the floating pill (or put it back). The pill is the Phase 4 overlay. */
    private fun togglePill() {
        val now = GameActions.profileFor(deps, game).pill.enabled
        deps.repo.update(game) { it.copy(pill = it.pill.copy(enabled = !now, showFps = true)) }
        toast(if (now) "FPS pill attached back to the HUD" else "FPS pill detached. Drag it anywhere, long-press to pin.")
    }

    // =========================================================================================
    // Part 6: refresh rate, frame stability, Max Hardware Boost
    // =========================================================================================

    /** The "1% LOW" chip: FPS of the slowest 1% of HUD frames, coloured by how many frames hit the display rate. */
    private fun updateLow(st: FrameStats) {
        if (!::lowCell.isInitialized) return
        if (!st.running || st.frames < 30) {
            lowCell.set("--", theme.textSecondary, "1% LOW")
            return
        }
        val c = when {
            st.stabilityPct >= 95f -> theme.good
            st.stabilityPct >= 85f -> theme.warn
            else -> theme.hot
        }
        lowCell.set(String.format(Locale.US, "%.0f", st.low1Fps), c, "1% LOW")
    }

    private fun showFrameDetail() {
        val st = lastStats
        if (!st.running || st.frames < 30) {
            toast("Frame monitor is warming up")
            return
        }
        toast(
            String.format(
                Locale.US,
                "HUD frames: avg %.0f FPS, 1%% low %.0f, jitter %.1f ms, %.0f%% stable, %.1f%% janky (target %.1f ms)",
                st.avgFps, st.low1Fps, st.jitterMs, st.stabilityPct, st.jankPct, st.periodMs
            )
        )
    }

    /** Tap on the Hz badge: lock the panel at its top rate for this game, or give it back. */
    private fun toggleMaxHz() {
        if (lastHz.busy != null) {
            toast("Busy: " + lastHz.busy)
            return
        }
        if (lastHz.engaged) {
            hzEngine.releaseAsync("HUD badge") { post { toast("Refresh rate lock released") } }
        } else {
            hzEngine.engageAsync(game) { rep ->
                post {
                    toast(
                        if (rep.reachedMax) "Panel locked at ${rep.shownHz} Hz (${rep.rom.label})"
                        else "Panel shows ${rep.shownHz} of ${rep.panelMaxHz} Hz; ${rep.failures} layer(s) refused"
                    )
                }
            }
        }
    }

    private fun buildBoostCard(): View {
        val card = Hyper.card(context, theme)
        val row = Ui.hbox(context)
        row.gravity = Gravity.CENTER_VERTICAL
        val icon = VIcon.view(context, R.drawable.ic_max_hardware_boost, 40)
        boostIcon = icon
        row.addView(icon, Ui.lp(dp(40), dp(40), 0f, 0, 0, dp(10), 0))
        val info = Ui.vbox(context)
        info.addView(Ui.label(context, "AnTuTu / Max Hardware Boost", 13f, theme.textPrimary, true).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        })
        val sub = Ui.label(context, "", 10f, theme.textSecondary).apply { maxLines = 2 }
        boostSub = sub
        info.addView(sub, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, dp(2), 0, 0))
        row.addView(info, Ui.lp(0, Ui.WRAP, 1f))
        val btn = Ui.button(context, theme, "Boost", true) { toggleHardwareBoost() }
        boostButton = btn
        row.addView(btn, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, dp(8), 0, 0, 0))
        card.addView(row, Ui.lp(Ui.MATCH, Ui.WRAP))
        boostCard = card
        boostShimmer = AnimationController.BusyShimmer(card, Ui.dpf(context, 14f))
        boostWasActive = lastBoost.active
        refreshBoostCard(force = true)
        return card
    }

    private fun refreshBoostCard(force: Boolean = false) {
        refreshRail()
        val sub = boostSub ?: return
        val btn = boostButton ?: return
        val b = lastBoost
        val busy = b.busy
        sub.text = when {
            busy != null -> busy
            b.active -> buildString {
                append(String.format(Locale.US, "ON  |  %.1f C  |  thermal %s", b.tempC, b.thermalStatus.ifBlank { "n/a" }))
                b.report?.takeIf { it.ramGainedMb > 0 }?.let { append("  |  +${it.ramGainedMb} MB RAM") }
                if (lastHz.panelMaxHz > 0) append("  |  ${lastHz.shownHz}/${lastHz.panelMaxHz} Hz")
            }
            b.stopReason != null -> "Stopped: " + b.stopReason
            else -> "Thermal override, fixed clocks, RAM purge, panel lock" +
                (if (lastHz.panelMaxHz > 0) " at ${lastHz.panelMaxHz} Hz" else "")
        }
        btn.text = when {
            busy != null -> "Working..."
            b.active -> "Stop"
            else -> "Boost"
        }
        btn.alpha = if (busy != null) 0.6f else 1f
        if (busy != null) boostShimmer?.start() else boostShimmer?.stop()
        if (force || b.active != boostWasActive) {
            boostIcon?.let { ic ->
                ic.setImageDrawable(
                    VIcon.drawable(context, if (b.active) R.drawable.avd_max_boost_charge else R.drawable.ic_max_hardware_boost)
                )
                if (b.active) VIcon.start(ic.drawable)
            }
            if (b.active && !boostWasActive && !force) boostCard?.let { AnimationController.Shockwave.play(it, theme.accent2, 2, theme) }
            boostWasActive = b.active
        }
    }

    /**
     * One tap for the whole stack: AnTuTu / Max Hardware Boost (thermal override, fixed-performance clocks,
     * storage trim, RAM purge, background-data block, max panel refresh + GameManager fps for the game) plus the
     * frame smoother (PerformanceHintManager session, render-thread priority, HWUI / SurfaceFlinger flags).
     * Tap again to restore everything that was changed. The temperature watchdog also ends it by itself.
     */
    private fun toggleHardwareBoost() {
        val b = lastBoost
        if (b.busy != null) {
            boostCard?.let { AnimationController.shake(it, theme) }
            toast("Busy: " + b.busy)
            return
        }
        scope.launch {
            val steps = ArrayList<com.hyperengine.gameturbo.core.StepResult>()
            if (b.active) {
                steps += booster.release("HUD toggle")
                steps += smoother.release()
                val (ok, text) = GameActions.summary(steps)
                toast(if (ok) "Max Hardware Boost off, settings restored" else text.lineSequence().firstOrNull { it.startsWith("[failed]") } ?: text)
            } else {
                steps += booster.engage(BoostOptions(targets = listOf(game))).steps
                steps += smoother.engage()
                val (ok, text) = GameActions.summary(steps)
                if (!ok) boostCard?.let { AnimationController.shake(it, theme) }
                toast(
                    if (ok) "Max Hardware Boost on at ${hzEngine.currentHz()} Hz"
                    else text.lineSequence().firstOrNull { it.startsWith("[failed]") } ?: text
                )
            }
        }
    }

    companion object {
        /** True when a gamepad, D-pad or physical keyboard is connected, so the HUD window should take focus. */
        fun inputDeviceAttached(): Boolean = runCatching {
            InputDevice.getDeviceIds().any { id ->
                val dev = InputDevice.getDevice(id) ?: return@any false
                if (dev.isVirtual) return@any false
                val s = dev.sources
                (s and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
                    (s and InputDevice.SOURCE_DPAD) == InputDevice.SOURCE_DPAD ||
                    ((s and InputDevice.SOURCE_KEYBOARD) == InputDevice.SOURCE_KEYBOARD &&
                        dev.keyboardType == InputDevice.KEYBOARD_TYPE_ALPHABETIC)
            }
        }.getOrDefault(false)
    }
}
