package com.hyperengine.gameturbo.ui

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.telephony.TelephonyManager
import com.hyperengine.gameturbo.core.SystemBridgeExecutor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * GPU utilisation from the kernel's own counters. There is no public Android API for it, so the value comes
 * from whichever sysfs node this SoC exposes (Adreno kgsl, Mali, MediaTek GED). Those nodes are usually
 * readable only by the shell user, so without Shizuku / root most phones return -1 and the HUD shows "--".
 * Nothing here is estimated or invented.
 */
class GpuLoadReader(private val bridge: SystemBridgeExecutor) {

    private var path: String? = null
    private var probed = false
    private var needsShell = false

    /** 0..100, or -1 when this phone exposes no readable GPU counter. */
    suspend fun read(): Int = withContext(Dispatchers.IO) {
        if (!probed) probe()
        val p = path ?: return@withContext -1
        val text = if (needsShell) {
            if (!bridge.hasShell()) return@withContext -1
            val r = bridge.shell("cat $p", 3_000L)
            if (r.ok) r.stdout else ""
        } else {
            runCatching { File(p).readText() }.getOrDefault("")
        }
        parse(text)
    }

    private suspend fun probe() {
        // 1. direct read, as the app user
        for (c in KNOWN) {
            val f = File(c)
            if (f.exists() && runCatching { parse(f.readText()) }.getOrDefault(-1) >= 0) {
                path = c
                needsShell = false
                probed = true
                return
            }
        }
        // 2. through the privileged shell, including the vendor-specific names that need a glob
        if (bridge.hasShell()) {
            val list = KNOWN.joinToString(" ") + " " + GLOBS.joinToString(" ")
            val r = bridge.shell("for f in $list; do [ -r \"\$f\" ] && { echo \"\$f\"; break; }; done", 5_000L)
            val found = r.stdout.lines().firstOrNull { it.startsWith("/") }?.trim()
            if (found != null && Regex("^[A-Za-z0-9_./:@*-]+$").matches(found)) {
                path = found
                needsShell = true
            }
            probed = true
        }
        // Without a shell the probe is repeated later: Shizuku may be started after the HUD was first opened.
    }

    private fun parse(text: String): Int {
        val n = Regex("\\d+").find(text.trim())?.value?.toIntOrNull() ?: return -1
        return if (n in 0..100) n else -1
    }

    companion object {
        private val KNOWN = listOf(
            "/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage",
            "/sys/class/kgsl/kgsl-3d0/devfreq/gpu_load",
            "/sys/kernel/gpu/gpu_busy",
            "/sys/kernel/ged/hal/gpu_utilization",
            "/proc/mali/utilization",
            "/sys/devices/platform/mali/utilization",
            "/sys/class/misc/mali0/device/utilization"
        )
        private val GLOBS = listOf(
            "/sys/devices/platform/*mali*/utilization",
            "/sys/class/devfreq/*mali*/load",
            "/sys/class/devfreq/*gpu*/load"
        )
    }
}

/** Connection kind and strength for the HUD, straight from ConnectivityManager / WifiManager / TelephonyManager. */
object SignalReader {

    /** [level] is 0..4, or -1 when unknown / offline. */
    data class Net(val label: String, val level: Int)

    @Suppress("DEPRECATION")
    fun read(ctx: Context): Net = runCatching {
        val app = ctx.applicationContext
        val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.activeNetwork?.let { cm.getNetworkCapabilities(it) }
        when {
            caps == null -> Net("Offline", -1)
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> {
                val wm = app.getSystemService(Context.WIFI_SERVICE) as WifiManager
                val rssi = wm.connectionInfo?.rssi ?: -127
                Net("Wi-Fi", if (rssi <= -120) -1 else WifiManager.calculateSignalLevel(rssi, 5))
            }
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> {
                val tm = app.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
                val level = if (Build.VERSION.SDK_INT >= 28) tm.signalStrength?.level ?: -1 else -1
                Net("Cell", level)
            }
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> Net("LAN", 4)
            else -> Net("Online", -1)
        }
    }.getOrDefault(Net("--", -1))
}
