package com.hyperengine.gameturbo.core

import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.Matrix
import android.os.Handler
import android.os.HandlerThread
import android.os.Process
import android.os.SystemClock
import android.view.Surface
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

/**
 * The picture side of the virtual-display upscaler.
 *
 * A game runs on a VirtualDisplay that is [srcW] x [srcH] pixels (smaller than the screen). Everything that display
 * draws lands in [inputSurface], which belongs to a SurfaceTexture. For every new frame this class
 *
 *  1. scales it up to the screen size with a Catmull-Rom bicubic filter (5 bilinear taps, so it is cheap and keeps
 *     edges much cleaner than the plain bilinear scaler the panel would use), then
 *  2. runs a contrast-adaptive sharpening pass (the same idea as AMD's open CAS: 5 taps, the strength per pixel is
 *     limited by the local contrast so flat areas get no noise and already-sharp edges get no halo),
 *
 * and presents the result on the window surface passed to [attachOutput]. With sharpness 0, pass 2 is skipped.
 *
 * Own GL thread, own EGL context. The window surface can come and go (screen off, window hidden): the context
 * lives on, frames are still drained so the game never stalls, and drawing resumes when a surface is attached again.
 *
 * Honest limits: this is a spatial filter in the spirit of FSR 1 / CAS. It is NOT DLSS-style AI upscaling and it
 * cannot invent detail that the low-resolution render never had. It needs a GPU that supports OpenGL ES 2.0 and
 * the external-image extension, which every Android 8+ phone does.
 */
class UpscaleRenderer(
    private val srcW: Int,
    private val srcH: Int,
    @Volatile var sharpness: Int,
    private val onFps: (Int) -> Unit
) {
    private val thread = HandlerThread("HyperUpscaleGL", Process.THREAD_PRIORITY_DISPLAY).also { it.start() }
    private val gl = Handler(thread.looper)

    private var dpy: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var ctx: EGLContext = EGL14.EGL_NO_CONTEXT
    private var cfg: EGLConfig? = null
    private var pbuffer: EGLSurface = EGL14.EGL_NO_SURFACE
    private var window: EGLSurface = EGL14.EGL_NO_SURFACE
    private var winW = 0
    private var winH = 0

    private var oesTex = 0
    private var fboTex = 0
    private var fbo = 0
    private var fboW = 0
    private var fboH = 0
    private var progScale = 0
    private var progSharpen = 0

    // Attribute / uniform locations. glGet*Location is a driver string lookup; doing it 8 times per frame on the GL thread
    // was pure overhead at 60-120 fps. They are resolved once, after the programs link.
    private class Locs(prog: Int) {
        val aPos = GLES20.glGetAttribLocation(prog, "aPos")
        val aUv = GLES20.glGetAttribLocation(prog, "aUv")
        val uTex = GLES20.glGetUniformLocation(prog, "uTex")
        val uMat = GLES20.glGetUniformLocation(prog, "uMat")
        val uSrcSize = GLES20.glGetUniformLocation(prog, "uSrcSize")
        val uTexel = GLES20.glGetUniformLocation(prog, "uTexel")
        val uSharp = GLES20.glGetUniformLocation(prog, "uSharp")
    }
    private var locScale: Locs? = null
    private var locSharpen: Locs? = null
    private var texture: SurfaceTexture? = null

    private val quad: FloatBuffer = ByteBuffer.allocateDirect(QUAD.size * 4).order(ByteOrder.nativeOrder())
        .asFloatBuffer().apply { put(QUAD); position(0) }
    private val texMatrix = FloatArray(16).also { Matrix.setIdentityM(it, 0) }
    private val identity = FloatArray(16).also { Matrix.setIdentityM(it, 0) }

    private var frames = 0
    private var fpsSince = 0L

    @Volatile
    private var released = false

    /** The surface the virtual display draws into. Valid after [init] returned true. */
    @Volatile
    var inputSurface: Surface? = null
        private set

    /** Why [init] failed, in the GL driver's own words. */
    @Volatile
    var error: String? = null
        private set

    /** Sets up EGL, the shaders and the SurfaceTexture on the GL thread. */
    suspend fun init(): Boolean {
        val done = CompletableDeferred<Boolean>()
        gl.post { done.complete(setup()) }
        return withTimeoutOrNull(4_000L) { done.await() } ?: run {
            error = "GL setup timed out"
            false
        }
    }

    fun attachOutput(surface: Surface) {
        gl.post {
            if (released) return@post
            detachInternal()
            try {
                window = EGL14.eglCreateWindowSurface(dpy, cfg, surface, intArrayOf(EGL14.EGL_NONE), 0)
                if (window == EGL14.EGL_NO_SURFACE) {
                    error = "eglCreateWindowSurface failed (0x" + Integer.toHexString(EGL14.eglGetError()) + ")"
                    return@post
                }
                val w = IntArray(1)
                val h = IntArray(1)
                EGL14.eglQuerySurface(dpy, window, EGL14.EGL_WIDTH, w, 0)
                EGL14.eglQuerySurface(dpy, window, EGL14.EGL_HEIGHT, h, 0)
                winW = w[0].coerceAtLeast(1)
                winH = h[0].coerceAtLeast(1)
                EGL14.eglMakeCurrent(dpy, window, window, ctx)
                EGL14.eglSwapInterval(dpy, 0)          // frames come from the game at its own pace; never wait for vsync here
                ensureFbo(winW, winH)
            } catch (t: Throwable) {
                error = t.javaClass.simpleName + ": " + (t.message ?: "")
                detachInternal()
            }
        }
    }

    fun detachOutput() {
        gl.post { detachInternal() }
    }

    fun release() {
        if (released) return
        released = true
        gl.post {
            runCatching { texture?.setOnFrameAvailableListener(null) }
            teardown()
            thread.quitSafely()
        }
    }

    // ---------------------------------------------------------------------------------------------
    // GL thread only below this line
    // ---------------------------------------------------------------------------------------------

    private fun setup(): Boolean {
        return try {
            dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
            check(dpy != EGL14.EGL_NO_DISPLAY) { "no EGL display" }
            val ver = IntArray(2)
            check(EGL14.eglInitialize(dpy, ver, 0, ver, 1)) { "eglInitialize failed" }

            val attrs = intArrayOf(
                EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
                EGL14.EGL_SURFACE_TYPE, EGL14.EGL_WINDOW_BIT or EGL14.EGL_PBUFFER_BIT,
                EGL14.EGL_NONE
            )
            val cfgs = arrayOfNulls<EGLConfig>(1)
            val n = IntArray(1)
            check(EGL14.eglChooseConfig(dpy, attrs, 0, cfgs, 0, 1, n, 0) && n[0] > 0) { "no usable EGL config" }
            cfg = cfgs[0]
            ctx = EGL14.eglCreateContext(dpy, cfg, EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
            check(ctx != EGL14.EGL_NO_CONTEXT) { "eglCreateContext failed (0x" + Integer.toHexString(EGL14.eglGetError()) + ")" }

            // A 1x1 pbuffer keeps the context current while no window is attached.
            pbuffer = EGL14.eglCreatePbufferSurface(dpy, cfg, intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0)
            check(EGL14.eglMakeCurrent(dpy, pbuffer, pbuffer, ctx)) { "eglMakeCurrent failed (0x" + Integer.toHexString(EGL14.eglGetError()) + ")" }

            progScale = program(VERT, FRAG_SCALE)
            progSharpen = program(VERT, FRAG_SHARPEN)
            locScale = Locs(progScale)
            locSharpen = Locs(progSharpen)

            val t = IntArray(1)
            GLES20.glGenTextures(1, t, 0)
            oesTex = t[0]
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTex)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

            val st = SurfaceTexture(oesTex)
            st.setDefaultBufferSize(srcW, srcH)
            st.setOnFrameAvailableListener({ drawFrame() }, gl)
            texture = st
            inputSurface = Surface(st)
            true
        } catch (t: Throwable) {
            error = t.javaClass.simpleName + ": " + (t.message ?: "")
            teardown()
            false
        }
    }

    private fun drawFrame() {
        if (released) return
        val st = texture ?: return
        // Always take the newest frame, even with no window, or the producer (the game) would block.
        try {
            st.updateTexImage()
        } catch (_: Throwable) {
            return
        }
        if (window == EGL14.EGL_NO_SURFACE) return
        st.getTransformMatrix(texMatrix)
        try {
            val sharp = sharpness.coerceIn(0, 100)
            if (sharp > 0) {
                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo)
                GLES20.glViewport(0, 0, fboW, fboH)
                drawScale()
                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
                GLES20.glViewport(0, 0, winW, winH)
                drawSharpen(sharp / 100f)
            } else {
                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
                GLES20.glViewport(0, 0, winW, winH)
                drawScale()
            }
            if (!EGL14.eglSwapBuffers(dpy, window)) {
                val e = EGL14.eglGetError()
                // The window went away under us (EGL_BAD_SURFACE / BAD_NATIVE_WINDOW): stop drawing until a new one is attached.
                if (e == EGL14.EGL_BAD_SURFACE || e == EGL14.EGL_BAD_NATIVE_WINDOW) detachInternal()
                return
            }
        } catch (t: Throwable) {
            error = t.javaClass.simpleName + ": " + (t.message ?: "")
            return
        }
        frames++
        val now = SystemClock.uptimeMillis()
        if (fpsSince == 0L) fpsSince = now
        if (now - fpsSince >= 1_000L) {
            val fps = (frames * 1000L / (now - fpsSince)).toInt()
            frames = 0
            fpsSince = now
            runCatching { onFps(fps) }
        }
    }

    private fun drawScale() {
        val l = locScale ?: return
        GLES20.glUseProgram(progScale)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTex)
        GLES20.glUniform1i(l.uTex, 0)
        GLES20.glUniformMatrix4fv(l.uMat, 1, false, texMatrix, 0)
        GLES20.glUniform2f(l.uSrcSize, srcW.toFloat(), srcH.toFloat())
        drawQuad(l)
    }

    private fun drawSharpen(amount: Float) {
        val l = locSharpen ?: return
        GLES20.glUseProgram(progSharpen)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, fboTex)
        GLES20.glUniform1i(l.uTex, 0)
        GLES20.glUniformMatrix4fv(l.uMat, 1, false, identity, 0)
        GLES20.glUniform2f(l.uTexel, 1f / fboW, 1f / fboH)
        GLES20.glUniform1f(l.uSharp, amount)
        drawQuad(l)
    }

    private fun drawQuad(l: Locs) {
        quad.position(0)
        GLES20.glVertexAttribPointer(l.aPos, 2, GLES20.GL_FLOAT, false, 16, quad)
        GLES20.glEnableVertexAttribArray(l.aPos)
        quad.position(2)
        GLES20.glVertexAttribPointer(l.aUv, 2, GLES20.GL_FLOAT, false, 16, quad)
        GLES20.glEnableVertexAttribArray(l.aUv)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(l.aPos)
        GLES20.glDisableVertexAttribArray(l.aUv)
    }

    private fun ensureFbo(w: Int, h: Int) {
        if (fbo != 0 && fboW == w && fboH == h) return
        deleteFbo()
        val t = IntArray(1)
        GLES20.glGenTextures(1, t, 0)
        fboTex = t[0]
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, fboTex)
        GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, w, h, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        val f = IntArray(1)
        GLES20.glGenFramebuffers(1, f, 0)
        fbo = f[0]
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo)
        GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0, GLES20.GL_TEXTURE_2D, fboTex, 0)
        val status = GLES20.glCheckFramebufferStatus(GLES20.GL_FRAMEBUFFER)
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
        check(status == GLES20.GL_FRAMEBUFFER_COMPLETE) { "framebuffer incomplete (0x" + Integer.toHexString(status) + ")" }
        fboW = w
        fboH = h
    }

    private fun deleteFbo() {
        if (fbo != 0) GLES20.glDeleteFramebuffers(1, intArrayOf(fbo), 0)
        if (fboTex != 0) GLES20.glDeleteTextures(1, intArrayOf(fboTex), 0)
        fbo = 0
        fboTex = 0
        fboW = 0
        fboH = 0
    }

    private fun detachInternal() {
        if (window == EGL14.EGL_NO_SURFACE) return
        runCatching {
            EGL14.eglMakeCurrent(dpy, pbuffer, pbuffer, ctx)
            EGL14.eglDestroySurface(dpy, window)
        }
        window = EGL14.EGL_NO_SURFACE
    }

    private fun teardown() {
        runCatching { detachInternal() }
        runCatching { inputSurface?.release() }
        inputSurface = null
        runCatching { texture?.release() }
        texture = null
        runCatching {
            if (ctx != EGL14.EGL_NO_CONTEXT) {
                EGL14.eglMakeCurrent(dpy, pbuffer, pbuffer, ctx)
                deleteFbo()
                if (oesTex != 0) GLES20.glDeleteTextures(1, intArrayOf(oesTex), 0)
                if (progScale != 0) GLES20.glDeleteProgram(progScale)
                if (progSharpen != 0) GLES20.glDeleteProgram(progSharpen)
            }
        }
        oesTex = 0
        progScale = 0
        progSharpen = 0
        locScale = null
        locSharpen = null
        runCatching {
            if (dpy != EGL14.EGL_NO_DISPLAY) {
                EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                if (pbuffer != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(dpy, pbuffer)
                if (ctx != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(dpy, ctx)
                // eglTerminate is left out on purpose: the display connection is shared with the rest of the process.
            }
        }
        pbuffer = EGL14.EGL_NO_SURFACE
        ctx = EGL14.EGL_NO_CONTEXT
    }

    private fun program(vs: String, fs: String): Int {
        val v = shader(GLES20.GL_VERTEX_SHADER, vs)
        val f = shader(GLES20.GL_FRAGMENT_SHADER, fs)
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, v)
        GLES20.glAttachShader(p, f)
        GLES20.glLinkProgram(p)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        val log = GLES20.glGetProgramInfoLog(p)
        GLES20.glDeleteShader(v)
        GLES20.glDeleteShader(f)
        check(ok[0] == GLES20.GL_TRUE) { "shader link failed: " + log.take(200) }
        return p
    }

    private fun shader(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] != GLES20.GL_TRUE) {
            val log = GLES20.glGetShaderInfoLog(s)
            GLES20.glDeleteShader(s)
            throw IllegalStateException("shader compile failed: " + log.take(200))
        }
        return s
    }

    private companion object {
        /** x, y, u, v for a full-screen triangle strip. */
        val QUAD = floatArrayOf(
            -1f, -1f, 0f, 0f,
            1f, -1f, 1f, 0f,
            -1f, 1f, 0f, 1f,
            1f, 1f, 1f, 1f
        )

        const val VERT = """
attribute vec4 aPos;
attribute vec2 aUv;
uniform mat4 uMat;
varying vec2 vUv;
void main() {
    gl_Position = aPos;
    vUv = (uMat * vec4(aUv, 0.0, 1.0)).xy;
}
"""

        /**
         * Pass 1: Catmull-Rom bicubic upscale from the virtual display's buffer. The classic "5 taps using the
         * bilinear unit" form: the four inner texels are merged into one fetch, the corners are dropped.
         */
        const val FRAG_SCALE = """
#extension GL_OES_EGL_image_external : require
precision highp float;
uniform samplerExternalOES uTex;
uniform vec2 uSrcSize;
varying vec2 vUv;

vec3 tap(vec2 texel) {
    return texture2D(uTex, texel / uSrcSize).rgb;
}

void main() {
    vec2 pos = vUv * uSrcSize;
    vec2 tc = floor(pos - 0.5) + 0.5;
    vec2 f = pos - tc;
    vec2 f2 = f * f;
    vec2 f3 = f2 * f;
    vec2 w0 = f2 - 0.5 * (f3 + f);
    vec2 w1 = 1.5 * f3 - 2.5 * f2 + 1.0;
    vec2 w3 = 0.5 * (f3 - f2);
    vec2 w2 = 1.0 - w0 - w1 - w3;
    vec2 w12 = w1 + w2;
    vec2 p0 = tc - 1.0;
    vec2 p3 = tc + 2.0;
    vec2 p12 = tc + w2 / w12;

    float wA = w12.x * w0.y;
    float wB = w0.x * w12.y;
    float wC = w12.x * w12.y;
    float wD = w3.x * w12.y;
    float wE = w12.x * w3.y;

    vec3 c = tap(vec2(p12.x, p0.y)) * wA
           + tap(vec2(p0.x, p12.y)) * wB
           + tap(vec2(p12.x, p12.y)) * wC
           + tap(vec2(p3.x, p12.y)) * wD
           + tap(vec2(p12.x, p3.y)) * wE;
    gl_FragColor = vec4(clamp(c / (wA + wB + wC + wD + wE), 0.0, 1.0), 1.0);
}
"""

        /**
         * Pass 2: contrast-adaptive sharpening at screen resolution. The weight of the four neighbours shrinks where
         * local contrast is already high, so there are no halos and no noise boost in flat areas. [uSharp] 0..1.
         */
        const val FRAG_SHARPEN = """
precision highp float;
uniform sampler2D uTex;
uniform vec2 uTexel;
uniform float uSharp;
varying vec2 vUv;

void main() {
    vec3 b = texture2D(uTex, vUv + vec2(0.0, -uTexel.y)).rgb;
    vec3 d = texture2D(uTex, vUv + vec2(-uTexel.x, 0.0)).rgb;
    vec3 e = texture2D(uTex, vUv).rgb;
    vec3 f = texture2D(uTex, vUv + vec2(uTexel.x, 0.0)).rgb;
    vec3 h = texture2D(uTex, vUv + vec2(0.0, uTexel.y)).rgb;

    vec3 mn = min(min(min(d, e), min(f, b)), h);
    vec3 mx = max(max(max(d, e), max(f, b)), h);
    vec3 amp = clamp(min(mn, 1.0 - mx) / max(mx, vec3(0.0001)), 0.0, 1.0);
    amp = sqrt(amp);

    float peak = -1.0 / mix(8.0, 5.0, uSharp);
    vec3 w = amp * peak;
    vec3 rcpW = 1.0 / (1.0 + 4.0 * w);
    vec3 col = (b * w + d * w + f * w + h * w + e) * rcpW;
    gl_FragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}
"""
    }
}
