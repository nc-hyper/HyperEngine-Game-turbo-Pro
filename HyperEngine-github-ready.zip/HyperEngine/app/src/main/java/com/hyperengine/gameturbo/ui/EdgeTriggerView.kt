package com.hyperengine.gameturbo.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.os.Build
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import com.hyperengine.gameturbo.data.EdgeSide
import com.hyperengine.gameturbo.data.HandleConfig
import kotlin.math.abs

/**
 * The slim edge handle that opens the HUD.
 *
 * It is drawn in a window slightly thicker than the visible bar so it is easy to hit. Opening gestures: tap, or
 * drag inward. Long-press and drag slides the handle along the screen edge (the new position is saved by the
 * controller through [onReposition]). A small chevron on the bar points the way in, so in landscape the handle
 * reads as a console edge tab rather than a stray line. Position, size, colour and idle opacity come from
 * HandleConfig, and the system back-gesture zone under it is excluded (API 29+) so the swipe is not stolen.
 */
class EdgeTriggerView(
    context: Context,
    private val onOpen: () -> Unit
) : View(context) {

    /**
     * Called while the handle is being dragged along the edge. [rawX] / [rawY] are the finger position in screen
     * pixels; [finished] is true on release.
     */
    var onReposition: ((rawX: Float, rawY: Float, finished: Boolean) -> Unit)? = null

    private var cfg = HandleConfig()
    private var animations = true

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val chevronPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val chevron = Path()
    private val bar = RectF()
    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var fired = false
    private var moving = false
    private val idleRunnable = Runnable { fadeToIdle() }
    private val longPress = Runnable {
        moving = true
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        invalidate()
    }

    fun apply(config: HandleConfig, animationsEnabled: Boolean) {
        cfg = config
        animations = animationsEnabled
        invalidate()
        wake()
    }

    /** Full opacity now, back to the configured idle opacity after 2.5 seconds. */
    fun wake() {
        removeCallbacks(idleRunnable)
        animate().cancel()
        alpha = 1f
        postDelayed(idleRunnable, 2500L)
    }

    private fun fadeToIdle() {
        if (moving) return
        val target = cfg.autoHideAlphaPct.coerceIn(10, 100) / 100f
        if (animations) animate().alpha(target).setDuration(300L).start() else alpha = target
    }

    private val hl = RectF()

    override fun onDraw(c: Canvas) {
        val thick = Ui.dp(context, cfg.widthDp.coerceIn(4, 16)).toFloat()
        val w = width.toFloat()
        val h = height.toFloat()
        when (cfg.side) {
            EdgeSide.LEFT -> bar.set(0f, 0f, thick, h)
            EdgeSide.RIGHT -> bar.set(w - thick, 0f, w, h)
            EdgeSide.TOP -> bar.set(0f, 0f, w, thick)
        }
        val color = HudThemes.parse(cfg.colorHex, 0xFF00E5FF.toInt())
        paint.color = if (moving) HudThemes.withAlpha(color, 255) else color
        val radius = thick / 2f
        c.drawRoundRect(bar, radius, radius, paint)
        paint.color = HudThemes.withAlpha(0xFFFFFFFF.toInt(), 70)
        val inset = thick * 0.28f
        hl.set(bar.left + inset, bar.top + inset, bar.right - inset, bar.bottom - inset)
        c.drawRoundRect(hl, radius, radius, paint)

        // chevron next to the bar, pointing inward
        val d = resources.displayMetrics.density
        val s = 5f * d
        chevronPaint.color = color
        chevronPaint.strokeWidth = 2f * d
        chevron.reset()
        when (cfg.side) {
            EdgeSide.LEFT -> {
                val cx = thick + 3f * d
                val cy = h / 2f
                chevron.moveTo(cx, cy - s); chevron.lineTo(cx + s, cy); chevron.lineTo(cx, cy + s)
            }
            EdgeSide.RIGHT -> {
                val cx = w - thick - 3f * d
                val cy = h / 2f
                chevron.moveTo(cx, cy - s); chevron.lineTo(cx - s, cy); chevron.lineTo(cx, cy + s)
            }
            EdgeSide.TOP -> {
                val cx = w / 2f
                val cy = thick + 3f * d
                chevron.moveTo(cx - s, cy); chevron.lineTo(cx, cy + s); chevron.lineTo(cx + s, cy)
            }
        }
        if (thick + 4f * d + s <= (if (cfg.side == EdgeSide.TOP) h else w)) c.drawPath(chevron, chevronPaint)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        super.onLayout(changed, l, t, r, b)
        if (Build.VERSION.SDK_INT >= 29 && cfg.side != EdgeSide.TOP) {
            runCatching { systemGestureExclusionRects = listOf(Rect(0, 0, r - l, b - t)) }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX
                downY = e.rawY
                fired = false
                moving = false
                wake()
                postDelayed(longPress, ViewConfiguration.getLongPressTimeout().toLong())
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (moving) {
                    onReposition?.invoke(e.rawX, e.rawY, false)
                    return true
                }
                val inward = when (cfg.side) {
                    EdgeSide.LEFT -> e.rawX - downX
                    EdgeSide.RIGHT -> downX - e.rawX
                    EdgeSide.TOP -> e.rawY - downY
                }
                if (abs(e.rawX - downX) + abs(e.rawY - downY) > slop) removeCallbacks(longPress)
                if (!fired && inward > slop * 3) {
                    removeCallbacks(longPress)
                    fired = true
                    performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    onOpen()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longPress)
                if (moving) {
                    moving = false
                    onReposition?.invoke(e.rawX, e.rawY, true)
                    invalidate()
                    wake()
                    return true
                }
                val moved = abs(e.rawX - downX) + abs(e.rawY - downY)
                if (!fired && moved < slop * 2) {
                    fired = true
                    performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    onOpen()
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longPress)
                moving = false
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(idleRunnable)
        removeCallbacks(longPress)
        animate().cancel()
        super.onDetachedFromWindow()
    }
}
