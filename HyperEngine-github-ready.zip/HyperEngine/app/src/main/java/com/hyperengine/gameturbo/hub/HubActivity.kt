package com.hyperengine.gameturbo.hub

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import com.hyperengine.gameturbo.DiagnosticsActivity
import com.hyperengine.gameturbo.HyperApp
import com.hyperengine.gameturbo.MainActivity
import com.hyperengine.gameturbo.core.AntutuBenchmarkBooster
import com.hyperengine.gameturbo.core.ConsoleWindow
import com.hyperengine.gameturbo.service.GameDetectorService
import com.hyperengine.gameturbo.ui.HudTheme
import com.hyperengine.gameturbo.ui.HudThemes
import com.hyperengine.gameturbo.ui.Ui
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * Game Space: the launcher screen.
 *
 *  header          title, game-watcher switch, menu
 *  setup banner    real execution mode (Shizuku / root / ADB grant / standard) + permission checklist
 *  status strip    engine state, restore button, RAM / temperature / battery
 *  pages           tabs from [HubPageRegistry] (Games first; Part 9 adds "ROM Lab")
 *  tab bar         along the bottom, shown once more than one page is registered
 *
 * Portrait only (see the manifest).
 *
 * The whole screen is built in code from the same [HudTheme] as the in-game HUD. When the theme
 * changes (colours, theme id, opacity, corner radius) the activity recreates itself, so every view
 * picks the new look up.
 */
class HubActivity : Activity() {

    private val scope = MainScope()
    private val app get() = HyperApp.instance

    private lateinit var theme: HudTheme
    private lateinit var host: HubHost
    private lateinit var pages: List<HubPage>
    private lateinit var pageViews: List<View>
    private lateinit var tabs: List<TextView>
    private lateinit var tabBar: LinearLayout
    private lateinit var banner: SetupBanner
    private lateinit var strip: StatusStrip
    private lateinit var watcherSwitch: Switch

    private var current = 0
    private var liveJob: Job? = null
    private var autoStarted = false
    private var syncingSwitch = false

    // =========================================================================================
    // Lifecycle
    // =========================================================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ConsoleWindow.apply(this)
        ConsoleWindow.lockPanel(this) // Part 9: the lobby itself runs at the panel's top refresh rate
        val repo = app.repository
        theme = HudThemes.resolve(repo.global.value)
        host = HubHost(this, scope, theme)

        window.statusBarColor = theme.panelTop or OPAQUE
        window.navigationBarColor = theme.panelBottom or OPAQUE
        window.setBackgroundDrawable(HubStyle.screenBackground(theme))

        // Portrait layout: header, setup banner and status strip on top, the page in the middle,
        // tab bar along the bottom where the thumb reaches it.
        val root = Ui.vbox(this)
        root.background = HubStyle.screenBackground(theme)
        root.setPadding(host.dp(12), host.dp(8), host.dp(12), host.dp(8))

        val main = Ui.vbox(this)
        main.addView(buildHeader(), Ui.lp(Ui.MATCH, Ui.WRAP))
        banner = SetupBanner(host)
        main.addView(banner, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(6), 0, 0))
        strip = StatusStrip(host)
        main.addView(strip, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(6), 0, 0))

        val content = FrameLayout(this)
        main.addView(content, Ui.lp(Ui.MATCH, 0, 1f, 0, host.dp(6), 0, 0))

        pages = HubPageRegistry.create(host)
        pageViews = pages.map { it.createView() }
        pageViews.forEach {
            it.visibility = View.GONE
            content.addView(it, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        }

        tabBar = buildTabBar()
        root.addView(main, Ui.lp(Ui.MATCH, 0, 1f))
        root.addView(tabBar, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(8), 0, 0))

        host.showPage = { id ->
            val i = pages.indexOfFirst { it.id == id }
            if (i >= 0) selectPage(i)
        }

        if (savedInstanceState != null) {
            pages.forEach { it.restoreState(savedInstanceState) }
            current = savedInstanceState.getInt(KEY_PAGE, 0).coerceIn(0, pages.size - 1)
        }
        showOnly(current)
        setContentView(root)

        // a theme change anywhere (the Themes tab, a backup restore) rebuilds this screen
        scope.launch {
            repo.global.collect { g -> if (HudThemes.resolve(g) != theme) recreate() }
        }
    }

    override fun onResume() {
        super.onResume()
        app.bridge.refresh()
        app.telemetry.acquire("hub")
        startLive()
        banner.refresh()
        pages.getOrNull(current)?.onShow()

        if (!autoStarted) {
            autoStarted = true
            if (app.repository.global.value.watcherAutoStart && !GameDetectorService.state.value.running) {
                GameDetectorService.start(this)
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) ConsoleWindow.apply(this)
    }

    override fun onPause() {
        pages.getOrNull(current)?.onHide()
        liveJob?.cancel()
        liveJob = null
        app.telemetry.release("hub")
        super.onPause()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(KEY_PAGE, current)
        pages.forEach { it.saveState(outState) }
    }

    override fun onDestroy() {
        ConsoleWindow.unlockPanel(this)
        host.destroyHooks.forEach { runCatching { it() } }
        pages.forEach { it.onDestroy() }
        scope.cancel()
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        banner.refresh()
        pages.forEach { it.onPermissionsChanged() }
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (current != 0) selectPage(0) else super.onBackPressed()
    }

    // =========================================================================================
    // Live data
    // =========================================================================================

    private fun startLive() {
        liveJob?.cancel()
        liveJob = scope.launch {
            launch { app.bridge.state.collect { banner.render(it) } }
            launch { app.engine.status.collect { strip.update(it) } }
            launch {
                // sustained mode caps peak clocks: leave it off while a benchmark boost is running
                AntutuBenchmarkBooster.from(this@HubActivity).state.map { it.active }.distinctUntilChanged().collect { on ->
                    ConsoleWindow.lockPanel(this@HubActivity, sustained = !on)
                }
            }
            launch { app.telemetry.sample.collect { strip.update(it) } }
            launch {
                GameDetectorService.state.collect { st ->
                    strip.update(st)
                    syncingSwitch = true
                    watcherSwitch.isChecked = st.running
                    syncingSwitch = false
                }
            }
        }
    }

    // =========================================================================================
    // Header, tabs, menu
    // =========================================================================================

    private fun buildHeader(): View {
        val row = Ui.hbox(this)
        row.gravity = Gravity.CENTER_VERTICAL

        val col = Ui.vbox(this)
        col.addView(Ui.label(this, "HYPERENGINE", 18f, theme.accent, true).apply { letterSpacing = 0.14f })
        col.addView(Ui.label(this, "Game Space", 11f, theme.textSecondary), Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, host.dp(2), 0, 0))
        row.addView(col, Ui.lp(0, Ui.WRAP, 1f))

        row.addView(Ui.label(this, "Watcher", 10f, theme.textSecondary), Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, 0, host.dp(6), 0))
        watcherSwitch = Switch(this).apply {
            val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
            thumbTintList = ColorStateList(states, intArrayOf(theme.accent, theme.textSecondary))
            trackTintList = ColorStateList(
                states,
                intArrayOf(HudThemes.withAlpha(theme.accent, 0x80), HudThemes.withAlpha(theme.textSecondary, 0x55))
            )
            isChecked = GameDetectorService.state.value.running
            setOnCheckedChangeListener { _, on ->
                if (syncingSwitch) return@setOnCheckedChangeListener
                app.repository.updateGlobal { it.copy(watcherAutoStart = on) }
                if (on) GameDetectorService.start(this@HubActivity) else GameDetectorService.stop(this@HubActivity)
            }
        }
        row.addView(watcherSwitch, Ui.lp(Ui.WRAP, Ui.WRAP))

        val menu = Ui.label(this, "Menu", 12f, theme.textPrimary, true).apply {
            gravity = Gravity.CENTER
            setPadding(host.dp(14), host.dp(8), host.dp(6), host.dp(8))
            setOnClickListener { showMenu() }
        }
        row.addView(menu, Ui.lp(Ui.WRAP, Ui.WRAP))
        return row
    }

    private fun buildTabBar(): LinearLayout {
        val bar = Ui.hbox(this)
        bar.setPadding(host.dp(4), host.dp(4), host.dp(4), host.dp(4))
        bar.background = Ui.rounded(theme.tile, HubStyle.radius(this, theme, 14), theme.stroke, host.dp(1))
        tabs = pages.mapIndexed { i, p ->
            TextView(this).apply {
                text = if (p.glyph.isBlank()) p.title else p.glyph + "\n" + p.title
                textSize = 11f
                gravity = Gravity.CENTER
                setPadding(host.dp(4), host.dp(8), host.dp(4), host.dp(8))
                setOnClickListener { selectPage(i) }
            }
        }
        tabs.forEach { bar.addView(it, Ui.lp(0, Ui.WRAP, 1f)) }
        bar.visibility = if (pages.size < 2) View.GONE else View.VISIBLE
        return bar
    }

    private fun showOnly(index: Int) {
        pageViews.forEachIndexed { i, v -> v.visibility = if (i == index) View.VISIBLE else View.GONE }
        tabs.forEachIndexed { i, t ->
            val on = i == index
            t.setTextColor(if (on) theme.accent else theme.textSecondary)
            t.typeface = if (on) android.graphics.Typeface.DEFAULT_BOLD else android.graphics.Typeface.DEFAULT
            t.background = if (on) Ui.rounded(HudThemes.withAlpha(theme.accent, 0x26), Ui.tileRadius(this, theme)) else null
        }
    }

    private fun selectPage(index: Int) {
        if (index == current || index !in pages.indices) return
        pages.getOrNull(current)?.onHide()
        current = index
        showOnly(index)
        pages[index].onShow()
    }

    private fun showMenu() {
        val d = HubDialog(host, "Game Space menu")
        d.row("Restore everything now", "Undo every change the engine made to your phone's settings") {
            scope.launch {
                val rep = app.engine.restoreAll("hub menu")
                host.toast(
                    if (rep.complete) "Phone settings restored"
                    else "Restore incomplete: ${rep.steps.firstOrNull { !it.ok }?.detail?.take(80) ?: "see developer console"}",
                    !rep.complete
                )
            }
        }
        d.row("Copy backup of all settings", "Profiles, themes, freeze list and layout as JSON on the clipboard") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("HyperEngine backup", app.repository.exportJson()))
            host.toast("Backup copied. Paste it somewhere safe.")
        }
        d.row("Restore backup from clipboard", "Replaces every profile and setting with the copied backup") {
            HubDialog.confirm(host, "Restore backup?", "This replaces all current profiles and settings with the backup on your clipboard.", "Restore") {
                restoreFromClipboard()
            }
        }
        d.row("Permissions and engine diagnostics", "Every permission, the Shizuku binder and the input injector, with one-tap fixes") {
            startActivity(Intent(this, DiagnosticsActivity::class.java))
        }
        d.row("Developer console", "Raw test buttons for every engine function") {
            startActivity(Intent(this, MainActivity::class.java))
        }
        d.button("Close")
        d.show()
    }

    private fun restoreFromClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
        if (text.isBlank()) {
            host.toast("The clipboard is empty", true)
            return
        }
        val n = app.repository.importJson(text)
        if (n < 0) {
            host.toast("That is not a valid HyperEngine backup", true)
        } else {
            host.toast("Backup restored: $n game profile(s)")
            recreate()
        }
    }

    companion object {
        private const val KEY_PAGE = "hub.page"
        private const val OPAQUE = 0xFF000000.toInt()
    }
}
