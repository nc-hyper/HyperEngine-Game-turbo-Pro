package com.hyperengine.gameturbo.hub

import android.app.Dialog
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import com.hyperengine.gameturbo.core.GameModeLevel
import com.hyperengine.gameturbo.data.DnsPreset
import com.hyperengine.gameturbo.data.GameProfile
import com.hyperengine.gameturbo.data.PrecompileMode
import com.hyperengine.gameturbo.ui.HudThemes
import com.hyperengine.gameturbo.ui.Ui
import kotlinx.coroutines.launch

/**
 * Full-screen "Rules and automation" editor for one game.
 *
 * Every control writes straight into the game's saved profile, which is exactly what the optimization
 * engine reads when the game starts (Boost & Play, or the game watcher noticing the launch). Nothing here
 * is decoration: each switch and chip maps to a field of [GameProfile] that OptimizationEngine.applyProfile uses.
 *
 * Turning an option OFF takes effect from the next launch. "Apply now" re-applies the profile to a game that
 * is running at this moment.
 */
class RulesEditor(private val host: HubHost) {

    private val ctx = host.activity
    private val theme = host.theme
    private val repo = host.repo

    private var dialog: Dialog? = null
    private var pkg = ""
    private var label = ""
    private lateinit var body: LinearLayout

    init {
        host.destroyHooks.add { dismiss() }
    }

    fun dismiss() {
        runCatching { dialog?.dismiss() }
        dialog = null
    }

    // ── open ──

    fun open(packageName: String) {
        if (ctx.isFinishing) return
        dismiss()
        pkg = packageName
        label = resolveLabel(packageName)
        repo.profile(packageName) ?: repo.getOrCreate(packageName, label)

        val d = Dialog(ctx, android.R.style.Theme_Material_NoActionBar)
        d.window?.apply {
            setBackgroundDrawable(HubStyle.screenBackground(theme))
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            statusBarColor = theme.panelTop or OPAQUE
            navigationBarColor = theme.panelBottom or OPAQUE
        }

        val root = Ui.vbox(ctx)
        root.setPadding(host.dp(12), host.dp(10), host.dp(12), host.dp(8))

        // header
        val head = Ui.hbox(ctx)
        head.gravity = Gravity.CENTER_VERTICAL
        val icon = ImageView(ctx)
        GameIcons.load(ctx, packageName, label, host.dp(42), icon, HudThemes.withAlpha(theme.accent, 0x99))
        head.addView(icon, Ui.lp(host.dp(42), host.dp(42)))
        val col = Ui.vbox(ctx)
        col.addView(Ui.label(ctx, label, 16f, theme.textPrimary, true).apply { maxLines = 1 })
        col.addView(Ui.label(ctx, "Rules and automation", 11f, theme.accent, true).apply { setPadding(0, host.dp(2), 0, 0) })
        head.addView(col, Ui.lp(0, Ui.WRAP, 1f, host.dp(10), 0, host.dp(8), 0))
        head.addView(Ui.button(ctx, theme, "Done", true) { d.dismiss() })
        root.addView(head, Ui.lp(Ui.MATCH, Ui.WRAP))

        // body
        val scroll = ScrollView(ctx)
        body = Ui.vbox(ctx)
        body.setPadding(0, 0, 0, host.dp(12))
        scroll.addView(body, android.widget.FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        root.addView(scroll, Ui.lp(Ui.MATCH, 0, 1f, 0, host.dp(4), 0, 0))

        d.setContentView(root)
        d.setOnDismissListener { if (dialog === d) dialog = null }
        dialog = d
        buildBody()
        runCatching { d.show() }
    }

    @Suppress("DEPRECATION")
    private fun resolveLabel(p: String): String = runCatching {
        ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(p, 0)).toString()
    }.getOrNull().orEmpty().ifBlank { repo.profile(p)?.label.orEmpty() }.ifBlank { p }

    private fun p(): GameProfile = repo.profile(pkg) ?: repo.getOrCreate(pkg, label)

    private fun upd(block: (GameProfile) -> GameProfile) = repo.update(pkg, block)

    // ── content ──

    private fun buildBody() {
        body.removeAllViews()
        val p = p()
        val g = repo.global.value

        // ---- profile ----
        body.addRow(
            host,
            Forms.switchRow(
                host, "Profile is on",
                "Off = the game watcher and Boost & Play leave this game alone.",
                p.enabled
            ) { on -> upd { it.copy(enabled = on) } },
            4
        )

        // ---- performance ----
        val perf = section("Performance")
        val modeValues = listOf(GameModeLevel.BATTERY, GameModeLevel.STANDARD, GameModeLevel.PERFORMANCE)
        val modeChips = Forms.choice(
            host, perf, "Game mode", listOf("Battery saver", "Balanced", "Wild Boost"), modeValues, p.gameMode, 3
        ) { v -> upd { it.copy(gameMode = v) } }

        val ratios = listOf<Float?>(null, 0.90f, 0.85f, 0.80f, 0.75f, 0.70f, 0.60f, 0.50f)
        Forms.choice(
            host, perf, "Resolution scale", listOf("Off", "90%", "85%", "80%", "75%", "70%", "60%", "50%"),
            ratios, p.downscale, 4
        ) { v ->
            upd { it.copy(downscale = v) }
            promoteMode(modeChips)
        }
        val fpsValues = listOf(0, 30, 45, 60, 90, 120, 144)
        Forms.choice(host, perf, "FPS cap", listOf("Off", "30", "45", "60", "90", "120", "144"), fpsValues, p.targetFps, 4) { v ->
            upd { it.copy(targetFps = v) }
            promoteMode(modeChips)
        }
        Forms.choice(
            host, perf, "FPS cap method", listOf("Game setting + display lock", "Game setting only"),
            listOf(true, false), p.fpsCapViaDisplay, 1
        ) { v -> upd { it.copy(fpsCapViaDisplay = v) } }
        perf.addView(
            Forms.note(
                host,
                "Resolution and FPS cap use the system's game manager, which only accepts them in Wild Boost, so Balanced switches to Wild Boost " +
                    "when you set either one. They need Shizuku or root. Display lock also pins the panel refresh rate so the cap holds in every game."
            )
        )

        // refresh rate
        val rates = host.engine.supportedRefreshRates()
        val hzValues = listOf(0) + rates + listOf(-1)
        val hzLabels = listOf("Untouched") + rates.map { "$it Hz" } + listOf("Max")
        Forms.choice(host, perf, "Refresh rate lock", hzLabels, hzValues, p.refreshHz, 3) { v ->
            upd { it.copy(refreshHz = v) }
        }
        perf.addView(
            Forms.note(
                host,
                if (rates.isEmpty()) "This phone did not report its supported refresh rates."
                else "This panel supports ${rates.joinToString(", ") { "$it Hz" }}. The previous rate comes back when the game session ends."
            )
        )

        // ---- zero-stutter ----
        val stutter = section("Zero-Stutter Boost")
        Forms.choice(
            host, stutter, "Compile the game before launch", listOf("Off", "Fast optimize", "Full AOT"),
            listOf(PrecompileMode.NONE, PrecompileMode.FAST, PrecompileMode.FULL), p.precompile, 3
        ) { v -> upd { it.copy(precompile = v) } }
        stutter.addView(
            Forms.note(
                host,
                "Runs cmd package compile (speed-profile or speed) from Boost & Play, before the game opens. Never while it runs. Full AOT is slower and uses more storage."
            )
        )
        stutter.addRow(
            host,
            Forms.switchRow(host, "Trim system caches before launch", "pm trim-caches before Boost & Play opens the game. Needs Shizuku or root.", p.trimCachesOnLaunch) { on ->
                upd { it.copy(trimCachesOnLaunch = on) }
            },
            10
        )

        // ---- background ----
        val bg = section("Background control")
        val frozenCount = g.freezeList.size
        bg.addRow(
            host,
            Forms.switchRow(
                host, "Freeze background apps on launch",
                if (frozenCount == 0) "The Freeze List is empty. Add apps on the Freeze List tab."
                else "$frozenCount app(s) on the Freeze List are stopped while this game runs.",
                p.freezeOnLaunch
            ) { on -> upd { it.copy(freezeOnLaunch = on) } },
            0
        )
        bg.addRow(
            host,
            Ui.button(ctx, theme, "Edit the Freeze List", false) {
                dismiss()
                host.showPage("freeze")
            },
            6
        )
        bg.addRow(
            host,
            Forms.switchRow(host, "Block background data", "Turns Data Saver on during the game so other apps cannot download. Turned back off afterwards.", p.blockBackgroundData) { on ->
                upd { it.copy(blockBackgroundData = on) }
            },
            6
        )
        bg.addRow(
            host,
            Forms.switchRow(host, "Pause account sync", "Master sync is paused during the game and put back afterwards.", p.pauseSync) { on ->
                upd { it.copy(pauseSync = on) }
            },
            6
        )

        // ---- network ----
        val net = section("Network")
        val presets = DnsPreset.values().toList()
        Forms.choice(host, net, "Private DNS", presets.map { it.label }, presets, p.dns, 2) { v -> upd { it.copy(dns = v) } }
        net.addView(Forms.note(host, "Switches Private DNS for the game and restores your original DNS afterwards. Needs Shizuku, root or the one-time WRITE_SECURE_SETTINGS grant."))
        if (g.pingTargets.isNotEmpty()) {
            val idx = p.pingTargetIndex.coerceIn(0, g.pingTargets.size - 1)
            Forms.choice(
                host, net, "Ping server for the live ping readout",
                g.pingTargets.map { it.name.ifBlank { it.host } }, g.pingTargets.indices.toList(), idx, 1
            ) { v -> upd { it.copy(pingTargetIndex = v) } }
        }

        // ---- compositor and input ----
        val input = section("Compositor and touch")
        input.addRow(
            host,
            Forms.switchRow(host, "Zero-animation mode", "Window, transition and animator scales go to 0 during the game, then back to your values.", p.zeroAnimation) { on ->
                upd { it.copy(zeroAnimation = on) }
            },
            0
        )
        input.addView(optionalSlider("Pointer speed", "Mouse and trackpad pointers only", -7, 7, "", p.pointerSpeed, 0) { v ->
            upd { it.copy(pointerSpeed = v) }
        }, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(6), 0, 0))
        input.addView(optionalSlider("Touch long-press delay", "Time before a held touch counts as a long press", 100, 1500, " ms", p.longPressMs, 400) { v ->
            upd { it.copy(longPressMs = v) }
        }, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(6), 0, 0))
        val hasSens = host.engine.hasTouchSensitivityKey()
        input.addRow(
            host,
            Forms.switchRow(
                host, "High touch sensitivity",
                if (hasSens) "Uses this phone's own high-sensitivity touch setting." else "This phone has no touch-sensitivity setting, so this option is unavailable.",
                p.touchSensitivity && hasSens, enabled = hasSens
            ) { on -> upd { it.copy(touchSensitivity = on) } },
            6
        )

        // ---- HUD tools ----
        val hud = section("In-game tools for this game")
        hud.addView(
            Forms.note(host, "Choose which overlays start with this game. Fine-tune each one from the sidebar while you play; its settings are saved here per game.")
        )
        hud.addRow(host, Forms.switchRow(host, "Crosshair", "Custom reticle in the screen centre", p.crosshair.enabled) { on ->
            upd { it.copy(crosshair = it.crosshair.copy(enabled = on)) }
        }, 4)
        hud.addRow(host, Forms.switchRow(host, "FPS pill", "Floating FPS, ping and temperature readout", p.pill.enabled) { on ->
            upd { it.copy(pill = it.pill.copy(enabled = on)) }
        })
        hud.addRow(host, Forms.switchRow(host, "Visual filter", "Shadow boost, colour balance and extra dimmer", p.filter.enabled) { on ->
            upd { it.copy(filter = it.filter.copy(enabled = on)) }
        })
        hud.addRow(host, Forms.switchRow(host, "Edge guard", "Touch-blocking strips along the screen edges", p.edgeGuard.enabled) { on ->
            upd { it.copy(edgeGuard = it.edgeGuard.copy(enabled = on)) }
        })
        hud.addRow(host, Forms.switchRow(host, "Auto tapper", "Floating tap node that taps for you", p.macro.enabled) { on ->
            upd { it.copy(macro = it.macro.copy(enabled = on)) }
        })

        // ---- automation ----
        val auto = section("Automatic restore")
        val delayValues = listOf<Int?>(null, 0, 5, 15, 30, 60, 120, 300)
        val delayLabels = listOf("Global (${g.restoreDelaySec} s)", "Instant", "5 s", "15 s", "30 s", "60 s", "2 min", "5 min")
        Forms.choice(host, auto, "Restore your phone settings after the game has been away for", delayLabels, delayValues, p.autoRestoreDelaySec, 3) { v ->
            upd { it.copy(autoRestoreDelaySec = v) }
        }
        auto.addView(
            Forms.note(
                host,
                "When the game closes or stays in the background this long, refresh rate, animation scales, brightness, DNS, background data and frozen apps all go back to how they were."
            )
        )

        // ---- actions ----
        val tools = section("Profile tools")
        if (host.engine.status.value.activeGame == pkg) {
            tools.addRow(host, Ui.button(ctx, theme, "Apply to the running game now", true) { applyNow() }, 0)
        }
        tools.addRow(host, Ui.button(ctx, theme, "Copy rules from another game", false) { pickSource() }, 6)
        tools.addRow(host, Ui.button(ctx, theme, "Open Android's app info", false) { HubIntents.appDetails(host, pkg) }, 6)
        tools.addRow(
            host,
            Ui.button(ctx, theme, "Reset this game to defaults", false) {
                HubDialog.confirm(
                    host, "Reset $label?",
                    "All per-game tuning, crosshair, macro, timer and HUD settings for this game go back to their defaults.",
                    "Reset"
                ) {
                    repo.upsert(GameProfile(packageName = pkg, label = label))
                    buildBody()
                    host.toast("Profile reset")
                }
            },
            6
        )
    }

    private fun section(title: String): LinearLayout {
        body.addView(Ui.section(ctx, theme, title), Ui.lp(Ui.MATCH, Ui.WRAP))
        val card = Forms.card(host)
        body.addView(card, Ui.lp(Ui.MATCH, Ui.WRAP))
        return card
    }

    /** Resolution scale and FPS cap only work in Wild Boost: move Balanced up and refresh the chip. */
    private fun promoteMode(modeChips: com.hyperengine.gameturbo.ui.ChipGroup) {
        val p = p()
        if (p.gameMode == GameModeLevel.STANDARD && (p.downscale != null || p.targetFps > 0)) {
            upd { it.copy(gameMode = GameModeLevel.PERFORMANCE) }
            modeChips.select(2)
            host.toast("Switched to Wild Boost, which resolution and FPS cap require")
        }
    }

    /**
     * A switch that decides whether a value is used at all (null = leave the phone's setting alone),
     * with a slider that appears while it is on.
     */
    private fun optionalSlider(
        title: String,
        sub: String,
        min: Int,
        max: Int,
        unit: String,
        current: Int?,
        fallback: Int,
        onChange: (Int?) -> Unit
    ): View {
        val box = Ui.vbox(ctx)
        val sliderHolder = Ui.vbox(ctx)
        sliderHolder.setPadding(host.dp(4), host.dp(2), host.dp(4), 0)
        var value = (current ?: fallback).coerceIn(min, max)

        fun showSlider(on: Boolean) {
            sliderHolder.removeAllViews()
            if (!on) return
            sliderHolder.addView(
                Ui.labeledSlider(ctx, theme, title, unit, min, max, value) { v ->
                    value = v
                    onChange(v)
                }
            )
        }

        box.addView(
            Forms.switchRow(host, title, sub, current != null) { on ->
                showSlider(on)
                onChange(if (on) value else null)
            }
        )
        box.addView(sliderHolder, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(4), 0, 0))
        showSlider(current != null)
        return box
    }

    // ── actions ──

    private fun applyNow() {
        host.scope.launch {
            val rep = host.engine.applyProfile(p())
            val bad = rep.steps.firstOrNull { !it.ok }
            host.toast(
                if (bad == null) "Profile applied to ${rep.game}" else "${rep.failures} step(s) failed: ${bad.step}, ${bad.detail.take(70)}",
                bad != null
            )
        }
    }

    private fun pickSource() {
        val others = repo.profiles.value.values.filter { it.packageName != pkg }
            .sortedBy { it.label.ifBlank { it.packageName }.lowercase() }
        if (others.isEmpty()) {
            host.toast("No other game has a profile yet")
            return
        }
        val d = HubDialog(host, "Copy rules from")
        d.text("Copies every setting of the chosen game onto $label, including HUD tool settings.", theme.textSecondary, 11f)
        for (src in others) {
            d.row(src.label.ifBlank { src.packageName }, GameText.summary(src)) {
                upd { src.copy(packageName = pkg, label = label) }
                buildBody()
                host.toast("Rules copied from ${src.label.ifBlank { src.packageName }}")
            }
        }
        d.button("Cancel")
        d.show()
    }

    private companion object {
        const val OPAQUE = 0xFF000000.toInt()
    }
}
