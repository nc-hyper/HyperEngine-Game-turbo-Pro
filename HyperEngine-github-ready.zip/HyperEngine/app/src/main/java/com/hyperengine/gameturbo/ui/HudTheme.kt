package com.hyperengine.gameturbo.ui

import android.graphics.Color
import com.hyperengine.gameturbo.data.GlobalSettings
import com.hyperengine.gameturbo.data.ThemeId

private fun withAlphaOf(color: Int, alpha: Int): Int = (color and 0x00FFFFFF) or (alpha.coerceIn(0, 255) shl 24)

enum class PanelStyle { GLASS, CYBER_ANGULAR, MECHA, FLAT }

enum class GaugeStyle { RING, SEGMENTS, HEX }

/** Fully resolved look of the HUD. Built from GlobalSettings, so every slider and picker feeds into it. */
data class HudTheme(
    val id: ThemeId,
    val name: String,
    val style: PanelStyle,
    val gauge: GaugeStyle,
    val panelTop: Int,
    val panelBottom: Int,
    val textPrimary: Int,
    val textSecondary: Int,
    val accent: Int,        // Balanced / primary
    val accent2: Int,       // Wild Boost / secondary
    val hot: Int,
    val good: Int,
    val warn: Int,
    val stroke: Int,
    val tile: Int,
    val animations: Boolean,
    val blur: Boolean,
    val opacityPct: Int,
    val cornerDp: Int,
    // Design tokens added in the UI redesign (part 1)
    val surface: Int = tile,                         // card / group background
    val divider: Int = withAlphaOf(textPrimary, 22), // hairline between rows
    val knobOff: Int = withAlphaOf(textPrimary, 64)  // switch / slider track when off
) {
    val panelAlpha: Int get() = opacityPct.coerceIn(20, 100) * 255 / 100
}

object HudThemes {

    val LABELS = listOf("HyperOS Game Turbo", "Realme GT Cyber Matrix", "RedMagic Cyber Console", "AMOLED Pitch Black")

    fun parse(hex: String, fallback: Int): Int = try {
        Color.parseColor(hex)
    } catch (_: Throwable) {
        fallback
    }

    fun withAlpha(color: Int, alpha: Int): Int = (color and 0x00FFFFFF) or (alpha.coerceIn(0, 255) shl 24)

    fun blend(a: Int, b: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        fun ch(x: Int, y: Int) = (x + (y - x) * k).toInt()
        return Color.argb(
            ch(Color.alpha(a), Color.alpha(b)), ch(Color.red(a), Color.red(b)),
            ch(Color.green(a), Color.green(b)), ch(Color.blue(a), Color.blue(b))
        )
    }

    /** Readable text colour on top of an accent fill. */
    fun onAccent(accent: Int): Int {
        val lum = 0.299f * Color.red(accent) + 0.587f * Color.green(accent) + 0.114f * Color.blue(accent)
        return if (lum > 150f) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
    }

    fun resolve(g: GlobalSettings): HudTheme {
        val s = g.sidebar
        val base = when (g.theme) {
            ThemeId.HYPEROS_WILD_BOOST -> HudTheme(
                // HyperOS Game Turbo: soft graphite glass, hairline borders, Xiaomi blue + Wild Boost orange
                id = g.theme, name = LABELS[0], style = PanelStyle.GLASS, gauge = GaugeStyle.RING,
                panelTop = 0xFF202226.toInt(), panelBottom = 0xFF121316.toInt(),
                textPrimary = 0xFFFFFFFF.toInt(), textSecondary = 0xFFA9ADB6.toInt(),
                accent = 0xFF4C8DFF.toInt(), accent2 = 0xFFFF8A1F.toInt(),
                hot = 0xFFFF453A.toInt(), good = 0xFF34C759.toInt(), warn = 0xFFFFB020.toInt(),
                stroke = 0x22FFFFFF, tile = 0x2EFFFFFF,
                animations = true, blur = true, opacityPct = s.opacityPct, cornerDp = s.cornerRadiusDp
            )
            ThemeId.REALME_GT_CYBER -> HudTheme(
                id = g.theme, name = LABELS[1], style = PanelStyle.CYBER_ANGULAR, gauge = GaugeStyle.SEGMENTS,
                panelTop = 0xFF121212.toInt(), panelBottom = 0xFF050505.toInt(),
                textPrimary = 0xFFFFFFFF.toInt(), textSecondary = 0xFFB8B08A.toInt(),
                accent = 0xFFFFD600.toInt(), accent2 = 0xFFFF9100.toInt(),
                hot = 0xFFFF3D00.toInt(), good = 0xFFB2FF59.toInt(), warn = 0xFFFFD600.toInt(),
                stroke = 0xFFFFD600.toInt(), tile = 0xFF1C1C1C.toInt(),
                animations = true, blur = false, opacityPct = s.opacityPct, cornerDp = s.cornerRadiusDp
            )
            ThemeId.MECHA_REDMAGIC -> HudTheme(
                // RedMagic cyber console: near-black carbon, signal red, orange heat accent, angular panels
                id = g.theme, name = LABELS[2], style = PanelStyle.MECHA, gauge = GaugeStyle.HEX,
                panelTop = 0xFF16171A.toInt(), panelBottom = 0xFF08090A.toInt(),
                textPrimary = 0xFFF4F5F7.toInt(), textSecondary = 0xFF8D929C.toInt(),
                accent = 0xFFFF2D46.toInt(), accent2 = 0xFFFF7A00.toInt(),
                hot = 0xFFFF3B30.toInt(), good = 0xFF2EE6A6.toInt(), warn = 0xFFFFB300.toInt(),
                stroke = 0xFF3A3C43.toInt(), tile = 0xFF1D1F23.toInt(),
                animations = true, blur = false, opacityPct = s.opacityPct, cornerDp = s.cornerRadiusDp
            )
            ThemeId.AMOLED_BLACK -> HudTheme(
                id = g.theme, name = LABELS[3], style = PanelStyle.FLAT, gauge = GaugeStyle.RING,
                panelTop = 0xFF000000.toInt(), panelBottom = 0xFF000000.toInt(),
                textPrimary = 0xFFFFFFFF.toInt(), textSecondary = 0xFF8A8A8A.toInt(),
                accent = 0xFF00E5FF.toInt(), accent2 = 0xFFFF6D00.toInt(),
                hot = 0xFFFF1744.toInt(), good = 0xFF69F0AE.toInt(), warn = 0xFFFFD740.toInt(),
                stroke = 0xFF2A2A2A.toInt(), tile = 0xFF121212.toInt(),
                animations = false, blur = false, opacityPct = 100, cornerDp = s.cornerRadiusDp
            )
        }
        return if (s.useCustomAccent) {
            base.copy(accent = parse(s.primaryHex, base.accent), accent2 = parse(s.secondaryHex, base.accent2))
        } else {
            base
        }
    }
}
