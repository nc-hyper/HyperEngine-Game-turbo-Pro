package com.hyperengine.gameturbo.hub

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.hyperengine.gameturbo.R
import com.hyperengine.gameturbo.core.GameModeLevel
import com.hyperengine.gameturbo.data.DnsPreset
import com.hyperengine.gameturbo.data.GameProfile
import com.hyperengine.gameturbo.ui.AnimationController
import com.hyperengine.gameturbo.ui.HudTheme
import com.hyperengine.gameturbo.ui.HudThemes
import com.hyperengine.gameturbo.ui.PanelStyle
import com.hyperengine.gameturbo.ui.Ui
import com.hyperengine.gameturbo.ui.VIcon

// =============================================================================================
// Text helpers shared by the card, the grid and the info bar
// =============================================================================================

object GameText {

    fun modeLabel(m: GameModeLevel): String = when (m) {
        GameModeLevel.BATTERY -> "BATTERY SAVER"
        GameModeLevel.STANDARD -> "BALANCED"
        GameModeLevel.PERFORMANCE -> "WILD BOOST"
    }

    fun modeColor(theme: HudTheme, m: GameModeLevel): Int = when (m) {
        GameModeLevel.BATTERY -> theme.good
        GameModeLevel.STANDARD -> theme.accent
        GameModeLevel.PERFORMANCE -> theme.accent2
    }

    /** Short tags describing what the profile will change, most important first. Max [limit]. */
    fun tags(p: GameProfile?, limit: Int): List<String> {
        if (p == null) return emptyList()
        val out = ArrayList<String>()
        if (p.targetFps > 0) out += "${p.targetFps} FPS"
        when {
            p.refreshHz > 0 -> out += "${p.refreshHz} Hz"
            p.refreshHz == -1 -> out += "MAX Hz"
        }
        p.downscale?.let { out += "${Math.round(it * 100f)}% RES" }
        if (p.dns != DnsPreset.NO_CHANGE) out += p.dns.label.uppercase().take(14)
        if (p.freezeOnLaunch) out += "FREEZE"
        if (p.blockBackgroundData) out += "NET GUARD"
        if (p.zeroAnimation) out += "NO ANIM"
        return out.take(limit)
    }

    /** One readable line for the info bar under the carousel. */
    fun summary(p: GameProfile?): String {
        if (p == null) return "No profile yet. Boost & Play creates one with the default tuning."
        val parts = ArrayList<String>()
        parts += modeLabel(p.gameMode).lowercase().replaceFirstChar { it.uppercase() }
        if (p.targetFps > 0) parts += "${p.targetFps} fps cap"
        when {
            p.refreshHz > 0 -> parts += "${p.refreshHz} Hz lock"
            p.refreshHz == -1 -> parts += "max Hz lock"
        }
        p.downscale?.let { parts += "${Math.round(it * 100f)}% resolution" }
        if (p.dns != DnsPreset.NO_CHANGE) parts += p.dns.label
        if (p.freezeOnLaunch) parts += "freezer on"
        if (p.blockBackgroundData) parts += "background data blocked"
        if (!p.enabled) parts += "PROFILE OFF"
        return parts.joinToString("  |  ")
    }

    fun stats(e: GameEntry, usageAccess: Boolean): String = when {
        !usageAccess -> "Play time needs Usage Access"
        e.lastUsedMs <= 0L -> "Not played recently"
        else -> "Today ${Fmt.minutes(e.todayMin)}  |  Last ${Fmt.ago(e.lastUsedMs)}"
    }
}

// =============================================================================================
// Spinning "turbine" ring drawn behind the icon of a Wild Boost card
// =============================================================================================

private class TurbineRing(ctx: Context) : View(ctx) {

    var angle = 0f
    var color = 0
    var active = false

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val box = RectF()

    override fun onDraw(canvas: Canvas) {
        if (!active) return
        val s = Ui.dpf(context, 3f)
        paint.strokeWidth = s
        val inset = s
        box.set(inset, inset, width - inset, height - inset)
        for (k in 0 until 3) {
            paint.color = HudThemes.withAlpha(color, if (k == 0) 0xFF else 0x99)
            canvas.drawArc(box, angle + k * 120f, 70f, false, paint)
        }
    }
}

// =============================================================================================
// Big card (centre of the 3D carousel)
// =============================================================================================

class GameCardView(private val host: HubHost) : FrameLayout(host.activity), Carousel3DView.Focusable {

    var onPlay: (() -> Unit)? = null
    var onMenu: (() -> Unit)? = null

    private val theme = host.theme
    private val iconView = ImageView(host.activity)
    private val ring = TurbineRing(host.activity)
    private val badge = TextView(host.activity)
    private val offTag = TextView(host.activity)
    private val nameView = TextView(host.activity)
    private val statView = TextView(host.activity)
    private val tagRow = LinearLayout(host.activity)
    private val playBtn = TextView(host.activity)
    private val menuBtn = TextView(host.activity)

    private var mode = GameModeLevel.PERFORMANCE
    private var glow = 0f
    private var active = false
    private val glowAnim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1300L
        repeatMode = ValueAnimator.REVERSE
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener {
            glow = it.animatedValue as Float
            invalidate()
        }
    }
    private val spinAnim = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 1800L
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            ring.angle = it.animatedValue as Float
            ring.invalidate()
        }
    }
    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val box = RectF()
    private val radius = HubStyle.radius(host.activity, theme, 22)

    /** Animated neon border (breathing ring + orbiting comet) while this is the centre card. */
    private val neon = AnimationController.NeonBorderPulse(this, theme.accent, radius)

    init {
        AnimationController.enableCardGlow(this, radius, 4f)
        setWillNotDraw(false)
        background = HubStyle.cardBackground(host)
        isClickable = true
        isLongClickable = true

        val content = Ui.vbox(host.activity)
        content.gravity = Gravity.CENTER_HORIZONTAL
        content.setPadding(host.dp(14), host.dp(14), host.dp(14), host.dp(14))
        addView(content, LayoutParams(Ui.MATCH, Ui.MATCH))

        // top row: mode badge + "profile off" tag
        val top = Ui.hbox(host.activity)
        top.gravity = Gravity.CENTER_VERTICAL
        badge.textSize = 10f
        badge.typeface = Typeface.DEFAULT_BOLD
        badge.includeFontPadding = false
        badge.letterSpacing = 0.1f
        badge.setPadding(host.dp(8), host.dp(5), host.dp(8), host.dp(5))
        top.addView(badge, Ui.lp(Ui.WRAP, Ui.WRAP))
        top.addView(View(host.activity), Ui.lp(0, 1, 1f))
        offTag.text = "OFF"
        offTag.textSize = 10f
        offTag.typeface = Typeface.DEFAULT_BOLD
        offTag.setTextColor(theme.hot)
        offTag.visibility = View.GONE
        top.addView(offTag, Ui.lp(Ui.WRAP, Ui.WRAP))
        content.addView(top, Ui.lp(Ui.MATCH, Ui.WRAP))

        content.addView(View(host.activity), Ui.lp(Ui.MATCH, 0, 1f))

        // icon with the spinning ring
        val iconFrame = FrameLayout(host.activity)
        iconFrame.addView(ring, LayoutParams(Ui.MATCH, Ui.MATCH))
        iconFrame.addView(
            iconView,
            LayoutParams(host.dp(76), host.dp(76), Gravity.CENTER)
        )
        content.addView(iconFrame, Ui.lp(host.dp(104), host.dp(104)))

        nameView.textSize = 17f
        nameView.typeface = Typeface.DEFAULT_BOLD
        nameView.setTextColor(theme.textPrimary)
        nameView.gravity = Gravity.CENTER
        nameView.maxLines = 2
        nameView.ellipsize = TextUtils.TruncateAt.END
        content.addView(nameView, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(8), 0, 0))

        statView.textSize = 11f
        statView.setTextColor(theme.textSecondary)
        statView.gravity = Gravity.CENTER
        statView.maxLines = 1
        statView.ellipsize = TextUtils.TruncateAt.END
        content.addView(statView, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(3), 0, 0))

        tagRow.orientation = LinearLayout.HORIZONTAL
        tagRow.gravity = Gravity.CENTER
        content.addView(tagRow, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(10), 0, 0))

        content.addView(View(host.activity), Ui.lp(Ui.MATCH, 0, 1f))

        // buttons
        val buttons = Ui.hbox(host.activity)
        buttons.gravity = Gravity.CENTER_VERTICAL
        playBtn.text = "BOOST & PLAY"
        playBtn.textSize = 13f
        playBtn.typeface = Typeface.DEFAULT_BOLD
        playBtn.gravity = Gravity.CENTER
        playBtn.letterSpacing = 0.06f
        playBtn.setPadding(host.dp(10), host.dp(12), host.dp(10), host.dp(12))
        playBtn.setOnClickListener { onPlay?.invoke() }
        menuBtn.text = ""
        menuBtn.gravity = Gravity.CENTER
        VIcon.setOnText(menuBtn, R.drawable.ic_more_dots, 20, theme.textPrimary)
        VIcon.pressSpring(menuBtn)
        menuBtn.minimumWidth = host.dp(46)
        menuBtn.setPadding(host.dp(12), host.dp(12), host.dp(12), host.dp(12))
        menuBtn.background = Ui.rounded(theme.tile, Ui.tileRadius(host.activity, theme), theme.stroke, host.dp(1))
        menuBtn.setOnClickListener { onMenu?.invoke() }
        buttons.addView(playBtn, Ui.lp(0, Ui.WRAP, 1f))
        buttons.addView(menuBtn, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, host.dp(8), 0, 0, 0))
        content.addView(buttons, Ui.lp(Ui.MATCH, Ui.WRAP))

        onFocus(0f)
    }

    fun bind(e: GameEntry, p: GameProfile?, usageAccess: Boolean) {
        nameView.text = e.label
        statView.text = GameText.stats(e, usageAccess)
        GameIcons.load(host.activity, e.pkg, e.label, host.dp(76), iconView, HudThemes.withAlpha(theme.accent, 0x99))

        mode = p?.gameMode ?: GameModeLevel.PERFORMANCE
        val c = GameText.modeColor(theme, mode)
        badge.text = GameText.modeLabel(mode)
        badge.setTextColor(HudThemes.onAccent(c))
        badge.background = Ui.rounded(c, HubStyle.radius(host.activity, theme, 8))
        offTag.visibility = if (p != null && !p.enabled) View.VISIBLE else View.GONE

        playBtn.setTextColor(HudThemes.onAccent(c))
        playBtn.background = Ui.rounded(c, Ui.tileRadius(host.activity, theme))
        ring.color = c
        neon.setColor(c)

        tagRow.removeAllViews()
        val tags = GameText.tags(p, 3)
        if (tags.isEmpty()) {
            tagRow.addView(HubStyle.chip(host, if (p == null) "NEW" else "DEFAULT TUNING", theme.textSecondary))
        } else {
            tags.forEachIndexed { i, t ->
                tagRow.addView(HubStyle.chip(host, t, theme.accent), Ui.lp(Ui.WRAP, Ui.WRAP, 0f, if (i == 0) 0 else host.dp(4), 0, 0, 0))
            }
        }
        refreshRing()
    }

    override fun glowColor(): Int = GameText.modeColor(theme, mode)

    override fun onFocus(amount: Float) {
        val a = ((amount - 0.5f) * 2f).coerceIn(0f, 1f)
        playBtn.alpha = a
        menuBtn.alpha = a
        val vis = if (a < 0.05f) View.INVISIBLE else View.VISIBLE
        playBtn.visibility = vis
        menuBtn.visibility = vis
        setActive(amount > 0.6f)
    }

    private fun setActive(on: Boolean) {
        if (on == active) return
        active = on
        if (on && theme.animations && isAttachedToWindow) {
            neon.setColor(GameText.modeColor(theme, mode))
            neon.start()
            if (mode == GameModeLevel.PERFORMANCE) spinAnim.start()
        } else {
            neon.stop()
            spinAnim.cancel()
            glow = 0f
        }
        refreshRing()
        invalidate()
    }

    private fun refreshRing() {
        val spin = active && theme.animations && mode == GameModeLevel.PERFORMANCE
        ring.active = spin
        if (spin && isAttachedToWindow && !spinAnim.isRunning) spinAnim.start()
        if (!spin) spinAnim.cancel()
        ring.invalidate()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (active && theme.animations) {
            neon.setColor(GameText.modeColor(theme, mode))
            neon.start()
            refreshRing()
        }
    }

    override fun onDetachedFromWindow() {
        neon.stop()
        spinAnim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        // With motion on, the neon pulse draws the border; this static ring is only for themes with animations off.
        if (!active || theme.animations) return
        val w = Ui.dpf(context, if (theme.style == PanelStyle.CYBER_ANGULAR) 2.5f else 2f)
        outline.strokeWidth = w
        outline.color = HudThemes.withAlpha(GameText.modeColor(theme, mode), (70 + 150 * glow).toInt())
        box.set(w / 2f, w / 2f, width - w / 2f, height - w / 2f)
        canvas.drawRoundRect(box, radius, radius, outline)
    }
}

// =============================================================================================
// Grid tile + grid
// =============================================================================================

class GameTileView(private val host: HubHost) : LinearLayout(host.activity) {

    private val theme = host.theme
    private val iconView = ImageView(host.activity)
    private val nameView = TextView(host.activity)
    private val modeView = TextView(host.activity)

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(host.dp(6), host.dp(10), host.dp(6), host.dp(8))
        background = Ui.rounded(theme.tile, HubStyle.radius(host.activity, theme, 14), theme.stroke, host.dp(1))
        isClickable = true

        addView(iconView, Ui.lp(host.dp(56), host.dp(56)))
        nameView.textSize = 11f
        nameView.setTextColor(theme.textPrimary)
        nameView.gravity = Gravity.CENTER
        nameView.maxLines = 2
        nameView.minLines = 2
        nameView.ellipsize = TextUtils.TruncateAt.END
        addView(nameView, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(6), 0, 0))
        modeView.textSize = 9f
        modeView.typeface = Typeface.DEFAULT_BOLD
        modeView.gravity = Gravity.CENTER
        modeView.includeFontPadding = false
        addView(modeView, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(4), 0, 0))
    }

    fun bind(e: GameEntry, p: GameProfile?, selected: Boolean) {
        nameView.text = e.label
        GameIcons.load(host.activity, e.pkg, e.label, host.dp(56), iconView, HudThemes.withAlpha(theme.accent, 0x99))
        val m = p?.gameMode ?: GameModeLevel.PERFORMANCE
        val c = GameText.modeColor(theme, m)
        modeView.text = if (p != null && !p.enabled) "OFF" else GameText.modeLabel(m)
        modeView.setTextColor(if (p != null && !p.enabled) theme.hot else c)
        background = Ui.rounded(
            theme.tile, HubStyle.radius(host.activity, theme, 14),
            if (selected) theme.accent else theme.stroke, host.dp(if (selected) 2 else 1)
        )
    }
}

/** Scrolling grid of [GameTileView]s, [COLUMNS] per row. Rebuilt wholesale on [submit]. */
class GameGridView(private val host: HubHost) : ScrollView(host.activity) {

    var onTap: ((GameEntry) -> Unit)? = null
    var onLongPress: ((GameEntry) -> Unit)? = null

    private val column = Ui.vbox(host.activity)

    init {
        isVerticalScrollBarEnabled = false
        overScrollMode = OVER_SCROLL_NEVER
        column.setPadding(host.dp(2), host.dp(4), host.dp(2), host.dp(12))
        addView(column, LayoutParams(Ui.MATCH, Ui.WRAP))
    }

    fun submit(entries: List<GameEntry>, selectedPkg: String?) {
        column.removeAllViews()
        var row: LinearLayout? = null
        entries.forEachIndexed { i, e ->
            if (i % COLUMNS == 0) {
                row = Ui.hbox(host.activity).also {
                    column.addView(it, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(4), 0, host.dp(4)))
                }
            }
            val tile = GameTileView(host)
            tile.bind(e, host.repo.profile(e.pkg), e.pkg == selectedPkg)
            tile.setOnClickListener { onTap?.invoke(e) }
            tile.setOnLongClickListener {
                onLongPress?.invoke(e)
                true
            }
            row?.addView(tile, Ui.lp(0, Ui.WRAP, 1f, host.dp(4), 0, host.dp(4), 0))
        }
        // pad the last row so tiles keep a constant width
        val rest = entries.size % COLUMNS
        if (rest != 0) {
            for (k in rest until COLUMNS) row?.addView(View(host.activity), Ui.lp(0, 1, 1f, host.dp(4), 0, host.dp(4), 0))
        }
    }

    companion object {
        private const val COLUMNS = 3
    }
}
