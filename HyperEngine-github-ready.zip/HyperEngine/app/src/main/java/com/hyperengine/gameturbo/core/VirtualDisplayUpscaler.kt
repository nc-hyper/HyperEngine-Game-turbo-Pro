package com.hyperengine.gameturbo.core

import android.content.Context
import android.content.pm.ActivityInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Display
import android.view.WindowManager
import com.hyperengine.gameturbo.HyperApp
import com.hyperengine.gameturbo.ui.OverlayKit
import com.hyperengine.gameturbo.ui.UpscaleOverlay
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.roundToInt

data class UpscalerState(
    val active: Boolean = false,
    val busy: Boolean = false,
    val game: String? = null,
    val displayId: Int = -1,
    /** What the game renders (virtual display size) and what reaches the panel. */
    val srcW: Int = 0,
    val srcH: Int = 0,
    val outW: Int = 0,
    val outH: Int = 0,
    val scale: Float = 1f,
    /** Frames per second the upscaler puts on the screen. */
    val fps: Int = 0,
    /** true = the game is confirmed on the virtual display, false = it is not, null = cannot be checked on this ROM. */
    val onDisplay: Boolean? = null,
    /** Why it stopped, or a warning while running. Empty when there is nothing to say. */
    val note: String = ""
)

/**
 * Virtual-display upscaler: the game renders at a lower resolution on a private virtual display and this class
 * stretches that picture to the real screen with a bicubic upscale plus contrast-adaptive sharpening
 * ([UpscaleRenderer]). Unlike HyperBoost's "system resolution" route, nothing system-wide is changed: the real screen,
 * the HUD and every other app stay at native resolution, and the picture is sharpened instead of only stretched.
 *
 * How it works, in order:
 *  1. An overlay window ([UpscaleOverlay]) covers the screen; its surface is the output of the renderer.
 *  2. A VirtualDisplay of [scale] x the screen size is created (public, own content only) and its output is the
 *     renderer's input surface. Its density is scaled too, so the game's layout (dp) stays the same size.
 *  3. The game is launched on that display (`am start --display <id>`), after force-stopping it when asked, because an
 *     app that is already running keeps its task on the phone screen.
 *  4. Touches landing on the overlay are re-injected into the virtual display (Shizuku, scaled coordinates).
 *  5. A monitor checks every few seconds that the game is really on the virtual display, and stops everything when it
 *     is not (it never opened there, or the player closed it), so the screen is never left covered by a dead picture.
 *
 * Nothing persists. The virtual display belongs to this process: if the app dies the system removes it, and the game
 * task moves back to the phone screen. [stop] does the same on purpose.
 *
 * Needs: Shizuku (touch injection and the display-targeted launch), the display-over-apps permission, and a game
 * that can run on a secondary display. Honest limits are in docs/FIX_VIRTUAL_UPSCALER_NOTES.md; the short version:
 * virtual displays usually run at 60 Hz, secure (FLAG_SECURE) games draw black, games that refuse a secondary display
 * fall back to the phone screen (reported, then the upscaler stops), and the screen must already be in the game's
 * orientation when it starts.
 */
class VirtualDisplayUpscaler(
    context: Context,
    private val bridge: SystemBridgeExecutor,
    /** True while HyperBoost lowers the system resolution; stacking both would shrink the picture twice. */
    private val systemScaleActive: () -> Boolean
) {
    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("hyper_upscaler", Context.MODE_PRIVATE)
    private val dm = app.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
    private val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val mutex = Mutex()

    private val _state = MutableStateFlow(UpscalerState())
    val state: StateFlow<UpscalerState> = _state.asStateFlow()

    private class Session(
        val pkg: String,
        val displayId: Int,
        val display: VirtualDisplay,
        val renderer: UpscaleRenderer,
        val overlay: UpscaleOverlay,
        val outW: Int,
        val outH: Int,
        val listener: DisplayManager.DisplayListener
    )

    private var session: Session? = null
    private var monitor: Job? = null

    // ---- saved choices ---------------------------------------------------------------------------

    /** Render scale for [pkg], Balanced (0.67x) when none was chosen. Takes effect the next time the upscaler starts. */
    fun scale(pkg: String): Float = prefs.getFloat("s.$pkg", HyperBoostQuality.BALANCED.scale).coerceIn(MIN_SCALE, MAX_SCALE)

    fun setScale(pkg: String, s: Float) {
        prefs.edit().putFloat("s.$pkg", s.coerceIn(MIN_SCALE, MAX_SCALE)).apply()
    }

    /** Sharpening strength 0..100, shared by all games. 0 = plain bicubic upscale with no sharpening pass. */
    fun sharpness(): Int = prefs.getInt("sharp", 60).coerceIn(0, 100)

    /** Saved, and applied to the running picture at once. */
    fun setSharpness(v: Int) {
        val c = v.coerceIn(0, 100)
        prefs.edit().putInt("sharp", c).apply()
        session?.renderer?.sharpness = c
    }

    fun isActive(): Boolean = session != null

    // ---- start -----------------------------------------------------------------------------------

    /**
     * Starts the upscaler for [pkg] and launches the game on the virtual display. [restartGame] force-stops the game
     * first (it loses unsaved progress); leave it true unless the game is not running.
     */
    suspend fun start(pkg: String, restartGame: Boolean): List<StepResult> = mutex.withLock {
        val out = ArrayList<StepResult>()
        fun fail(detail: String): List<StepResult> {
            out += StepResult(NAME, false, detail)
            _state.update { it.copy(busy = false) }
            return out
        }
        if (!Validators.PACKAGE.matches(pkg)) return@withLock fail("invalid package name")
        session?.let { return@withLock fail("already running for ${it.pkg}; stop it first") }
        if (!Settings.canDrawOverlays(app)) return@withLock fail("needs the display-over-apps permission")
        if (!bridge.hasShell()) return@withLock fail("needs Shizuku or root")
        if (!bridge.input.connect()) {
            return@withLock fail("touch forwarding needs Shizuku: " + (bridge.input.lastError ?: "input service unavailable"))
        }
        if (systemScaleActive()) {
            return@withLock fail("HyperBoost is lowering the system resolution. Turn off \"Use system resolution\" first, or the picture would shrink twice")
        }
        val target = launchComponent(pkg) ?: return@withLock fail("this game has no launcher activity")
        if (!SAFE_COMPONENT.matches(target.flat)) return@withLock fail("unsupported activity name")

        _state.update { it.copy(busy = true, game = pkg, note = "") }

        // Most games declare themselves non-resizable, and Android refuses (or letterboxes into nothing) a non-resizable
        // activity on a secondary display: that is why the upscaler "did not open" in so many games. These two global
        // switches let every activity run there. They are tracked, so they are put back when the upscaler stops.
        val eng = HyperApp.instance.engine
        eng.putTracked(Ns.GLOBAL, "force_resizable_activities", "1")
        eng.putTracked(Ns.GLOBAL, "enable_non_resizable_multi_window", "1")

        withContext(Dispatchers.Main) {
            var real = OverlayKit.realSize(wm)
            // The game's orientation is fixed by its manifest. Starting from the portrait lobby used to be refused;
            // turn the screen to the game's orientation instead (tracked, restored when the upscaler stops).
            if (target.landscape != null && target.landscape != (real.x > real.y)) {
                out += forceOrientation(target.landscape)
                real = OverlayKit.realSize(wm)
            }
            val outW = real.x
            val outH = real.y
            val screenLandscape = outW > outH
            val wantLandscape = target.landscape
            if (wantLandscape != null && wantLandscape != screenLandscape) {
                releaseTweaks()
                return@withContext fail(
                    "the game wants " + (if (wantLandscape) "landscape" else "portrait") +
                        " but the screen is " + (if (screenLandscape) "landscape" else "portrait") +
                        ". Rotate the phone first (starting from the in-game HUD does this for you)"
                )
            }
            val s = scale(pkg)
            val srcW = even(outW * s)
            val srcH = even(outH * s)
            val dpi = (app.resources.displayMetrics.densityDpi * s).roundToInt().coerceAtLeast(120)

            // 1. renderer
            val renderer = UpscaleRenderer(srcW, srcH, sharpness()) { fps -> _state.update { st -> if (st.active) st.copy(fps = fps) else st } }
            if (!renderer.init()) {
                val why = renderer.error ?: "unknown"
                renderer.release()
                releaseTweaks()
                return@withContext fail("GPU setup failed: $why")
            }
            out += StepResult("Upscale pipeline", true, "bicubic + sharpening, ${srcW}x$srcH to ${outW}x$outH")

            // 2. overlay (picture + touch)
            val overlay = UpscaleOverlay(
                app, wm, outW, outH, srcW, srcH, bridge.input,
                onSurface = { renderer.attachOutput(it) },
                onSurfaceLost = { renderer.detachOutput() },
                onStop = { scope.launch { stop("stopped from the on-screen pill") } }
            )
            if (!overlay.show()) {
                renderer.release()
                releaseTweaks()
                return@withContext fail("could not draw the overlay window (display-over-apps permission?)")
            }

            // 3. virtual display
            val vd: VirtualDisplay? = try {
                dm.createVirtualDisplay(VD_NAME, srcW, srcH, dpi, renderer.inputSurface, VD_FLAGS)
            } catch (t: Throwable) {
                out += StepResult("Virtual display", false, (t.message ?: t.javaClass.simpleName).take(140))
                null
            }
            if (vd == null) {
                overlay.hide()
                renderer.release()
                if (out.none { !it.ok }) out += StepResult("Virtual display", false, "the system refused to create it")
                releaseTweaks()
                _state.update { it.copy(busy = false) }
                return@withContext out
            }
            val id = vd.display.displayId
            overlay.setTarget(id)
            out += StepResult("Virtual display", true, "#$id at ${srcW}x$srcH, $dpi dpi (${fmt(s)}x)")

            val listener = object : DisplayManager.DisplayListener {
                override fun onDisplayAdded(displayId: Int) {}
                override fun onDisplayRemoved(displayId: Int) {
                    if (displayId == id) scope.launch { stop("the system removed the virtual display") }
                }

                override fun onDisplayChanged(displayId: Int) {
                    if (displayId != Display.DEFAULT_DISPLAY) return
                    val now = OverlayKit.realSize(wm)
                    if (now.x != outW || now.y != outH) scope.launch { stop("the screen size or rotation changed; start it again") }
                }
            }
            dm.registerDisplayListener(listener, main)
            session = Session(pkg, id, vd, renderer, overlay, outW, outH, listener)
            _state.value = UpscalerState(
                active = true, busy = true, game = pkg, displayId = id,
                srcW = srcW, srcH = srcH, outW = outW, outH = outH, scale = s
            )

            // 4. launch the game on the virtual display
            if (restartGame) {
                bridge.shell("am force-stop $pkg", 8_000L)
                delay(600L)
            }
            val r = bridge.shell("am start --display $id -n \"" + target.flat.replace("$", "\\$") + "\"", 10_000L)
            val text = r.stdout + " " + r.stderr
            if (!r.ok || text.contains("Error", true) || text.contains("Exception", true)) {
                out += StepResult("Launch on virtual display", false, text.trim().take(140).ifBlank { r.message })
                stopLocked("the game could not be started on the virtual display")
                return@withContext out
            }
            if (text.contains("brought to the front", true)) {
                out += StepResult(
                    "Launch on virtual display", true,
                    "the game was already running, so it stayed on the phone screen. Start again with the restart option"
                )
            } else {
                out += StepResult("Launch on virtual display", true, "started")
            }

            // 5. keep an eye on it
            _state.update { it.copy(busy = false) }
            startMonitor(pkg, id)
            out
        }
        out
    }

    // ---- stop ------------------------------------------------------------------------------------

    /** Removes the windows and the virtual display. The game task moves back to the phone screen. */
    suspend fun stop(reason: String = ""): StepResult = mutex.withLock { stopLocked(reason) }

    private suspend fun stopLocked(reason: String): StepResult = withContext(Dispatchers.Main) {
        val s = session ?: return@withContext StepResult(NAME, true, "not running")
        session = null
        monitor?.cancel()
        monitor = null
        runCatching { dm.unregisterDisplayListener(s.listener) }
        runCatching { s.overlay.hide() }
        runCatching { s.display.release() }
        runCatching { s.renderer.release() }
        releaseTweaks()
        _state.value = UpscalerState(note = reason)
        StepResult(NAME, true, if (reason.isBlank()) "stopped" else "stopped: $reason")
    }

    // ---- monitor ---------------------------------------------------------------------------------

    /** Stop from a coroutine that [stop] would otherwise cancel (the monitor): runs on the engine's own scope. */
    private fun stopAsync(reason: String) {
        scope.launch { stop(reason) }
    }

    private fun startMonitor(pkg: String, id: Int) {
        monitor?.cancel()
        monitor = scope.launch {
            delay(2_500L)
            val t0 = SystemClock.uptimeMillis()
            var seen = false
            var misses = 0
            while (isActive) {
                when (locateGame(pkg, id)) {
                    true -> {
                        seen = true
                        misses = 0
                        _state.update { it.copy(onDisplay = true) }
                    }
                    false -> {
                        misses++
                        _state.update { it.copy(onDisplay = if (seen) true else false) }
                        if (!seen && SystemClock.uptimeMillis() - t0 > OPEN_TIMEOUT_MS) {
                            stopAsync("the game did not open on the virtual display (it probably does not support a secondary display)")
                            return@launch
                        }
                        if (seen && misses >= 2) {
                            stopAsync("the game was closed")
                            return@launch
                        }
                    }
                    null -> _state.update { it.copy(onDisplay = null) }
                }
                // `dumpsys activity activities` holds system_server's activity lock while it runs. Every 4 s was a visible
                // micro-stutter in the game; once the game is confirmed on the virtual display, 10 s is plenty to notice a close.
                delay(if (seen) 10_000L else 4_000L)
            }
        }
    }

    /**
     * Reads `dumpsys activity activities` and says whether [pkg] has an activity listed under display [id].
     * null when the output cannot be read or has no display headers (a ROM with another format): then nothing is
     * assumed, and the on-screen Stop button stays the way out.
     */
    private suspend fun locateGame(pkg: String, id: Int): Boolean? {
        val r = bridge.shell("dumpsys activity activities | grep -E 'Display #|$pkg'", 8_000L)
        if (!r.ok && r.stdout.isBlank()) return null
        var current = -1
        var sawHeader = false
        var found = false
        for (line in r.stdout.lineSequence()) {
            val m = DISPLAY_HEADER.find(line)
            if (m != null) {
                current = m.groupValues[1].toIntOrNull() ?: -1
                sawHeader = true
                continue
            }
            if (current == id && line.contains(pkg)) found = true
        }
        return if (sawHeader) found else null
    }

    // ---- helpers ---------------------------------------------------------------------------------

    private suspend fun forceOrientation(landscape: Boolean): StepResult {
        val eng = HyperApp.instance.engine
        val a = eng.putTracked(Ns.SYSTEM, "accelerometer_rotation", "0")
        val b = eng.putTracked(Ns.SYSTEM, "user_rotation", if (landscape) "1" else "0")
        delay(1_300L)   // the display needs a moment to rotate before its size is read again
        return StepResult("Rotate screen", a.ok && b.ok, if (landscape) "landscape for this game" else "portrait for this game")
    }

    /** Puts back the global switches and the rotation lock this class wrote (keys it never touched are skipped). */
    private suspend fun releaseTweaks() {
        runCatching {
            HyperApp.instance.engine.releaseTracked(
                listOf(
                    Ns.GLOBAL to "force_resizable_activities",
                    Ns.GLOBAL to "enable_non_resizable_multi_window",
                    Ns.SYSTEM to "user_rotation",
                    Ns.SYSTEM to "accelerometer_rotation"
                )
            )
        }
    }

    private class LaunchTarget(val flat: String, val landscape: Boolean?)

    @Suppress("DEPRECATION")
    private fun launchComponent(pkg: String): LaunchTarget? {
        val pm = app.packageManager
        val comp = pm.getLaunchIntentForPackage(pkg)?.component ?: return null
        val landscape: Boolean? = runCatching {
            when (pm.getActivityInfo(comp, 0).screenOrientation) {
                ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE, ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE,
                ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE, ActivityInfo.SCREEN_ORIENTATION_USER_LANDSCAPE -> true
                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT, ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT,
                ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT, ActivityInfo.SCREEN_ORIENTATION_USER_PORTRAIT -> false
                else -> null
            }
        }.getOrNull()
        return LaunchTarget(comp.packageName + "/" + comp.className, landscape)
    }

    private fun even(v: Float): Int = ((v / 2f).roundToInt() * 2).coerceAtLeast(2)

    private fun fmt(v: Float): String = String.format(Locale.US, "%.2f", v)

    private companion object {
        const val NAME = "Virtual-display upscaler"
        const val VD_NAME = "HyperUpscale"
        const val MIN_SCALE = 0.5f
        const val MAX_SCALE = 0.95f
        const val OPEN_TIMEOUT_MS = 14_000L

        // PUBLIC (1) lets other apps' activities run on it, OWN_CONTENT_ONLY (8) is required with PUBLIC and stops it
        // mirroring the phone screen, SUPPORTS_TOUCH (1 shl 6, hidden constant) marks it as a touch display.
        const val VD_FLAGS = DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC or
            DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY or (1 shl 6)

        val SAFE_COMPONENT = Regex("^[A-Za-z0-9_.]+/[A-Za-z0-9_.$]+$")
        val DISPLAY_HEADER = Regex("Display #(\\d+)")
    }
}
