package com.hyperengine.gameturbo.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.hyperengine.gameturbo.HyperApp

/**
 * Wakes the accessibility self-healer when the process was dead: the watchdog / restart alarms, a reboot, or an
 * app update. goAsync keeps the process alive until the run ends (9 s at most).
 */
class SelfHealReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val trigger = when (intent.action) {
            ACTION_HEAL -> intent.getStringExtra(EXTRA_REASON).orEmpty().ifBlank { "alarm" }
            Intent.ACTION_BOOT_COMPLETED -> "boot"
            Intent.ACTION_MY_PACKAGE_REPLACED -> "app updated"
            else -> return
        }
        // Keep-running is opt-in. When it is off, a reboot, an update or a stale alarm must not wake the app.
        if (!HyperApp.instance.selfHealer.autoHeal) return
        val pending = goAsync()
        HyperApp.instance.selfHealer.healThen(trigger) { pending.finish() }
    }

    companion object {
        const val ACTION_HEAL = "com.hyperengine.gameturbo.action.SELF_HEAL"
        const val EXTRA_REASON = "reason"
    }
}
