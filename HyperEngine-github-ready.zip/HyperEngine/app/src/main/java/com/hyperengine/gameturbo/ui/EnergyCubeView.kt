package com.hyperengine.gameturbo.ui

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import com.hyperengine.gameturbo.HyperApp
import com.hyperengine.gameturbo.core.FpsEnforcerState
import com.hyperengine.gameturbo.core.PerfTier
import com.hyperengine.gameturbo.core.StepResult
import com.hyperengine.gameturbo.core.TelemetrySample
import com.hyperengine.gameturbo.core.WildBoostState
import com.hyperengine.gameturbo.data.FanMode
import com.hyperengine.gameturbo.data.GameProfile
import com.hyperengine.gameturbo.data.TurboConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.abs

/**
 * RedMagic-style Energy Cube. Four faces on a real 3D cube transition (swipe, tap the arrows, or L1 / R1 on a
 * gamepad):
 *
 *   PERFORMANCE   Green / Blue / Red tier, Diablo, 5-layer FPS unlock
 *   THERMAL       turbine, fan mode, spin-up sound, 165 Hz speaker eject pulse
 *   POWER         Charge Separation, the phone's real Battery Saver, live watts, RAM cleaner
 *   DISPLAY       refresh-rate lock status, motion smoothing + black-frame insertion, render resolution
 *
 * Every control calls the same engines as the sidebar's Turbo core page ([HyperApp.fps], [HyperApp.wild]) and
 * shows the real per-step result, including the steps that failed.
 */
class EnergyCubeView(
    context: Context,
    private val scope: CoroutineScope,
    private var theme: HudTheme,
    private var game: String,
    startFace: Int,
    private val onFaceChanged: (Int) -> Unit
) : LinearLayout(context) {

    private val app get() = HyperApp.instance
    private val repo get() = app.repository

    private val stage = FrameLayout(context)
    private val faces = ArrayList<Face>()
    private val dots = ArrayList<View>()
    private val faceTitle = Ui.label(context, "", 10f, theme.accent, true)
    private var current = startFace.coerceIn(0, 3)
    private var animating = false
    private var job: Job? = null
    private var lastSample: TelemetrySample? = null
    private var lastFps = FpsEnforcerState()
    private var lastWild = WildBoostState()

    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var dragging = false

    init {
        orientation = VERTICAL
        // Faces are built after construction: their bodies read subclass fields that do not exist yet inside
        // the base-class constructor.
        faces += PerfFace().also { it.rebuild() }
        faces += ThermalFace().also { it.rebuild() }
        faces += PowerFace().also { it.rebuild() }
        faces += DisplayFace().also { it.rebuild() }
        for (f in faces) {
            stage.addView(f.root, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
            f.root.visibility = INVISIBLE
        }
        faces[current].root.visibility = VISIBLE
        addView(stage, Ui.lp(Ui.MATCH, 0, 1f))
        addView(buildNav(), Ui.lp(Ui.MATCH, Ui.dp(context, 28), 0f, 0, Ui.dp(context, 4), 0, 0))
        refreshNav()
    }

    // =========================================================================================
    // Public API
    // =========================================================================================

    fun restyle(newTheme: HudTheme) {
        theme = newTheme
        // The faces hold views styled with the old theme; rebuild them in place and keep the current one.
        for (f in faces) f.rebuild()
        faceTitle.setTextColor(theme.accent)
        refreshNav()
        faces.forEach { it.update(lastFps, lastWild, lastSample) }
    }

    fun changeGame(pkg: String) {
        game = pkg
        for (f in faces) f.rebuild()
        faces.forEach { it.update(lastFps, lastWild, lastSample) }
    }

    fun onSample(s: TelemetrySample) {
        lastSample = s
        faces.forEach { it.onSample(s) }
    }

    fun next() = go(current + 1)
    fun prev() = go(current - 1)

    fun go(target: Int, animate: Boolean = true) {
        val n = faces.size
        val t = ((target % n) + n) % n
        if (t == current || animating) return
        val forward = ((t - current + n) % n) <= n / 2
        val from = faces[current].root
        val to = faces[t].root
        val width = stage.width.toFloat()
        val height = stage.height.toFloat()
        current = t
        onFaceChanged(t)
        refreshNav()
        if (!animate || width <= 0f || !theme.animations) {
            faces.forEachIndexed { i, f -> f.root.visibility = if (i == t) VISIBLE else INVISIBLE; resetTransform(f.root) }
            return
        }
        animating = true
        to.visibility = VISIBLE
        val dir = if (forward) 1 else -1
        val anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 240L
            interpolator = DecelerateInterpolator()
            addUpdateListener { transform(from, to, it.animatedValue as Float, dir, width, height) }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: Animator) {
                    from.visibility = INVISIBLE
                    resetTransform(from)
                    resetTransform(to)
                    animating = false
                }
            })
        }
        anim.start()
    }

    /** D-pad / gamepad shoulder buttons. Returns true when the key was used. */
    fun handleKey(keyCode: Int): Boolean = when (keyCode) {
        android.view.KeyEvent.KEYCODE_BUTTON_R1, android.view.KeyEvent.KEYCODE_PAGE_DOWN -> { next(); true }
        android.view.KeyEvent.KEYCODE_BUTTON_L1, android.view.KeyEvent.KEYCODE_PAGE_UP -> { prev(); true }
        else -> false
    }

    // =========================================================================================
    // Lifecycle: live engine state only while attached
    // =========================================================================================

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        job = scope.launch {
            combine(app.fps.state, app.wild.state) { f, w -> f to w }.collect { (f, w) ->
                lastFps = f
                lastWild = w
                faces.forEach { it.update(f, w, lastSample) }
            }
        }
    }

    override fun onDetachedFromWindow() {
        job?.cancel()
        job = null
        super.onDetachedFromWindow()
    }

    // =========================================================================================
    // Swipe between faces
    // =========================================================================================

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x
                downY = e.y
                dragging = false
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - downX
                val dy = e.y - downY
                if (!dragging && abs(dx) > slop * 2 && abs(dx) > abs(dy) * 1.5f) {
                    dragging = true
                    return true
                }
            }
        }
        return false
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> return true
            MotionEvent.ACTION_UP -> {
                val dx = e.x - downX
                if (dragging && abs(dx) > width * 0.16f) {
                    if (dx < 0) next() else prev()
                }
                dragging = false
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                dragging = false
                return true
            }
        }
        return dragging
    }

    // =========================================================================================
    // Cube transform
    // =========================================================================================

    /**
     * Two faces on adjacent sides of a cube. dir = 1: the next face comes in from the right edge, the current one
     * leaves to the left, both hinged on the edge they share. dir = -1 is the mirror image.
     */
    private fun transform(from: View, to: View, t: Float, dir: Int, w: Float, h: Float) {
        val cam = resources.displayMetrics.density * 12000f
        from.cameraDistance = cam
        to.cameraDistance = cam
        from.pivotY = h / 2f
        to.pivotY = h / 2f
        if (dir > 0) {
            from.pivotX = w
            from.rotationY = 90f * t
            from.translationX = -t * w
            to.pivotX = 0f
            to.rotationY = -90f * (1f - t)
            to.translationX = (1f - t) * w
        } else {
            from.pivotX = 0f
            from.rotationY = -90f * t
            from.translationX = t * w
            to.pivotX = w
            to.rotationY = 90f * (1f - t)
            to.translationX = -(1f - t) * w
        }
        from.alpha = 1f - 0.55f * t
        to.alpha = 0.45f + 0.55f * t
    }

    private fun resetTransform(v: View) {
        v.rotationY = 0f
        v.translationX = 0f
        v.alpha = 1f
    }

    // =========================================================================================
    // Navigation strip
    // =========================================================================================

    private fun buildNav(): View {
        val row = Ui.hbox(context)
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(navButton(IconKind.CHEVRON_LEFT) { prev() }, Ui.lp(Ui.dp(context, 36), Ui.MATCH))
        val mid = Ui.hbox(context)
        mid.gravity = Gravity.CENTER
        for (i in 0 until 4) {
            val d = View(context)
            dots += d
            mid.addView(d, Ui.lp(Ui.dp(context, 8), Ui.dp(context, 8), 0f, Ui.dp(context, 3), 0, Ui.dp(context, 3), 0))
        }
        mid.addView(faceTitle, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, Ui.dp(context, 8), 0, 0, 0))
        row.addView(mid, Ui.lp(0, Ui.MATCH, 1f))
        row.addView(navButton(IconKind.CHEVRON_RIGHT) { next() }, Ui.lp(Ui.dp(context, 36), Ui.MATCH))
        return row
    }

    private fun navButton(kind: IconKind, onClick: () -> Unit): View = IconView(context, kind, theme.textPrimary).apply {
        fillFraction = 0.55f
        isClickable = true
        isFocusable = true
        setOnClickListener { onClick() }
    }

    private fun refreshNav() {
        dots.forEachIndexed { i, d ->
            d.background = Ui.rounded(
                if (i == current) theme.accent else HudThemes.withAlpha(theme.textSecondary, 90),
                Ui.dpf(context, 4f)
            )
        }
        faceTitle.text = faces[current].title
        faceTitle.setTextColor(theme.accent)
    }

    // =========================================================================================
    // Shared widgets
    // =========================================================================================

    /** Equal-width chips in one row. [colors] gives a selected colour per chip (for the Green / Blue / Red tiers). */
    private inner class Chips(
        labels: List<String>,
        selected: Int,
        private val colors: List<Int>? = null,
        private val onPick: (Int) -> Unit
    ) : LinearLayout(context) {
        private val items = ArrayList<TextView>()
        private var sel = selected

        init {
            orientation = HORIZONTAL
            labels.forEachIndexed { i, text ->
                val tv = TextView(context).apply {
                    this.text = text
                    textSize = 11f
                    gravity = Gravity.CENTER
                    maxLines = 1
                    isClickable = true
                    isFocusable = true
                    setPadding(Ui.dp(context, 2), 0, Ui.dp(context, 2), 0)
                    setOnClickListener {
                        select(i)
                        onPick(i)
                    }
                }
                items += tv
                addView(tv, Ui.lp(0, Ui.dp(context, 30), 1f, Ui.dp(context, 2), 0, Ui.dp(context, 2), 0))
            }
            paint()
        }

        /** Moves the highlight without firing [onPick] (used when engine state changes elsewhere). */
        fun select(i: Int) {
            if (i == sel) return
            sel = i
            paint()
        }

        private fun paint() {
            val r = Ui.tileRadius(context, theme)
            items.forEachIndexed { i, tv ->
                val on = i == sel
                val fill = if (on) (colors?.getOrNull(i) ?: theme.accent) else theme.tile
                tv.setTextColor(if (on) HudThemes.onAccent(fill) else theme.textPrimary)
                tv.typeface = if (on) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                tv.background = Ui.rounded(fill, r, if (on) fill else theme.stroke, Ui.dp(context, 1))
            }
        }
    }

    private class SwitchRow(val root: View, val sw: Switch)

    private fun switchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit): SwitchRow {
        val row = Ui.hbox(context)
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(Ui.label(context, title, 11f, theme.textPrimary, true), Ui.lp(0, Ui.WRAP, 1f))
        val sw = Switch(context).apply {
            val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
            thumbTintList = ColorStateList(states, intArrayOf(theme.accent, theme.textSecondary))
            trackTintList = ColorStateList(
                states, intArrayOf(HudThemes.withAlpha(theme.accent, 0x80), HudThemes.withAlpha(theme.textSecondary, 0x55))
            )
            isChecked = checked
            setOnCheckedChangeListener { _, on -> onChange(on) }
        }
        row.addView(sw, Ui.lp(Ui.WRAP, Ui.WRAP))
        return SwitchRow(row, sw)
    }

    private fun smallButton(text: String, onClick: () -> Unit): TextView = TextView(context).apply {
        this.text = text
        textSize = 11f
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        maxLines = 1
        isClickable = true
        isFocusable = true
        setTextColor(theme.textPrimary)
        background = Ui.rounded(theme.tile, Ui.tileRadius(context, theme), theme.accent, Ui.dp(context, 1))
        setOnClickListener { onClick() }
    }

    private fun profile(): GameProfile = repo.profile(game) ?: repo.getOrCreate(game, game)

    private fun saveTurbo(block: (TurboConfig) -> TurboConfig) {
        repo.update(game) { it.copy(turbo = block(it.turbo)) }
    }

    // =========================================================================================
    // Faces
    // =========================================================================================

    private abstract inner class Face(val title: String, val icon: IconKind) {
        val root = FrameLayout(context)
        protected lateinit var msg: TextView

        fun rebuild() {
            root.removeAllViews()
            build()
        }

        private fun build() {
            root.background = Ui.rounded(
                HudThemes.blend(theme.panelTop, theme.tile, 0.45f),
                Ui.tileRadius(context, theme) + Ui.dpf(context, 4f), theme.accent, Ui.dp(context, 1)
            )
            val col = Ui.vbox(context)
            col.setPadding(Ui.dp(context, 10), Ui.dp(context, 8), Ui.dp(context, 10), Ui.dp(context, 8))
            val head = Ui.hbox(context)
            head.gravity = Gravity.CENTER_VERTICAL
            head.addView(IconView(context, icon, theme.accent), Ui.lp(Ui.dp(context, 18), Ui.dp(context, 18)))
            head.addView(
                Ui.label(context, title, 12f, theme.textPrimary, true).apply { letterSpacing = 0.1f },
                Ui.lp(0, Ui.WRAP, 1f, Ui.dp(context, 6), 0, 0, 0)
            )
            col.addView(head, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, 0, 0, Ui.dp(context, 6)))
            col.addView(body(), Ui.lp(Ui.MATCH, 0, 1f))
            msg = Ui.label(context, "", 10f, theme.textSecondary).apply {
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
            }
            col.addView(msg, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(context, 4), 0, 0))
            root.addView(col, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        }

        protected abstract fun body(): View
        open fun update(f: FpsEnforcerState, w: WildBoostState, s: TelemetrySample?) {}
        open fun onSample(s: TelemetrySample) {}

        protected fun report(steps: List<StepResult>) {
            val (ok, text) = GameActions.summary(steps)
            msg.setTextColor(if (ok) theme.good else theme.hot)
            msg.text = text.replace('\n', ' ')
        }

        protected fun say(ok: Boolean, text: String) {
            msg.setTextColor(if (ok) theme.good else theme.hot)
            msg.text = text
        }
    }

    // ---- Face 0: performance ----

    private inner class PerfFace : Face("PERFORMANCE", IconKind.BOLT) {
        private lateinit var tier: Chips
        private lateinit var fpsChips: Chips
        private lateinit var diablo: SwitchRow
        private lateinit var status: TextView
        private val fpsChoices = listOf(0, 90, 120, 144)

        override fun body(): View {
            val col = Ui.vbox(context)
            val t = profile().turbo
            tier = Chips(
                listOf("Eco", "Balanced", "Wild Boost"),
                when { t.nativeBatterySaver -> 0; t.wildBoost -> 2; else -> 1 },
                listOf(theme.good, theme.accent, theme.accent2)
            ) { i ->
                scope.launch {
                    val tr = PerfTier.values()[i]
                    saveTurbo { it.copy(nativeBatterySaver = tr == PerfTier.ECO, wildBoost = tr == PerfTier.WILDBOOST) }
                    // Wild Boost is one thing everywhere (see WildBoostController): engine steps, the 5-layer FPS lock and the
                    // boosters, with the ignition playing when it goes from off to on.
                    val boost = app.wildBoost
                    if (tr == PerfTier.WILDBOOST) {
                        if (!app.wild.state.value.active) boost.ignite()
                        report(boost.boostOn(game, persistMode = true))
                    } else {
                        val steps = ArrayList<StepResult>()
                        steps += boost.releaseExtras(game)      // takes back the FPS lock a Wild Boost added
                        steps += app.wild.setTier(game, tr)
                        report(steps)
                    }
                }
            }
            col.addView(tier, Ui.lp(Ui.MATCH, Ui.WRAP))

            col.addView(Ui.label(context, "FPS unlock", 10f, theme.textSecondary), Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, Ui.dp(context, 6), 0, Ui.dp(context, 2)))
            fpsChips = Chips(listOf("Off", "90", "120", "144"), fpsChoices.indexOf(t.unlockFps).coerceAtLeast(0)) { i ->
                scope.launch {
                    val v = fpsChoices[i]
                    if (v > 0) {
                        val rep = app.fps.enforce(game, v)
                        saveTurbo { it.copy(unlockFps = v) }
                        val note = if (rep.panelTooSlow) "Panel tops out at ${rep.panelHz} Hz. " else ""
                        say(rep.failures == 0 && !rep.panelTooSlow, note + "Display reports ${rep.displayHzNow} Hz, ${rep.failures} layer(s) failed")
                    } else {
                        saveTurbo { it.copy(unlockFps = 0) }
                        report(app.fps.setUnlock(game, 0))
                    }
                }
            }
            col.addView(fpsChips, Ui.lp(Ui.MATCH, Ui.WRAP))

            diablo = switchRow("Diablo mode", t.diablo) { on ->
                scope.launch {
                    saveTurbo { it.copy(diablo = on) }
                    if (app.wild.state.value.active) {
                        val steps = ArrayList<StepResult>()
                        steps += app.wild.deactivate(game)
                        steps += app.wild.activate(game, on)
                        report(steps)
                    } else {
                        say(true, if (on) "Diablo saved. It starts with Wild Boost." else "Diablo off")
                    }
                }
            }
            col.addView(diablo.root, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(context, 6), 0, 0))
            status = Ui.label(context, "", 10f, theme.textSecondary)
            col.addView(status, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(context, 4), 0, 0))
            return col
        }

        override fun update(f: FpsEnforcerState, w: WildBoostState, s: TelemetrySample?) {
            tier.select(w.tier.ordinal)
            fpsChips.select(fpsChoices.indexOf(f.targetFps).coerceAtLeast(0))
            if (diablo.sw.isChecked != w.diablo && w.active) diablo.sw.isChecked = w.diablo
            status.text = buildString {
                append(w.tier.label)
                if (w.active) append(if (w.diablo) "  |  Diablo on" else "  |  Wild Boost on")
                if (f.lockedHz > 0) append("  |  lock ${f.lockedHz} Hz")
                if (f.reapplyCount > 0) append("  |  fixed ${f.reapplyCount}x")
            }
            w.busy?.let { status.text = it }
        }
    }

    // ---- Face 1: thermal ----

    private inner class ThermalFace : Face("THERMAL", IconKind.FAN) {
        private lateinit var turbine: TurbineView
        private lateinit var rpm: TextView
        private lateinit var temp: TextView
        private lateinit var fanChips: Chips
        private val modes = FanMode.values().toList()

        override fun body(): View {
            val col = Ui.vbox(context)
            val top = Ui.hbox(context)
            top.gravity = Gravity.CENTER_VERTICAL
            turbine = TurbineView(context)
            top.addView(turbine, Ui.lp(Ui.dp(context, 62), Ui.dp(context, 62)))
            val info = Ui.vbox(context)
            rpm = Ui.label(context, "Fan off", 13f, theme.textPrimary, true)
            temp = Ui.label(context, "", 10f, theme.textSecondary)
            info.addView(rpm)
            info.addView(temp, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, Ui.dp(context, 2), 0, 0))
            top.addView(info, Ui.lp(0, Ui.WRAP, 1f, Ui.dp(context, 10), 0, 0, 0))
            col.addView(top, Ui.lp(Ui.MATCH, Ui.WRAP))

            fanChips = Chips(listOf("Off", "Auto", "Smart", "Max"), modes.indexOf(profile().turbo.fan).coerceAtLeast(0)) { i ->
                scope.launch { report(app.wild.setFan(game, modes[i])) }
            }
            col.addView(fanChips, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(context, 6), 0, 0))

            val btns = Ui.hbox(context)
            btns.addView(smallButton("Spin-up sound") {
                scope.launch { val r = app.wild.playTurbineSpinUp(); say(r.ok, r.detail.ifBlank { r.step }) }
            }, Ui.lp(0, Ui.dp(context, 30), 1f, Ui.dp(context, 2), 0, Ui.dp(context, 2), 0))
            btns.addView(smallButton("Eject pulse") {
                scope.launch { val r = app.wild.playSonicEject(); say(r.ok, r.detail.ifBlank { r.step }) }
            }, Ui.lp(0, Ui.dp(context, 30), 1f, Ui.dp(context, 2), 0, Ui.dp(context, 2), 0))
            col.addView(btns, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(context, 6), 0, 0))
            return col
        }

        override fun update(f: FpsEnforcerState, w: WildBoostState, s: TelemetrySample?) {
            turbine.rpm = w.fanRpm
            fanChips.select(modes.indexOf(w.fanMode).coerceAtLeast(0))
            rpm.text = if (w.fanMode == FanMode.OFF) "Fan off" else String.format(Locale.US, "%,d RPM", w.fanRpm)
            temp.text = String.format(Locale.US, "Battery %.1f C  |  %s", w.batteryTempC, w.fanMode.label)
            temp.setTextColor(if (w.thermalTripped) theme.hot else theme.textSecondary)
            if (w.thermalTripped) msg.text = w.thermalNote
        }
    }

    // ---- Face 2: power ----

    private inner class PowerFace : Face("POWER", IconKind.PLUG) {
        private lateinit var charge: SwitchRow
        private lateinit var saver: SwitchRow
        private lateinit var floor: Chips
        private lateinit var stat: TextView
        private val floors = listOf(20, 30, 40, 50)
        private var syncing = false

        override fun body(): View {
            val col = Ui.vbox(context)
            val t = profile().turbo
            charge = switchRow("Charge separation", t.chargeSeparation) { on ->
                if (syncing) return@switchRow
                scope.launch {
                    val cur = profile().turbo
                    if (on) {
                        val st = app.wild.setChargeSeparation(true, cur.chargeFloorPct, cur.softwareUnplugFallback, game)
                        say(st.on || st.wanted, st.detail.ifBlank { "armed" })
                    } else {
                        val st = app.wild.disableChargeSeparation(game)
                        say(true, st.detail.ifBlank { "charging restored" })
                    }
                }
            }
            col.addView(charge.root)
            col.addView(Ui.label(context, "Resume charging below", 10f, theme.textSecondary), Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, Ui.dp(context, 2), 0, Ui.dp(context, 2)))
            floor = Chips(floors.map { "$it%" }, floors.indexOf(t.chargeFloorPct).coerceAtLeast(0)) { i ->
                scope.launch {
                    val v = floors[i]
                    saveTurbo { it.copy(chargeFloorPct = v) }
                    if (app.wild.state.value.chargeSeparation.wanted) {
                        val cur = profile().turbo
                        app.wild.setChargeSeparation(true, v, cur.softwareUnplugFallback, game)
                    }
                }
            }
            col.addView(floor, Ui.lp(Ui.MATCH, Ui.WRAP))
            saver = switchRow("Battery Saver", app.wild.state.value.batterySaverOn) { on ->
                if (syncing) return@switchRow
                scope.launch {
                    saveTurbo { it.copy(nativeBatterySaver = on, wildBoost = if (on) false else it.wildBoost) }
                    report(app.wild.setBatterySaver(on, game))
                }
            }
            col.addView(saver.root, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(context, 4), 0, 0))
            stat = Ui.label(context, "", 10f, theme.textSecondary)
            col.addView(stat, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(context, 4), 0, 0))
            col.addView(smallButton("Clean RAM now") {
                scope.launch {
                    val c = app.wild.cleanRam(game)
                    say(true, "RAM ${c.availBeforeMb} to ${c.availAfterMb} MB free (${c.reclaimedMb} MB)")
                }
            }, Ui.lp(Ui.MATCH, Ui.dp(context, 30), 0f, 0, Ui.dp(context, 4), 0, 0))
            return col
        }

        override fun update(f: FpsEnforcerState, w: WildBoostState, s: TelemetrySample?) {
            syncing = true
            val cs = w.chargeSeparation
            if (charge.sw.isChecked != (cs.on || cs.wanted)) charge.sw.isChecked = cs.on || cs.wanted
            if (saver.sw.isChecked != w.batterySaverOn) saver.sw.isChecked = w.batterySaverOn
            syncing = false
            floor.select(floors.indexOf(profile().turbo.chargeFloorPct).coerceAtLeast(0))
            if (cs.detail.isNotBlank()) {
                msg.setTextColor(if (cs.on && !cs.hardware) theme.warn else theme.textSecondary)
                msg.text = cs.detail
            }
            s?.let { onSample(it) }
        }

        override fun onSample(s: TelemetrySample) {
            if (!::stat.isInitialized) return
            val watts = if (s.powerW >= 0f) String.format(Locale.US, "%.1f W", s.powerW) else "n/a"
            stat.text = "Battery ${s.batteryPct}%" + (if (s.charging) " charging" else "") + "  |  " + watts +
                String.format(Locale.US, "  |  %.1f C", s.batteryTempC)
        }
    }

    // ---- Face 3: display ----

    private inner class DisplayFace : Face("DISPLAY", IconKind.DISPLAY) {
        private lateinit var info: TextView
        private lateinit var smooth: SwitchRow
        private lateinit var bfi: Chips
        private lateinit var res: Chips
        private val bfiChoices = listOf(0, 15, 30, 45)
        private val resChoices = listOf(100, 90, 80, 70, 60, 50)
        private var syncing = false

        override fun body(): View {
            val col = Ui.vbox(context)
            val t = profile().turbo
            val p = profile()
            info = Ui.label(context, "", 10f, theme.textSecondary)
            col.addView(info)
            smooth = switchRow("Motion smoothing", t.motionSmoothing) { on ->
                if (syncing) return@switchRow
                scope.launch {
                    saveTurbo { it.copy(motionSmoothing = on) }
                    report(app.fps.setMotionSmoothing(game, on, profile().turbo.bfiPct))
                }
            }
            col.addView(smooth.root, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(context, 4), 0, 0))
            col.addView(Ui.label(context, "Black-frame insertion", 10f, theme.textSecondary), Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, Ui.dp(context, 2), 0, Ui.dp(context, 2)))
            bfi = Chips(listOf("Off", "15%", "30%", "45%"), bfiChoices.indexOf(t.bfiPct).coerceAtLeast(0)) { i ->
                scope.launch {
                    val v = bfiChoices[i]
                    saveTurbo { it.copy(bfiPct = v) }
                    if (profile().turbo.motionSmoothing) report(app.fps.setMotionSmoothing(game, true, v))
                    else say(true, "Saved. Turn Motion smoothing on to use it.")
                }
            }
            col.addView(bfi, Ui.lp(Ui.MATCH, Ui.WRAP))
            col.addView(Ui.label(context, "Render resolution", 10f, theme.textSecondary), Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, Ui.dp(context, 6), 0, Ui.dp(context, 2)))
            val cur = ((p.downscale ?: 1f) * 100f).toInt()
            res = Chips(resChoices.map { "$it" }, resChoices.indexOfFirst { it == cur }.let { if (it < 0) 0 else it }) { i ->
                scope.launch {
                    val v = resChoices[i]
                    val ds: Float? = if (v >= 100) null else v / 100f
                    repo.update(game) { it.copy(downscale = ds) }
                    val pr = profile()
                    report(app.engine.setGameTuning(game, pr.gameMode, ds, pr.targetFps, pr.fpsCapViaDisplay, pr.refreshHz))
                }
            }
            col.addView(res, Ui.lp(Ui.MATCH, Ui.WRAP))
            return col
        }

        override fun update(f: FpsEnforcerState, w: WildBoostState, s: TelemetrySample?) {
            val rates = app.engine.supportedRefreshRates()
            info.text = (if (rates.isEmpty()) "Panel modes unreadable" else "Panel " + rates.joinToString("/") + " Hz") +
                "  |  lock " + (if (f.lockedHz > 0) "${f.lockedHz} Hz" else "off") + "  |  now ${f.displayHzNow} Hz"
            syncing = true
            val ms = profile().turbo.motionSmoothing
            if (smooth.sw.isChecked != ms) smooth.sw.isChecked = ms
            syncing = false
            bfi.select(bfiChoices.indexOf(profile().turbo.bfiPct).coerceAtLeast(0))
        }
    }
}
