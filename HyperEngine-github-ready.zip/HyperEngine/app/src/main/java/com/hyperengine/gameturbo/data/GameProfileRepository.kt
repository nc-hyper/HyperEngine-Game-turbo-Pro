package com.hyperengine.gameturbo.data

import android.content.Context
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.hyperengine.gameturbo.core.Validators
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors

/** On-disk shape of profiles.json */
data class ProfileStore(
    val version: Int = 1,
    val profiles: LinkedHashMap<String, GameProfile> = LinkedHashMap()
)

/** Full backup file (profiles + global settings). */
data class BackupBundle(
    val version: Int = 1,
    val profiles: LinkedHashMap<String, GameProfile> = LinkedHashMap(),
    val global: GlobalSettings = GlobalSettings(),
    // Added in Phase 1 completion: saved Auto-Touch / Command layouts (older backups simply lack them)
    val scripts: LinkedHashMap<String, List<AutoTouchScript>> = LinkedHashMap(),
    val activeScripts: LinkedHashMap<String, String> = LinkedHashMap()
)

/**
 * JSON persistence (no Room/kapt, so it builds on-device in CodeAssist).
 * Files live in the app's private storage:
 *   profiles.json  - per-game profiles
 *   scripts.json   - named Auto-Touch / Command layouts per game package
 *   global.json    - theme, sidebar, handle, freeze list, thresholds
 *   snapshot.json  - original system state for automatic restoration
 * Writes are atomic (temp file + rename) and serialized on one thread.
 */
class GameProfileRepository(context: Context) {

    private val dir: File = context.applicationContext.filesDir
    private val gson: Gson = GsonBuilder().setPrettyPrinting().create()
    private val compactGson: Gson = Gson()   // recorded macros hold thousands of events: no pretty printing
    private val scriptLock = Any()
    private val fileLock = Any()
    private val writerScope = CoroutineScope(
        SupervisorJob() + Executors.newSingleThreadExecutor { Thread(it, "hyper-store-writer") }.asCoroutineDispatcher()
    )

    private val _profiles = MutableStateFlow<Map<String, GameProfile>>(emptyMap())
    val profiles: StateFlow<Map<String, GameProfile>> = _profiles.asStateFlow()

    private val _global = MutableStateFlow(GlobalSettings())
    val global: StateFlow<GlobalSettings> = _global.asStateFlow()

    private val _scripts = MutableStateFlow(ScriptStore())

    /** Every saved Auto-Touch layout, keyed by game package. Observe it to refresh a layout picker. */
    val scriptStore: StateFlow<ScriptStore> = _scripts.asStateFlow()

    init {
        _profiles.value = readJson("profiles.json", ProfileStore::class.java)?.profiles ?: emptyMap()
        _global.value = (readJson("global.json", GlobalSettings::class.java) ?: GlobalSettings()).migrated()
        _scripts.value = loadScripts()
    }

    // ── profiles ──

    fun profile(pkg: String): GameProfile? = _profiles.value[pkg]

    fun getOrCreate(pkg: String, label: String): GameProfile {
        _profiles.value[pkg]?.let { return it }
        // Same rule as upsert: a name that is not a package is never stored. The caller still gets a usable profile.
        if (!Validators.PACKAGE.matches(pkg)) return GameProfile(packageName = pkg, label = label)
        val created = GameProfile(packageName = pkg, label = label, updatedAt = System.currentTimeMillis())
        _profiles.update { if (it.containsKey(pkg)) it else it + (pkg to created) }
        persistProfiles()
        return _profiles.value.getValue(pkg)
    }

    fun upsert(profile: GameProfile) {
        if (!Validators.PACKAGE.matches(profile.packageName)) return
        val stamped = profile.copy(updatedAt = System.currentTimeMillis())
        _profiles.update { it + (stamped.packageName to stamped) }
        persistProfiles()
    }

    fun update(pkg: String, transform: (GameProfile) -> GameProfile) {
        _profiles.update { map ->
            val cur = map[pkg] ?: return@update map
            map + (pkg to transform(cur).copy(packageName = pkg, updatedAt = System.currentTimeMillis()))
        }
        persistProfiles()
    }

    fun delete(pkg: String) {
        _profiles.update { it - pkg }
        persistProfiles()
    }

    // ── Auto-Touch / Command layouts (per game package) ──

    /** All layouts saved for a game, oldest first. */
    fun scripts(pkg: String): List<AutoTouchScript> = _scripts.value.scripts[pkg].orEmpty()

    fun script(pkg: String, id: String): AutoTouchScript? = scripts(pkg).firstOrNull { it.id == id }

    /** The layout that auto-loads when the game starts: the one the user picked last, else the first. */
    fun activeScript(pkg: String): AutoTouchScript? {
        val id = _scripts.value.active[pkg]
        return scripts(pkg).firstOrNull { it.id == id } ?: scripts(pkg).firstOrNull()
    }

    /** Creates an empty layout. Returns null for an invalid package or when the per-game limit is reached. */
    fun createScript(pkg: String, name: String): AutoTouchScript? = synchronized(scriptLock) {
        if (!Validators.PACKAGE.matches(pkg)) return@synchronized null
        val existing = scripts(pkg)
        if (existing.size >= AutoTouchScript.MAX_PER_GAME) return@synchronized null
        val now = System.currentTimeMillis()
        val created = AutoTouchScript(
            id = newScriptId(), name = uniqueName(existing, name.ifBlank { "Layout" }),
            packageName = pkg, createdAt = now, updatedAt = now
        ).sanitized()
        commitScripts(pkg, existing + created, activeId = created.id)
        created
    }

    /** Inserts or replaces a layout (matched by id). Values are clamped to their legal ranges. */
    fun saveScript(script: AutoTouchScript): Boolean = synchronized(scriptLock) {
        if (!Validators.PACKAGE.matches(script.packageName) || script.id.isBlank()) return@synchronized false
        val existing = scripts(script.packageName)
        val clean = script.copy(updatedAt = System.currentTimeMillis()).sanitized()
        val i = existing.indexOfFirst { it.id == clean.id }
        if (i < 0 && existing.size >= AutoTouchScript.MAX_PER_GAME) return@synchronized false
        val next = if (i >= 0) existing.toMutableList().also { it[i] = clean } else existing + clean
        commitScripts(script.packageName, next, activeId = null)
        true
    }

    fun renameScript(pkg: String, id: String, newName: String): Boolean = synchronized(scriptLock) {
        val s = script(pkg, id) ?: return@synchronized false
        val others = scripts(pkg).filter { it.id != id }
        saveScript(s.copy(name = uniqueName(others, newName.ifBlank { s.name })))
    }

    fun duplicateScript(pkg: String, id: String): AutoTouchScript? = synchronized(scriptLock) {
        val s = script(pkg, id) ?: return@synchronized null
        val existing = scripts(pkg)
        if (existing.size >= AutoTouchScript.MAX_PER_GAME) return@synchronized null
        val now = System.currentTimeMillis()
        val copy = s.copy(
            id = newScriptId(), name = uniqueName(existing, s.name + " copy"), createdAt = now, updatedAt = now,
            macros = s.macros.map { it.copy(id = newScriptId()) }
        ).sanitized()
        commitScripts(pkg, existing + copy, activeId = copy.id)
        copy
    }

    fun deleteScript(pkg: String, id: String) {
        synchronized(scriptLock) {
            val next = scripts(pkg).filter { it.id != id }
            val wasActive = _scripts.value.active[pkg] == id
            commitScripts(pkg, next, activeId = if (wasActive) (next.firstOrNull()?.id ?: "") else null)
        }
    }

    fun setActiveScript(pkg: String, id: String) {
        synchronized(scriptLock) {
            if (script(pkg, id) != null) {
                commitScripts(pkg, scripts(pkg), activeId = id)
            }
        }
    }

    /** Removes every layout of one game (used when a game is removed from the Game Space). */
    fun deleteScriptsFor(pkg: String) {
        synchronized(scriptLock) { commitScripts(pkg, emptyList(), activeId = "") }
    }

    private fun newScriptId(): String = java.util.UUID.randomUUID().toString().replace("-", "").take(12)

    private fun uniqueName(existing: List<AutoTouchScript>, wanted: String): String {
        val base = wanted.trim().take(AutoTouchScript.MAX_NAME).ifBlank { "Layout" }
        val taken = existing.map { it.name.lowercase() }.toSet()
        if (base.lowercase() !in taken) return base
        var n = 2
        while (true) {
            val suffix = " $n"
            val candidate = base.take(AutoTouchScript.MAX_NAME - suffix.length) + suffix
            if (candidate.lowercase() !in taken) return candidate
            n++
        }
    }

    /** activeId: null = keep, "" = clear, else set. Empty layout lists remove the package key. */
    private fun commitScripts(pkg: String, list: List<AutoTouchScript>, activeId: String?) {
        val cur = _scripts.value
        val scripts = LinkedHashMap(cur.scripts)
        val active = LinkedHashMap(cur.active)
        if (list.isEmpty()) scripts.remove(pkg) else scripts[pkg] = list
        when {
            activeId == null -> {}
            activeId.isEmpty() -> active.remove(pkg)
            else -> active[pkg] = activeId
        }
        val next = ScriptStore(scripts = scripts, active = active)
        _scripts.value = next
        writerScope.launch { writeAtomic("scripts.json", compactGson.toJson(next)) }
    }

    private fun loadScripts(): ScriptStore {
        val raw = readJson("scripts.json", ScriptStore::class.java, compactGson) ?: return ScriptStore()
        // Runs in init: a null that Gson let through from a damaged file must not crash the app on every launch.
        return try {
            val rawScripts: Map<String, List<AutoTouchScript?>?>? = raw.scripts
            val rawActive: Map<String, String?>? = raw.active
            val scripts = LinkedHashMap<String, List<AutoTouchScript>>()
            rawScripts?.forEach { (pkg, list) ->
                if (list != null && Validators.PACKAGE.matches(pkg)) {
                    scripts[pkg] = list.filterNotNull().filter { it.id.isNotBlank() }.take(AutoTouchScript.MAX_PER_GAME)
                        .map { it.copy(packageName = pkg).sanitized() }
                }
            }
            val active = LinkedHashMap<String, String>()
            rawActive?.forEach { (pkg, id) -> if (id != null && pkg in scripts) active[pkg] = id }
            ScriptStore(scripts = scripts, active = active)
        } catch (_: Throwable) {
            ScriptStore()
        }
    }

    // ── global settings ──

    fun updateGlobal(transform: (GlobalSettings) -> GlobalSettings) {
        _global.update(transform)
        val snapshot = _global.value
        writerScope.launch { writeAtomic("global.json", gson.toJson(snapshot)) }
    }

    fun addToFreezeList(pkg: String) {
        if (!Validators.PACKAGE.matches(pkg)) return
        updateGlobal { g -> if (pkg in g.freezeList) g else g.copy(freezeList = g.freezeList + pkg) }
    }

    fun removeFromFreezeList(pkg: String) = updateGlobal { it.copy(freezeList = it.freezeList - pkg) }

    // ── restore snapshot (synchronous on purpose: must hit disk before system changes) ──

    fun saveSnapshotBlocking(snapshot: SystemSnapshot) {
        writeAtomic("snapshot.json", gson.toJson(snapshot))
    }

    fun loadSnapshot(): SystemSnapshot? = readJson("snapshot.json", SystemSnapshot::class.java)

    fun clearSnapshot() {
        synchronized(fileLock) { File(dir, "snapshot.json").delete() }
    }

    // ── backup / restore of the whole configuration ──

    fun exportJson(): String =
        gson.toJson(
            BackupBundle(
                profiles = LinkedHashMap(_profiles.value), global = _global.value,
                scripts = LinkedHashMap(_scripts.value.scripts), activeScripts = LinkedHashMap(_scripts.value.active)
            )
        )

    /**
     * Replaces the saved profiles, global settings and layouts with the ones in a backup. Returns the number of profiles
     * imported, or -1 when the text is not a valid backup.
     *
     * All-or-nothing: everything is read, cleaned and turned back into JSON before anything live is touched, so a bad
     * backup leaves the current profiles exactly as they were. A section the backup does not contain (older backups have
     * no layouts) is left as it is instead of being wiped.
     */
    fun importJson(text: String): Int {
        return try {
            val b = gson.fromJson(text, BackupBundle::class.java) ?: return -1
            // Gson fills a missing or null key with null even for a non-null Kotlin field, so read them as nullable.
            val rawProfiles: Map<String, GameProfile?>? = b.profiles
            val rawGlobal: GlobalSettings? = b.global
            val rawScripts: Map<String, List<AutoTouchScript?>?>? = b.scripts
            val rawActive: Map<String, String?>? = b.activeScripts
            if (rawProfiles == null && rawGlobal == null && rawScripts == null) return -1

            // ---- prepare (nothing live is changed in this part) ----
            val cleanProfiles: LinkedHashMap<String, GameProfile>? = rawProfiles?.let { raw ->
                val out = LinkedHashMap<String, GameProfile>()
                raw.forEach { (pkg, profile) ->
                    if (profile != null && Validators.PACKAGE.matches(pkg)) out[pkg] = profile.copy(packageName = pkg)
                }
                out
            }
            val profilesJson = cleanProfiles?.let { gson.toJson(ProfileStore(profiles = it)) }

            val importedGlobal: GlobalSettings? = rawGlobal?.migrated()
            val globalJson = importedGlobal?.let { gson.toJson(it) }

            val nextScripts: ScriptStore? = rawScripts?.let { raw ->
                val scripts = LinkedHashMap<String, List<AutoTouchScript>>()
                raw.forEach { (pkg, list) ->
                    if (list != null && Validators.PACKAGE.matches(pkg)) {
                        scripts[pkg] = list.filterNotNull().filter { it.id.isNotBlank() }
                            .take(AutoTouchScript.MAX_PER_GAME)
                            .map { it.copy(packageName = pkg).sanitized() }
                    }
                }
                val active = LinkedHashMap<String, String>()
                rawActive?.forEach { (pkg, id) -> if (id != null && pkg in scripts) active[pkg] = id }
                ScriptStore(scripts = scripts, active = active)
            }
            val scriptsJson = nextScripts?.let { compactGson.toJson(it) }

            // ---- commit (only plain assignments and queued writes: nothing here parses or can reject the backup) ----
            if (cleanProfiles != null && profilesJson != null) {
                _profiles.value = cleanProfiles
                writerScope.launch { writeAtomic("profiles.json", profilesJson) }
            }
            if (importedGlobal != null && globalJson != null) {
                _global.value = importedGlobal
                writerScope.launch { writeAtomic("global.json", globalJson) }
            }
            if (nextScripts != null && scriptsJson != null) {
                synchronized(scriptLock) {
                    _scripts.value = nextScripts
                    writerScope.launch { writeAtomic("scripts.json", scriptsJson) }
                }
            }
            cleanProfiles?.size ?: 0
        } catch (_: Throwable) {
            -1
        }
    }

    // ── internals ──

    private fun persistProfiles() {
        val store = ProfileStore(profiles = LinkedHashMap(_profiles.value))
        writerScope.launch { writeAtomic("profiles.json", gson.toJson(store)) }
    }

    private fun writeAtomic(name: String, text: String) {
        synchronized(fileLock) {
            val target = File(dir, name)
            val tmp = File(dir, "$name.tmp")
            FileOutputStream(tmp).use { out ->
                out.write(text.toByteArray(Charsets.UTF_8))
                out.fd.sync()
            }
            if (!tmp.renameTo(target)) {
                target.delete()
                tmp.renameTo(target)
            }
        }
    }

    private fun <T> readJson(name: String, type: Class<T>, reader: Gson = gson): T? = synchronized(fileLock) {
        val f = File(dir, name)
        if (!f.exists()) return@synchronized null
        try {
            reader.fromJson(f.readText(Charsets.UTF_8), type)
        } catch (_: Throwable) {
            // keep the unreadable file for manual recovery instead of silently losing it
            f.renameTo(File(dir, "$name.bad"))
            null
        }
    }
}
