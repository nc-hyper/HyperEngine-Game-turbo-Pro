package com.hyperengine.gameturbo.core

import android.app.Activity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/**
 * Window mode for the app's own screens (Game Space hub, diagnostics). The app is portrait only, so the
 * system bars stay visible and the content sits between them: the status bar shows the clock and
 * battery, and the navigation bar keeps back / home reachable with one hand. The name is kept from the
 * old landscape console mode so every caller stays unchanged.
 *
 * Call [apply] from onCreate and again from onWindowFocusChanged(true): it brings the bars back if an
 * earlier version of the app, a dialog or a video player had hidden them.
 */
object ConsoleWindow {

    /**
     * Part 9: runs this screen at the panel's highest refresh rate (144 / 120 / 90 Hz, whatever the display offers at its
     * current resolution) instead of letting the ROM drop a plain app window to 60 Hz. Binds the window to
     * [MaxPanelHzEngine] (preferredDisplayModeId + preferredRefreshRate, re-stamped if the display mode changes) and to
     * [HardwareFrameSmoother] (sustained-performance mode where supported). Pass [sustained] = false while a benchmark
     * boost is on, because sustained mode trades peak clocks for steady ones. Call from onCreate. Needs no privileges.
     */
    fun lockPanel(activity: Activity, sustained: Boolean = true) {
        runCatching { MaxPanelHzEngine.from(activity).bindWindow(activity.window) }
        runCatching { HardwareFrameSmoother.from(activity).bindWindow(activity.window, sustained) }
    }

    fun unlockPanel(activity: Activity) {
        runCatching { MaxPanelHzEngine.from(activity).unbindWindow(activity.window) }
    }

    fun apply(activity: Activity) {
        runCatching {
            val window = activity.window
            WindowCompat.setDecorFitsSystemWindows(window, true)
            val controller = WindowInsetsControllerCompat(window, window.decorView)
            controller.show(WindowInsetsCompat.Type.systemBars())
        }
    }
}
