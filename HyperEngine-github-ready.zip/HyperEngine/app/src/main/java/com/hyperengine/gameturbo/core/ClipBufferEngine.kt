package com.hyperengine.gameturbo.core

import android.content.ContentValues
import android.content.Context
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.projection.MediaProjection
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Environment
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.Surface
import android.view.WindowManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/**
 * Rolling clip buffer. The screen is encoded all the time by the hardware H.264 encoder into a
 * RAM ring buffer that keeps only the last [windowSec] seconds; nothing touches the disk until [save], which muxes
 * the buffer to Movies/HyperEngine_Clips. The ring always starts on a keyframe (1 s apart), so a saved clip is
 * between windowSec and windowSec + 1 s long.
 *
 * Limits: video only (no game audio); the capture is scaled to at most 1280 px on the long side at 6 Mbps, so 60 s
 * is about 45 MB of RAM; games that mark themselves secure record black; the capture size is fixed when it starts,
 * so rotate-then-restart if the orientation changes.
 */
class ClipBufferEngine(context: Context) {

    private class Frame(val data: ByteArray, val ptsUs: Long, val flags: Int)

    private val ctx = context.applicationContext
    private val lock = Any()
    private val ring = ArrayDeque<Frame>()

    @Volatile private var windowUs = 30_000_000L
    @Volatile private var outFormat: MediaFormat? = null
    @Volatile private var live = false
    private var codec: MediaCodec? = null
    private var display: VirtualDisplay? = null
    private var inputSurface: Surface? = null
    private var worker: Thread? = null

    private val _running = MutableStateFlow(false)
    val running: StateFlow<Boolean> = _running.asStateFlow()
    private val _bufferedSec = MutableStateFlow(0)
    val bufferedSec: StateFlow<Int> = _bufferedSec.asStateFlow()

    private class Enc(val codec: MediaCodec, val surface: Surface, val w: Int, val h: Int)

    private var proj: MediaProjection? = null
    private var screenW = 0
    private var screenH = 0
    private var screenDpi = 0
    private val dm = ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
    private val main = Handler(Looper.getMainLooper())
    private var listener: DisplayManager.DisplayListener? = null

    /** Encoder (re)opening and codec shutdown are slow (100-500 ms); they must never run on the main thread. */
    private val ctl = java.util.concurrent.Executors.newSingleThreadExecutor { r ->
        Thread(r, "hyper-replay-ctl").apply { isDaemon = true }
    }

    /** A rotation produces a burst of display-changed events: look at the size once, shortly after the burst. */
    private val rotationCheck = Runnable {
        if (!live) return@Runnable
        val m = realMetrics()
        if (m.widthPixels == screenW && m.heightPixels == screenH) return@Runnable
        ctl.execute { reopen(m) }
    }

    private fun realMetrics(): DisplayMetrics {
        val m = DisplayMetrics()
        @Suppress("DEPRECATION")
        (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(m)
        return m
    }

    /**
     * Opens a hardware H.264 encoder for a screen of [sw] x [sh]. Some devices reject the first size they are asked for
     * (alignment, size or bitrate limits), which used to make the buffer fail to start in the middle of a game, so it asks
     * the codec what it supports and steps down 1280 -> 960 -> 720 px on the long side until one configures.
     */
    private fun openEncoder(sw: Int, sh: Int): Enc? {
        for (cap in intArrayOf(1280, 960, 720)) {
            var c: MediaCodec? = null
            try {
                val k = min(1f, cap.toFloat() / max(sw, sh))
                var w = (sw * k).toInt()
                var h = (sh * k).toInt()
                c = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
                var bitrate = 6_000_000
                try {
                    val vc = c.codecInfo.getCapabilitiesForType(MediaFormat.MIMETYPE_VIDEO_AVC).videoCapabilities
                    val wa = vc.widthAlignment.coerceAtLeast(2)
                    val ha = vc.heightAlignment.coerceAtLeast(2)
                    w -= w % wa
                    h -= h % ha
                    if (!vc.isSizeSupported(w, h)) { c.release(); continue }
                    bitrate = vc.bitrateRange.clamp(bitrate)
                } catch (_: Throwable) {
                    w = w and 1.inv(); h = h and 1.inv()
                }
                val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h).apply {
                    setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                    setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
                    setInteger(MediaFormat.KEY_FRAME_RATE, 60)
                    setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
                    // A still screen produces no frames at all, so no keyframes either; repeating keeps the ring cut points regular.
                    runCatching { setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 500_000L) }
                }
                c.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                val surf = c.createInputSurface()
                c.start()
                return Enc(c, surf, w, h)
            } catch (_: Throwable) {
                runCatching { c?.release() }
            }
        }
        return null
    }

    @Synchronized
    fun start(projection: MediaProjection, windowSec: Int): Boolean {
        if (live) { windowUs = windowSec.coerceIn(5, 60) * 1_000_000L; return true }
        return try {
            windowUs = windowSec.coerceIn(5, 60) * 1_000_000L
            val m = realMetrics()
            screenW = m.widthPixels; screenH = m.heightPixels; screenDpi = m.densityDpi
            val enc = openEncoder(screenW, screenH) ?: error("no H.264 encoder accepted this screen size")
            codec = enc.codec; inputSurface = enc.surface
            proj = projection
            display = projection.createVirtualDisplay(
                "hyper-replay", enc.w, enc.h, screenDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, enc.surface, null, null
            )
            synchronized(lock) { ring.clear() }
            outFormat = null
            live = true
            worker = Thread({ drain(enc.codec) }, "hyper-replay").also { it.start() }
            watchRotation()
            _running.value = true
            true
        } catch (t: Throwable) {
            teardown()
            false
        }
    }

    /**
     * The capture size used to be fixed when the buffer started. A game that opens in landscape after the buffer was
     * started from the portrait lobby was recorded as a tiny letterboxed picture. Now a size or rotation change re-opens
     * the encoder at the new size on the SAME virtual display (Android 14 allows one display per projection), and the ring
     * restarts, because clips cannot mix two sizes.
     */
    private fun watchRotation() {
        val l = object : DisplayManager.DisplayListener {
            override fun onDisplayAdded(displayId: Int) {}
            override fun onDisplayRemoved(displayId: Int) {}
            override fun onDisplayChanged(displayId: Int) {
                if (displayId != android.view.Display.DEFAULT_DISPLAY || !live) return
                main.removeCallbacks(rotationCheck)
                main.postDelayed(rotationCheck, 250L)
            }
        }
        listener = l
        dm.registerDisplayListener(l, main)
    }

    @Synchronized
    private fun reopen(m: DisplayMetrics) {
        if (!live) return
        val vd = display ?: return
        val enc = openEncoder(m.widthPixels, m.heightPixels) ?: return
        val old = codec
        val oldSurface = inputSurface
        try {
            vd.resize(enc.w, enc.h, m.densityDpi)
            vd.surface = enc.surface
        } catch (t: Throwable) {
            runCatching { enc.codec.stop() }; runCatching { enc.codec.release() }; runCatching { enc.surface.release() }
            return
        }
        screenW = m.widthPixels; screenH = m.heightPixels; screenDpi = m.densityDpi
        synchronized(lock) { ring.clear() }
        outFormat = null
        codec = enc.codec; inputSurface = enc.surface      // the old drain thread sees codec !== its own and exits
        _bufferedSec.value = 0
        runCatching { old?.stop() }; runCatching { old?.release() }; runCatching { oldSurface?.release() }
        worker = Thread({ drain(enc.codec) }, "hyper-replay").also { it.start() }
    }

    @Synchronized
    fun stop() = teardown()

    private fun teardown() {
        live = false
        main.removeCallbacks(rotationCheck)
        listener?.let { runCatching { dm.unregisterDisplayListener(it) } }
        listener = null
        // The drain loop wakes every 100 ms and sees live == false; do not hold the caller (often the main thread) longer.
        runCatching { worker?.join(200) }
        worker = null
        runCatching { display?.release() }; display = null
        runCatching { codec?.stop() }
        runCatching { codec?.release() }; codec = null
        runCatching { inputSurface?.release() }; inputSurface = null
        proj = null
        synchronized(lock) { ring.clear() }
        _bufferedSec.value = 0
        _running.value = false
    }

    private fun drain(c: MediaCodec) {
        val info = MediaCodec.BufferInfo()
        try {
            while (live && codec === c) {
                val i = c.dequeueOutputBuffer(info, 100_000)
                when {
                    i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> outFormat = c.outputFormat
                    i >= 0 -> {
                        val buf = c.getOutputBuffer(i)
                        val keep = buf != null && info.size > 0 && (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0
                        if (keep) {
                            buf!!.position(info.offset); buf.limit(info.offset + info.size)
                            val bytes = ByteArray(info.size); buf.get(bytes)
                            synchronized(lock) { ring.addLast(Frame(bytes, info.presentationTimeUs, info.flags)); trim() }
                        }
                        c.releaseOutputBuffer(i, false)
                    }
                }
            }
        } catch (_: Throwable) {
            // Rotation re-open and stop() stop/release the codec while this thread may be inside getOutputBuffer or
            // releaseOutputBuffer. That throws IllegalStateException, and on a plain Thread an uncaught exception
            // kills the whole app. If this codec is still the live one it really died: shut the buffer down cleanly.
            if (live && codec === c) ctl.execute { stop() }
        }
    }

    /** Drops whole keyframe groups from the front while the rest still covers the window. Caller holds [lock]. */
    private fun trim() {
        while (ring.size > 1) {
            var k = 1
            while (k < ring.size && (ring[k].flags and MediaCodec.BUFFER_FLAG_KEY_FRAME) == 0) k++
            if (k >= ring.size) break
            if (ring.last().ptsUs - ring[k].ptsUs >= windowUs) repeat(k) { ring.removeFirst() } else break
        }
        _bufferedSec.value = ((ring.last().ptsUs - ring.first().ptsUs) / 1_000_000L).toInt()
    }

    /** Muxes the buffer to Movies/HyperEngine_Clips. Returns where it went, or null if there was nothing to save. */
    suspend fun save(): String? = withContext(Dispatchers.IO) {
        val fmt = outFormat ?: return@withContext null
        val frames: List<Frame> = synchronized(lock) {
            val first = ring.indexOfFirst { (it.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0 }
            if (first < 0) emptyList() else ring.subList(first, ring.size).toList()   // copies references, not the video bytes
        }
        if (frames.size < 2) return@withContext null
        val base = frames.first().ptsUs
        val name = "HyperEngine_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        var pendingUri: android.net.Uri? = null
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, name)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/HyperEngine_Clips")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                val r = ctx.contentResolver
                val uri = r.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return@withContext null
                pendingUri = uri
                val pfd = r.openFileDescriptor(uri, "w") ?: return@withContext null
                pfd.use { mux(MediaMuxer(it.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4), fmt, frames, base) }
                values.clear(); values.put(MediaStore.Video.Media.IS_PENDING, 0)
                r.update(uri, values, null, null)
                pendingUri = null
                "Movies/HyperEngine_Clips/$name"
            } else {
                val dir = File(ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "HyperEngine_Clips").apply { mkdirs() }
                val f = File(dir, name)
                mux(MediaMuxer(f.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4), fmt, frames, base)
                f.absolutePath
            }
        } catch (_: Throwable) {
            // A failed mux used to leave an invisible, never-finished (IS_PENDING) entry behind in MediaStore.
            pendingUri?.let { u -> runCatching { ctx.contentResolver.delete(u, null, null) } }
            null
        }
    }

    private fun mux(mm: MediaMuxer, fmt: MediaFormat, frames: List<Frame>, base: Long) {
        try {
            val track = mm.addTrack(fmt)
            mm.start()
            val info = MediaCodec.BufferInfo()
            for (f in frames) {
                info.set(0, f.data.size, f.ptsUs - base, f.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME)
                mm.writeSampleData(track, ByteBuffer.wrap(f.data), info)
            }
            mm.stop()
        } finally {
            mm.release()
        }
    }
}
