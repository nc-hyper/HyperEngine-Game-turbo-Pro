package com.hyperengine.gameturbo.core

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.os.PerformanceHintManager
import android.os.PowerManager
import android.os.Process
import android.view.Choreographer
import android.view.Window
import androidx.annotation.RequiresApi
import com.hyperengine.gameturbo.HyperApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

// ───────────────────────────── Types ─────────────────────────────

/**
 * Pacing of THIS app's frames (HUD, overlays, lobby), measured from Choreographer vsync timestamps.
 * It is the stability of the display pipeline and our UI thread, not the game's own FPS: a game renders
 * in its own process, which an app cannot time.
 */
data class FrameStats(
    val running: Boolean = false,
    val periodMs: Float = 0f,        // expected frame time at the rate the display runs right now
    val avgFps: Float = 0f,
    val low1Fps: Float = 0f,         // "1% low": FPS of the slowest 1% of frames (mean of their frame times)
    val jitterMs: Float = 0f,        // standard deviation of the frame interval
    val worstMs: Float = 0f,
    val avgWorkMs: Float = 0f,       // UI-thread work per frame (animation + layout + draw recording)
    val jankPct: Float = 0f,         // frames slower than 1.5 x the period
    val stabilityPct: Float = 100f,  // frames within 1.25 x the period
    val frames: Int = 0
)

data class SmootherState(
    val engaged: Boolean = false,
    val hintSession: Boolean = false,
    val hintDetail: String = "not started",
    val targetHz: Int = 0,
    val targetNs: Long = 0L,
    val tids: List<Int> = emptyList(),
    val priorityBoosted: Boolean = false,
    val flagsApplied: Boolean = false,
    val busy: String? = null,
    val steps: List<StepResult> = emptyList()
)

// ───────────────────────────── Engine ─────────────────────────────

/**
 * Frame smoothing for the app process, using only APIs and shell commands that work on a locked bootloader.
 *
 *  1. ADPF: a `PerformanceHintManager` session on our UI thread and RenderThread, with the target work
 *     duration set to one frame at the max refresh rate (1e9 / maxHz). Every frame we report how long the
 *     UI thread really worked, so the vendor PowerHAL can raise CPU clocks BEFORE a frame is missed.
 *  2. `THREAD_PRIORITY_URGENT_DISPLAY` (-8) on the UI thread and RenderThread; restored on release.
 *  3. A Choreographer loop that measures frame pacing (avg FPS, 1% low, jitter, jank) for the HUD.
 *  4. HWUI / SurfaceFlinger flags through the existing tracked-property store (restored on release):
 *     `debug.hwui.use_hint_manager`, `debug.sf.predict_hwc_composition_strategy`, and `cmd looper_stats disable`.
 *
 * Honest limits: a hint session only covers threads of OUR process, so it smooths the HUD and lobby and does
 * not touch the game's threads. Both `debug.*` flags are read when a process starts and are already on by
 * default on recent Android, so they matter only on ROMs that turned them off. Steps 1 to 3 need no Shizuku.
 */
class HardwareFrameSmoother private constructor(
    private val ctx: Context,
    private val bridge: SystemBridgeExecutor,
    private val fps: FpsRefreshRateEnforcer
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val main = Handler(Looper.getMainLooper())
    private val mutex = Mutex()
    private val prefs = ctx.getSharedPreferences("hyper_smoother", Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(SmootherState())
    val state: StateFlow<SmootherState> = _state.asStateFlow()

    private val _stats = MutableStateFlow(FrameStats())
    val stats: StateFlow<FrameStats> = _stats.asStateFlow()

    // ── main-thread-only state ──
    private val loopOwners = LinkedHashSet<String>()
    private var choreographer: Choreographer? = null
    private var hint: HintHolder? = null
    private var targetNs = 0L
    private var renderTid: Int? = null
    private var resyncTries = 0
    private val savedPriority = HashMap<Int, Int>()

    private var lastVsyncNs = 0L
    private var frameStartNs = 0L
    private val intervalsMs = FloatArray(WINDOW)
    private val worksMs = FloatArray(WINDOW)
    private var intervalCount = 0   // valid samples, capped at WINDOW
    private var intervalIdx = 0      // next write position (wraps; never grows without bound)
    private var workCount = 0
    private var workIdx = 0
    private var lastPublishNs = 0L
    private val scratch = FloatArray(WINDOW)

    // ───────────────────── ADPF holder (kept in its own class so old Android never loads it) ─────────────────────

    @RequiresApi(Build.VERSION_CODES.S)
    private class HintHolder(private val session: PerformanceHintManager.Session) {
        fun report(ns: Long) = session.reportActualWorkDuration(ns)
        fun target(ns: Long) = session.updateTargetWorkDuration(ns)
        fun close() = session.close()
    }

    // ───────────────────── Choreographer loop ─────────────────────

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (loopOwners.isEmpty()) return
            val c = choreographer ?: return
            c.postFrameCallback(this)
            val last = lastVsyncNs
            lastVsyncNs = frameTimeNanos
            if (last != 0L) {
                val ms = (frameTimeNanos - last) / 1_000_000f
                // a pause (screen off, app in background) is not jank: drop the sample instead of recording it
                if (ms in 0.5f..250f) {
                    intervalsMs[intervalIdx] = ms
                    intervalIdx = (intervalIdx + 1) % WINDOW
                    if (intervalCount < WINDOW) intervalCount++
                }
            }
            frameStartNs = System.nanoTime()
            // Runs right after this frame's Choreographer pass (animation + traversal). Asynchronous, so a
            // sync barrier left by a pending traversal cannot delay it and inflate the measurement.
            val m = Message.obtain(main, workEnd)
            m.isAsynchronous = true
            main.sendMessageAtFrontOfQueue(m)
            if (frameTimeNanos - lastPublishNs >= PUBLISH_EVERY_NS) {
                lastPublishNs = frameTimeNanos
                publishStats()
            }
        }
    }

    private val workEnd = Runnable {
        val d = System.nanoTime() - frameStartNs
        if (d <= 0L || frameStartNs == 0L) return@Runnable
        worksMs[workIdx] = d / 1_000_000f
        workIdx = (workIdx + 1) % WINDOW
        if (workCount < WINDOW) workCount++
        val h = hint ?: return@Runnable
        // Reported every frame: this is what lets the PowerHAL see a long frame coming.
        if (runCatching { h.report(d) }.isFailure) {
            runCatching { h.close() }
            hint = null
            _state.update { it.copy(hintSession = false, hintDetail = "session lost; restart the smoother") }
        }
    }

    /** Starts the pacing monitor for [owner] (for example "hud"). Several owners share one loop. Any thread. */
    fun startMonitor(owner: String = "hud") = onMain { acquireLoop(owner) }

    fun stopMonitor(owner: String = "hud") = onMain { releaseLoop(owner) }

    private fun acquireLoop(owner: String) {
        val wasIdle = loopOwners.isEmpty()
        loopOwners += owner
        if (!wasIdle) return
        val c = Choreographer.getInstance()
        choreographer = c
        lastVsyncNs = 0L
        intervalCount = 0
        intervalIdx = 0
        workCount = 0
        workIdx = 0
        lastPublishNs = 0L
        c.postFrameCallback(frameCallback)
        _stats.update { it.copy(running = true) }
    }

    private fun releaseLoop(owner: String) {
        loopOwners -= owner
        if (loopOwners.isNotEmpty()) return
        choreographer?.removeFrameCallback(frameCallback)
        main.removeCallbacks(workEnd)
        _stats.update { it.copy(running = false) }
    }

    private fun publishStats() {
        val n = min(intervalCount, WINDOW)
        if (n < 30) return
        System.arraycopy(intervalsMs, 0, scratch, 0, n)
        java.util.Arrays.sort(scratch, 0, n)
        var sum = 0f
        var worst = 0f
        for (i in 0 until n) {
            sum += scratch[i]
            worst = max(worst, scratch[i])
        }
        val avg = sum / n
        var varSum = 0f
        for (i in 0 until n) varSum += (scratch[i] - avg) * (scratch[i] - avg)
        val jitter = sqrt(varSum / n)
        val slow = max(1, ceil(n * 0.01).toInt())
        var slowSum = 0f
        for (i in n - slow until n) slowSum += scratch[i]
        val low1 = 1000f / (slowSum / slow)

        val hzNow = DisplayModeLock.defaultDisplay(ctx)?.refreshRate ?: 0f
        val period = if (hzNow > 1f) 1000f / hzNow else avg
        var janky = 0
        var stable = 0
        for (i in 0 until n) {
            if (scratch[i] > period * 1.5f) janky++
            if (scratch[i] <= period * 1.25f) stable++
        }
        val wn = min(workCount, WINDOW)
        var wsum = 0f
        for (i in 0 until wn) wsum += worksMs[i]

        _stats.value = FrameStats(
            running = true,
            periodMs = period,
            avgFps = 1000f / avg,
            low1Fps = low1,
            jitterMs = jitter,
            worstMs = worst,
            avgWorkMs = if (wn > 0) wsum / wn else 0f,
            jankPct = janky * 100f / n,
            stabilityPct = stable * 100f / n,
            frames = n
        )
    }

    // ───────────────────── Engage / release ─────────────────────

    /**
     * Turns everything on. [targetHz] <= 0 uses the panel's maximum (from [MaxPanelHzEngine]).
     * Steps 1 to 3 always run; the property flags need Shizuku or root and report that honestly.
     */
    suspend fun engage(targetHz: Int = 0): List<StepResult> = mutex.withLock {
        val hz = if (targetHz > 0) targetHz
        else MaxPanelHzEngine.from(ctx).caps()?.hzInt?.takeIf { it > 0 }
            ?: DisplayModeLock.defaultDisplay(ctx)?.refreshRate?.toInt() ?: 60
        _state.update { it.copy(busy = "Starting frame smoother at $hz Hz") }
        try {
            val steps = ArrayList<StepResult>()
            steps += withContext(Dispatchers.Main) { engageMain(hz) }
            val flags = engageFlags()
            steps += flags
            _state.update {
                it.copy(
                    engaged = true,
                    flagsApplied = flags.isNotEmpty() && flags.all { s -> s.ok },
                    steps = steps
                )
            }
            steps
        } finally {
            _state.update { it.copy(busy = null) }
        }
    }

    /** Stops the session, the loop and the priority boost, and puts the properties back. */
    suspend fun release(): List<StepResult> = mutex.withLock {
        val out = ArrayList<StepResult>()
        out += withContext(Dispatchers.Main) { releaseMain() }
        out += restoreFlags()
        _state.update { SmootherState(steps = out) }
        out
    }

    /** Crash / restart recovery: undoes the shell flags a dead process left behind. */
    suspend fun recoverPending(): List<StepResult> = mutex.withLock {
        if (_state.value.engaged) emptyList() else restoreFlags()
    }

    fun engageAsync(targetHz: Int = 0, onDone: ((List<StepResult>) -> Unit)? = null): Job = scope.launch {
        val r = engage(targetHz)
        if (onDone != null) main.post { onDone(r) }
    }

    fun releaseAsync(onDone: ((List<StepResult>) -> Unit)? = null): Job = scope.launch {
        val r = release()
        if (onDone != null) main.post { onDone(r) }
    }

    /**
     * Activity windows: asks the system for sustained-performance mode where the device supports it.
     * It trades peak clocks for steadier ones, so leave [sustained] false for benchmark runs.
     */
    fun bindWindow(window: Window, sustained: Boolean = true) = onMain {
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        val on = sustained && runCatching { pm.isSustainedPerformanceModeSupported }.getOrDefault(false)
        runCatching { window.setSustainedPerformanceMode(on) }
    }

    /** Changes the ADPF target (for example after the panel rate changed). */
    fun setTargetHz(hz: Int) = onMain {
        if (hz <= 0) return@onMain
        targetNs = 1_000_000_000L / hz
        val h = hint
        if (h != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) runCatching { h.target(targetNs) }
        _state.update { it.copy(targetHz = hz, targetNs = targetNs) }
    }

    // ───────────────────── Main-thread work ─────────────────────

    private fun engageMain(hz: Int): List<StepResult> {
        val out = ArrayList<StepResult>()
        targetNs = 1_000_000_000L / hz
        val ui = Process.myTid()
        renderTid = findRenderThread()
        val tids = listOfNotNull(ui, renderTid)

        // thread priority
        val boosted = tids.map { it to boost(it) }
        val allOk = boosted.all { it.second }
        out += StepResult(
            "Thread priority",
            allOk,
            "UI thread " + (if (boosted.first().second) "at -8" else "refused") +
                (if (renderTid == null) "; RenderThread not created yet, retrying"
                else "; RenderThread " + if (boosted.last().second) "at -8" else "refused")
        )

        // ADPF
        val adpf = openHint(tids, targetNs)
        out += adpf
        _state.update {
            it.copy(
                targetHz = hz, targetNs = targetNs, tids = tids, priorityBoosted = allOk,
                hintSession = adpf.ok, hintDetail = adpf.detail
            )
        }

        // pacing monitor
        acquireLoop(OWNER_ENGAGE)
        out += StepResult("Frame-pacing monitor", true, "Choreographer loop, one frame = ${"%.2f".format(1000f / hz)} ms at $hz Hz")

        resyncTries = 0
        if (renderTid == null) scheduleResync()
        return out
    }

    private fun releaseMain(): List<StepResult> {
        main.removeCallbacks(resync)
        releaseLoop(OWNER_ENGAGE)
        closeHint()
        var restored = 0
        for ((tid, prio) in savedPriority) {
            if (runCatching { Process.setThreadPriority(tid, prio) }.isSuccess) restored++
        }
        val total = savedPriority.size
        savedPriority.clear()
        renderTid = null
        return listOf(StepResult("Frame smoother stopped", true, "hint session closed, $restored/$total thread priorities restored"))
    }

    private fun boost(tid: Int): Boolean = runCatching {
        savedPriority.getOrPut(tid) { Process.getThreadPriority(tid) }
        Process.setThreadPriority(tid, Process.THREAD_PRIORITY_URGENT_DISPLAY)
        Process.getThreadPriority(tid) <= Process.THREAD_PRIORITY_URGENT_DISPLAY
    }.getOrDefault(false)

    /** RenderThread appears with the first hardware-drawn window, so it may need a few retries. */
    private fun findRenderThread(): Int? = runCatching {
        File("/proc/self/task").listFiles()?.firstNotNullOfOrNull { d ->
            // a thread can exit between listing and reading, so each read is guarded on its own
            val name = runCatching { File(d, "comm").readText().trim() }.getOrNull()
            if (name == "RenderThread") d.name.toIntOrNull() else null
        }
    }.getOrNull()

    private val resync = Runnable {
        if (!_state.value.engaged && loopOwners.none { it == OWNER_ENGAGE }) return@Runnable
        val rt = findRenderThread()
        if (rt == null) {
            if (++resyncTries < 5) scheduleResync()
            return@Runnable
        }
        renderTid = rt
        val tids = listOfNotNull(Process.myTid(), rt)
        val ok = boost(rt)
        val s = openHint(tids, targetNs) // new thread list = new session
        _state.update {
            it.copy(tids = tids, priorityBoosted = it.priorityBoosted && ok, hintSession = s.ok, hintDetail = s.detail)
        }
    }

    private fun scheduleResync() {
        main.postDelayed(resync, 1_500L)
    }

    @SuppressLint("NewApi")
    private fun openHint(tids: List<Int>, targetNs: Long): StepResult {
        closeHint()
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            return StepResult("ADPF hint session", false, "needs Android 12 or newer (this is API ${Build.VERSION.SDK_INT})")
        }
        return try {
            val pm = ctx.getSystemService(PerformanceHintManager::class.java)
                ?: return StepResult("ADPF hint session", false, "PerformanceHintManager is not available on this ROM")
            val s = pm.createHintSession(tids.toIntArray(), targetNs)
                ?: return StepResult("ADPF hint session", false, "the vendor PowerHAL does not offer hint sessions")
            hint = HintHolder(s)
            StepResult("ADPF hint session", true, "${tids.size} thread(s), target $targetNs ns per frame")
        } catch (t: Throwable) {
            StepResult("ADPF hint session", false, t.message ?: t.javaClass.simpleName)
        }
    }

    @SuppressLint("NewApi")
    private fun closeHint() {
        val h = hint ?: return
        hint = null
        runCatching { h.close() }
    }

    // ───────────────────── Shell flags (Shizuku / root) ─────────────────────

    private suspend fun engageFlags(): List<StepResult> {
        if (!bridge.hasShell()) {
            return listOf(StepResult("HWUI / SurfaceFlinger flags", false, "needs Shizuku or root"))
        }
        val out = ArrayList<StepResult>()
        // tracked: the original value is written to disk first, and restoreProps puts it back
        out += fps.setPropTracked(PROP_HWUI_HINT, "true")
        out += fps.setPropTracked(PROP_SF_PREDICT, "1")
        val ls = bridge.runBatch { cmd("looper_stats", "disable", strict = true) }.items.first()
        if (ls.result.ok) prefs.edit().putBoolean(KEY_LOOPER_OFF, true).apply()
        out += StepResult(
            "looper_stats", ls.result.ok,
            if (ls.result.ok) "background looper profiling off" else ls.result.message
        )
        return out
    }

    private suspend fun restoreFlags(): List<StepResult> {
        val out = ArrayList<StepResult>()
        out += fps.restoreProps(listOf(PROP_HWUI_HINT, PROP_SF_PREDICT))
        if (prefs.getBoolean(KEY_LOOPER_OFF, false)) {
            if (!bridge.hasShell()) {
                out += StepResult("looper_stats restore", false, "needs Shizuku or root; will retry")
            } else {
                val r = bridge.runBatch { cmd("looper_stats", "enable", strict = true) }.items.first().result
                if (r.ok) prefs.edit().putBoolean(KEY_LOOPER_OFF, false).apply()
                out += StepResult("looper_stats restore", r.ok, if (r.ok) "background looper profiling back on" else r.message)
            }
        }
        return out
    }

    private fun onMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else main.post(block)
    }

    companion object {
        private const val WINDOW = 720                      // about 5 s of frames at 144 Hz
        private const val PUBLISH_EVERY_NS = 500_000_000L   // stats are published twice a second, not per frame
        private const val OWNER_ENGAGE = "smoother"
        private const val PROP_HWUI_HINT = "debug.hwui.use_hint_manager"
        private const val PROP_SF_PREDICT = "debug.sf.predict_hwc_composition_strategy"
        private const val KEY_LOOPER_OFF = "looper_stats_off"

        @Volatile private var inst: HardwareFrameSmoother? = null

        /** App-wide instance built from the objects HyperApp already owns (no HyperApp edit needed). */
        fun from(ctx: Context): HardwareFrameSmoother = inst ?: synchronized(this) {
            inst ?: run {
                val app = HyperApp.instance
                HardwareFrameSmoother(ctx.applicationContext, app.bridge, app.fps)
            }.also { inst = it }
        }
    }
}
