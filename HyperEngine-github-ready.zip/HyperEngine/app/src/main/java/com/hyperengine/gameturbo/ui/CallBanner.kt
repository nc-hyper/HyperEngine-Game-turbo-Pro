package com.hyperengine.gameturbo.ui

import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Typeface
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.hyperengine.gameturbo.core.CallPhase
import com.hyperengine.gameturbo.core.CallState
import com.hyperengine.gameturbo.core.DisplayModeLock
import com.hyperengine.gameturbo.core.HandsFreeCallManager
import com.hyperengine.gameturbo.data.CallConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.min

/**
 * The in-game incoming call banner. While a game is on screen and the line rings, a banner drops in at the top
 * with the caller and three round buttons: Answer on speaker, Reject, Mute ringer. After answering it becomes a
 * thin call strip (timer, speaker toggle, hang up), so the whole call can be handled without leaving the game.
 *
 * Only the banner itself takes touches; everything around it still reaches the game.
 */
class CallBannerController(
    context: Context,
    private val wm: WindowManager,
    private val manager: HandsFreeCallManager,
    private val themeProvider: () -> HudTheme,
    private val configProvider: () -> CallConfig,
    private val onTopSaved: (Int) -> Unit
) {

    /** Lets the HUD controller lift its own windows above the banner. */
    var onAttached: (() -> Unit)? = null

    private val ctx: Context = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var watchJob: Job? = null
    private var tickJob: Job? = null
    private var view: BannerView? = null
    private var params: WindowManager.LayoutParams? = null
    private var enabled = false
    private var previewing = false

    /** Starts listening (the phone state needs READ_PHONE_STATE; this retries until it is granted). */
    fun enable() {
        if (enabled) return
        enabled = true
        watchJob = scope.launch {
            launch { manager.state.collect { render(it) } }
            while (isActive) {
                if (!manager.start()) delay(3000L) else break
            }
        }
    }

    fun disable() {
        enabled = false
        watchJob?.cancel()
        watchJob = null
        hide()
        manager.stop()
    }

    fun destroy() {
        disable()
        scope.cancel()
    }

    /** Re-measures after rotation. */
    fun relayout() {
        val v = view ?: return
        val p = params ?: return
        applyGeometry(p)
        runCatching { if (v.isAttachedToWindow) wm.updateViewLayout(v, p) }
    }

    /** Shows the banner layout with sample text and inert buttons, so its look and position can be checked. */
    fun preview() {
        previewing = true
        render(CallState(CallPhase.RINGING, name = "Preview caller", number = "+00 000 000 000", note = "Preview only: no call is ringing"))
        scope.launch {
            delay(4500L)
            previewing = false
            render(manager.state.value)
        }
    }

    // =========================================================================================

    private fun render(s: CallState) {
        if (!enabled) return
        if (!configProvider().bannerEnabled || (s.phase == CallPhase.IDLE && !previewing)) {
            hide()
            return
        }
        val v = view ?: BannerView().also { view = it }
        v.bind(s)
        if (!v.isAttachedToWindow) {
            val p = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            p.title = "HyperEngineCallBanner"
            p.gravity = Gravity.TOP or Gravity.START
            applyGeometry(p)
            DisplayModeLock.applyCurrent(ctx, p)
            runCatching {
                wm.addView(v, p)
                params = p
            }.onFailure {
                view = null
                return
            }
            onAttached?.invoke()
        } else {
            params?.let { runCatching { wm.updateViewLayout(v, it) } }
        }
        tickJob?.cancel()
        if (s.phase == CallPhase.ACTIVE) {
            tickJob = scope.launch {
                while (isActive) {
                    v.tick()
                    delay(1000L)
                }
            }
        }
    }

    private fun hide() {
        tickJob?.cancel()
        tickJob = null
        view?.let { v -> runCatching { wm.removeViewImmediate(v) } }
        view = null
        params = null
    }

    @Suppress("DEPRECATION")
    private fun applyGeometry(p: WindowManager.LayoutParams) {
        val scr = Point().also { wm.defaultDisplay.getRealSize(it) }
        val w = min(Ui.dp(ctx, 540), scr.x - Ui.dp(ctx, 16))
        p.width = w
        p.x = (scr.x - w) / 2
        p.y = Ui.dp(ctx, configProvider().bannerTopDp).coerceIn(0, (scr.y * 0.6f).toInt())
    }

    // =========================================================================================

    private inner class BannerView : LinearLayout(ctx) {
        private val theme get() = themeProvider()
        private val caption = Ui.label(ctx, "", 10f, 0xFFFFFFFF.toInt(), true)
        private val title = Ui.label(ctx, "", 16f, 0xFFFFFFFF.toInt(), true)
        private val sub = Ui.label(ctx, "", 11f, 0xFFFFFFFF.toInt())
        private val note = Ui.label(ctx, "", 10f, 0xFFFFFFFF.toInt())
        private val buttons = Ui.hbox(ctx)
        private var state = CallState()
        private var dragStartY = 0f
        private var dragStartTop = 0

        init {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val d = Ui.dp(ctx, 12)
            setPadding(d, Ui.dp(ctx, 10), d, Ui.dp(ctx, 10))
            val text = Ui.vbox(ctx)
            text.addView(caption)
            text.addView(title, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, Ui.dp(ctx, 2), 0, 0))
            text.addView(sub)
            text.addView(note, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, Ui.dp(ctx, 2), 0, 0))
            title.maxLines = 1
            title.ellipsize = android.text.TextUtils.TruncateAt.END
            note.maxLines = 2
            addView(text, Ui.lp(0, Ui.WRAP, 1f))
            addView(buttons, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, Ui.dp(ctx, 8), 0, 0, 0))
        }

        fun bind(s: CallState) {
            state = s
            val t = theme
            background = Ui.rounded(HudThemes.withAlpha(t.panelTop, 245), Ui.tileRadius(ctx, t) + Ui.dpf(ctx, 8f), t.accent, Ui.dp(ctx, 1))
            caption.setTextColor(t.accent)
            title.setTextColor(t.textPrimary)
            sub.setTextColor(t.textSecondary)
            note.setTextColor(t.textSecondary)
            caption.text = when {
                previewing -> "PREVIEW"
                s.phase == CallPhase.RINGING -> "INCOMING CALL"
                else -> "IN CALL"
            }
            title.text = s.display
            sub.text = if (s.name.isNotBlank() && s.number.isNotBlank()) s.number else ""
            sub.visibility = if (sub.text.isEmpty()) View.GONE else View.VISIBLE
            note.text = s.note
            note.visibility = if (s.note.isBlank()) View.GONE else View.VISIBLE
            buttons.removeAllViews()
            if (s.phase == CallPhase.RINGING) {
                buttons.addView(round(IconKind.SPEAKER, t.good, "Answer") { act { manager.answerHandsFree(configProvider().speakerOnAnswer) } })
                buttons.addView(round(IconKind.PHONE_END, t.hot, "Reject") { act { manager.reject() } })
                buttons.addView(round(IconKind.BELL_OFF, t.tile, "Mute") { act { manager.muteRinger() } })
            } else {
                buttons.addView(round(if (s.speaker) IconKind.SPEAKER else IconKind.SPEAKER_OFF, if (s.speaker) t.accent else t.tile, "Speaker") {
                    act { manager.toggleSpeaker() }
                })
                buttons.addView(round(IconKind.PHONE_END, t.hot, "End") { act { manager.hangUp() } })
            }
            tick()
        }

        fun tick() {
            if (state.phase == CallPhase.ACTIVE && state.startedAt > 0L && !previewing) {
                val sec = ((System.currentTimeMillis() - state.startedAt) / 1000L).toInt()
                caption.text = "IN CALL  " + String.format(java.util.Locale.US, "%02d:%02d", sec / 60, sec % 60)
            }
        }

        private fun act(block: suspend () -> String) {
            if (previewing) {
                note.text = "Preview only. A real call would run this button."
                note.visibility = View.VISIBLE
                return
            }
            scope.launch { block() }
        }

        private fun round(kind: IconKind, fill: Int, caption: String, onClick: () -> Unit): View {
            val t = theme
            val col = Ui.vbox(ctx)
            col.gravity = Gravity.CENTER_HORIZONTAL
            val box = FrameLayout(ctx)
            box.background = Ui.rounded(fill, Ui.dpf(ctx, 24f), t.stroke, Ui.dp(ctx, 1))
            val fg = if (fill == t.tile) t.textPrimary else HudThemes.onAccent(fill)
            box.addView(IconView(ctx, kind, fg).apply { fillFraction = 0.58f }, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
            box.isClickable = true
            box.setOnClickListener { onClick() }
            col.addView(box, Ui.lp(Ui.dp(ctx, 46), Ui.dp(ctx, 46)))
            col.addView(Ui.label(ctx, caption, 9f, t.textSecondary).apply { typeface = Typeface.DEFAULT_BOLD }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, Ui.dp(ctx, 2), 0, 0))
            val lp = Ui.lp(Ui.WRAP, Ui.WRAP, 0f, Ui.dp(ctx, 4), 0, Ui.dp(ctx, 4), 0)
            col.layoutParams = lp
            return col
        }

        /** Drag the text area up and down to move the banner out of the way of the game's own HUD. */
        override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragStartY = e.rawY
                    dragStartTop = params?.y ?: 0
                }
                MotionEvent.ACTION_MOVE -> if (kotlin.math.abs(e.rawY - dragStartY) > Ui.dp(ctx, 8)) return true
            }
            return false
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            val p = params ?: return false
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> return true
                MotionEvent.ACTION_MOVE -> {
                    p.y = (dragStartTop + (e.rawY - dragStartY)).toInt().coerceAtLeast(0)
                    runCatching { wm.updateViewLayout(this, p) }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    onTopSaved((p.y / ctx.resources.displayMetrics.density).toInt())
                    return true
                }
            }
            return false
        }
    }
}
