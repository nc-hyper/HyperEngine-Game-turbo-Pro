package com.hyperengine.gameturbo.ui

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import androidx.core.content.ContextCompat
import com.hyperengine.gameturbo.R
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/**
 * The Quick Settings tile's animation: light comets circle the screen edge while a glass pill springs in with a
 * spinning turbine, then both melt away. Switching off gets its own cooler cousin (blue comets, the turbine spins
 * down, the pill reads "BALANCED"), so a tap always shows what happened.
 *
 * One hardware-layer view driven by a single ValueAnimator, no bitmaps, nothing allocated per frame.
 * Never takes touches. The full-screen turbine ([WildBoostIgnitionOverlay]) stays the HUD's animation.
 */
class WildBoostAuraOverlay(context: Context) {

    private val ctx = context.applicationContext
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var view: AuraView? = null
    private var anim: ValueAnimator? = null

    /** Main thread only. Skipped silently without the overlay permission. */
    fun play(on: Boolean, title: String, subtitle: String) {
        if (!Settings.canDrawOverlays(ctx)) return
        cancel()
        val v = AuraView(ctx, on, title, subtitle)
        val lp = OverlayKit.params(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, "HyperAura", touchable = false
        )
        lp.x = 0; lp.y = 0
        if (!runCatching { wm.addView(v, lp) }.isSuccess) return
        view = v
        haptic(on)
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = if (on) 1700L else 1100L
            interpolator = LinearInterpolator()
            addUpdateListener { v.progress = it.animatedValue as Float }
            addListener(object : AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(a: Animator) { cancelled = true }
                override fun onAnimationEnd(a: Animator) { if (!cancelled) this@WildBoostAuraOverlay.cancel() }
            })
            start()
        }
    }

    fun cancel() {
        anim?.let { a -> a.removeAllListeners(); a.cancel() }
        anim = null
        view?.let { runCatching { wm.removeView(it) } }
        view = null
    }

    private fun haptic(on: Boolean) {
        val vib = ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        if (!vib.hasVibrator()) return
        runCatching {
            if (Build.VERSION.SDK_INT >= 26) {
                vib.vibrate(
                    if (on) VibrationEffect.createWaveform(longArrayOf(0, 14, 50, 34), -1)
                    else VibrationEffect.createOneShot(18, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            }
        }
    }

    private class AuraView(
        ctx: Context, private val on: Boolean, private val title: String, private val subtitle: String
    ) : View(ctx) {

        var progress = 0f
            set(v) { field = v; invalidate() }

        private val d = ctx.resources.displayMetrics.density
        private val c1 = if (on) Color.parseColor("#FF7A18") else Color.parseColor("#2E7BFF")
        private val c2 = if (on) Color.parseColor("#FF2D95") else Color.parseColor("#00C2FF")
        private val c3 = if (on) Color.parseColor("#00E5FF") else Color.parseColor("#7CF2FF")

        private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.5f * d }
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 2.2f * d; strokeCap = Paint.Cap.ROUND; color = c3
        }
        private val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textSize = 15f * d; letterSpacing = 0.16f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        private val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = c3; textSize = 11f * d; letterSpacing = 0.08f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        }

        private val passes = arrayOf(30f to 0.10f, 15f to 0.20f, 4.5f to 0.95f)   // glow width (dp) to alpha
        private val edgeRect = RectF()
        private val pill = RectF()
        private val arc = RectF()
        private val m = Matrix()
        private var sweep: SweepGradient? = null
        private var glass: LinearGradient? = null
        private var rimGrad: LinearGradient? = null
        private val icon: Drawable? = ContextCompat.getDrawable(ctx, R.drawable.ic_wild_boost_turbine)?.mutate()

        init { setLayerType(LAYER_TYPE_HARDWARE, null) }

        override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
            val t = Color.TRANSPARENT
            // Two comets, opposite each other, each fading from tail to bright head.
            sweep = SweepGradient(
                w / 2f, h / 2f,
                intArrayOf(t, c1, c2, c3, t, c1, c2, c3, t),
                floatArrayOf(0f, 0.10f, 0.25f, 0.40f, 0.50f, 0.60f, 0.75f, 0.90f, 1f)
            )
            edge.shader = sweep
            val pw = 232f * d
            val ph = 64f * d
            val cx = w / 2f
            val cy = h * 0.22f
            pill.set(cx - pw / 2, cy - ph / 2, cx + pw / 2, cy + ph / 2)
            glass = LinearGradient(pill.left, pill.top, pill.left, pill.bottom, Color.parseColor("#EE141A2E"), Color.parseColor("#EE090C18"), Shader.TileMode.CLAMP)
            rimGrad = LinearGradient(pill.left, pill.top, pill.right, pill.bottom, c1, c3, Shader.TileMode.CLAMP)
            fill.shader = glass
            rim.shader = rimGrad
        }

        override fun onDraw(canvas: Canvas) {
            val p = progress
            val w = width.toFloat()
            val h = height.toFloat()
            if (w == 0f) return

            // ---- edge comets: fast in, hold, fade ----
            val env = smooth(p / 0.18f) * (1f - smooth((p - 0.62f) / 0.38f))
            if (env > 0.01f) {
                val spin = 360f * easeOutCubic(min(1f, p / 0.85f)) * (if (on) 1f else -1f)
                m.setRotate(spin, w / 2f, h / 2f)
                sweep?.setLocalMatrix(m)
                val inset = 3f * d
                edgeRect.set(inset, inset, w - inset, h - inset)
                val r = 38f * d
                // three widening passes fake a glow without a blur filter (which hardware layers handle poorly)
                for ((wd, a) in passes) {
                    edge.strokeWidth = wd * d
                    edge.alpha = (255 * a * env).toInt()
                    canvas.drawRoundRect(edgeRect, r, r, edge)
                }
            }

            // ---- glass pill: springs in, holds, drifts up and fades ----
            val inT = (p - 0.10f) / 0.38f
            val outT = (p - 0.76f) / 0.24f
            if (inT > 0f && outT < 1f) {
                val scale = (0.55f + 0.45f * overshoot(inT.coerceIn(0f, 1f))) * (1f - 0.08f * smooth(outT))
                val alpha = smooth(inT * 2f) * (1f - smooth(outT))
                val lift = -12f * d * smooth(outT)
                canvas.save()
                canvas.translate(0f, lift)
                canvas.scale(scale, scale, pill.centerX(), pill.centerY())
                fill.alpha = (255 * alpha).toInt()
                rim.alpha = (255 * alpha).toInt()
                val rad = pill.height() / 2f
                canvas.drawRoundRect(pill, rad, rad, fill)
                canvas.drawRoundRect(pill, rad, rad, rim)

                // turbine: spins up (on) or winds down (off), inside a progress ring
                val ic = 34f * d
                val icx = pill.left + rad
                val icy = pill.centerY()
                val rot = if (on) 900f * easeOutCubic(min(1f, p / 0.8f)) else 540f * (1f - easeOutCubic(min(1f, p / 0.8f)))
                arc.set(icx - ic * 0.68f, icy - ic * 0.68f, icx + ic * 0.68f, icy + ic * 0.68f)
                ring.alpha = (255 * alpha).toInt()
                canvas.drawArc(arc, -90f, 360f * smooth((p - 0.14f) / 0.46f), false, ring)
                icon?.let { dr ->
                    dr.setTint(Color.WHITE)
                    dr.alpha = (255 * alpha).toInt()
                    dr.setBounds((icx - ic / 2).toInt(), (icy - ic / 2).toInt(), (icx + ic / 2).toInt(), (icy + ic / 2).toInt())
                    canvas.save()
                    canvas.rotate(rot, icx, icy)
                    dr.draw(canvas)
                    canvas.restore()
                }

                val tx = icx + ic * 0.95f
                titlePaint.alpha = (255 * alpha).toInt()
                subPaint.alpha = (255 * alpha).toInt()
                canvas.drawText(title, tx, icy - 2f * d, titlePaint)
                canvas.drawText(subtitle, tx, icy + 15f * d, subPaint)
                canvas.restore()
            }
        }

        private fun smooth(x: Float): Float { val t = x.coerceIn(0f, 1f); return t * t * (3f - 2f * t) }
        private fun easeOutCubic(x: Float): Float = 1f - (1f - x.coerceIn(0f, 1f)).pow(3)
        /** Eases to 1 with a small overshoot on the way (peaks near 1.1). */
        private fun overshoot(x: Float): Float = easeOutCubic(x) + 0.12f * sin(PI.toFloat() * x) * (1f - x)
    }
}
