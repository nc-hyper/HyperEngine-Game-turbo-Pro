package com.hyperengine.gameturbo.core

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import com.hyperengine.gameturbo.R
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Holds the one MediaProjection grant the app gets from the user's consent dialog. the clip buffer uses it now;
 * anything else that needs the screen (a future screen recorder) shares it, so the user is asked once.
 *
 * The grant ends when the user taps "stop sharing", the service stops, or the process dies. Android 14 and newer
 * ask again for every new session; that is the system's rule, not something this app can skip.
 */
object ProjectionHub {
    private val _ready = MutableStateFlow(false)
    val ready: StateFlow<Boolean> = _ready.asStateFlow()

    @Volatile var projection: MediaProjection? = null
        private set

    /** Called on the main thread when consent was just granted. */
    @Volatile var onReady: (() -> Unit)? = null
    /** Called on the main thread when the grant ends for any reason. */
    @Volatile var onLost: (() -> Unit)? = null

    internal fun attach(p: MediaProjection) {
        projection = p
        // Android 14 requires a callback before a VirtualDisplay is created from this projection. Without one the first
        // createVirtualDisplay() throws, so a registration that fails means this grant is unusable: drop it.
        val registered = runCatching {
            p.registerCallback(object : MediaProjection.Callback() {
                // An older grant that ends late must not tear down the newer one that replaced it.
                override fun onStop() { if (projection === p) detach() }
            }, Handler(Looper.getMainLooper()))
        }.isSuccess
        if (!registered) {
            runCatching { p.stop() }
            projection = null
            return
        }
        _ready.value = true
        runCatching { onReady?.invoke() }
    }

    internal fun detach() {
        if (projection == null) return
        projection = null
        _ready.value = false
        runCatching { onLost?.invoke() }
    }

    /** Opens the system consent dialog. Needs the overlay permission (already required by the HUD) to start from the background. */
    fun request(ctx: Context) {
        // Can throw when the system blocks an activity start from the background; the caller simply gets no consent dialog.
        runCatching {
            ctx.startActivity(Intent(ctx, ProjectionRequestActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    fun release(ctx: Context) {
        runCatching { projection?.stop() }
        runCatching { ctx.stopService(Intent(ctx, ProjectionService::class.java)) }
        detach()
    }
}

/** Transparent activity that only shows the system's screen-capture consent dialog. */
class ProjectionRequestActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Some stripped ROMs have no screen-capture consent dialog at all: close quietly instead of crashing.
        val started = runCatching {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            @Suppress("DEPRECATION")
            startActivityForResult(mpm.createScreenCaptureIntent(), REQ)
        }.isSuccess
        if (!started) finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ && resultCode == RESULT_OK && data != null) {
            runCatching {
                startForegroundService(
                    Intent(this, ProjectionService::class.java).putExtra("code", resultCode).putExtra("data", data)
                )
            }
        }
        finish()
    }

    private companion object { const val REQ = 4711 }
}

/** Foreground service of type mediaProjection; Android refuses to hand out a projection without one. */
class ProjectionService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Android only hands out a projection to a foreground service of type mediaProjection. If it refuses the
        // foreground start (a SecurityException on 14+, a blocked start on some ROMs) there is no point going on, and the
        // exception must not escape: it would crash the app.
        val foreground = try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CH, "Clip buffer", NotificationManager.IMPORTANCE_LOW))
            val n = Notification.Builder(this, CH)
                .setSmallIcon(R.drawable.ic_qs_wild_boost)
                .setContentTitle("HyperEngine clip buffer")
                .setContentText("Screen capture is on")
                .setOngoing(true)
                .build()
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
            } else {
                startForeground(ID, n)
            }
            true
        } catch (_: Throwable) {
            false
        }
        if (!foreground) { stopSelf(); return START_NOT_STICKY }
        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = runCatching { mpm.getMediaProjection(code, data) }.getOrNull()
        if (p == null) { stopSelf(); return START_NOT_STICKY }
        ProjectionHub.attach(p)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        runCatching { ProjectionHub.projection?.stop() }
        ProjectionHub.detach()
        super.onDestroy()
    }

    private companion object {
        const val CH = "hyper_projection"
        const val ID = 4712
    }
}
