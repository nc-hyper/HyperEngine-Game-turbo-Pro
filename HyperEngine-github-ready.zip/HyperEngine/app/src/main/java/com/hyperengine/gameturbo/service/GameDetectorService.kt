package com.hyperengine.gameturbo.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import com.hyperengine.gameturbo.HyperApp
import com.hyperengine.gameturbo.R
import com.hyperengine.gameturbo.core.GameHeuristics
import com.hyperengine.gameturbo.core.GameSessionGuard
import com.hyperengine.gameturbo.hub.HubActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Foreground service that watches which app is on screen and drives everything else:
 *
 *  game comes forward  -> OptimizationEngine.onGameForeground (applies the per-game profile),
 *                         telemetry starts, edge handle appears
 *  game leaves         -> OptimizationEngine.onGameBackground (restores after the delay, default 15 s),
 *                         handle disappears, telemetry stops
 *
 * Detection source, best first:
 *  1. UsageStatsManager events (needs Usage Access). ACTIVITY_RESUMED / ACTIVITY_PAUSED and screen-off.
 *  2. dumpsys activity (needs Shizuku or root).
 * If neither is available the notification says so; nothing is faked.
 *
 * Part 10: GameSessionGuard rides on the same two events. A game coming forward locks the panel at its top rate and starts
 * the frame smoother (unless the profile picks its own rate); leaving restores both after the restore delay. It also ends
 * an AnTuTu / benchmark boost when its app has been closed, and puts everything back when this service stops.
 *
 * An app counts as a game when it has an enabled profile, or (auto-detect on) the system categorises it
 * as a game. Auto-detected games get a profile created for them.
 */
class GameDetectorService : Service() {

    data class DetectorState(
        val running: Boolean = false,
        val foreground: String? = null,
        val game: String? = null,
        val source: String = "none",
        val problem: String? = null,
        val demo: String? = null
    )

    private class Reading(val pkg: String?, val ok: Boolean, val source: String, val ignored: Boolean = false, val game: Boolean = false)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val app get() = HyperApp.instance
    private val guard by lazy { GameSessionGuard.from(applicationContext) }
    private var hud: HudController? = null
    private var loopJob: Job? = null

    private var currentGame: String? = null
    private var demoPkg: String? = null
    private var overlayWarned = false

    /** True when Android refused to let this service become a foreground service; the service then stops itself quietly. */
    private var startFailed = false

    // usage stats state
    private var lastQuery = 0L
    private var fgPkg: String? = null
    private var fgClass: String? = null
    private val autoCache = java.util.concurrent.ConcurrentHashMap<String, Boolean>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (!enterForeground()) {
            // Android 12+ refuses a foreground start from the background on some paths, and a ROM can reject the service
            // type or the notification. An exception here used to take the whole app down; now the watcher just does not
            // start, and the hub shows why.
            startFailed = true
            _state.value = DetectorState(
                running = false,
                problem = "Android blocked the game watcher from starting. Open the app and switch the watcher on again."
            )
            stopSelf()
            return
        }
        // A HUD that cannot be built must not kill detection: every use below is null-safe.
        hud = runCatching { HudController(this, app.engine, app.telemetry, app.repository, app.bridge) }.getOrNull()
        _state.value = DetectorState(running = true)
        loopJob = scope.launch { detectLoop() }
    }

    /** Creates the channel and goes foreground. False when the system refuses (the caller stops the service). */
    private fun enterForeground(): Boolean = try {
        createChannel()
        val n = buildNotification("Starting game watcher")
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
        true
    } catch (_: Throwable) {
        false
    }

    /**
     * The user swiped the app out of Recents. Unless "Keep running after closing the app" is on, the watcher
     * stops here: the HUD goes away and onDestroy puts every changed setting back.
     */
    override fun onTaskRemoved(rootIntent: Intent?) {
        if (!app.selfHealer.autoHeal) stopSelf()
        super.onTaskRemoved(rootIntent)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (startFailed) return START_NOT_STICKY
        when (intent?.action) {
            ACTION_STOP -> stopSelf()
            ACTION_SHOW_DEMO -> {
                val pkg = intent.getStringExtra(EXTRA_PACKAGE)?.trim().orEmpty()
                if (pkg.isNotEmpty()) startDemo(pkg)
            }
            ACTION_HIDE_DEMO -> stopDemo()
        }
        // Not sticky: Android must not bring the watcher back on its own after it was killed or stopped.
        return if (app.selfHealer.autoHeal) START_STICKY else START_NOT_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        hud?.relayout()
    }

    override fun onDestroy() {
        if (startFailed) {
            // Nothing was started, so there is nothing to restore; keep the "why" message in the state.
            scope.cancel()
            super.onDestroy()
            return
        }
        loopJob?.cancel()
        app.wildBoost.onWatcherStopped()
        hud?.destroy()
        hud = null
        // The watcher is gone, so nothing would ever restore the phone later: do it now.
        CoroutineScope(SupervisorJob() + Dispatchers.Default).launch {
            // Part 10: panel lock, frame smoother and any benchmark boost go back first; they sit on top of the engines below
            runCatching { guard.releaseAll("watcher stopped") }
            app.fps.releaseSoft("watcher stopped")
            app.wild.releaseSoft("watcher stopped")
            if (app.engine.hasPendingRestore()) app.engine.restoreAll("watcher stopped")
        }
        _state.value = DetectorState()
        scope.cancel()
        super.onDestroy()
    }

    // =========================================================================================
    // Demo mode: show the HUD for a package without detecting a running game (for testing)
    // =========================================================================================

    private fun startDemo(pkg: String) {
        demoPkg = pkg
        app.repository.profile(pkg) ?: app.repository.getOrCreate(pkg, pkg)
        val ok = hud?.show(pkg) ?: false
        _state.update { it.copy(demo = pkg) }
        postNotice(if (ok) "HUD demo: $pkg" else "Overlay permission needed")
    }

    private fun stopDemo() {
        demoPkg = null
        hud?.hide()
        currentGame = null // force re-evaluation of the real foreground app
        _state.update { it.copy(demo = null) }
        postNotice("Watching for games")
    }

    // =========================================================================================
    // Detection
    // =========================================================================================

    private suspend fun detectLoop() {
        var tick = 0
        var recovered = false
        while (currentCoroutineContext().isActive) {
            if (tick++ % 5 == 0) withContext(Dispatchers.IO) { app.bridge.refreshNow() }
            // Everything that touches the package manager, the native-library folder or Settings.Secure is resolved here, on a
            // worker thread. It used to run inside process() on the MAIN thread, so the first time a new app came forward the
            // HUD and the game's overlay stalled on disk and binder calls.
            val reading = withContext(Dispatchers.Default) { classify(readForeground()) }
            process(reading)
            if (!recovered && reading.ok) {
                recovered = true
                if (currentGame == null && demoPkg == null && app.engine.hasPendingRestore()) {
                    scope.launch { app.engine.recoverPendingRestore() }
                }
                if (currentGame == null && demoPkg == null) {
                    scope.launch {
                        app.fps.recoverPending()
                        app.wild.recoverPending()
                        app.hyperBoost.recoverPending()
                        // Part 10: benchmark boost, frame smoother flags and the Realme / OPPO refresh keys left by a dead process
                        runCatching { guard.recoverPending() }
                    }
                }
            }
            // Usage stats are cheap, so 1 s is fine. The dumpsys fallback walks system_server's activity stack every call:
            // poll it less often while no game is in front so the phone is not doing that work for nothing.
            delay(
                when {
                    reading.source == "dumpsys" && currentGame == null -> 2500L
                    currentGame != null -> 1000L
                    else -> 1500L
                }
            )
        }
    }

    private suspend fun readForeground(): Reading {
        val st = app.bridge.state.value
        if (st.usageAccess && pollUsageStats()) return Reading(fgPkg, true, "usage stats")
        if (app.bridge.hasShell()) {
            val r = app.bridge.shell("dumpsys activity activities | grep -m6 -E 'ResumedActivity|topResumedActivity'", 4000L)
            if (r.ok || r.stdout.isNotBlank()) {
                val re = Regex("ActivityRecord\\{[^ ]+ u\\d+ ([A-Za-z0-9_.]+)/")
                // topResumedActivity is the focused one; mResumedActivity lines can belong to another display
                val top = r.stdout.lineSequence().firstOrNull { it.contains("topResumedActivity") }?.let { re.find(it) }
                val m = top ?: re.find(r.stdout)
                return Reading(m?.groupValues?.get(1), true, "dumpsys")
            }
        }
        return Reading(null, false, "none")
    }

    private fun classify(r: Reading): Reading {
        val pkg = r.pkg ?: return r
        if (!r.ok) return r
        if (isIgnored(pkg)) return Reading(pkg, true, r.source, ignored = true)
        return Reading(pkg, true, r.source, ignored = false, game = isGame(pkg))
    }

    private fun pollUsageStats(): Boolean = try {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val from = if (lastQuery == 0L) now - 2 * 3_600_000L else lastQuery - 1500L
        val events = usm.queryEvents(from, now)
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            when (e.eventType) {
                1 -> { fgPkg = e.packageName; fgClass = e.className }          // ACTIVITY_RESUMED
                // A game often swaps activities inside its own package (splash -> main, login, ads). Android may
                // deliver the old activity's PAUSED after the new one's RESUMED; matching on the package alone
                // then wiped the game and the whole HyperLab dropped. Only the activity that is in front can clear it.
                2 -> if (e.packageName == fgPkg && (fgClass == null || e.className == null || e.className == fgClass)) {
                    fgPkg = null; fgClass = null                                // ACTIVITY_PAUSED
                }
                16 -> { fgPkg = null; fgClass = null }                          // SCREEN_NON_INTERACTIVE
            }
        }
        lastQuery = now
        true
    } catch (_: Throwable) {
        false
    }

    private fun process(r: Reading) {
        _state.update {
            it.copy(
                source = r.source,
                problem = if (r.ok) null else "Grant Usage Access, or start Shizuku, so games can be detected"
            )
        }
        if (!r.ok) {
            postNotice("Grant Usage Access or start Shizuku to detect games")
            return
        }
        if (demoPkg != null) return
        val pkg = r.pkg
        if (r.ignored) return
        _state.update { it.copy(foreground = pkg) }
        app.fps.onForegroundApp(pkg)
        guard.onForegroundApp(pkg)              // ends a benchmark boost once its app has been closed

        val game = pkg?.takeIf { r.game }
        if (game == currentGame) return
        currentGame = game
        _state.update { it.copy(game = game) }

        if (game != null) {
            app.engine.onGameForeground(game)
            app.fps.onGameForeground(game)
            app.wild.onGameForeground(game)
            app.wildBoost.onGameForeground(game)
            app.suite.onGameForeground(game)       // colour filters + refresh matching for this game
            guard.onGameForeground(game)           // Part 10: max panel Hz + frame smoother, released again on exit
            app.selfHealer.heal("game launch")      // re-enable / rebind the auto-tapper service if it dropped
            // Competitive Mode armed from the tile / key chord before the game opened: start Wild Boost for it now.
            scope.launch { CompetitiveMode.onGameForeground(applicationContext, game) }
            val shown = hud?.show(game) ?: false
            val label = app.repository.profile(game)?.label?.ifBlank { game } ?: game
            if (shown) {
                overlayWarned = false
                postNotice("Playing: $label")
            } else if (!overlayWarned) {
                overlayWarned = true
                postNotice("Overlay permission needed for the sidebar")
            }
        } else {
            app.engine.onGameBackground()
            app.fps.onGameBackground()
            app.wild.onGameBackground()
            app.wildBoost.onGameBackground()
            app.suite.onGameBackground()
            guard.onGameBackground()               // Part 10: restores after the same delay as the profile engine
            hud?.hide()
            CompetitiveMode.onGameEnded(applicationContext)
            postNotice("Watching for games")
        }
    }

    private fun isIgnored(pkg: String): Boolean {
        if (pkg == packageName || pkg == "com.android.systemui" || pkg == "android") return true
        val ime = Settings.Secure.getString(contentResolver, "default_input_method")?.substringBefore('/')
        return ime != null && pkg == ime
    }

    @Suppress("DEPRECATION")
    private fun isGame(pkg: String): Boolean {
        val profile = app.repository.profile(pkg)
        if (profile != null) return profile.enabled
        if (!app.repository.global.value.autoDetectGames) return false
        autoCache[pkg]?.let { return it }
        val result = try {
            val ai = packageManager.getApplicationInfo(pkg, 0)
            val system = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
            // Same rule as the Game Space library (category, FLAG_IS_GAME or a game engine's native library), so a game
            // that is auto-detected here is also listed there.
            val game = GameHeuristics.looksLikeGame(ai)
            if (game && !system) {
                val label = packageManager.getApplicationLabel(ai).toString()
                app.repository.getOrCreate(pkg, label)
                true
            } else {
                false
            }
        } catch (_: Throwable) {
            false
        }
        autoCache[pkg] = result
        return result
    }

    // =========================================================================================
    // Notification
    // =========================================================================================

    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Game watcher", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, HubActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, GameDetectorService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_qs_wild_boost)
            .setContentTitle("HyperEngine Game Turbo")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(R.drawable.ic_close, "Stop", stop).build())
            .build()
    }

    private var lastNotice = ""

    private fun postNotice(text: String) {
        if (text == lastNotice) return
        lastNotice = text
        runCatching {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIF_ID, buildNotification(text))
        }
    }

    companion object {
        const val ACTION_STOP = "com.hyperengine.gameturbo.action.STOP"
        const val ACTION_SHOW_DEMO = "com.hyperengine.gameturbo.action.SHOW_DEMO"
        const val ACTION_HIDE_DEMO = "com.hyperengine.gameturbo.action.HIDE_DEMO"
        const val EXTRA_PACKAGE = "package"
        private const val CHANNEL = "hyper_service"
        private const val NOTIF_ID = 4101

        private val _state = MutableStateFlow(DetectorState())
        val state: StateFlow<DetectorState> = _state.asStateFlow()

        fun start(ctx: Context) {
            startForegroundSafely(ctx, Intent(ctx, GameDetectorService::class.java))
        }

        fun stop(ctx: Context) {
            runCatching { ctx.stopService(Intent(ctx, GameDetectorService::class.java)) }
        }

        fun showDemo(ctx: Context, pkg: String) {
            startForegroundSafely(ctx, Intent(ctx, GameDetectorService::class.java).setAction(ACTION_SHOW_DEMO).putExtra(EXTRA_PACKAGE, pkg))
        }

        fun hideDemo(ctx: Context) {
            startForegroundSafely(ctx, Intent(ctx, GameDetectorService::class.java).setAction(ACTION_HIDE_DEMO))
        }

        /**
         * startForegroundService throws (ForegroundServiceStartNotAllowedException on Android 12+, SecurityException on some
         * ROMs) when the app is not allowed to start a foreground service right now, for example from a background path.
         * That used to crash the caller; now it is reported through [state] and the app keeps running.
         */
        private fun startForegroundSafely(ctx: Context, intent: Intent) {
            try {
                ctx.startForegroundService(intent)
            } catch (_: Throwable) {
                _state.update {
                    it.copy(problem = "Android blocked the game watcher from starting. Open the app and switch the watcher on again.")
                }
            }
        }
    }
}
