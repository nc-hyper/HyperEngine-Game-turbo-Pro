package com.hyperengine.gameturbo.core

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.net.Uri
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.provider.ContactsContract
import android.telecom.TelecomManager
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import android.view.KeyEvent
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper
import java.lang.reflect.Method

enum class CallPhase { IDLE, RINGING, ACTIVE }

data class CallState(
    val phase: CallPhase = CallPhase.IDLE,
    val name: String = "",
    val number: String = "",
    val speaker: Boolean = false,
    val startedAt: Long = 0L,         // when the call became active
    val note: String = ""             // last action result, shown in the banner
) {
    val display: String get() = name.ifBlank { number }.ifBlank { "Unknown caller" }
}

/**
 * Takes a phone call without leaving the game (the Xiaomi Game Turbo trick).
 *
 *  detect   TelephonyCallback (Android 12+) or PhoneStateListener tells us the line is ringing / in a call
 *  name     the dialer's call notification (through our notification listener) and, when the contacts permission
 *           is granted, a contacts lookup of the number. Without either, the banner says "Unknown caller".
 *  answer   TelecomManager.acceptRingingCall, else KEYCODE_CALL through the shell. Then speakerphone is forced
 *           ON, 300 ms later and again twice after that, because the telecom stack resets the route when the
 *           call connects. Speaker routing is tried through the Shizuku-bound audio service first, then the
 *           standard AudioManager APIs, and the real result is read back and reported.
 *  reject   TelecomManager.endCall, else KEYCODE_ENDCALL through the shell
 *  mute     TelecomManager.silenceRinger, else a volume key through the shell, else the ring stream is muted
 *
 * Needs READ_PHONE_STATE (to see the ringing) and ANSWER_PHONE_CALLS (to answer / reject). Both can be granted
 * from the Diagnostics screen or with the self-grant commands.
 */
class HandsFreeCallManager(
    context: Context,
    private val bridge: SystemBridgeExecutor
) {

    private val ctx: Context = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
    private val telecom = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private val _state = MutableStateFlow(CallState())
    val state: StateFlow<CallState> = _state.asStateFlow()

    private var registered = false
    private var legacy: PhoneStateListener? = null
    private var modern: Any? = null
    private var lastSystemState = TelephonyManager.CALL_STATE_IDLE

    /** Caller text taken from the dialer's notification while the phone rings (see DanmakuNotificationService). */
    @Volatile
    private var notificationName: String = ""

    fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED

    fun canAnswer(): Boolean =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ANSWER_PHONE_CALLS) == PackageManager.PERMISSION_GRANTED

    /** Safe to call repeatedly: starts listening once the permission is there. Returns true while listening. */
    fun start(): Boolean {
        if (registered) return true
        if (!hasPermission()) return false
        runCatching {
            if (Build.VERSION.SDK_INT >= 31) {
                val cb = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                    override fun onCallStateChanged(state: Int) = onSystemState(state, "")
                }
                tm.registerTelephonyCallback(ContextCompat.getMainExecutor(ctx), cb)
                modern = cb
            } else {
                @Suppress("DEPRECATION")
                val l = object : PhoneStateListener() {
                    @Deprecated("Deprecated in Java")
                    override fun onCallStateChanged(state: Int, phoneNumber: String?) = onSystemState(state, phoneNumber.orEmpty())
                }
                @Suppress("DEPRECATION")
                tm.listen(l, PhoneStateListener.LISTEN_CALL_STATE)
                legacy = l
            }
            registered = true
        }
        return registered
    }

    fun stop() {
        runCatching {
            if (Build.VERSION.SDK_INT >= 31) {
                (modern as? TelephonyCallback)?.let { tm.unregisterTelephonyCallback(it) }
            } else {
                @Suppress("DEPRECATION")
                legacy?.let { tm.listen(it, PhoneStateListener.LISTEN_NONE) }
            }
        }
        modern = null
        legacy = null
        registered = false
        lastSystemState = TelephonyManager.CALL_STATE_IDLE
        _state.value = CallState()
    }

    /** The dialer posted (or updated) its call notification: its title is the caller's name or number. */
    fun onCallNotification(title: String) {
        if (title.isBlank()) return
        notificationName = title
        val s = _state.value
        if (s.phase == CallPhase.RINGING && s.name.isBlank()) _state.update { it.copy(name = title) }
    }

    private fun onSystemState(state: Int, number: String) {
        val prev = lastSystemState
        lastSystemState = state
        when (state) {
            TelephonyManager.CALL_STATE_RINGING -> {
                val name = if (notificationName.isNotBlank()) notificationName else lookupName(number)
                _state.value = CallState(CallPhase.RINGING, name = name, number = number)
                if (number.isNotBlank() && name.isBlank()) {
                    scope.launch { _state.update { it.copy(name = lookupName(number)) } }
                }
            }
            TelephonyManager.CALL_STATE_OFFHOOK -> {
                val cur = _state.value
                _state.value = cur.copy(phase = CallPhase.ACTIVE, startedAt = if (cur.startedAt > 0) cur.startedAt else System.currentTimeMillis())
            }
            else -> {
                notificationName = ""
                if (prev != TelephonyManager.CALL_STATE_IDLE) _state.value = CallState()
            }
        }
    }

    private fun lookupName(number: String): String {
        if (number.isBlank()) return ""
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return ""
        return runCatching {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            ctx.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0).orEmpty() else ""
            }.orEmpty()
        }.getOrDefault("")
    }

    // =========================================================================================
    // Actions
    // =========================================================================================

    /** Answer, then force the speaker. The result text says which route worked and whether the speaker is really on. */
    suspend fun answerHandsFree(speaker: Boolean): String {
        val how = answer()
        if (how == null) return say("Could not answer: needs the Phone permission (ANSWER_PHONE_CALLS) or Shizuku")
        if (!speaker) return say("Answered ($how)")
        delay(300L)
        var result = setSpeaker(true)
        // the call connects a moment later and the telecom stack may reset the route: assert it again
        repeat(2) {
            delay(700L)
            if (!isSpeakerOn()) result = setSpeaker(true)
        }
        return say(
            if (isSpeakerOn()) "Answered ($how), speaker on" else "Answered ($how). Speaker could not be forced: $result"
        )
    }

    suspend fun reject(): String {
        val how = withContext(Dispatchers.IO) {
            val viaTelecom = runCatching {
                if (Build.VERSION.SDK_INT >= 28 && canAnswer()) telecom.endCall() else false
            }.getOrDefault(false)
            when {
                viaTelecom -> "telecom"
                bridge.hasShell() && bridge.pressKey(KeyEvent.KEYCODE_ENDCALL).ok -> "shell key"
                else -> null
            }
        }
        return say(if (how != null) "Call ended ($how)" else "Could not end the call: needs the Phone permission or Shizuku")
    }

    suspend fun muteRinger(): String {
        val how = withContext(Dispatchers.IO) {
            val viaTelecom = runCatching { telecom.silenceRinger(); true }.getOrDefault(false)
            when {
                viaTelecom && audio.ringerMode != AudioManager.RINGER_MODE_NORMAL -> "telecom"
                bridge.hasShell() && bridge.pressKey(KeyEvent.KEYCODE_VOLUME_DOWN).ok -> "volume key"
                else -> runCatching {
                    audio.adjustStreamVolume(AudioManager.STREAM_RING, AudioManager.ADJUST_MUTE, 0)
                    "ring stream muted"
                }.getOrNull()
            }
        }
        return say(if (how != null) "Ringer silenced ($how)" else "Could not silence the ringer")
    }

    suspend fun hangUp(): String = reject()

    suspend fun toggleSpeaker(): String {
        val want = !isSpeakerOn()
        val r = setSpeaker(want)
        return say(if (isSpeakerOn() == want) (if (want) "Speaker on" else "Speaker off") else "Speaker change refused: $r")
    }

    private suspend fun answer(): String? = withContext(Dispatchers.IO) {
        val viaTelecom = runCatching {
            if (canAnswer()) { telecom.acceptRingingCall(); true } else false
        }.getOrDefault(false)
        if (viaTelecom) return@withContext "telecom"
        // KEYCODE_CALL is what a headset button sends; the shell can inject it
        if (bridge.hasShell() && bridge.pressKey(KeyEvent.KEYCODE_CALL).ok) return@withContext "shell key"
        null
    }

    private fun say(text: String): String {
        _state.update { it.copy(note = text, speaker = isSpeakerOn()) }
        return text
    }

    // =========================================================================================
    // Speaker routing
    // =========================================================================================

    @Suppress("DEPRECATION")
    fun isSpeakerOn(): Boolean = runCatching {
        if (Build.VERSION.SDK_INT >= 31) {
            audio.communicationDevice?.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER
        } else {
            audio.isSpeakerphoneOn
        }
    }.getOrDefault(false)

    /**
     * Routes call audio to the loudspeaker (or back). Order: the audio service through Shizuku (a shell identity
     * is allowed to set the route during a telephony call), then the public AudioManager API. Returns a short
     * description of what was tried.
     */
    private suspend fun setSpeaker(on: Boolean): String = withContext(Dispatchers.Main) {
        val tried = ArrayList<String>()

        if (bridge.hasShell()) {
            tried += "shizuku audio service: " + (shizukuSpeaker(on) ?: "ok")
            if (isSpeakerOn() == on) return@withContext tried.joinToString("; ")
        }

        runCatching {
            if (Build.VERSION.SDK_INT >= 31) {
                if (on) {
                    val dev = audio.availableCommunicationDevices.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
                    tried += if (dev != null && audio.setCommunicationDevice(dev)) "setCommunicationDevice ok" else "setCommunicationDevice refused"
                } else {
                    audio.clearCommunicationDevice()
                    tried += "clearCommunicationDevice"
                }
            } else {
                @Suppress("DEPRECATION")
                audio.isSpeakerphoneOn = on
                tried += "setSpeakerphoneOn"
            }
        }.onFailure { tried += "AudioManager: " + (it.message ?: it.javaClass.simpleName) }
        tried.joinToString("; ")
    }

    /** Returns null on success, else the reason. The IAudioService signature differs between Android releases. */
    private fun shizukuSpeaker(on: Boolean): String? = runCatching {
        HiddenApiUnlock.ensure()
        val raw: IBinder = SystemServiceHelper.getSystemService("audio") ?: return@runCatching "no audio service"
        val wrapped = ShizukuBinderWrapper(raw)
        val stub = Class.forName("android.media.IAudioService\$Stub")
        val svc = stub.getMethod("asInterface", IBinder::class.java).invoke(null, wrapped)
            ?: return@runCatching "no interface"
        val cls = svc.javaClass

        // Android 12+: setCommunicationDevice(IBinder cb, int portId, String attributionTag)
        if (Build.VERSION.SDK_INT >= 31 && on) {
            val dev = audio.availableCommunicationDevices.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
            val m = find(cls, "setCommunicationDevice")
            if (dev != null && m != null) {
                val args = adapt(m, mapOf(IBinder::class.java to Binder(), Int::class.javaPrimitiveType!! to dev.id, String::class.java to ctx.packageName))
                m.invoke(svc, *args)
                return@runCatching null
            }
        }
        // Android 8-14: setSpeakerphoneOn(IBinder cb, boolean on, String eventSource)
        val m = find(cls, "setSpeakerphoneOn") ?: return@runCatching "setSpeakerphoneOn not found"
        val args = adapt(m, mapOf(IBinder::class.java to Binder(), Boolean::class.javaPrimitiveType!! to on, String::class.java to ctx.packageName))
        m.invoke(svc, *args)
        null
    }.getOrElse { (it.cause ?: it).let { c -> c.javaClass.simpleName + ": " + (c.message ?: "") } }

    private fun find(cls: Class<*>, name: String): Method? = cls.methods.firstOrNull { it.name == name }

    private fun adapt(m: Method, byType: Map<Class<*>, Any>): Array<Any?> =
        m.parameterTypes.map { byType[it] }.toTypedArray()
}
