package com.hyperengine.gameturbo.ui

import android.content.Context
import com.hyperengine.gameturbo.core.GamingSuiteManager
import kotlinx.coroutines.launch

/**
 * Sidebar tile "HyperLab": opens the full [LabPanel] (low-latency mode, clip buffer, colour filters, refresh-rate matching
 * stabilizer, HyperBoost quality) as a detail page of the HUD. The tile lights up while any of them is running.
 */
class LabTool(private val nv: GamingSuiteManager) : HudTool("lab") {

    override fun isActive(host: ToolHost): Boolean =
        nv.lowLatency.value.on || nv.replay.running.value || nv.gameFilterState.value.active || nv.refreshSyncState.value.on

    override fun onTap(host: ToolHost) {
        val panel = LabPanel(host.hostContext, host.theme, host.game, liveGame = true) { msg, _ -> host.toast(msg) }
        host.openDetail(Brand.LAB_TITLE, panel.build())
    }
}

/**
 * One-tap "Save last clip" tile. Buffer running: saves the last seconds to Movies/HyperEngine_Clips.
 * Buffer off: starts it (asking for screen-capture consent the first time) using the window chosen in the Lab.
 */
class ClipBufferTool(private val nv: GamingSuiteManager) : HudTool("replay") {

    override fun isActive(host: ToolHost): Boolean = nv.replay.running.value

    override fun onTap(host: ToolHost) {
        if (!nv.replay.running.value) {
            val sec = host.hostContext.getSharedPreferences("hyper_lab", Context.MODE_PRIVATE).getInt("replay.sec", 30)
            val started = nv.startReplay(sec)
            host.toast(if (started) "Replay buffer on ($sec s)" else "Allow screen capture. The buffer starts when you accept.")
            host.refreshTiles()
            return
        }
        host.scope.launch {
            val where = nv.saveReplay()
            host.toast(if (where != null) "Saved to $where" else "Nothing buffered yet, play a little first")
            host.refreshTiles()
        }
    }
}
