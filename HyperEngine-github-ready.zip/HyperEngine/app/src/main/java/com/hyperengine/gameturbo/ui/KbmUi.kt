package com.hyperengine.gameturbo.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import com.hyperengine.gameturbo.HyperApp
import com.hyperengine.gameturbo.core.DisplayModeLock
import com.hyperengine.gameturbo.core.KbmCodes
import com.hyperengine.gameturbo.core.KbmMapper
import com.hyperengine.gameturbo.core.KbmPreset
import com.hyperengine.gameturbo.data.GameProfileRepository
import com.hyperengine.gameturbo.data.KbmConfig
import com.hyperengine.gameturbo.data.KbmKeyNode
import kotlin.math.hypot

// =============================================================================================
// Tool page
// =============================================================================================

/** Keyboard and mouse mapper: switch it on, review the keys, open the on-screen editor. */
class KbmTool : HudTool("kbm") {

    override fun isActive(host: ToolHost): Boolean = HyperApp.instance.repository.profile(host.game)?.kbm?.enabled == true

    override fun onTap(host: ToolHost) {
        val ctx = host.hostContext
        val theme = host.theme
        val repo = host.deps.repo
        val app = HyperApp.instance
        val game = host.game
        val cfg = (repo.profile(game) ?: repo.getOrCreate(game, game)).kbm
        val col = Ui.vbox(ctx)

        col.addView(
            ToolUi.note(
                host,
                "Play with a USB or Bluetooth keyboard and mouse. W A S D drives a virtual joystick, other keys press the screen points " +
                    "you place, and the mouse buttons press their own points. Needs the accessibility service on, and Shizuku for the " +
                    "joystick and held keys."
            )
        )
        col.addView(ToolUi.check(ctx, theme, "Use the keyboard and mouse in this game", cfg.enabled) { on ->
            repo.update(game) { it.copy(kbm = it.kbm.copy(enabled = on)) }
            host.refreshTiles()
        })

        val devices = app.system.hidDevices()
        col.addView(
            ToolUi.note(
                host,
                if (devices.isEmpty()) "No external keyboard or mouse detected right now."
                else "Detected: " + devices.joinToString { it.name }
            ),
            Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 4), 0, 0)
        )

        col.addView(Ui.section(ctx, theme, "Joystick (W A S D)"))
        col.addView(ToolUi.check(ctx, theme, "Map the movement keys to a joystick", cfg.joystick) { on ->
            repo.update(game) { it.copy(kbm = it.kbm.copy(joystick = on)) }
        })
        col.addView(Ui.labeledSlider(ctx, theme, "Joystick reach", "%", 4, 25, (cfg.joyRadius * 100f).toInt().coerceIn(4, 25)) { v ->
            repo.update(game) { it.copy(kbm = it.kbm.copy(joyRadius = v / 100f)) }
        })

        col.addView(Ui.section(ctx, theme, "Mapped keys (${cfg.nodes.size})"))
        if (cfg.nodes.isEmpty()) {
            col.addView(ToolUi.note(host, "Nothing mapped yet. Load the starter layout or open the editor."))
        }
        for (node in cfg.nodes) {
            val row = Ui.hbox(ctx)
            row.gravity = Gravity.CENTER_VERTICAL
            val name = if (node.label.isBlank()) KbmCodes.name(node.keyCode) else KbmCodes.name(node.keyCode) + "  |  " + node.label
            row.addView(Ui.label(ctx, name, 12f, theme.textPrimary), Ui.lp(0, Ui.WRAP, 1f))
            row.addView(Ui.button(ctx, theme, if (node.hold) "Hold" else "Tap") {
                repo.update(game) { p ->
                    p.copy(kbm = p.kbm.copy(nodes = p.kbm.nodes.map { if (it.keyCode == node.keyCode) it.copy(hold = !it.hold) else it }))
                }
                onTap(host)
            }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, Ui.dp(ctx, 6), 0, Ui.dp(ctx, 6), 0))
            row.addView(Ui.button(ctx, theme, "Remove") {
                repo.update(game) { p -> p.copy(kbm = p.kbm.copy(nodes = p.kbm.nodes.filter { it.keyCode != node.keyCode })) }
                onTap(host)
            })
            col.addView(row, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 3), 0, Ui.dp(ctx, 3)))
        }

        val actions = Ui.hbox(ctx)
        actions.addView(Ui.button(ctx, theme, "Edit on screen", true) {
            HudBus.closeHud?.invoke()
            HudBus.kbmEditor?.invoke() ?: host.toast("Open this from inside a game")
        }, Ui.lp(0, Ui.WRAP, 1f, 0, 0, Ui.dp(ctx, 3), 0))
        actions.addView(Ui.button(ctx, theme, "Starter layout") {
            repo.update(game) { it.copy(kbm = KbmPreset.default().copy(enabled = true)) }
            onTap(host)
        }, Ui.lp(0, Ui.WRAP, 1f, Ui.dp(ctx, 3), 0, Ui.dp(ctx, 3), 0))
        actions.addView(Ui.button(ctx, theme, "Clear") {
            repo.update(game) { it.copy(kbm = it.kbm.copy(nodes = emptyList())) }
            onTap(host)
        }, Ui.lp(0, Ui.WRAP, 1f, Ui.dp(ctx, 3), 0, 0, 0))
        col.addView(actions, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 10), 0, 0))
        col.addView(
            ToolUi.note(
                host,
                "Mouse buttons: Android 14 and newer reports them to the accessibility service. On older Android the mouse still works " +
                    "as the system's own click-to-tap, but extra buttons such as right-click cannot be mapped."
            ),
            Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 8), 0, 0)
        )
        host.openDetail("Keyboard and mouse", col as View)
    }
}

// =============================================================================================
// On-screen editor
// =============================================================================================

/**
 * Full-screen editor drawn over the game. Drag the joystick ring and every key node where the game's buttons are.
 * "Add key" waits for a real key press on the connected keyboard; the mouse buttons are added with their own
 * buttons. Done saves the layout into the game's profile.
 */
class KbmEditorOverlay(
    context: Context,
    private val wm: WindowManager,
    private val theme: HudTheme,
    private val game: String,
    private val repo: GameProfileRepository,
    private val mapper: KbmMapper,
    private val onClosed: () -> Unit
) {
    private val ctx: Context = context.applicationContext
    private var root: FrameLayout? = null
    private var canvas: EditorCanvas? = null
    private var status: TextView? = null
    private var tapHold: TextView? = null

    private var joyX = 0.17f
    private var joyY = 0.72f
    private var joyR = 0.10f
    private var joyOn = true
    private val nodes = ArrayList<KbmKeyNode>()
    private var selected = -1          // index in nodes, -2 = joystick, -1 = none
    private var base = KbmConfig()

    fun show() {
        if (root != null) return
        val prof = repo.profile(game) ?: repo.getOrCreate(game, game)
        base = prof.kbm
        joyX = base.joyX; joyY = base.joyY; joyR = base.joyRadius; joyOn = base.joystick
        nodes.clear()
        nodes.addAll(base.nodes)
        mapper.beginEdit()

        val r = FrameLayout(ctx)
        r.setBackgroundColor(0x66000000)
        val cv = EditorCanvas(ctx)
        canvas = cv
        r.addView(cv, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        r.addView(controls(), FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        root = r

        val p = WindowManager.LayoutParams(
            Ui.MATCH, Ui.MATCH, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        p.title = "HyperEngineKbmEditor"
        DisplayModeLock.applyCurrent(ctx, p)
        runCatching { wm.addView(r, p) }.onFailure {
            root = null
            mapper.endEdit()
            onClosed()
        }
        say("Drag the joystick ring and the key dots onto the game's buttons. Tap Add key, then press a key on the keyboard.")
    }

    fun close(save: Boolean) {
        if (save) {
            val cfg = base.copy(
                joystick = joyOn, joyX = joyX, joyY = joyY, joyRadius = joyR,
                nodes = nodes.toList()
            )
            repo.update(game) { it.copy(kbm = cfg) }
        }
        mapper.endEdit()
        root?.let { v -> runCatching { wm.removeViewImmediate(v) } }
        root = null
        canvas = null
        onClosed()
    }

    val isShowing: Boolean get() = root != null

    private fun say(text: String) {
        status?.text = text
    }

    private fun controls(): View {
        val box = Ui.vbox(ctx)
        box.background = Ui.rounded(HudThemes.withAlpha(theme.panelTop, 240), Ui.dpf(ctx, 14f), theme.accent, Ui.dp(ctx, 1))
        box.setPadding(Ui.dp(ctx, 10), Ui.dp(ctx, 8), Ui.dp(ctx, 10), Ui.dp(ctx, 8))
        status = Ui.label(ctx, "", 11f, theme.textSecondary).apply { maxLines = 2 }
        box.addView(Ui.label(ctx, "Keyboard and mouse layout", 13f, theme.textPrimary, true))
        box.addView(status, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 2), 0, Ui.dp(ctx, 6)))

        fun btn(text: String, filled: Boolean = false, click: () -> Unit): TextView =
            Ui.button(ctx, theme, text, filled, click).apply { textSize = 11f; setPadding(Ui.dp(ctx, 8), Ui.dp(ctx, 6), Ui.dp(ctx, 8), Ui.dp(ctx, 6)) }

        val r1 = Ui.hbox(ctx)
        r1.addView(btn("Add key", true) { addKey() }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, 0, Ui.dp(ctx, 4), 0))
        r1.addView(btn("Left click") { addMouse(KbmCodes.MOUSE_LEFT, "Fire") }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, 0, Ui.dp(ctx, 4), 0))
        r1.addView(btn("Right click") { addMouse(KbmCodes.MOUSE_RIGHT, "Scope") }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, 0, Ui.dp(ctx, 4), 0))
        r1.addView(btn("Middle") { addMouse(KbmCodes.MOUSE_MIDDLE, "") }, Ui.lp(Ui.WRAP, Ui.WRAP))
        box.addView(r1)

        val r2 = Ui.hbox(ctx)
        val th = btn("Tap") { toggleHold() }
        tapHold = th
        r2.addView(th, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, 0, Ui.dp(ctx, 4), 0))
        r2.addView(btn("Delete") { deleteSelected() }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, 0, Ui.dp(ctx, 4), 0))
        r2.addView(btn("Joy -") { joyR = (joyR - 0.01f).coerceAtLeast(0.04f); canvas?.invalidate() }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, 0, Ui.dp(ctx, 4), 0))
        r2.addView(btn("Joy +") { joyR = (joyR + 0.01f).coerceAtMost(0.25f); canvas?.invalidate() }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, 0, Ui.dp(ctx, 4), 0))
        r2.addView(btn("Starter") { loadStarter() }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, 0, Ui.dp(ctx, 4), 0))
        r2.addView(btn("Cancel") { close(false) }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, 0, Ui.dp(ctx, 4), 0))
        r2.addView(btn("Done", true) { close(true) }, Ui.lp(Ui.WRAP, Ui.WRAP))
        box.addView(r2, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, Ui.dp(ctx, 6), 0, 0))
        return box
    }

    private fun addKey() {
        say("Press the key you want to add on the keyboard...")
        mapper.captureNextKey { code ->
            canvas?.post {
                val i = nodes.indexOfFirst { it.keyCode == code }
                if (i >= 0) {
                    selected = i
                    say(KbmCodes.name(code) + " is already mapped. Drag it where you want it.")
                } else {
                    nodes += KbmKeyNode(code, 0.5f, 0.5f, false, "")
                    selected = nodes.size - 1
                    say("Added " + KbmCodes.name(code) + " in the middle. Drag it onto the game's button.")
                }
                refreshButtons()
                canvas?.invalidate()
            }
        }
    }

    private fun addMouse(code: Int, label: String) {
        val i = nodes.indexOfFirst { it.keyCode == code }
        if (i >= 0) {
            selected = i
        } else {
            nodes += KbmKeyNode(code, 0.5f, 0.5f, code == KbmCodes.MOUSE_LEFT, label)
            selected = nodes.size - 1
        }
        say(KbmCodes.name(code) + " added. Drag it onto the game's button. (Mouse buttons need Android 14 or newer.)")
        refreshButtons()
        canvas?.invalidate()
    }

    private fun toggleHold() {
        val i = selected
        if (i !in nodes.indices) return
        nodes[i] = nodes[i].copy(hold = !nodes[i].hold)
        refreshButtons()
        canvas?.invalidate()
    }

    private fun deleteSelected() {
        val i = selected
        if (i in nodes.indices) {
            nodes.removeAt(i)
            selected = -1
        } else if (i == -2) {
            joyOn = false
            selected = -1
        }
        refreshButtons()
        canvas?.invalidate()
    }

    private fun loadStarter() {
        val p = KbmPreset.default()
        nodes.clear()
        nodes.addAll(p.nodes)
        joyX = p.joyX; joyY = p.joyY; joyR = p.joyRadius; joyOn = true
        selected = -1
        say("Starter layout loaded. Drag everything onto your game's buttons.")
        refreshButtons()
        canvas?.invalidate()
    }

    private fun refreshButtons() {
        val i = selected
        tapHold?.text = if (i in nodes.indices && nodes[i].hold) "Hold" else "Tap"
    }

    // ---- canvas ----

    private inner class EditorCanvas(c: Context) : View(c) {
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = Paint.Align.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }
        private val d = c.resources.displayMetrics.density
        private var dragging = -1   // -2 joystick, >=0 node
        private var offX = 0f
        private var offY = 0f

        override fun onDraw(cv: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            if (joyOn) {
                val cx = joyX * w
                val cy = joyY * h
                val r = joyR * h
                line.color = if (selected == -2) theme.accent2 else theme.accent
                line.strokeWidth = 3f * d
                cv.drawCircle(cx, cy, r, line)
                fill.color = HudThemes.withAlpha(theme.accent, 50)
                cv.drawCircle(cx, cy, r, fill)
                fill.color = HudThemes.withAlpha(theme.accent, 200)
                cv.drawCircle(cx, cy, 8f * d, fill)
                text.color = 0xFFFFFFFF.toInt()
                text.textSize = 11f * d
                cv.drawText("W A S D", cx, cy - r - 6f * d, text)
            }
            for ((i, n) in nodes.withIndex()) {
                val x = n.x * w
                val y = n.y * h
                val sel = i == selected
                fill.color = HudThemes.withAlpha(if (n.hold) theme.accent2 else theme.accent, if (sel) 235 else 170)
                cv.drawCircle(x, y, 24f * d, fill)
                line.color = if (sel) 0xFFFFFFFF.toInt() else HudThemes.withAlpha(0xFFFFFFFF.toInt(), 160)
                line.strokeWidth = (if (sel) 3f else 1.5f) * d
                cv.drawCircle(x, y, 24f * d, line)
                text.color = HudThemes.onAccent(if (n.hold) theme.accent2 else theme.accent)
                text.textSize = 11f * d
                cv.drawText(KbmCodes.short(n.keyCode), x, y + 4f * d, text)
                if (n.label.isNotBlank()) {
                    text.color = 0xFFFFFFFF.toInt()
                    text.textSize = 9f * d
                    cv.drawText(n.label, x, y + 38f * d, text)
                }
            }
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            val w = width.toFloat()
            val h = height.toFloat()
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragging = -1
                    var best = Float.MAX_VALUE
                    for ((i, n) in nodes.withIndex()) {
                        val dist = hypot(e.x - n.x * w, e.y - n.y * h)
                        if (dist < 34f * d && dist < best) { best = dist; dragging = i }
                    }
                    if (dragging < 0 && joyOn) {
                        val cx = joyX * w
                        val cy = joyY * h
                        val dist = hypot(e.x - cx, e.y - cy)
                        if (dist < joyR * h + 16f * d) dragging = -2
                    }
                    selected = if (dragging == -1) -1 else dragging
                    if (dragging >= 0) {
                        offX = nodes[dragging].x * w - e.x
                        offY = nodes[dragging].y * h - e.y
                    } else if (dragging == -2) {
                        offX = joyX * w - e.x
                        offY = joyY * h - e.y
                    }
                    refreshButtons()
                    invalidate()
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val nx = ((e.x + offX) / w).coerceIn(0.02f, 0.98f)
                    val ny = ((e.y + offY) / h).coerceIn(0.02f, 0.98f)
                    if (dragging >= 0 && dragging < nodes.size) {
                        nodes[dragging] = nodes[dragging].copy(x = nx, y = ny)
                    } else if (dragging == -2) {
                        joyX = nx
                        joyY = ny
                    }
                    invalidate()
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    dragging = -1
                    return true
                }
            }
            return super.onTouchEvent(e)
        }
    }
}
