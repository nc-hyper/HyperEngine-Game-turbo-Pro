package com.hyperengine.gameturbo.core

import android.os.SystemClock
import android.view.MotionEvent
import com.hyperengine.gameturbo.data.AutoTouchScript
import com.hyperengine.gameturbo.data.CommandMacro
import com.hyperengine.gameturbo.data.MacroEvent
import com.hyperengine.gameturbo.data.MacroEventType
import kotlin.math.abs

/**
 * Records a Realme-style "Command": the exact taps, holds and swipe paths of up to four fingers with
 * millisecond timestamps. It does not own a window. The recording overlay (the Realme dock's REC mode)
 * feeds it every MotionEvent it receives, and [finish] returns the [CommandMacro] to save in the script.
 *
 * Fingers: each real pointer id is given the lowest free recorded slot 0..3. A fifth simultaneous finger is
 * ignored. Replay ([AutoTouchEngine.playMacro]) puts every recorded slot on its own synthetic finger.
 *
 * Samples: coordinates are stored as fractions of the screen so a command survives a resolution change.
 * MOVE samples are thinned: a finger must have moved at least MIN_MOVE_PX (1.5 px) AND at least
 * MIN_MOVE_GAP_MS (8 ms) must have passed since its last sample, so a 10 second swipe is a few hundred
 * samples and not twenty thousand.
 *
 * Live forwarding: the recording surface swallows the touches, so the game underneath would not react while
 * you record. With [forward] on, every recorded finger is also injected through [touch] so the game sees the
 * touch as well (the combo can be tested while it is recorded). Off by default.
 *
 * Not thread safe: call everything from the main thread (view touch callbacks).
 */
class MacroRecorder(private val touch: MultiTouchInjector? = null) {

    private val events = ArrayList<MacroEvent>(512)
    private val slotOfPointer = HashMap<Int, Int>()
    private val lastX = FloatArray(SLOTS)
    private val lastY = FloatArray(SLOTS)
    private val lastT = LongArray(SLOTS)
    private val handles = arrayOfNulls<TouchHandle>(SLOTS)

    private var width = 1f
    private var height = 1f
    private var firstEventTime = -1L
    private var startedUptime = 0L
    private var forward = false

    var recording: Boolean = false
        private set

    /** Samples captured so far (for the live counter on the dock). */
    val eventCount: Int get() = events.size

    val elapsedMs: Long get() = if (recording) SystemClock.uptimeMillis() - startedUptime else 0L

    /** True while at least one recorded finger is on the screen. */
    val fingerDown: Boolean get() = slotOfPointer.isNotEmpty()

    /** Starts a new recording for a screen of [screenW] x [screenH] px. Discards anything recorded before. */
    fun begin(screenW: Int, screenH: Int, forward: Boolean = false) {
        discardHandles()
        events.clear()
        slotOfPointer.clear()
        width = screenW.coerceAtLeast(1).toFloat()
        height = screenH.coerceAtLeast(1).toFloat()
        firstEventTime = -1L
        startedUptime = SystemClock.uptimeMillis()
        this.forward = forward && touch != null
        recording = true
    }

    /**
     * Feeds one touch event. [offsetX] / [offsetY] convert view coordinates to screen coordinates (pass the
     * view's on-screen position, 0 for a full-screen window). Returns true while recording.
     */
    fun onTouch(e: MotionEvent, offsetX: Float = 0f, offsetY: Float = 0f): Boolean {
        if (!recording) return false
        if (firstEventTime < 0L) firstEventTime = e.eventTime
        val t = (e.eventTime - firstEventTime).coerceAtLeast(0L)

        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                val slot = claimSlot(e.getPointerId(i))
                if (slot >= 0 && events.size < MAX_EVENTS - RESERVE_FOR_UP) {
                    val x = e.getX(i) + offsetX
                    val y = e.getY(i) + offsetY
                    add(t, MacroEventType.DOWN, slot, x, y)
                    if (forward) handles[slot] = touch?.beginHold(x, y, OWNER)
                } else if (slot >= 0) {
                    slotOfPointer.remove(e.getPointerId(i))   // buffer full: refuse this finger
                }
            }

            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) {
                    val slot = slotOfPointer[e.getPointerId(i)] ?: continue
                    val x = e.getX(i) + offsetX
                    val y = e.getY(i) + offsetY
                    val moved = abs(x - lastX[slot]) >= MIN_MOVE_PX || abs(y - lastY[slot]) >= MIN_MOVE_PX
                    val waited = t - lastT[slot] >= MIN_MOVE_GAP_MS
                    if ((moved && waited) && events.size < MAX_EVENTS - RESERVE_FOR_UP) {
                        add(t, MacroEventType.MOVE, slot, x, y)
                        handles[slot]?.let { touch?.moveHold(it, x, y) }
                    }
                }
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val i = e.actionIndex
                val slot = slotOfPointer.remove(e.getPointerId(i))
                if (slot != null) {
                    add(t, MacroEventType.UP, slot, e.getX(i) + offsetX, e.getY(i) + offsetY)
                    releaseHandle(slot)
                }
            }

            MotionEvent.ACTION_CANCEL -> closeAllFingers(t)
        }
        return true
    }

    /**
     * Ends the recording and returns the command, or null when nothing was captured. A finger still down is
     * lifted at the last timestamp so the command can never leave a stuck touch behind.
     */
    fun finish(name: String): CommandMacro? {
        if (!recording) return null
        closeAllFingers((events.lastOrNull()?.tMs ?: 0L))
        recording = false
        discardHandles()
        if (events.none { it.type == MacroEventType.DOWN }) {
            events.clear()
            return null
        }
        val now = System.currentTimeMillis()
        val macro = CommandMacro(
            id = "cmd_" + now.toString(36),
            name = name.trim().take(AutoTouchScript.MAX_NAME).ifBlank { "Command" },
            durationMs = events.last().tMs,
            events = ArrayList(events),
            createdAt = now
        ).clamped()
        events.clear()
        return macro
    }

    /** Throws the recording away. */
    fun cancel() {
        recording = false
        discardHandles()
        events.clear()
        slotOfPointer.clear()
    }

    // ---------------------------------------------------------------------------------------------

    private fun claimSlot(pointerId: Int): Int {
        slotOfPointer[pointerId]?.let { return it }
        for (s in 0 until SLOTS) {
            if (!slotOfPointer.containsValue(s)) {
                slotOfPointer[pointerId] = s
                return s
            }
        }
        return -1
    }

    private fun add(t: Long, type: MacroEventType, slot: Int, x: Float, y: Float) {
        lastX[slot] = x
        lastY[slot] = y
        lastT[slot] = t
        events.add(
            MacroEvent(
                tMs = t, type = type, slot = slot,
                x = (x / width).coerceIn(0f, 1f),
                y = (y / height).coerceIn(0f, 1f)
            )
        )
    }

    private fun closeAllFingers(t: Long) {
        val open = slotOfPointer.values.toList()
        slotOfPointer.clear()
        for (slot in open) {
            // the buffer reserve guarantees room for these
            events.add(
                MacroEvent(
                    tMs = t, type = MacroEventType.UP, slot = slot,
                    x = (lastX[slot] / width).coerceIn(0f, 1f),
                    y = (lastY[slot] / height).coerceIn(0f, 1f)
                )
            )
            releaseHandle(slot)
        }
    }

    private fun releaseHandle(slot: Int) {
        val h = handles[slot] ?: return
        handles[slot] = null
        touch?.endHold(h)
    }

    private fun discardHandles() {
        for (s in 0 until SLOTS) releaseHandle(s)
    }

    companion object {
        private const val SLOTS = 4
        private const val OWNER = "record"
        private const val MAX_EVENTS = AutoTouchScript.MAX_EVENTS_PER_MACRO
        private const val RESERVE_FOR_UP = 16
        private const val MIN_MOVE_PX = 1.5f
        private const val MIN_MOVE_GAP_MS = 8L
    }
}
