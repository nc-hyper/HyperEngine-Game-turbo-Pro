package com.hyperengine.gameturbo.core

import android.content.Context
import android.os.SystemClock
import com.hyperengine.gameturbo.HyperApp
import com.hyperengine.gameturbo.data.GameProfile
import com.hyperengine.gameturbo.data.GameProfileRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull

data class GuardState(
    val game: String? = null,
    val panelOwned: Boolean = false,          // this guard locked the panel for the current game
    val smootherOwned: Boolean = false,       // this guard started the frame smoother for the current game
    val restoreInSec: Int? = null,            // countdown after the game left the screen
    val boostEndsInSec: Int? = null,          // countdown after the benchmark app left the screen
    val lastRestore: List<StepResult> = emptyList()
) {
    val holding: Boolean get() = panelOwned || smootherOwned
}

/**
 * Part 10: the session guard. It owns the "a game or benchmark is running, so the phone is in a special state, and it must
 * go back by itself" part of Parts 1 to 9, driven by the foreground watcher ([com.hyperengine.gameturbo.service.GameDetectorService]).
 *
 * Game starts:
 *   - [MaxPanelHzEngine.engage] for that game and [HardwareFrameSmoother.engage], each behind its own switch
 *     ([autoPanel], [autoSmoother], both on by default). The panel lock is skipped when the game's profile already picks a
 *     refresh rate or an FPS: the user's per-game choice wins, and the profile engine applies it.
 *   - Only what the guard started itself is ever released by it. A lock the user took from the HUD or the Lab card stays theirs.
 *
 * Game leaves:
 *   - After the same delay the optimisation engine uses (profile or global "restore delay", 15 s by default) the guard
 *     releases the frame smoother and the panel lock. Coming back inside the delay cancels it.
 *   - While a benchmark boost is on, the release waits; it happens when the boost ends.
 *
 * Benchmark boost ([AntutuBenchmarkBooster]) is ended automatically when
 *   - the apps it was started for were in front and then left for [BOOST_AWAY_MS] (default 45 s), or
 *   - none of them was opened within [BOOST_IDLE_MS] (default 15 min), or
 *   - the battery limit trips (handled inside the booster itself).
 *   Turn that off with [autoEndBoost] to keep the boost on until you stop it.
 *
 * Crash / reboot: [recoverPending] gives every engine the chance to undo what a dead process left behind.
 * Watcher stops: [releaseAll] puts everything back immediately, because nothing would restore it later.
 */
class GameSessionGuard private constructor(
    ctx: Context,
    private val engine: OptimizationEngine,
    private val repo: GameProfileRepository,
    private val maxHz: MaxPanelHzEngine,
    private val smoother: HardwareFrameSmoother,
    private val booster: AntutuBenchmarkBooster
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val lock = Mutex()
    private val prefs = ctx.getSharedPreferences("hyper_session", Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(GuardState())
    val state: StateFlow<GuardState> = _state.asStateFlow()

    @Volatile private var current: String? = null
    @Volatile private var restoreJob: Job? = null
    @Volatile private var ending = false

    // benchmark watch (touched only from the watcher thread, through onForegroundApp)
    private var boostStartedAt = 0L
    private var boostSeen = false
    private var lastTargetTick = 0L
    private var targets: Set<String>? = null

    // ───────────────────── Switches (persisted) ─────────────────────

    var autoPanel: Boolean
        get() = prefs.getBoolean(K_PANEL, true)
        set(v) { prefs.edit().putBoolean(K_PANEL, v).apply() }

    var autoSmoother: Boolean
        get() = prefs.getBoolean(K_SMOOTH, true)
        set(v) { prefs.edit().putBoolean(K_SMOOTH, v).apply() }

    var autoEndBoost: Boolean
        get() = prefs.getBoolean(K_ENDBOOST, true)
        set(v) { prefs.edit().putBoolean(K_ENDBOOST, v).apply() }

    init {
        // A boost that ends from anywhere (Lab card, HUD toggle, safety limit) frees what a game session had to leave in place.
        scope.launch {
            booster.state.map { it.active }.distinctUntilChanged().collect { active ->
                targets = null
                if (active) {
                    boostStartedAt = 0L
                    boostSeen = false
                    lastTargetTick = 0L
                } else {
                    boostStartedAt = 0L
                    _state.update { it.copy(boostEndsInSec = null) }
                    if (current == null && restoreJob == null && _state.value.holding) restoreNow("benchmark boost ended")
                }
            }
        }
    }

    // ───────────────────── Game lifecycle (called by the watcher) ─────────────────────

    fun onGameForeground(game: String) {
        cancelRestore()
        current = game
        _state.update { it.copy(game = game, restoreInSec = null) }
        scope.launch {
            val profile = repo.profile(game)
            if (profile != null && !profile.enabled) return@launch
            // the profile engine applies its own refresh-rate step first; ours must come after it
            withTimeoutOrNull(ENGINE_WAIT_MS) { engine.status.first { it.activeGame == game && it.busy == null } }
            if (current != game) return@launch
            lock.withLock {
                if (current != game) return@withLock
                if (autoPanel && profileLeavesRateToUs(profile)) engagePanelLocked(game)
                if (autoSmoother && !smoother.state.value.engaged) {
                    smoother.engage()
                    if (smoother.state.value.engaged) _state.update { it.copy(smootherOwned = true) }
                }
            }
        }
    }

    fun onGameBackground() {
        val g = current ?: return
        current = null
        if (!_state.value.holding) {
            _state.update { it.copy(game = null) }
            return
        }
        val delaySec = repo.global.value.restoreDelayFor(repo.profile(g))
        cancelRestore()
        restoreJob = scope.launch {
            var left = delaySec
            while (left > 0) {
                _state.update { it.copy(restoreInSec = left) }
                delay(1_000L)
                left--
            }
            restoreNow("game closed")
        }
    }

    private suspend fun engagePanelLocked(game: String) {
        val st = maxHz.state.value
        if (st.engaged && !_state.value.panelOwned) return // the user's own lock (HUD / Lab card): leave it alone
        if (st.engaged && st.game == game) return           // already ours, for this game
        if (st.engaged) {                                   // ours, but for the previous game
            maxHz.release("switched to another game")
            _state.update { it.copy(panelOwned = false) }
        }
        maxHz.engage(game)
        if (maxHz.state.value.engaged) _state.update { it.copy(panelOwned = true) }
    }

    /** The profile owns the rate when it picks a refresh rate, an FPS unlock or motion smoothing. */
    private fun profileLeavesRateToUs(p: GameProfile?): Boolean =
        p == null || (p.refreshHz == 0 && p.turbo.unlockFps <= 0 && !p.turbo.motionSmoothing)

    private fun cancelRestore() {
        restoreJob?.cancel()
        restoreJob = null
        _state.update { it.copy(restoreInSec = null) }
    }

    /** Puts back what the guard started. Waits while a benchmark boost is on (the boost's end triggers it again). */
    suspend fun restoreNow(reason: String): List<StepResult> = lock.withLock<List<StepResult>> {
        restoreJob = null
        val out = ArrayList<StepResult>()
        if (booster.state.value.active) {
            _state.update { it.copy(restoreInSec = null) }
            return@withLock out
        }
        val s = _state.value
        if (s.smootherOwned && smoother.state.value.engaged) out += smoother.release()
        if (s.panelOwned && maxHz.state.value.engaged) out += maxHz.release(reason)
        _state.update {
            it.copy(game = current, panelOwned = false, smootherOwned = false, restoreInSec = null, lastRestore = out)
        }
        out
    }

    /** Watcher is stopping: nothing would restore the phone later, so everything goes back now, boost included. */
    suspend fun releaseAll(reason: String): List<StepResult> {
        cancelRestore()
        current = null
        val out = ArrayList<StepResult>()
        if (booster.state.value.active) {
            out += booster.release(reason)
            if (smoother.state.value.engaged) out += smoother.release()
        }
        out += restoreNow(reason)
        _state.update { it.copy(game = null, boostEndsInSec = null) }
        return out
    }

    // ───────────────────── Benchmark watch (called on every watcher tick) ─────────────────────

    /**
     * [pkg] is the app in front, null when nothing could be read or the screen is off. Our own app, the keyboard and system UI
     * never reach this call (the watcher filters them), so a quick look at the Lab card does not count as leaving.
     */
    fun onForegroundApp(pkg: String?) {
        if (!booster.state.value.active) return
        if (!autoEndBoost) {
            if (_state.value.boostEndsInSec != null) _state.update { it.copy(boostEndsInSec = null) }
            return
        }
        val now = SystemClock.elapsedRealtime()
        if (boostStartedAt == 0L) boostStartedAt = now
        val watched = targets ?: booster.engagedTargets().also { targets = it }
        val inTarget = pkg != null && pkg in watched
        if (inTarget) {
            boostSeen = true
            lastTargetTick = now
            if (_state.value.boostEndsInSec != null) _state.update { it.copy(boostEndsInSec = null) }
            return
        }
        val deadline = if (boostSeen) lastTargetTick + BOOST_AWAY_MS else boostStartedAt + BOOST_IDLE_MS
        val left = ((deadline - now) / 1000L).toInt()
        // The countdown is shown only for the short "app closed" wait; the 15 min idle limit stays quiet until the last minute.
        val shown = if (boostSeen || left <= 60) left.coerceAtLeast(0) else null
        _state.update { if (it.boostEndsInSec == shown) it else it.copy(boostEndsInSec = shown) }
        if (now >= deadline) {
            endBoost(if (boostSeen) "the benchmark app was closed" else "no benchmark app was opened for ${BOOST_IDLE_MS / 60_000L} min")
        }
    }

    private fun endBoost(reason: String) {
        if (ending) return
        ending = true
        scope.launch {
            try {
                val steps = ArrayList<StepResult>()
                steps += booster.release("auto: $reason")
                // the Lab card and the HUD start the smoother together with the boost; stop it with the boost
                if (smoother.state.value.engaged && !_state.value.smootherOwned) steps += smoother.release()
                _state.update { it.copy(boostEndsInSec = null, lastRestore = steps) }
            } finally {
                ending = false
            }
        }
    }

    // ───────────────────── Crash / reboot recovery ─────────────────────

    /** Undoes whatever a dead process left on. The watcher calls it once, when no game is in front. */
    suspend fun recoverPending(): List<StepResult> {
        val out = ArrayList<StepResult>()
        out += booster.recoverPending()   // also recovers the panel lock it took, and the per-game overrides
        out += smoother.recoverPending()
        out += maxHz.recoverPending()
        return out
    }

    companion object {
        private const val K_PANEL = "auto_panel"
        private const val K_SMOOTH = "auto_smoother"
        private const val K_ENDBOOST = "auto_end_boost"
        private const val ENGINE_WAIT_MS = 8_000L
        private const val BOOST_AWAY_MS = 45_000L
        private const val BOOST_IDLE_MS = 15 * 60_000L

        @Volatile private var inst: GameSessionGuard? = null

        /** App-wide instance built from the objects HyperApp already owns (no HyperApp edit needed). */
        fun from(ctx: Context): GameSessionGuard = inst ?: synchronized(this) {
            inst ?: run {
                val app = HyperApp.instance
                val c = ctx.applicationContext
                GameSessionGuard(
                    c, app.engine, app.repository,
                    MaxPanelHzEngine.from(c), HardwareFrameSmoother.from(c), AntutuBenchmarkBooster.from(c)
                )
            }.also { inst = it }
        }
    }
}
