package com.hyperengine.gameturbo.core

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.database.ContentObserver
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.hardware.display.DisplayManager
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Choreographer
import android.view.Display
import android.view.View
import android.view.WindowManager
import androidx.core.content.ContextCompat
import com.hyperengine.gameturbo.data.GameProfileRepository
import com.hyperengine.gameturbo.service.TouchMacroService
import com.hyperengine.gameturbo.ui.OverlayKit
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

// ---------------------------------------------------------------------------------------------
// Public types
// ---------------------------------------------------------------------------------------------

data class FpsEnforcerState(
    val active: Boolean = false,              // the 5-layer override is applied
    val game: String? = null,
    val targetFps: Int = 0,
    val lockedHz: Int = 0,                    // rate the watchdog and the overlay lock are holding (0 = none)
    val displayHzNow: Int = 0,
    val reapplyCount: Int = 0,
    val lastReapply: String = "",
    val motionSmoothing: Boolean = false,
    val bfiPct: Int = 0,
    val busy: String? = null,
    val layers: List<StepResult> = emptyList()
)

data class FpsUnlockReport(
    val fps: Int,
    val panelHz: Int,                         // refresh rate the panel was asked for
    val panelRates: List<Int>,
    val displayHzNow: Int,                    // what the display really reports afterwards
    val layers: List<StepResult>
) {
    val failures: Int get() = layers.count { !it.ok }
    /** True when the panel physically cannot reach the requested FPS (for example 144 on a 120 Hz screen). */
    val panelTooSlow: Boolean get() = panelRates.isNotEmpty() && panelHz < fps
}

// ---------------------------------------------------------------------------------------------
// Display-mode lock for overlay windows (Layer 5)
// ---------------------------------------------------------------------------------------------

/**
 * Stamps a refresh-rate preference onto a WindowManager.LayoutParams. Every overlay window that stays
 * on top of the game (edge handle, FPS pill, sidebar, the dedicated lock window) carries it, so the
 * window policy keeps asking for the same display mode even after the OEM power manager resets the
 * global setting. Whether the compositor honours an overlay's request is up to the ROM; this is why
 * the watchdog and the settings layers exist as well.
 */
object DisplayModeLock {

    /** Rate that overlay windows should request right now (0 = no preference). Written by the enforcer. */
    @Volatile
    var currentHz: Int = 0

    fun defaultDisplay(ctx: Context): Display? = runCatching {
        (ctx.applicationContext.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager)
            .getDisplay(Display.DEFAULT_DISPLAY)
    }.getOrNull()

    /** The mode whose rate is closest to [hz], among the modes with the display's current resolution. */
    fun resolve(display: Display?, hz: Int): Display.Mode? {
        if (display == null || hz <= 0) return null
        val cur = runCatching { display.mode }.getOrNull() ?: return null
        val all = runCatching { display.supportedModes.toList() }.getOrDefault(emptyList())
        val sameRes = all.filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
        return (if (sameRes.isEmpty()) all else sameRes).minByOrNull { abs(it.refreshRate - hz) }
    }

    /** Sets preferredDisplayModeId + preferredRefreshRate. Returns false when no matching mode exists. */
    fun apply(p: WindowManager.LayoutParams, display: Display?, hz: Int): Boolean {
        if (hz <= 0) {
            clear(p)
            return false
        }
        val mode = resolve(display, hz) ?: return false
        p.preferredDisplayModeId = mode.modeId
        p.preferredRefreshRate = mode.refreshRate
        setMinRate(p, mode.refreshRate)
        return true
    }

    /** Convenience for overlay code: applies whatever the enforcer is currently holding. */
    fun applyCurrent(ctx: Context, p: WindowManager.LayoutParams): Boolean =
        apply(p, defaultDisplay(ctx), currentHz)

    fun clear(p: WindowManager.LayoutParams) {
        p.preferredDisplayModeId = 0
        p.preferredRefreshRate = 0f
        setMinRate(p, 0f)
    }

    /** Android 14+ "at least this rate" hint. Reflection keeps this compiling on any SDK; ignored where absent. */
    private fun setMinRate(p: WindowManager.LayoutParams, hz: Float) {
        runCatching {
            WindowManager.LayoutParams::class.java.getField("preferredMinDisplayRefreshRate").setFloat(p, hz)
        }
    }
}

// ---------------------------------------------------------------------------------------------
// OEM battery / FPS throttlers (Layer 1), shared with the Wild Boost engine
// ---------------------------------------------------------------------------------------------

/**
 * Suspends the vendor power managers that cap frame rate in the background (Xiaomi PowerKeeper,
 * Realme/OPPO battery manager). Reference counted: the FPS unlocker and Wild Boost can both hold it,
 * the apps are released only when the last holder lets go. Original app-op modes are written to
 * [Phase2Store] before they are changed.
 */
class ThrottlerGuard(
    private val ctx: Context,
    private val bridge: SystemBridgeExecutor,
    private val store: Phase2Store
) {
    private val mutex = Mutex()
    private val holders = LinkedHashSet<String>()
    private val ops = listOf("RUN_IN_BACKGROUND", "RUN_ANY_IN_BACKGROUND")

    val packages = listOf("com.miui.powerkeeper", "com.oplus.battery")

    suspend fun acquire(owner: String): List<StepResult> = mutex.withLock {
        val first = holders.isEmpty()
        holders += owner
        if (!first) return@withLock listOf(StepResult("OEM throttlers", true, "already suspended"))
        if (!bridge.hasShell()) {
            holders -= owner
            return@withLock listOf(StepResult("OEM throttlers", false, "needs Shizuku or root"))
        }
        val present = packages.filter { installed(it) }
        if (present.isEmpty()) {
            return@withLock listOf(StepResult("OEM throttlers", true, "none installed on this phone, nothing to suspend"))
        }
        val out = ArrayList<StepResult>()
        for (pkg in present) {
            val problems = ArrayList<String>()
            for (op in ops) {
                val original = readMode(pkg, op)
                // the original goes to disk BEFORE the change
                store.update { s ->
                    if (s.appOps.any { it.pkg == pkg && it.op == op }) s
                    else s.copy(appOps = s.appOps + AppOpBackup(pkg, op, original))
                }
                val r = bridge.setAppOp(pkg, op, "ignore")
                if (!r.ok) {
                    problems += "$op: ${r.message}"
                    store.update { s -> s.copy(appOps = s.appOps.filterNot { it.pkg == pkg && it.op == op }) }
                }
            }
            val stop = bridge.forceStop(pkg)
            if (!stop.ok) problems += "force-stop: ${stop.message}"
            out += StepResult(
                "OEM throttler $pkg",
                problems.isEmpty(),
                if (problems.isEmpty()) "force-stopped, background run blocked" else problems.joinToString("; ")
            )
        }
        out
    }

    suspend fun release(owner: String): List<StepResult> = mutex.withLock {
        holders -= owner
        if (holders.isNotEmpty()) emptyList() else restoreStored()
    }

    /** Crash / restart recovery: ignores the holder list and restores everything on disk. */
    suspend fun restoreAll(): List<StepResult> = mutex.withLock {
        holders.clear()
        restoreStored()
    }

    private suspend fun restoreStored(): List<StepResult> {
        val pending = store.snapshot.appOps
        if (pending.isEmpty()) return emptyList()
        if (!bridge.hasShell()) return listOf(StepResult("OEM throttlers restore", false, "needs Shizuku or root; will retry"))
        var restored = 0
        val failed = ArrayList<String>()
        for (b in pending) {
            val mode = if (b.original in Validators.APPOP_MODES) b.original else "default"
            val r = bridge.setAppOp(b.pkg, b.op, mode)
            if (r.ok) {
                restored++
                store.update { s -> s.copy(appOps = s.appOps - b) }
            } else {
                failed += "${b.pkg} ${b.op}: ${r.message}"
            }
        }
        return listOf(
            StepResult(
                "OEM throttlers restored", failed.isEmpty(),
                if (failed.isEmpty()) "$restored app ops put back" else failed.joinToString(" | ")
            )
        )
    }

    private suspend fun readMode(pkg: String, op: String): String {
        val r = bridge.shell("cmd appops get $pkg $op 2>/dev/null | head -n 1", 6_000L)
        val mode = Regex("$op\\s*:\\s*([A-Za-z_]+)", RegexOption.IGNORE_CASE).find(r.stdout)
            ?.groupValues?.get(1)?.lowercase(Locale.US)
        return if (mode != null && mode in Validators.APPOP_MODES) mode else "default"
    }

    @Suppress("DEPRECATION")
    private fun installed(pkg: String): Boolean = try {
        ctx.packageManager.getPackageInfo(pkg, 0)
        true
    } catch (_: PackageManager.NameNotFoundException) {
        false
    } catch (_: Throwable) {
        false
    }
}

// ---------------------------------------------------------------------------------------------
// The enforcer
// ---------------------------------------------------------------------------------------------

/**
 * 5-layer FPS / refresh-rate override with an app-switch watchdog.
 *
 *  Layer 1  OEM throttlers (PowerKeeper / Oplus battery) force-stopped and blocked from the background
 *  Layer 2  GameManager: `cmd game set --mode performance --fps N` (through OptimizationEngine, so it is
 *           tracked and restored) plus `device_config put game_overlay <pkg> mode=2,fps=N,...`
 *  Layer 3  peak / min / user / miui refresh-rate settings (through OptimizationEngine.lockRefreshRate)
 *  Layer 4  `setprop debug.sf.frame_rate_multiple_threshold N`
 *  Layer 5  display-mode lock on every overlay window ([DisplayModeLock]) plus a dedicated 1x1 lock window
 *
 * Watchdog: re-applies the lock within about 50 ms when the OEM resets it. Triggers are a ContentObserver
 * on the four refresh-rate keys, accessibility window-state events, a DisplayListener, screen-on, and
 * the foreground-app callback from the game detector. It only fights while OptimizationEngine still holds
 * the original values, so a Restore from anywhere switches it off instead of being undone.
 *
 * Honest limits: the panel decides what is possible. A request for 144 Hz on a 120 Hz screen is rounded
 * down and reported as such, and nothing here can make a game render more frames than the game itself
 * allows. What it removes are the ways Android and the OEM skins pull the panel back to 60 Hz.
 */
class FpsRefreshRateEnforcer(
    context: Context,
    private val bridge: SystemBridgeExecutor,
    private val engine: OptimizationEngine,
    private val repo: GameProfileRepository,
    private val store: Phase2Store
) {

    private val ctx: Context = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutex = Mutex()
    private val enforceGen = AtomicInteger(0)

    val throttlers = ThrottlerGuard(ctx, bridge, store)

    private val _state = MutableStateFlow(FpsEnforcerState())
    val state: StateFlow<FpsEnforcerState> = _state.asStateFlow()

    private val _lockedHz = MutableStateFlow(0)
    /** The rate overlay windows should request. HudController re-stamps its windows whenever this changes. */
    val lockedHz: StateFlow<Int> = _lockedHz.asStateFlow()

    /** Set by HudController: re-stamps the handle / pill / sidebar windows with [DisplayModeLock]. */
    @Volatile
    var overlayRefresh: (() -> Unit)? = null

    // watchdog plumbing (all callbacks run on this thread, never on the UI thread)
    private val wdThread = HandlerThread("hyper-fps-watchdog").also { it.start() }
    private val wd = Handler(wdThread.looper)
    private val main = Handler(Looper.getMainLooper())
    private val dm = ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    @Volatile private var watching = false
    @Volatile private var activeGame: String? = null
    @Volatile private var settingsWritable = true
    private var releaseJob: Job? = null
    private var started = false

    private val stamps = ArrayDeque<Long>()
    private var backoffUntil = 0L
    private var lastRestamp = 0L
    @Volatile private var pendingReason = ""

    private val observer = object : ContentObserver(wd) {
        override fun onChange(selfChange: Boolean) = scheduleReapply("refresh-rate setting changed", 30L)
        override fun onChange(selfChange: Boolean, uri: android.net.Uri?) =
            scheduleReapply("setting changed: ${uri?.lastPathSegment ?: "?"}", 30L)
    }

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) {
            if (displayId != Display.DEFAULT_DISPLAY) return
            val hz = _lockedHz.value
            if (hz <= 0) return
            val now = DisplayModeLock.defaultDisplay(ctx)?.refreshRate ?: return
            _state.update { it.copy(displayHzNow = now.roundToInt()) }
            if (now < hz - 1.5f) scheduleReapply("display dropped to ${now.roundToInt()} Hz", 0L)
        }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) = scheduleReapply("screen turned on", 100L)
    }

    private val reapplyRunnable = Runnable { scope.launch { reapplyNow() } }

    // =========================================================================================
    // Lifecycle
    // =========================================================================================

    /** Call once from Application.onCreate. */
    fun start() {
        if (started) return
        started = true
        // accessibility window-state events: notification shade, Recents, app switch, game regaining focus
        TouchMacroService.windowListener = { pkg -> onWindowChanged(pkg) }

        // When the engine has restored the phone (its timer, the hub's Restore button), our side goes too.
        scope.launch {
            var sawActive = false
            engine.status.collect { st ->
                if (st.sessionActive) {
                    sawActive = true
                } else if (sawActive) {
                    sawActive = false
                    if (_lockedHz.value > 0 || !store.snapshot.isEmpty()) {
                        releaseSoft("OptimizationEngine restored the phone", enforceGen.get())
                    }
                }
            }
        }
    }

    /** Game came forward. Waits for the profile to be applied, then runs the layers the profile asks for. */
    fun onGameForeground(pkg: String) {
        cancelRelease()
        activeGame = pkg
        scope.launch {
            val p = repo.profile(pkg) ?: return@launch
            if (!p.enabled) return@launch
            val fps = p.turbo.unlockFps
            val smooth = p.turbo.motionSmoothing
            if (fps <= 0 && !smooth) {
                // No FPS unlock, but the user picked a refresh rate for this game: hold it so the ROM cannot undo it.
                if (p.refreshHz != 0) {
                    withTimeoutOrNull(8_000L) { engine.status.first { it.activeGame == pkg && it.busy == null } }
                    if (activeGame != pkg) return@launch
                    val hz = explicitHzFor(pkg, engine.supportedRefreshRates())
                    if (hz > 0 && _lockedHz.value != hz) holdRate(hz)
                }
                return@launch
            }

            val st = _state.value
            if (st.active && st.game == pkg && st.targetFps == fps && (st.motionSmoothing == smooth)) {
                scheduleReapply("game regained focus", 0L)
                return@launch
            }
            // The engine applies the profile first; its own refresh-rate step must not overwrite ours.
            withTimeoutOrNull(8_000L) { engine.status.first { it.activeGame == pkg && it.busy == null } }
            if (activeGame != pkg) return@launch
            if (fps > 0) enforce(pkg, fps)
            if (smooth) setMotionSmoothing(pkg, true, p.turbo.bfiPct)
        }
    }

    /** Game left. Everything of ours is released shortly before the engine restores its own settings. */
    fun onGameBackground() {
        val pkg = activeGame ?: return
        val delaySec = repo.global.value.restoreDelayFor(repo.profile(pkg))
        cancelRelease()
        releaseJob = scope.launch {
            // 1.5 s early, so the engine's restore is never undone by our watchdog
            delay((delaySec * 1000L - 1_500L).coerceAtLeast(0L))
            releaseSoft("game in background for more than ${delaySec}s")
        }
    }

    /** Foreground app changed (from the game detector's usage-stats loop). */
    fun onForegroundApp(pkg: String?) {
        if (pkg != null) onWindowChanged(pkg)
    }

    /** Puts back everything left over by a killed process. Needs the shell, so call it once the bridge is up. */
    suspend fun recoverPending(): List<StepResult> = mutex.withLock {
        val out = ArrayList<StepResult>()
        if (store.snapshot.appOps.isNotEmpty()) out += throttlers.restoreAll()
        out += restoreProps()
        out += restoreDeviceConfig()
        out
    }

    private fun cancelRelease() {
        releaseJob?.cancel()
        releaseJob = null
    }

    // =========================================================================================
    // Public actions
    // =========================================================================================

    /** HUD / hub entry: saves the choice in the profile, then applies or removes the override. */
    suspend fun setUnlock(pkg: String, fps: Int): List<StepResult> {
        repo.update(pkg) { it.copy(turbo = it.turbo.copy(unlockFps = fps.coerceIn(0, 360))) }
        return if (fps > 0) enforce(pkg, fps).layers else deactivate(pkg)
    }

    /** Runs all five layers for [pkg] at [fps]. Safe to call again: originals are captured only once. */
    suspend fun enforce(pkg: String, fps: Int): FpsUnlockReport = mutex.withLock {
        enforceGen.incrementAndGet()
        activeGame = pkg
        val steps = ArrayList<StepResult>()
        if (!Validators.PACKAGE.matches(pkg) || fps !in 20..360) {
            steps += StepResult("FPS override", false, "invalid package or FPS value")
            return@withLock FpsUnlockReport(fps, 0, emptyList(), 0, steps)
        }
        val profile = repo.profile(pkg) ?: repo.getOrCreate(pkg, pkg)
        val rates = engine.supportedRefreshRates()
        // The rate the user picked for this game always wins over the one computed from the FPS target.
        val explicit = explicitHzFor(pkg, rates)
        val hz = if (explicit > 0) explicit else panelRateFor(fps, rates)
        _state.update { it.copy(busy = "Applying the FPS override", game = pkg, targetFps = fps) }
        try {
            // Clean up SurfaceFlinger properties that older builds left behind (no-op when nothing is stored).
            restoreProps(listOf(SF_THRESHOLD, PACE_SF, PACE_APP, PACE_LATCH))
            // Layer 1
            steps += throttlers.acquire(OWNER_FPS).map { it.copy(step = "L1 " + it.step) }

            // Layer 2
            steps += engine.setGameMode(pkg, GameModeLevel.PERFORMANCE, profile.downscale, fps)
                .map { it.copy(step = "L2 " + it.step) }
            steps += deviceConfigOverride(pkg, fps, profile.downscale)

            // Layer 3 (tracked by the engine, so Restore undoes it)
            val lock = engine.lockRefreshRate(hz)
            settingsWritable = lock.ok
            steps += lock.copy(step = "L3 " + lock.step)

            // Layer 4 (SurfaceFlinger frame_rate_multiple_threshold) is intentionally not written any more:
            // the value is not an FPS, and forcing it made the scheduler switch refresh rates unpredictably.
            steps += StepResult("L4 SurfaceFlinger threshold", true, "skipped on purpose (it made the refresh rate jump around)")

            // Layer 5
            setLockedValue(hz)
            val windowOk = withContext(Dispatchers.Main) { ensureLockWindow(hz) }
            steps += StepResult(
                "L5 Overlay display-mode lock",
                windowOk,
                if (windowOk) "requesting ${hz} Hz on the lock window and every HUD window"
                else "overlay permission missing: only the HUD windows carry the lock"
            )
            startWatchdog()
            delay(700L) // let the display settle before reading it back
            val now = engine.currentRefreshRate()
            _state.update {
                it.copy(
                    active = true, game = pkg, targetFps = fps, lockedHz = hz, displayHzNow = now,
                    layers = steps.toList()
                )
            }
            FpsUnlockReport(fps, hz, rates, now, steps)
        } finally {
            _state.update { it.copy(busy = null) }
        }
    }

    /** Turns the override off from the HUD and puts the profile's own tuning back. */
    suspend fun deactivate(pkg: String): List<StepResult> {
        val out = ArrayList<StepResult>()
        out += releaseSoft("FPS unlock turned off")
        out += restoreProfileDisplay(pkg)
        return out
    }

    /**
     * Motion smoothing for 60 FPS games on a fast panel: locks the display to its maximum rate (touch to
     * photon latency is set by the panel, not the game), tunes SurfaceFlinger frame pacing from the vsync
     * period, and optionally draws black-frame insertion to cut sample-and-hold blur. It does not create
     * new frames. SurfaceFlinger reads the pacing properties at start-up, so they help only on ROMs that
     * re-read them; the panel lock works everywhere.
     */
    suspend fun setMotionSmoothing(pkg: String, on: Boolean, bfiPct: Int): List<StepResult> = mutex.withLock {
        val out = ArrayList<StepResult>()
        if (!on) {
            withContext(Dispatchers.Main) { removeBfi() }
            out += restoreProps(listOf(PACE_SF, PACE_APP, PACE_LATCH))
            val keepLock = _state.value.active
            _state.update { it.copy(motionSmoothing = false, bfiPct = 0) }
            if (!keepLock) {
                stopWatchdog()
                setLockedValue(0)
                withContext(Dispatchers.Main) { ensureLockWindow(0) }
                out += restoreProfileDisplay(pkg)
            }
            return@withLock out
        }
        val rates = engine.supportedRefreshRates()
        val maxHz = rates.maxOrNull() ?: 0
        if (maxHz < 90) {
            return@withLock listOf(StepResult("Motion smoothing", false, "this panel tops out at $maxHz Hz; it needs 90 Hz or more"))
        }
        val hz = max(maxHz, _lockedHz.value)
        val lock = engine.lockRefreshRate(hz)
        settingsWritable = lock.ok
        out += lock.copy(step = "Panel lock")
        setLockedValue(hz)
        val windowOk = withContext(Dispatchers.Main) { ensureLockWindow(hz) }
        out += StepResult("Overlay display-mode lock", windowOk, if (windowOk) "$hz Hz" else "overlay permission missing")

        // SurfaceFlinger pacing properties are no longer written: they can destabilise the compositor and other apps.
        restoreProps(listOf(PACE_SF, PACE_APP, PACE_LATCH))

        val bfi = withContext(Dispatchers.Main) { applyBfi(bfiPct, hz) }
        if (bfiPct > 0) out += bfi
        startWatchdog()
        _state.update { it.copy(motionSmoothing = true, bfiPct = if (bfi.ok) bfiPct else 0, lockedHz = hz, game = pkg) }
        out
    }

    /** Holds [hz] with the watchdog and overlay lock without running the layers (used by the Battery Saver tier). */
    suspend fun holdRate(hz: Int) = mutex.withLock {
        enforceGen.incrementAndGet()
        setLockedValue(hz)
        withContext(Dispatchers.Main) { ensureLockWindow(hz) }
        startWatchdog()
        _state.update { it.copy(lockedHz = hz) }
    }

    /**
     * Drops every lock, prop and override of ours. It never touches the engine's own tracked settings:
     * those come back through OptimizationEngine.restoreAll(), which this class listens to.
     */
    suspend fun releaseSoft(reason: String, onlyIfGen: Int = -1): List<StepResult> = mutex.withLock {
        if (onlyIfGen >= 0 && enforceGen.get() != onlyIfGen) return@withLock emptyList()
        val out = ArrayList<StepResult>()
        withContext(Dispatchers.Main) {
            removeBfi()
            ensureLockWindow(0)
        }
        stopWatchdog()
        setLockedValue(0)
        out += throttlers.release(OWNER_FPS)
        out += restoreProps()
        out += restoreDeviceConfig()
        activeGame = null
        _state.value = FpsEnforcerState(lastReapply = reason)
        out
    }

    // =========================================================================================
    // Watchdog
    // =========================================================================================

    private fun startWatchdog() {
        if (watching) return
        watching = true
        runCatching {
            val cr = ctx.contentResolver
            cr.registerContentObserver(Settings.System.getUriFor("peak_refresh_rate"), false, observer)
            cr.registerContentObserver(Settings.System.getUriFor("min_refresh_rate"), false, observer)
            cr.registerContentObserver(Settings.Secure.getUriFor("user_refresh_rate"), false, observer)
            cr.registerContentObserver(Settings.Secure.getUriFor("miui_refresh_rate"), false, observer)
        }
        runCatching { dm.registerDisplayListener(displayListener, wd) }
        runCatching {
            val f = IntentFilter(Intent.ACTION_SCREEN_ON).apply { addAction(Intent.ACTION_USER_PRESENT) }
            ContextCompat.registerReceiver(ctx, screenReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        }
    }

    private fun stopWatchdog() {
        if (!watching) return
        watching = false
        wd.removeCallbacks(reapplyRunnable)
        runCatching { ctx.contentResolver.unregisterContentObserver(observer) }
        runCatching { dm.unregisterDisplayListener(displayListener) }
        runCatching { ctx.unregisterReceiver(screenReceiver) }
    }

    private fun onWindowChanged(pkg: String) {
        if (!watching || _lockedHz.value <= 0) return
        scheduleReapply("window change: $pkg", 0L)
        if (pkg == activeGame) {
            // some skins reset the rate a moment AFTER the game window gains focus
            wd.postDelayed({ scheduleReapply("game regained focus", 0L) }, 50L)
        }
    }

    private fun scheduleReapply(reason: String, delayMs: Long) {
        if (!watching || _lockedHz.value <= 0) return
        pendingReason = reason
        wd.removeCallbacks(reapplyRunnable)
        wd.postDelayed(reapplyRunnable, delayMs)
    }

    private suspend fun reapplyNow() {
        val hz = _lockedHz.value
        if (hz <= 0 || !watching) return
        val reason = pendingReason
        val now = SystemClock.elapsedRealtime()

        // Back off when something keeps fighting us, instead of looping forever.
        synchronized(stamps) {
            if (backoffUntil > now) return
            stamps.addLast(now)
            while (stamps.isNotEmpty() && now - stamps.first() > 5_000L) stamps.removeFirst()
            if (stamps.size > 10) {
                backoffUntil = now + 3_000L
                stamps.clear()
                _state.update { it.copy(lastReapply = "backing off for 3 s: something keeps changing the refresh rate") }
                return
            }
        }

        // Only fight while the engine still owns the original values; after a Restore we stand down.
        if (settingsWritable && !engine.isTracked(Ns.SYSTEM, "peak_refresh_rate")) {
            releaseSoft("engine restored the refresh-rate settings")
            return
        }

        var wrote = 0
        if (settingsWritable) {
            for ((ns, key, value) in desired(hz)) {
                val cur = bridge.getSetting(ns, key)?.toFloatOrNull()
                if (cur != null && abs(cur - hz) <= 0.5f) continue
                if (fastPut(ns, key, value) || bridge.putSetting(ns, key, value).ok) wrote++
            }
        }
        val shown = DisplayModeLock.defaultDisplay(ctx)?.refreshRate ?: 0f
        var restamped = false
        if (shown in 1f..(hz - 1.5f) && now - lastRestamp > 2_500L) {
            // The settings are right but the panel still runs slow: re-stamp the overlay windows too, at most
            // every 2.5 s. Doing it on every display event made the HUD stutter.
            lastRestamp = now
            restamped = true
            withContext(Dispatchers.Main) {
                ensureLockWindow(hz)
                overlayRefresh?.invoke()
            }
        }
        if (wrote > 0 || restamped) {
            _state.update {
                it.copy(
                    reapplyCount = it.reapplyCount + 1,
                    lastReapply = "$reason: $wrote key(s) rewritten, display ${shown.roundToInt()} Hz",
                    displayHzNow = shown.roundToInt()
                )
            }
        }
    }

    private data class Want(val ns: Ns, val key: String, val value: String)

    private fun desired(hz: Int): List<Want> {
        val f = String.format(Locale.US, "%.1f", hz.toFloat())
        val out = arrayListOf(
            Want(Ns.SYSTEM, "peak_refresh_rate", f),
            Want(Ns.SYSTEM, "min_refresh_rate", f),
            Want(Ns.SECURE, "user_refresh_rate", f)
        )
        if (bridge.getSetting(Ns.SECURE, "miui_refresh_rate") != null) {
            out += Want(Ns.SECURE, "miui_refresh_rate", hz.toString())
        }
        return out
    }

    /** Direct Settings write: a few milliseconds instead of a shell round trip. Needs WRITE_(SECURE_)SETTINGS. */
    private fun fastPut(ns: Ns, key: String, value: String): Boolean = runCatching {
        val cr = ctx.contentResolver
        when (ns) {
            Ns.SYSTEM -> Settings.System.canWrite(ctx) && Settings.System.putString(cr, key, value)
            Ns.SECURE ->
                ctx.checkSelfPermission(android.Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED &&
                    Settings.Secure.putString(cr, key, value)
            Ns.GLOBAL -> false
        }
    }.getOrDefault(false)

    // =========================================================================================
    // Layer helpers
    // =========================================================================================

    private fun setLockedValue(hz: Int) {
        DisplayModeLock.currentHz = hz
        _lockedHz.value = hz
        _state.update { it.copy(lockedHz = hz) }
        main.post { overlayRefresh?.invoke() }
    }

    /** Smallest panel rate that is a whole multiple of the target (clean pacing), else the next one up, else the maximum. */
    private fun panelRateFor(fps: Int, rates: List<Int>): Int {
        if (rates.isEmpty()) return fps
        rates.firstOrNull { it >= fps && it % fps == 0 }?.let { return it }
        rates.firstOrNull { it >= fps }?.let { return it }
        return rates.max()
    }

    private suspend fun restoreProfileDisplay(pkg: String): List<StepResult> {
        val p = repo.profile(pkg) ?: return emptyList()
        val out = ArrayList<StepResult>()
        out += engine.setGameTuning(pkg, p.gameMode, p.downscale, p.targetFps, p.fpsCapViaDisplay, p.refreshHz)
        if (p.refreshHz == 0 && !(p.targetFps > 0 && p.fpsCapViaDisplay)) out += engine.unlockRefreshRate()
        return out
    }

    // ---- device_config (Layer 2) ----

    private suspend fun deviceConfigOverride(pkg: String, fps: Int, downscale: Float?): StepResult {
        val name = "L2 device_config game_overlay"
        if (!bridge.hasShell()) return StepResult(name, false, "needs Shizuku or root")
        val got = bridge.shell("device_config get $DC_NS $pkg", 6_000L)
        val original = got.stdout.trim().takeIf { got.ok && it.isNotEmpty() && !it.equals("null", true) }
        store.update { s ->
            if (s.deviceConfig.any { it.ns == DC_NS && it.key == pkg }) s
            else s.copy(deviceConfig = s.deviceConfig + DeviceConfigBackup(DC_NS, pkg, original))
        }
        val ds = String.format(Locale.US, "%.2f", (downscale ?: 1f).coerceIn(0.3f, 1f))
        val value = "mode=2,fps=$fps,downscaleFactor=$ds:mode=3,fps=60"
        val r = bridge.deviceConfigPut(DC_NS, pkg, value)
        return StepResult(name, r.ok, if (r.ok) "performance mode fps=$fps, battery mode fps=60" else r.message)
    }

    /** The profile's explicit refresh rate resolved against the panel's real modes (0 = none chosen). */
    private fun explicitHzFor(pkg: String, rates: List<Int>): Int {
        val r = repo.profile(pkg)?.refreshHz ?: 0
        return when {
            r == 0 -> 0
            r < 0 -> rates.maxOrNull() ?: 0
            rates.isEmpty() -> r
            else -> rates.minByOrNull { abs(it - r) } ?: r
        }
    }

    /**
     * HUD / hub entry for a manual refresh-rate choice. [refreshHz] is what was saved in the profile:
     * 0 = unlock, -1 = panel maximum, otherwise Hz. The settings keys are written, and the watchdog plus the
     * overlay windows are told to hold the same rate, so nothing else (FPS unlock, Wild Boost, the ROM)
     * can pull the panel to a different one.
     */
    suspend fun applyExplicitRate(pkg: String, refreshHz: Int): StepResult {
        if (activeGame == null) activeGame = pkg
        if (refreshHz == 0) {
            val st = _state.value
            return when {
                st.active && st.game == pkg && st.targetFps > 0 ->
                    retargetDisplay(panelRateFor(st.targetFps, engine.supportedRefreshRates()))
                st.motionSmoothing -> {
                    val top = engine.maxRefreshRate()
                    val r = engine.lockRefreshRate(top)
                    holdRate(top)
                    r
                }
                else -> {
                    releaseSoft("manual refresh-rate lock removed")
                    val steps = restoreProfileDisplay(pkg)
                    steps.firstOrNull { !it.ok } ?: StepResult("Refresh rate unlock", true, "back to the system's own rate")
                }
            }
        }
        val rates = engine.supportedRefreshRates()
        val hz = if (refreshHz < 0) rates.maxOrNull() ?: 0 else rates.minByOrNull { abs(it - refreshHz) } ?: refreshHz
        val lock = engine.lockRefreshRate(refreshHz)
        if (hz > 0) holdRate(hz)
        val shown = engine.currentRefreshRate()
        return lock.copy(
            detail = lock.detail + if (shown in 1 until hz) " The ROM still reports $shown Hz; the lock keeps retrying." else ""
        )
    }

    /**
     * Moves only the display rate of an active lock (layers 3 and 5), leaving the game's FPS cap, the device_config
     * and the SurfaceFlinger threshold alone. Used by the refresh-rate matcher; the watchdog then holds the new rate.
     */
    suspend fun retargetDisplay(hz: Int): StepResult = mutex.withLock {
        if (!_state.value.active || _lockedHz.value <= 0) {
            return@withLock StepResult("Display rate", false, "FPS lock is not active")
        }
        val manual = activeGame?.let { explicitHzFor(it, engine.supportedRefreshRates()) } ?: 0
        if (manual > 0 && hz != manual) {
            return@withLock StepResult("Display rate", false, "your manual refresh-rate lock ($manual Hz) is set")
        }
        if (hz == _lockedHz.value) return@withLock StepResult("Display rate", true, "already $hz Hz")
        val lock = engine.lockRefreshRate(hz)
        setLockedValue(hz)
        withContext(Dispatchers.Main) { ensureLockWindow(hz) }
        lock.copy(step = "Display rate", detail = "$hz Hz")
    }

    /** Public entry for HyperBoost: same crash-safe game_overlay write the L2 layer uses. */
    suspend fun overrideGameOverlay(pkg: String, fps: Int, downscale: Float?): StepResult =
        deviceConfigOverride(pkg, fps, downscale)

    private suspend fun restoreDeviceConfig(): List<StepResult> {
        val pending = store.snapshot.deviceConfig
        if (pending.isEmpty()) return emptyList()
        if (!bridge.hasShell()) return listOf(StepResult("device_config restore", false, "needs Shizuku or root; will retry"))
        var restored = 0
        val failed = ArrayList<String>()
        for (b in pending) {
            val safeOriginal = b.original?.takeIf { Validators.SETTING_VALUE.matches(it) }
            val r = if (safeOriginal != null) bridge.deviceConfigPut(b.ns, b.key, safeOriginal)
            else if (Validators.NAMESPACE.matches(b.ns) && Validators.SETTING_KEY.matches(b.key)) {
                bridge.shell("device_config delete ${b.ns} ${b.key}", 6_000L)
            } else {
                CommandResult(true)
            }
            if (r.ok) {
                restored++
                store.update { s -> s.copy(deviceConfig = s.deviceConfig - b) }
            } else {
                failed += "${b.key}: ${r.message}"
            }
        }
        return listOf(
            StepResult(
                "device_config restored", failed.isEmpty(),
                if (failed.isEmpty()) "$restored override(s) removed" else failed.joinToString(" | ")
            )
        )
    }

    // ---- system properties (Layer 4 and frame pacing) ----

    /** Reads the original, saves it to disk, then writes the new value. */
    suspend fun setPropTracked(key: String, value: String): StepResult {
        if (!Validators.PROP_KEY.matches(key)) return StepResult(key, false, "invalid property name")
        if (!bridge.hasShell()) return StepResult(key, false, "needs Shizuku or root")
        val original = bridge.shell("getprop $key", 5_000L).stdout.trim()
        store.update { s ->
            if (s.props.any { it.key == key }) s else s.copy(props = s.props + PropBackup(key, original))
        }
        val r = bridge.setProp(key, value)
        return StepResult(key, r.ok, if (r.ok) "$key=$value (was ${original.ifBlank { "unset" }})" else r.message)
    }

    /** Restores the given keys, or every key we changed when [only] is null. */
    suspend fun restoreProps(only: List<String>? = null): List<StepResult> {
        val pending = store.snapshot.props.filter { only == null || it.key in only }
        if (pending.isEmpty()) return emptyList()
        if (!bridge.hasShell()) return listOf(StepResult("Property restore", false, "needs Shizuku or root; will retry"))
        var restored = 0
        val failed = ArrayList<String>()
        for (b in pending) {
            val r = when {
                !Validators.PROP_KEY.matches(b.key) -> CommandResult(true)
                b.original.isEmpty() -> bridge.shell("setprop ${b.key} \"\"", 5_000L)
                Validators.SETTING_VALUE.matches(b.original) -> bridge.setProp(b.key, b.original)
                else -> CommandResult(true) // cannot be passed safely; dropping it is better than blocking forever
            }
            if (r.ok) {
                restored++
                store.update { s -> s.copy(props = s.props - b) }
            } else {
                failed += "${b.key}: ${r.message}"
            }
        }
        return listOf(
            StepResult(
                "Properties restored", failed.isEmpty(),
                if (failed.isEmpty()) "$restored put back" else failed.joinToString(" | ")
            )
        )
    }

    // =========================================================================================
    // Overlay windows (main thread only)
    // =========================================================================================

    private var lockView: View? = null
    private var lockParams: WindowManager.LayoutParams? = null
    private var lockAppliedHz = 0
    private var bfiView: BfiView? = null
    private var bfiParams: WindowManager.LayoutParams? = null

    /** hz <= 0 removes the window. Returns false when the overlay permission is missing or the add failed. */
    private fun ensureLockWindow(hz: Int): Boolean {
        if (hz <= 0) {
            lockView?.let { runCatching { wm.removeViewImmediate(it) } }
            lockView = null
            lockParams = null
            lockAppliedHz = 0
            return true
        }
        if (!Settings.canDrawOverlays(ctx)) return false
        if (lockView != null && lockAppliedHz == hz) return true
        return try {
            val p = lockParams ?: OverlayKit.params(1, 1, "HyperEngineHzLock", touchable = false).also { lockParams = it }
            DisplayModeLock.apply(p, DisplayModeLock.defaultDisplay(ctx), hz)
            val v = lockView
            if (v == null) {
                // one almost-transparent pixel: the window must have a surface for the policy to see it
                val nv = View(ctx).apply { setBackgroundColor(Color.argb(1, 0, 0, 0)) }
                wm.addView(nv, p)
                lockView = nv
            } else {
                wm.updateViewLayout(v, p)
            }
            lockAppliedHz = hz
            true
        } catch (_: Throwable) {
            lockView = null
            lockAppliedHz = 0
            false
        }
    }

    private fun removeBfi() {
        bfiView?.let {
            it.stop()
            runCatching { wm.removeViewImmediate(it) }
        }
        bfiView = null
        bfiParams = null
    }

    private fun applyBfi(pct: Int, hz: Int): StepResult {
        removeBfi()
        if (pct <= 0) return StepResult("Black-frame insertion", true, "off")
        if (hz < 90) return StepResult("Black-frame insertion", false, "needs a panel running at 90 Hz or more")
        if (!Settings.canDrawOverlays(ctx)) return StepResult("Black-frame insertion", false, "overlay permission missing")
        return try {
            val p = OverlayKit.params(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                "HyperEngineBfi", touchable = false
            )
            val v = BfiView(ctx).also { it.strength = pct.coerceIn(5, 60) / 100f }
            wm.addView(v, p)
            v.start()
            bfiView = v
            bfiParams = p
            StepResult("Black-frame insertion", true, "$pct% dark frame on every second refresh at $hz Hz (lowers brightness, may flicker)")
        } catch (t: Throwable) {
            StepResult("Black-frame insertion", false, t.message ?: "could not add the overlay")
        }
    }

    /** Draws a dark layer on every second display refresh. Fully pass-through (NOT_TOUCHABLE window). */
    private class BfiView(ctx: Context) : View(ctx) {
        var strength = 0.3f
        private var odd = false
        private var running = false
        private val paint = Paint()
        private val callback = object : Choreographer.FrameCallback {
            override fun doFrame(frameTimeNanos: Long) {
                if (!running) return
                odd = !odd
                invalidate()
                Choreographer.getInstance().postFrameCallback(this)
            }
        }

        fun start() {
            if (running) return
            running = true
            Choreographer.getInstance().postFrameCallback(callback)
        }

        fun stop() {
            running = false
            Choreographer.getInstance().removeFrameCallback(callback)
        }

        override fun onDraw(c: Canvas) {
            if (!odd) return
            // Android blocks touches through overlays above 0.8 opacity, so never exceed 0.79
            val a = (strength * 255f).toInt().coerceIn(0, 201)
            paint.color = Color.argb(a, 0, 0, 0)
            c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        }

        override fun onDetachedFromWindow() {
            stop()
            super.onDetachedFromWindow()
        }
    }

    private companion object {
        const val OWNER_FPS = "fps"
        const val DC_NS = "game_overlay"
        const val SF_THRESHOLD = "debug.sf.frame_rate_multiple_threshold"
        const val PACE_SF = "debug.sf.late.sf.duration"
        const val PACE_APP = "debug.sf.late.app.duration"
        const val PACE_LATCH = "debug.sf.latch_unsignaled"
    }
}
