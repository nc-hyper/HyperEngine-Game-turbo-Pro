package com.hyperengine.gameturbo.hub

import android.content.res.ColorStateList
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import com.hyperengine.gameturbo.ui.ChipGroup
import com.hyperengine.gameturbo.ui.HudThemes
import com.hyperengine.gameturbo.ui.Ui

/**
 * Small themed form pieces shared by the Freeze List, Theme and Rules screens, so all three look
 * and behave the same as the rest of the Game Space.
 */
internal object Forms {

    /** Tile with a title, optional sub line and a themed switch. The whole tile toggles the switch. */
    fun switchRow(
        host: HubHost,
        title: String,
        sub: String?,
        checked: Boolean,
        enabled: Boolean = true,
        onChange: (Boolean) -> Unit
    ): View {
        val ctx = host.activity
        val t = host.theme
        val row = Ui.hbox(ctx)
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(host.dp(12), host.dp(9), host.dp(12), host.dp(9))
        row.background = Ui.rounded(t.tile, Ui.tileRadius(ctx, t), t.stroke, host.dp(1))

        val col = Ui.vbox(ctx)
        col.addView(Ui.label(ctx, title, 13f, t.textPrimary, true))
        if (!sub.isNullOrBlank()) {
            col.addView(Ui.label(ctx, sub, 11f, t.textSecondary).apply {
                setPadding(0, host.dp(2), 0, 0)
                setLineSpacing(0f, 1.1f)
            })
        }
        row.addView(col, Ui.lp(0, Ui.WRAP, 1f, 0, 0, host.dp(8), 0))

        val sw = Switch(ctx)
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(t.accent, t.textSecondary))
        sw.trackTintList = ColorStateList(
            states,
            intArrayOf(HudThemes.withAlpha(t.accent, 0x80), HudThemes.withAlpha(t.textSecondary, 0x55))
        )
        sw.isChecked = checked
        sw.isEnabled = enabled
        sw.setOnCheckedChangeListener { _, on -> onChange(on) }
        row.addView(sw, Ui.lp(Ui.WRAP, Ui.WRAP))

        if (enabled) row.setOnClickListener { sw.toggle() } else row.alpha = 0.5f
        return row
    }

    /** Wrapped explanation text. */
    fun note(host: HubHost, text: String, color: Int = host.theme.textSecondary): TextView =
        Ui.label(host.activity, text, 11f, color).apply {
            setLineSpacing(0f, 1.15f)
            setPadding(0, host.dp(4), 0, host.dp(2))
        }

    /** Rounded panel that groups related controls. */
    fun card(host: HubHost): LinearLayout = Ui.vbox(host.activity).apply {
        setPadding(host.dp(12), host.dp(10), host.dp(12), host.dp(12))
        background = HubStyle.cardBackground(host)
    }

    /** Compact text button used inside rows (Up / Down / Remove). */
    fun smallButton(host: HubHost, text: String, enabled: Boolean = true, danger: Boolean = false, onClick: () -> Unit): TextView {
        val t = host.theme
        val color = if (danger) t.hot else t.textPrimary
        return TextView(host.activity).apply {
            this.text = text
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(color)
            setPadding(host.dp(10), host.dp(7), host.dp(10), host.dp(7))
            background = Ui.rounded(
                HudThemes.withAlpha(color, 0x14), Ui.tileRadius(host.activity, t),
                HudThemes.withAlpha(color, 0x66), host.dp(1)
            )
            alpha = if (enabled) 1f else 0.35f
            isEnabled = enabled
            if (enabled) setOnClickListener { onClick() }
        }
    }

    /**
     * Section title plus a single-choice chip grid. If [current] is not one of [values] (a value saved
     * by an older build, or a refresh rate this phone does not list) it is appended as a "custom" chip,
     * so opening the editor never silently changes what is stored.
     */
    fun <T> choice(
        host: HubHost,
        into: LinearLayout,
        title: String,
        labels: List<String>,
        values: List<T>,
        current: T,
        cols: Int,
        onPick: (T) -> Unit
    ): ChipGroup {
        val l = labels.toMutableList()
        val v = values.toMutableList()
        if (current !in v) {
            v += current
            l += "$current (custom)"
        }
        into.addView(Ui.section(host.activity, host.theme, title), Ui.lp(Ui.MATCH, Ui.WRAP))
        val chips = ChipGroup(host.activity, host.theme, l, v.indexOf(current), cols) { i -> onPick(v[i]) }
        into.addView(chips, Ui.lp(Ui.MATCH, Ui.WRAP))
        return chips
    }
}

/** Adds [view] to this vertical box with the standard gap above it. */
internal fun LinearLayout.addRow(host: HubHost, view: View, topDp: Int = 6) {
    addView(view, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(topDp), 0, 0))
}
