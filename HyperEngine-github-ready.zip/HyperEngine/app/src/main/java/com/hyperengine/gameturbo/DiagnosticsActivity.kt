package com.hyperengine.gameturbo

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.hyperengine.gameturbo.core.BridgeState
import com.hyperengine.gameturbo.core.ConsoleWindow
import com.hyperengine.gameturbo.core.HiddenApiUnlock
import com.hyperengine.gameturbo.core.Ns
import com.hyperengine.gameturbo.hub.HubStyle
import com.hyperengine.gameturbo.service.DanmakuNotificationService
import com.hyperengine.gameturbo.service.TouchMacroService
import com.hyperengine.gameturbo.ui.HudTheme
import com.hyperengine.gameturbo.ui.HudThemes
import com.hyperengine.gameturbo.ui.Ui
import com.hyperengine.gameturbo.ui.VIcon
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Permissions & Engine Diagnostics (portrait, one column of cards).
 *
 * One card per capability the engine depends on: Shizuku binder, Shizuku permission, the hardware
 * input-injection binder, Overlay, Usage Access, Accessibility, Notification Listener, Phone / Call,
 * Microphone, secure-settings grant, system settings, notifications, battery and the self-healing
 * restore state. Every card shows the REAL current state (read from the system, never assumed) and a
 * one-tap fix button that either performs the grant silently (Shizuku / root / ADB-granted) or opens
 * exactly the system screen that grants it.
 */
class DiagnosticsActivity : Activity() {

    private class DiagCheck(
        val title: String,
        val detail: String,
        val ok: Boolean,
        val required: Boolean,
        val fixLabel: String?,
        val fix: (() -> Unit)?
    )

    private val scope = MainScope()
    private val app get() = HyperApp.instance
    private val bridge get() = app.bridge

    private lateinit var theme: HudTheme
    private lateinit var leftCol: LinearLayout
    private lateinit var rightCol: LinearLayout
    private lateinit var summary: TextView

    private var state = BridgeState()
    private var working = false

    // =========================================================================================
    // Lifecycle
    // =========================================================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ConsoleWindow.apply(this)
        ConsoleWindow.lockPanel(this)
        theme = HudThemes.resolve(app.repository.global.value)
        window.setBackgroundDrawable(HubStyle.screenBackground(theme))

        val root = Ui.vbox(this)
        root.background = HubStyle.screenBackground(theme)
        root.setPadding(dp(14), dp(8), dp(14), dp(8))

        // header: title on the first line, the three buttons on the second (a portrait phone is too narrow for one row)
        val header = Ui.vbox(this)
        val titles = Ui.vbox(this)
        titles.addView(Ui.label(this, "PERMISSIONS & ENGINE DIAGNOSTICS", 16f, theme.accent, true).apply { letterSpacing = 0.1f })
        summary = Ui.label(this, "Checking...", 11f, theme.textSecondary)
        titles.addView(summary, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, dp(2), 0, 0))
        header.addView(titles, Ui.lp(Ui.MATCH, Ui.WRAP))
        val buttons = Ui.hbox(this)
        buttons.addView(Ui.button(this, theme, "Fix everything", true) { fixEverything() }, Ui.lp(0, Ui.WRAP, 1.3f))
        buttons.addView(Ui.button(this, theme, "Self-test", false) { selfTest() }, Ui.lp(0, Ui.WRAP, 1f, dp(8), 0, 0, 0))
        buttons.addView(Ui.button(this, theme, "Back", false) { finish() }, Ui.lp(0, Ui.WRAP, 0.7f, dp(8), 0, 0, 0))
        header.addView(buttons, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, dp(8), 0, 0))
        root.addView(header, Ui.lp(Ui.MATCH, Ui.WRAP))

        // one column of full-width cards (rightCol stays allocated but is never attached)
        val columns = Ui.vbox(this)
        leftCol = Ui.vbox(this)
        rightCol = Ui.vbox(this)
        columns.addView(leftCol, Ui.lp(Ui.MATCH, Ui.WRAP))
        val scroll = ScrollView(this)
        scroll.isFillViewport = false
        scroll.addView(columns, android.widget.FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        root.addView(scroll, Ui.lp(Ui.MATCH, 0, 1f, 0, dp(6), 0, 0))

        setContentView(root)

        scope.launch { bridge.state.collect { state = it; render() } }
        // the services connect a moment after Android enables them: re-read when that happens
        scope.launch { TouchMacroService.connected.collect { bridge.refresh() } }
        scope.launch { DanmakuNotificationService.connected.collect { bridge.refresh() } }
        scope.launch { app.engine.status.collect { render() } }
    }

    override fun onResume() {
        super.onResume()
        bridge.refresh()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) ConsoleWindow.apply(this)
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        bridge.refresh()
        // "Don't ask again" was chosen earlier: Android no longer shows the dialog, so open the page that can grant it
        val blocked = permissions.filterIndexed { i, p ->
            grantResults.getOrNull(i) != PackageManager.PERMISSION_GRANTED && !shouldShowRequestPermissionRationale(p)
        }
        if (blocked.isNotEmpty() && grantResults.isNotEmpty()) {
            toast("Android will not ask again. Turn the permission on in App info > Permissions.", true)
            startSafely(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri()), "Open Settings > Apps > Hyper Engine > Permissions")
        }
    }

    // =========================================================================================
    // Checks
    // =========================================================================================

    private fun buildChecks(st: BridgeState): List<DiagCheck> {
        val shell = bridge.hasShell()
        val list = ArrayList<DiagCheck>()

        // ── Shizuku ──
        val uidText = when (st.shizukuUid) {
            0 -> "root"
            2000 -> "ADB shell"
            -1 -> ""
            else -> "uid ${st.shizukuUid}"
        }
        list += DiagCheck(
            "Shizuku binder",
            when {
                st.shizukuRunning -> "Binder alive, Shizuku API v${st.shizukuVersion}" + (if (uidText.isNotEmpty()) ", running as $uidText" else "")
                st.shizukuInstalled -> "Installed but not started. Start it with Wireless debugging (or root), then come back."
                else -> "Not installed. Shizuku provides the privileged shell the engine uses."
            },
            st.shizukuRunning, false,
            when {
                st.shizukuRunning -> null
                st.shizukuInstalled -> "Open Shizuku"
                else -> "Get Shizuku"
            }
        ) { openShizuku() }

        list += DiagCheck(
            "Shizuku permission",
            when {
                st.shizukuGranted -> "Allowed. Game mode, FPS overrides, force-stop, compile, DNS and key injection are unlocked."
                st.shizukuRunning -> "Shizuku is running but Hyper Engine is not allowed yet."
                st.rootGranted -> "Not used: root (su) is active instead."
                else -> "Start Shizuku first. Without it the engine falls back to standard Android APIs."
            },
            st.shizukuGranted || st.rootGranted, false,
            if (st.shizukuGranted || st.rootGranted) null else if (st.shizukuRunning) "Allow" else "Open Shizuku"
        ) {
            if (bridge.state.value.shizukuRunning) {
                if (!bridge.requestShizukuPermission()) toast("Shizuku is not running", true)
            } else {
                openShizuku()
            }
        }

        val input = bridge.input
        list += DiagCheck(
            "Hardware input injector (IInputManager)",
            when {
                st.inputInjection -> "Bound: ${input.description}. Injected fingers use pointer ids 3, 4, 5, 6; ids 0..2 stay yours."
                !st.shizukuGranted -> "Needs Shizuku permission. Until then taps fall back to the accessibility service."
                else -> "Not bound yet." + (input.lastError?.let { " Last error: ${it.take(110)}" } ?: " Tap Test to bind it.")
            },
            st.inputInjection, false,
            if (st.inputInjection) null else if (st.shizukuGranted) "Test" else null
        ) { testInput() }

        // ── Special access ──
        list += DiagCheck(
            "Display over other apps",
            if (st.overlay) "Allowed. The sidebar, FPS pill, crosshair, auto-touch reticles and call banner can draw over games."
            else "Required: every in-game overlay needs this.",
            st.overlay, true, if (st.overlay) null else "Allow"
        ) { startSafely(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkgUri()), "Open Settings > Apps > Special access > Display over other apps") }

        list += DiagCheck(
            "Usage access (game detection)",
            when {
                st.usageAccess -> "On. Games are detected and play time is counted."
                shell -> "Not granted, but the privileged shell detects the foreground game. Usage access also adds play time."
                else -> "Required to see which game is on screen (unless Shizuku is running)."
            },
            st.usageAccess || shell, true, if (st.usageAccess) null else "Allow"
        ) { startSafely(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS), "Open Settings > Apps > Special access > Usage access") }

        list += DiagCheck(
            "Accessibility (auto-touch fallback, volume triggers)",
            when {
                st.accessibilityConnected -> "Connected. Taps, swipes and volume-key triggers work without Shizuku."
                st.accessibilityEnabled -> "Switched on, waiting for Android to connect it."
                else -> "Off. It never reads screen content. Needed for tap injection and key chords when Shizuku is not running."
            },
            st.accessibilityConnected || st.accessibilityEnabled, false,
            if (st.accessibilityConnected || st.accessibilityEnabled) null else "Enable"
        ) { enableAccessibility() }

        list += DiagCheck(
            "Notification listener (danmaku, call banner)",
            when {
                st.notificationListenerConnected -> "Connected. Notifications can scroll across the game."
                st.notificationListenerEnabled -> "Switched on, waiting for Android to connect it."
                else -> "Off. Needed for bullet notifications."
            },
            st.notificationListenerConnected || st.notificationListenerEnabled, false,
            if (st.notificationListenerConnected || st.notificationListenerEnabled) null else "Enable"
        ) { enableListener() }

        // ── Runtime permissions ──
        list += DiagCheck(
            "Phone / call control",
            "READ_PHONE_STATE: ${yn(st.readPhoneState)}   ANSWER_PHONE_CALLS: ${yn(st.answerCalls)}" +
                (if (st.phoneCall) ". The in-game call banner can answer on speaker." else ". Needed to answer calls without leaving the game."),
            st.phoneCall, false, if (st.phoneCall) null else "Allow"
        ) { fixRuntime(listOf(Manifest.permission.READ_PHONE_STATE, Manifest.permission.ANSWER_PHONE_CALLS), "Phone access") }

        list += DiagCheck(
            "Contacts (caller names)",
            if (st.readContacts) "Allowed. The in-game call banner shows the caller's name."
            else "Optional. Without it the call banner shows only the phone number.",
            st.readContacts, false, if (st.readContacts) null else "Allow"
        ) { fixRuntime(listOf(Manifest.permission.READ_CONTACTS), "Contacts") }

        list += DiagCheck(
            "Microphone (voice changer)",
            if (st.recordAudio) "Allowed. The voice changer studio can record." else "Needed for the live voice changer and the push-to-talk bubble.",
            st.recordAudio, false, if (st.recordAudio) null else "Allow"
        ) { fixRuntime(listOf(Manifest.permission.RECORD_AUDIO), "Microphone") }

        if (Build.VERSION.SDK_INT >= 33) {
            list += DiagCheck(
                "Notifications",
                if (st.postNotifications) "Allowed. The game-watcher status notification is visible." else "Needed to show the game-watcher status notification.",
                st.postNotifications, false, if (st.postNotifications) null else "Allow"
            ) { fixRuntime(listOf(Manifest.permission.POST_NOTIFICATIONS), "Notifications") }
        }

        // ── System settings ──
        list += DiagCheck(
            "Secure settings grant",
            if (st.writeSecureSettings) "Granted over ADB / Shizuku. Refresh-rate lock, DNS and auto-enable keep working even when Shizuku stops."
            else "One-time grant. With Shizuku running it is automatic; otherwise copy the ADB commands to a PC.",
            st.writeSecureSettings, false,
            if (st.writeSecureSettings) null else if (shell) "Grant now" else "Copy ADB commands"
        ) { if (bridge.hasShell()) selfGrant() else copyAdb() }

        list += DiagCheck(
            "Modify system settings",
            if (st.writeSystemSettings || st.writeSecureSettings || shell) "Available. Refresh rate, animation scales and brightness can be changed."
            else "Lets refresh rate, animation scales and brightness be changed without a shell.",
            st.writeSystemSettings || st.writeSecureSettings || shell, false,
            if (st.writeSystemSettings) null else "Allow"
        ) { startSafely(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, pkgUri()), "Open Settings > Apps > Special access > Modify system settings") }

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val unrestricted = runCatching { pm.isIgnoringBatteryOptimizations(packageName) }.getOrDefault(false)
        list += DiagCheck(
            "Battery: unrestricted",
            if (unrestricted) "Unrestricted. The system will not kill the game watcher while you play."
            else "Stops the system from killing the game watcher in the background.",
            unrestricted, false, if (unrestricted) null else "Allow"
        ) { startSafely(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkgUri()), "Open Settings > Battery > Unrestricted") }

        // ── Self healing ──
        val session = app.engine.status.value
        list += DiagCheck(
            "Self-healing restore",
            if (session.sessionActive) "A game session is still applied" + (session.activeGame?.let { " ($it)" } ?: "") +
                ". Restore puts refresh rate, animation scales, brightness and background policies back."
            else "Clean. Refresh rate, animation scales, brightness and background policies are at their original values.",
            !session.sessionActive, false, if (session.sessionActive) "Restore now" else null
        ) { restoreNow() }

        return list
    }

    private fun yn(b: Boolean) = if (b) "yes" else "no"

    // =========================================================================================
    // Rendering
    // =========================================================================================

    private fun render() {
        if (!::leftCol.isInitialized) return
        val checks = buildChecks(state)
        leftCol.removeAllViews()
        rightCol.removeAllViews()
        checks.forEach { c ->
            val col = leftCol
            col.addView(card(c), Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, 0, 0, dp(8)))
        }
        val ok = checks.count { it.ok }
        val missingRequired = checks.filter { it.required && !it.ok }
        summary.text = "$ok of ${checks.size} ready  |  mode: ${state.mode.label}" +
            (if (missingRequired.isNotEmpty()) "  |  needs: " + missingRequired.joinToString(", ") { it.title.lowercase() } else "")
        summary.setTextColor(if (missingRequired.isNotEmpty()) theme.hot else theme.textSecondary)
    }

    private fun card(c: DiagCheck): View {
        val row = Ui.hbox(this)
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(12), dp(10), dp(12), dp(10))
        val tint = if (c.ok) theme.good else if (c.required) theme.hot else theme.warn
        row.background = Ui.rounded(
            HudThemes.withAlpha(tint, 0x14), HubStyle.radius(this, theme, 12), HudThemes.withAlpha(tint, 0x77), dp(1)
        )
        val markRes = if (c.ok) R.drawable.ic_check else if (c.required) R.drawable.ic_alert else R.drawable.ic_dash
        val mark = VIcon.view(this, markRes, 18, tint)
        row.addView(mark, Ui.lp(dp(20), dp(20), 0f, 0, 0, dp(10), 0))

        val col = Ui.vbox(this)
        col.addView(Ui.label(this, c.title, 13f, theme.textPrimary, true))
        col.addView(
            Ui.label(this, c.detail, 11f, theme.textSecondary).apply { setLineSpacing(0f, 1.1f) },
            Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, dp(3), 0, 0)
        )
        row.addView(col, Ui.lp(0, Ui.WRAP, 1f))

        val fix = c.fix
        val label = c.fixLabel
        if (fix != null && label != null) {
            row.addView(Ui.button(this, theme, label, !c.ok) { fix.invoke() }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, dp(10), 0, 0, 0))
        }
        return row
    }

    // =========================================================================================
    // Fix actions
    // =========================================================================================

    private fun openShizuku() {
        val shizukuIntent = packageManager.getLaunchIntentForPackage(SHIZUKU_PKG)
        if (shizukuIntent != null) {
            startSafely(shizukuIntent, "Cannot open Shizuku")
            return
        }
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$SHIZUKU_PKG")))
        } catch (_: Throwable) {
            startSafely(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/RikkaApps/Shizuku/releases")),
                "Install Shizuku from GitHub (RikkaApps/Shizuku)"
            )
        }
    }

    private fun testInput() {
        if (working) return
        working = true
        toast("Binding the input service...")
        scope.launch {
            val r = bridge.probeInputInjection()
            working = false
            showText(
                if (r.ok) "Input injector ready" else "Input injector not available",
                if (r.ok) r.message + "\n\nInjected fingers use pointer ids 3, 4, 5 and 6. Ids 0, 1 and 2 are left to your own fingers."
                else r.message + "\n\nThe auto tapper still works through the accessibility service."
            )
            render()
        }
    }

    private fun fixRuntime(perms: List<String>, label: String) {
        val missing = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) {
            bridge.refresh()
            return
        }
        if (!bridge.hasShell()) {
            requestPermissions(missing.toTypedArray(), REQ_RUNTIME)
            return
        }
        scope.launch {
            val results = missing.map { bridge.grantRuntimePermission(it) }
            val failed = results.firstOrNull { !it.ok }
            if (failed == null) {
                toast("$label granted")
            } else {
                toast("Silent grant failed (${failed.message.take(70)}). Asking Android instead.", true)
                requestPermissions(missing.toTypedArray(), REQ_RUNTIME)
            }
            bridge.refresh()
        }
    }

    private fun enableAccessibility() {
        if (bridge.state.value.writeSecureSettings || bridge.hasShell()) {
            scope.launch {
                val r = bridge.enableAccessibilityService(ComponentName(this@DiagnosticsActivity, TouchMacroService::class.java))
                if (r.ok) {
                    toast("Accessibility service enabled")
                } else {
                    toast("Could not enable it automatically: ${r.message.take(80)}", true)
                    startSafely(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS), "Open Settings > Accessibility")
                }
                bridge.refresh()
            }
        } else {
            toast("Find \"HyperEngine Touch Macro\" in the list and turn it on.", true)
            startSafely(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS), "Open Settings > Accessibility")
        }
    }

    private fun enableListener() {
        if (bridge.state.value.writeSecureSettings || bridge.hasShell()) {
            scope.launch {
                val r = bridge.enableNotificationListener(ComponentName(this@DiagnosticsActivity, DanmakuNotificationService::class.java))
                if (r.ok) {
                    toast("Notification listener enabled")
                } else {
                    toast("Could not enable it automatically: ${r.message.take(80)}", true)
                    startSafely(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS), "Open Settings > Notifications > Device and app notifications")
                }
                bridge.refresh()
            }
        } else {
            toast("Find \"HyperEngine Danmaku Ticker\" in the list and turn it on.", true)
            startSafely(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS), "Open Settings > Notifications > Device and app notifications")
        }
    }

    private fun selfGrant() {
        if (working) return
        working = true
        toast("Granting permissions...")
        scope.launch {
            val results = bridge.selfGrant()
            working = false
            val ok = results.count { it.second.ok }
            val lines = results.joinToString("\n") { (cmd, r) ->
                (if (r.ok) "OK    " else "FAIL  ") + cmd.removePrefix("pm grant $packageName ").removePrefix("appops set $packageName ") +
                    (if (r.ok) "" else "\n      " + r.message.take(90))
            }
            showText("Permissions: $ok of ${results.size} granted", lines, mono = true)
        }
    }

    private fun copyAdb() {
        val text = bridge.adbCommands().joinToString("\n")
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("adb", text))
        showText("ADB commands copied", "Run these once from a PC with USB debugging on:\n\n$text", mono = true)
    }

    private fun restoreNow() {
        if (working) return
        working = true
        scope.launch {
            val rep = app.engine.restoreAll("diagnostics screen")
            working = false
            toast(
                if (rep.complete) "Phone settings restored"
                else "Restore incomplete: ${rep.steps.firstOrNull { !it.ok }?.detail?.take(80) ?: "see developer console"}",
                !rep.complete
            )
            bridge.refresh()
        }
    }

    /** One tap: everything that can be granted silently is granted; what is left needs the user. */
    private fun fixEverything() {
        if (working) return
        val firstMissing = buildChecks(state).firstOrNull { !it.ok && it.fix != null }
        if (!bridge.hasShell() && !state.writeSecureSettings) {
            if (firstMissing == null) {
                toast("Everything is already set up")
            } else {
                toast("Start Shizuku for one-tap fixing. Opening the first missing item instead.", true)
                firstMissing.fix?.invoke()
            }
            return
        }
        working = true
        toast("Fixing...")
        scope.launch {
            val log = StringBuilder()
            if (bridge.hasShell()) {
                bridge.selfGrant().forEach { (cmd, r) ->
                    log.append(if (r.ok) "OK    " else "FAIL  ")
                        .append(cmd.removePrefix("pm grant $packageName ").removePrefix("appops set $packageName "))
                        .append(if (r.ok) "" else "  -> " + r.message.take(60)).append('\n')
                }
            }
            var s = withContext(Dispatchers.IO) { bridge.refreshNow() }
            if (!s.accessibilityEnabled) {
                val r = bridge.enableAccessibilityService(ComponentName(this@DiagnosticsActivity, TouchMacroService::class.java))
                log.append(if (r.ok) "OK    " else "FAIL  ").append("enable accessibility service")
                    .append(if (r.ok) "" else "  -> " + r.message.take(60)).append('\n')
            }
            if (!s.notificationListenerEnabled) {
                val r = bridge.enableNotificationListener(ComponentName(this@DiagnosticsActivity, DanmakuNotificationService::class.java))
                log.append(if (r.ok) "OK    " else "FAIL  ").append("enable notification listener")
                    .append(if (r.ok) "" else "  -> " + r.message.take(60)).append('\n')
            }
            if (bridge.hasShell() && !bridge.input.isConnected) {
                val r = bridge.probeInputInjection()
                log.append(if (r.ok) "OK    " else "FAIL  ").append("bind input injector")
                    .append(if (r.ok) "" else "  -> " + r.message.take(60)).append('\n')
            }
            s = withContext(Dispatchers.IO) { bridge.refreshNow() }
            working = false

            val left = buildChecks(s).filter { !it.ok && it.fix != null && it.title != "Self-healing restore" }
            if (left.isNotEmpty()) {
                log.append("\nStill needs you (Android only lets you grant these yourself):\n")
                left.forEach { log.append(" - ").append(it.title).append('\n') }
            } else {
                log.append("\nEverything is ready.")
            }
            showText("One-tap fix finished", log.toString(), mono = true)
        }
    }

    /** Runs real probes and prints their real output. */
    private fun selfTest() {
        if (working) return
        working = true
        toast("Running self-test...")
        scope.launch {
            val st = withContext(Dispatchers.IO) { bridge.refreshNow() }
            val sb = StringBuilder()
            sb.appendLine("Device          : ${Build.MANUFACTURER} ${Build.MODEL}")
            sb.appendLine("Android         : ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
            sb.appendLine("Execution mode  : ${st.mode.label}")
            val id = bridge.shell("id")
            sb.appendLine("Shell (id)      : [${id.via}] " + id.message.take(120))
            val probe = bridge.probeInputInjection()
            sb.appendLine("Input binder    : " + (if (probe.ok) "OK, " else "FAIL, ") + probe.message.take(120))
            sb.appendLine(
                "Hidden API      : " + (if (HiddenApiUnlock.unlocked) "unlocked" else "locked (" + (HiddenApiUnlock.lastError ?: "not needed or not tried yet") + ")")
            )
            val rates = app.engine.supportedRefreshRates()
            sb.appendLine("Refresh rates   : " + rates.joinToString(" / ") + " Hz, current " + app.engine.currentRefreshRate() + " Hz")
            sb.appendLine("peak_refresh    : " + (bridge.getSetting(Ns.SYSTEM, "peak_refresh_rate") ?: "unset"))
            sb.appendLine("min_refresh     : " + (bridge.getSetting(Ns.SYSTEM, "min_refresh_rate") ?: "unset"))
            sb.appendLine("Accessibility   : " + (if (st.accessibilityConnected) "connected" else if (st.accessibilityEnabled) "enabled, waiting" else "off"))
            sb.appendLine("Notif. listener : " + (if (st.notificationListenerConnected) "connected" else if (st.notificationListenerEnabled) "enabled, waiting" else "off"))
            sb.append("Overlay / Usage : ${yn(st.overlay)} / ${yn(st.usageAccess)}")
            working = false
            showText("Engine self-test", sb.toString(), mono = true)
            render()
        }
    }

    // =========================================================================================
    // Helpers
    // =========================================================================================

    private fun startSafely(intent: Intent, failMsg: String) {
        try {
            startActivity(intent)
        } catch (_: Throwable) {
            toast(failMsg, true)
        }
    }

    private fun pkgUri(): Uri = Uri.parse("package:$packageName")

    private fun showText(title: String, text: String, mono: Boolean = false) {
        if (isFinishing) return
        val body = TextView(this).apply {
            this.text = text
            textSize = 12f
            if (mono) typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }
        val scroll = ScrollView(this)
        scroll.addView(body)
        runCatching {
            AlertDialog.Builder(this)
                .setTitle(title)
                .setView(scroll)
                .setPositiveButton("Close", null)
                .show()
        }
    }

    private fun toast(msg: String, long: Boolean = false) {
        Toast.makeText(applicationContext, msg, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show()
    }

    private fun dp(v: Int): Int = Ui.dp(this, v)

    companion object {
        private const val SHIZUKU_PKG = "moe.shizuku.privileged.api"
        private const val REQ_RUNTIME = 7101
    }
}
