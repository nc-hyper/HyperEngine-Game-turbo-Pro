package com.hyperengine.gameturbo.ui

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.Point
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import androidx.dynamicanimation.animation.FloatPropertyCompat
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import com.hyperengine.gameturbo.HyperApp
import com.hyperengine.gameturbo.core.DisplayModeLock
import com.hyperengine.gameturbo.data.EdgeSide
import com.hyperengine.gameturbo.data.HandleConfig
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.tanh

/**
 * Full-screen "Wild Boost Ignition" animation, 2.2 seconds, drawn by one hardware-accelerated Canvas view
 * in a non-touchable overlay window (every touch goes to the game underneath).
 *
 * Timeline (fraction of 2200 ms):
 *   0.00 - 0.16  edge plasma surges in on all four edges; scrim darkens the game behind the HUD
 *   0.00 - 0.62  jet turbine spins up (visual speed ramps; RPM readout counts 0 -> 20,000), sparks fly
 *   0.30 - 0.72  stat rows roll in one after another (FPS, CPU, HYPERBOOST SCALE, LATENCY)
 *   0.50 - 0.88  two shockwave rings expand from the turbine
 *   0.74 - 0.90  panel fades, turbine shrinks and flies to the edge trigger pill, the disc morphs into
 *                the pill's exact rectangle and colour
 *   0.90 - 1.00  impact ring + spring pop on the pill, then the overlay removes itself
 *
 * Also plays a synthesized rising turbine sound (AudioTrack, no audio focus taken, so the game's own audio
 * is not paused) and a ramping haptic rev ending in a thump when the turbine docks.
 *
 * Android blocks touches that pass through an overlay above 0.8 window alpha, so (like every other
 * non-touchable window in this project) this one is pinned at 0.79 through [OverlayKit.params]. The
 * brightest colours therefore peak at about 79% of full intensity.
 *
 * No emojis or text glyph icons: everything is Canvas paths. The arrow between a stat label and its value
 * and the check mark are drawn as vector paths.
 *
 * Main thread only. The timeline allocates nothing per frame.
 */
class WildBoostIgnitionOverlay(context: Context) {

    /**
     * What to show.
     *  - [dock]: screen-pixel rectangle of the visible edge trigger pill (see [dockRectFor]).
     *  - [fpsTarget]: shown in the FPS row. Pass the locked refresh rate when one is held.
     *  - [latencyDeltaPct]: shown in the LATENCY row. -38 is the design value from the spec, NOT a
     *    measurement; pass a measured figure when the app has one.
     *  - [force]: play even when the theme has animations switched off (the AMOLED theme does).
     * The system "remove animations" setting and battery-saver animation cut always win over [force].
     */
    data class Spec(
        val theme: HudTheme,
        val dock: RectF,
        val dockColor: Int,
        val fpsTarget: Int = 144,
        val cpuLabel: String = "MAX BOOST",
        val scaleLabel: String = "ACTIVE",
        val latencyDeltaPct: Int = -38,
        val sound: Boolean = true,
        val haptics: Boolean = true,
        val force: Boolean = false
    )

    /** Fired once, the moment the turbine lands in the pill. Use it to flash / wake the real edge handle. */
    var onDocked: (() -> Unit)? = null

    /** Fired when the overlay window has been removed (also when cancelled or skipped). */
    var onFinished: (() -> Unit)? = null

    val isPlaying: Boolean get() = view != null

    private val ctx: Context = context.applicationContext
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val main = Handler(Looper.getMainLooper())

    private var view: IgnitionView? = null
    private var timeline: ValueAnimator? = null
    private var introSpring: SpringAnimation? = null
    private var popSpring: SpringAnimation? = null
    private var track: AudioTrack? = null
    private var vibrator: Vibrator? = null
    private var token = 0
    private var finishing = false

    /**
     * Starts the animation. Restarts it if one is already playing. Returns false when it cannot be shown
     * (no overlay permission, or animations are off), in which case [onDocked] and [onFinished] have still
     * been fired so a caller's flow never waits on an animation that is not coming.
     */
    fun play(spec: Spec): Boolean {
        cancel()

        val animationsOn = ValueAnimator.areAnimatorsEnabled()
        val themeAllows = spec.theme.animations || spec.force
        if (!Settings.canDrawOverlays(ctx) || !animationsOn || !themeAllows) {
            if (spec.haptics) hapticTick()
            onDocked?.invoke()
            onFinished?.invoke()
            return false
        }

        val v = IgnitionView(ctx)
        v.configure(spec)
        try {
            wm.addView(v, buildParams())
        } catch (_: Throwable) {
            onDocked?.invoke()
            onFinished?.invoke()
            return false
        }
        view = v
        finishing = false
        val myToken = ++token

        // Intro pop: the turbine springs in from 55% size with a little overshoot.
        introSpring = SpringAnimation(v, IntroProp, 1f).also {
            it.setStartValue(0.55f)
            it.setSpring(
                SpringForce(1f)
                    .setDampingRatio(SpringForce.DAMPING_RATIO_LOW_BOUNCY)
                    .setStiffness(SpringForce.STIFFNESS_LOW)
            )
            it.start()
        }

        var dockedFired = false
        val anim = ValueAnimator.ofFloat(0f, 1f)
        anim.duration = DURATION_MS
        anim.interpolator = LinearInterpolator()
        anim.addUpdateListener {
            val t = it.animatedFraction
            v.tick(t)
            if (!dockedFired && t >= DOCK_END) {
                dockedFired = true
                kickPop(v)
                onDocked?.invoke()
            }
        }
        anim.addListener(object : AnimatorListenerAdapter() {
            private var cancelled = false
            override fun onAnimationCancel(animation: Animator) {
                cancelled = true
            }

            override fun onAnimationEnd(animation: Animator) {
                if (token != myToken) return
                if (!cancelled && !dockedFired) {
                    dockedFired = true
                    onDocked?.invoke()
                }
                finish()
            }
        })
        timeline = anim

        if (spec.sound) startSound(myToken)
        if (spec.haptics) startHaptics()
        anim.start()
        return true
    }

    /** Stops the animation at once and removes the window. Safe to call when nothing is playing. */
    fun cancel() {
        if (view == null) return
        token++            // invalidates the running timeline's listeners
        timeline?.cancel()
        finish()
    }

    fun destroy() {
        onDocked = null
        onFinished = null
        cancel()
    }

    // =========================================================================================
    // Window
    // =========================================================================================

    private fun buildParams(): WindowManager.LayoutParams {
        val p = OverlayKit.params(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            "HyperEngineWildBoostIgnition",
            touchable = false
        )
        p.flags = p.flags or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
        // Only ever repeat the rate that is already locked. It used to force the panel's maximum rate while the
        // animation played, which overrode the user's refresh-rate choice (the "random refresh rate").
        runCatching { DisplayModeLock.applyCurrent(ctx, p) }
        return p
    }

    private fun finish() {
        if (finishing) return
        finishing = true
        introSpring?.let { runCatching { it.cancel() } }
        popSpring?.let { runCatching { it.cancel() } }
        introSpring = null
        popSpring = null
        timeline = null
        view?.let { v -> runCatching { wm.removeViewImmediate(v) } }
        view = null
        releaseSound()
        runCatching { vibrator?.cancel() }
        vibrator = null
        onFinished?.invoke()
    }

    private fun kickPop(v: IgnitionView) {
        popSpring?.let { runCatching { it.cancel() } }
        popSpring = SpringAnimation(v, PopProp, 0f).also {
            it.setStartValue(1f)
            it.setSpring(
                SpringForce(0f)
                    .setDampingRatio(SpringForce.DAMPING_RATIO_LOW_BOUNCY)
                    .setStiffness(SpringForce.STIFFNESS_MEDIUM)
            )
            it.start()
        }
    }

    // =========================================================================================
    // Sound + haptics
    // =========================================================================================

    private fun startSound(myToken: Int) {
        val ready = TurbineSound.cached()
        if (ready != null) {
            playBuffer(ready, myToken)
            return
        }
        // First use: synthesize off the main thread, then start (a few tens of ms late at worst).
        Thread {
            val buf = TurbineSound.buffer()
            main.post { if (token == myToken && view != null) playBuffer(buf, myToken) }
        }.start()
    }

    private fun playBuffer(samples: ShortArray, myToken: Int) {
        if (token != myToken) return
        runCatching {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val format = AudioFormat.Builder()
                .setSampleRate(TurbineSound.SAMPLE_RATE)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()
            val t = AudioTrack.Builder()
                .setAudioAttributes(attrs)
                .setAudioFormat(format)
                .setBufferSizeInBytes(samples.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            t.write(samples, 0, samples.size)
            t.play()
            track = t
        }
    }

    private fun releaseSound() {
        track?.let { t ->
            runCatching { t.stop() }
            runCatching { t.release() }
        }
        track = null
    }

    private fun vib(): Vibrator? = runCatching {
        if (Build.VERSION.SDK_INT >= 31) {
            (ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
    }.getOrNull()

    /** Rev: amplitude climbs for 1.35 s with the turbine, holds, then one hard thump at the dock. */
    private fun startHaptics() {
        val v = vib() ?: return
        vibrator = v
        runCatching {
            if (v.hasAmplitudeControl()) {
                val steps = 27
                val timings = LongArray(steps + 4)
                val amps = IntArray(steps + 4)
                timings[0] = 0L
                amps[0] = 0
                for (i in 0 until steps) {
                    timings[1 + i] = 50L
                    amps[1 + i] = (25 + (230f * i / (steps - 1))).roundToInt().coerceIn(1, 255)
                }
                timings[steps + 1] = 270L; amps[steps + 1] = 255   // hold at full while the turbine flies
                timings[steps + 2] = 310L; amps[steps + 2] = 0     // beat of silence
                timings[steps + 3] = 80L; amps[steps + 3] = 255    // dock thump
                v.vibrate(VibrationEffect.createWaveform(timings, amps, -1))
            } else {
                v.vibrate(
                    VibrationEffect.createWaveform(
                        longArrayOf(0, 60, 40, 90, 40, 130, 40, 190, 330, 90), -1
                    )
                )
            }
        }
    }

    private fun hapticTick() {
        val v = vib() ?: return
        runCatching { v.vibrate(VibrationEffect.createOneShot(40L, VibrationEffect.DEFAULT_AMPLITUDE)) }
    }

    // =========================================================================================
    // Synthesized turbine sound
    // =========================================================================================

    private object TurbineSound {
        const val SAMPLE_RATE = 22050
        private const val SECONDS = 2.18f

        @Volatile
        private var cache: ShortArray? = null

        fun cached(): ShortArray? = cache

        fun buffer(): ShortArray = cache ?: synchronized(this) { cache ?: synth().also { cache = it } }

        /**
         * Rising turbine whine (60 -> 960 Hz with two harmonics) over a growing filtered-noise whoosh,
         * peaking at 1.36 s (the turbine's top speed), easing off, then a low thump + noise burst at
         * 1.98 s when the turbine docks. Soft-clipped, so it never distorts.
         */
        private fun synth(): ShortArray {
            val total = (SAMPLE_RATE * SECONDS).toInt()
            val out = ShortArray(total)
            val rnd = Random(42L)
            var phase = 0.0
            var noiseLp = 0f
            for (i in 0 until total) {
                val t = i / SAMPLE_RATE.toFloat()
                val u = (t / 1.36f).coerceIn(0f, 1f)
                val freq = 60f + 900f * u * u
                phase += 2.0 * PI * freq / SAMPLE_RATE
                val tone = (Math.sin(phase) + 0.5 * Math.sin(2.0 * phase) + 0.25 * Math.sin(3.0 * phase)).toFloat()

                val n = rnd.nextFloat() * 2f - 1f
                noiseLp += 0.22f * (n - noiseLp)
                val whoosh = noiseLp * (0.25f + 1.2f * u)

                val attack = min(1f, t / 0.04f)
                val grow = 0.25f + 0.75f * u
                val toneEnv = attack * grow * (1f - ((t - 1.62f) / 0.30f).coerceIn(0f, 1f))
                val whooshEnv = attack * (1f - ((t - 1.70f) / 0.28f).coerceIn(0f, 1f))

                var s = tone * 0.30f * toneEnv + whoosh * 0.38f * whooshEnv

                val th = t - 1.98f
                if (th >= 0f) {
                    val decay = Math.exp((-18f * th).toDouble()).toFloat()
                    s += (Math.sin(2.0 * PI * 55.0 * th).toFloat() * 1.1f +
                        (rnd.nextFloat() * 2f - 1f) * 0.5f * Math.exp((-40f * th).toDouble()).toFloat()) * decay
                }
                val tail = min(1f, (SECONDS - t) / 0.08f)
                out[i] = (tanh(s.toDouble()) * 0.9 * tail * 32767.0).toInt().toShort()
            }
            return out
        }
    }

    // =========================================================================================
    // The view
    // =========================================================================================

    private class Row(val label: String, val kind: Int, val target: Int, val text: String, val color: Int) {
        val labelChars: CharArray = label.toCharArray()
        val textChars: CharArray = text.toCharArray()
    }

    private class IgnitionView(context: Context) : View(context) {

        // ---- spring-driven properties ----
        var intro = 1f
        var pop = 0f

        // ---- configuration ----
        private lateinit var spec: Spec
        private var accent = 0
        private var accent2 = 0
        private var hot = 0
        private var good = 0
        private val dock = RectF()
        private var dockColor = 0
        private var rows: Array<Row> = emptyArray()

        // ---- timeline state ----
        private var t = 0f
        private var lastMs = 0f
        private var angle = 0f
        private var ghostStep = 0f
        private var rpmF = 0f
        private var emitAccum = 0f

        // ---- geometry ----
        private val d = resources.displayMetrics.density
        private var cornerPx = 30f * d
        private var portrait = false
        private var cx0 = 0f
        private var cy0 = 0f
        private var radius = 0f
        private var dockCx = 0f
        private var dockCy = 0f
        private var panelX = 0f
        private var panelY = 0f
        private var panelW = 0f
        private var headerH = 0f
        private var rowH = 0f
        private var tcx = 0f
        private var tcy = 0f
        private var tScale = 1f
        private var rotorFade = 1f

        // ---- paints / shaders (all allocated here or in onSizeChanged) ----
        private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
        }
        private val edgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val cometPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
        }
        private val scrimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val hubPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rpmPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
        private val sparkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
        }
        private val underlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

        private var edgeTop: LinearGradient? = null
        private var edgeBottom: LinearGradient? = null
        private var edgeLeft: LinearGradient? = null
        private var edgeRight: LinearGradient? = null
        private var edgeDepth = 0f
        private var cometShader: SweepGradient? = null
        private val cometMatrix = Matrix()
        private var scrimShader: RadialGradient? = null
        private var haloShader: RadialGradient? = null
        private var hubShader: RadialGradient? = null
        private var underlineShader: LinearGradient? = null

        private val borderRect = RectF()
        private val tmpRect = RectF()
        private val rowPlate = Path()
        private val blade = Path()
        private val checkPath = Path()
        private val checkSeg = Path()
        private val checkMeasure = PathMeasure()
        private val arrowPath = Path()
        private val notchRect = RectF()
        private var tickLines = FloatArray(0)

        private val textBuf = CharArray(32)
        private val digitTmp = CharArray(12)

        // ---- sparks (struct of arrays) ----
        private val rnd = Random(7L)
        private val sx = FloatArray(MAX_SPARKS)
        private val sy = FloatArray(MAX_SPARKS)
        private val svx = FloatArray(MAX_SPARKS)
        private val svy = FloatArray(MAX_SPARKS)
        private val slife = FloatArray(MAX_SPARKS)       // remaining 1 -> 0
        private val sdecay = FloatArray(MAX_SPARKS)      // life lost per second

        init {
            importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
            isClickable = false
            isFocusable = false
            textPaint.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
            textPaint.letterSpacing = 0.12f
            valuePaint.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            rpmPaint.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            for (i in 0 until MAX_SPARKS) slife[i] = 0f
        }

        fun configure(s: Spec) {
            spec = s
            accent = s.theme.accent
            accent2 = s.theme.accent2
            hot = s.theme.hot
            good = s.theme.good
            dock.set(s.dock)
            dockColor = s.dockColor
            rows = arrayOf(
                Row("FPS", K_NUM, s.fpsTarget, "", accent),
                Row("CPU", K_TEXT, 0, s.cpuLabel.uppercase(), accent2),
                Row("HYPERBOOST SCALE", K_TEXT, 0, s.scaleLabel.uppercase(), good),
                Row("LATENCY", K_PCT, s.latencyDeltaPct, "", accent)
            )
        }

        fun tick(fraction: Float) {
            val ms = fraction * DURATION_MS
            val dt = ((ms - lastMs) / 1000f).coerceIn(0f, 0.05f)
            lastMs = ms
            t = fraction

            val spinT = clamp01(t / SPIN_END)
            rpmF = spinT * spinT
            val visualSpeed = 120f + 1700f * rpmF            // degrees per second, kept readable at 144 Hz
            angle = (angle + visualSpeed * dt) % 360f
            ghostStep = 5f * rpmF

            updateSparks(dt)
            invalidate()
        }

        override fun onAttachedToWindow() {
            super.onAttachedToWindow()
            if (Build.VERSION.SDK_INT >= 31) {
                runCatching {
                    val c = rootWindowInsets?.getRoundedCorner(android.view.RoundedCorner.POSITION_TOP_LEFT)
                    if (c != null && c.radius > 0) {
                        cornerPx = c.radius.toFloat()
                        rebuildBorder()
                    }
                }
            }
        }

        // ------------------------------------------------------------------------------------
        // Geometry
        // ------------------------------------------------------------------------------------

        override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
            if (w <= 0 || h <= 0) return
            val wf = w.toFloat()
            val hf = h.toFloat()
            portrait = hf > wf

            rowH = min(48f * d, hf * 0.11f)
            headerH = rowH * 0.9f
            if (portrait) {
                radius = min(wf * 0.30f, hf * 0.17f)
                panelW = min(wf * 0.86f, 340f * d)
                cx0 = wf / 2f
                cy0 = hf * 0.34f
                panelX = (wf - panelW) / 2f
                panelY = cy0 + radius * 1.62f
            } else {
                radius = min(hf * 0.26f, wf * 0.16f)
                panelW = min(wf * 0.36f, 320f * d)
                val gap = 28f * d
                val groupW = radius * 2f + gap + panelW
                val startX = (wf - groupW) / 2f
                cx0 = startX + radius
                cy0 = hf * 0.46f
                panelX = startX + radius * 2f + gap
                val panelH = headerH + rowH * 4f
                panelY = cy0 - panelH / 2f
            }
            dockCx = dock.centerX()
            dockCy = dock.centerY()

            rebuildBorder()

            // edge plasma: orange on top / bottom, cyan on left / right
            edgeDepth = min(wf, hf) * 0.22f
            edgeTop = edgeGradient(0f, 0f, 0f, edgeDepth, accent2)
            edgeBottom = edgeGradient(0f, hf, 0f, hf - edgeDepth, accent2)
            edgeLeft = edgeGradient(0f, 0f, edgeDepth, 0f, accent)
            edgeRight = edgeGradient(wf, 0f, wf - edgeDepth, 0f, accent)

            // two comets racing in opposite halves of the border
            cometShader = SweepGradient(
                wf / 2f, hf / 2f,
                intArrayOf(
                    HudThemes.withAlpha(accent2, 0), HudThemes.withAlpha(accent2, 210), 0xFFFFFFFF.toInt(),
                    HudThemes.withAlpha(accent2, 0), HudThemes.withAlpha(accent, 0),
                    HudThemes.withAlpha(accent, 210), 0xFFFFFFFF.toInt(), HudThemes.withAlpha(accent, 0),
                    HudThemes.withAlpha(accent, 0)
                ),
                floatArrayOf(0f, 0.13f, 0.22f, 0.2201f, 0.5f, 0.63f, 0.72f, 0.7201f, 1f)
            )

            scrimShader = RadialGradient(
                wf / 2f, hf / 2f, max(wf, hf) * 0.62f,
                intArrayOf(0xB0000000.toInt(), 0x00000000), floatArrayOf(0.15f, 1f), Shader.TileMode.CLAMP
            )

            // turbine shaders live around the origin; the canvas is translated to the turbine centre
            haloShader = RadialGradient(
                0f, 0f, radius * 1.9f,
                intArrayOf(HudThemes.withAlpha(accent2, 190), HudThemes.withAlpha(accent2, 0)),
                floatArrayOf(0.30f, 1f), Shader.TileMode.CLAMP
            )
            hubShader = RadialGradient(
                0f, 0f, radius * 0.30f,
                intArrayOf(0xFFFFFFFF.toInt(), accent2, 0xFF0B0F14.toInt()),
                floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
            )
            underlineShader = LinearGradient(
                panelX, 0f, panelX + panelW, 0f, accent2, accent, Shader.TileMode.CLAMP
            )

            // swept 12-blade rotor, unit radius (scaled by canvas)
            blade.reset()
            blade.moveTo(0f, -0.20f)
            blade.cubicTo(0.29f, -0.28f, 0.36f, -0.70f, 0.08f, -0.96f)
            blade.cubicTo(0.10f, -0.62f, 0.03f, -0.40f, -0.06f, -0.20f)
            blade.close()

            // 36 ticks around the casing, relative to the turbine centre, unit radius
            tickLines = FloatArray(36 * 4)
            for (i in 0 until 36) {
                val a = (i * 10.0) * PI / 180.0
                val inner = if (i % 3 == 0) 1.07f else 1.10f
                val outer = 1.15f
                tickLines[i * 4] = (cos(a) * inner).toFloat()
                tickLines[i * 4 + 1] = (sin(a) * inner).toFloat()
                tickLines[i * 4 + 2] = (cos(a) * outer).toFloat()
                tickLines[i * 4 + 3] = (sin(a) * outer).toFloat()
            }

            // stat row plate: slanted cyber plate with a cut corner, origin at the row's top-left
            val rw = panelW
            val rh = rowH * 0.88f
            val sl = rh * 0.32f
            rowPlate.reset()
            rowPlate.moveTo(sl, 0f)
            rowPlate.lineTo(rw, 0f)
            rowPlate.lineTo(rw - sl, rh)
            rowPlate.lineTo(0f, rh)
            rowPlate.close()

            // arrow (shaft + head), drawn as a path so no text glyph is needed
            val aw = rowH * 0.34f
            val ah = rowH * 0.13f
            arrowPath.reset()
            arrowPath.moveTo(0f, 0f)
            arrowPath.lineTo(aw, 0f)
            arrowPath.moveTo(aw - ah, -ah)
            arrowPath.lineTo(aw, 0f)
            arrowPath.lineTo(aw - ah, ah)

            // check mark
            val cs = rowH * 0.34f
            checkPath.reset()
            checkPath.moveTo(0.05f * cs, 0.55f * cs)
            checkPath.lineTo(0.38f * cs, 0.88f * cs)
            checkPath.lineTo(0.95f * cs, 0.12f * cs)
            checkMeasure.setPath(checkPath, false)

            // type sizes
            textPaint.textSize = rowH * 0.30f
            valuePaint.textSize = rowH * 0.40f
            var longest = 1f
            for (r in rows) longest = max(longest, valuePaint.measureText(r.text.ifEmpty { "0" }))
            val maxValueW = panelW * 0.36f
            if (longest > maxValueW) valuePaint.textSize = valuePaint.textSize * maxValueW / longest
        }

        private fun edgeGradient(x0: Float, y0: Float, x1: Float, y1: Float, c: Int): LinearGradient =
            LinearGradient(
                x0, y0, x1, y1,
                intArrayOf(HudThemes.withAlpha(c, 235), HudThemes.withAlpha(c, 80), HudThemes.withAlpha(c, 0)),
                floatArrayOf(0f, 0.35f, 1f), Shader.TileMode.CLAMP
            )

        private fun rebuildBorder() {
            val inset = 3f * d
            borderRect.set(inset, inset, width - inset, height - inset)
        }

        // ------------------------------------------------------------------------------------
        // Sparks
        // ------------------------------------------------------------------------------------

        private fun updateSparks(dt: Float) {
            // emit from the rim while the turbine is spinning and has not started to dock
            val emitting = t < DOCK_START && rpmF > 0.12f
            if (emitting) {
                emitAccum += (40f + 150f * rpmF) * dt
                while (emitAccum >= 1f) {
                    emitAccum -= 1f
                    spawnSpark()
                }
            }
            for (i in 0 until MAX_SPARKS) {
                if (slife[i] <= 0f) continue
                slife[i] -= sdecay[i] * dt
                sx[i] += svx[i] * dt
                sy[i] += svy[i] * dt
                svx[i] *= 0.985f
                svy[i] *= 0.985f
            }
        }

        private fun spawnSpark() {
            var slot = -1
            for (i in 0 until MAX_SPARKS) {
                if (slife[i] <= 0f) {
                    slot = i
                    break
                }
            }
            if (slot < 0) return
            val a = rnd.nextFloat() * (2f * PI.toFloat())
            val r = radius * tScale
            sx[slot] = tcx + cos(a) * r
            sy[slot] = tcy + sin(a) * r
            val tangent = radius * (2.2f + rnd.nextFloat() * 3.2f)
            val outward = radius * (0.5f + rnd.nextFloat() * 1.6f)
            svx[slot] = -sin(a) * tangent + cos(a) * outward
            svy[slot] = cos(a) * tangent + sin(a) * outward
            slife[slot] = 1f
            sdecay[slot] = 1f / (0.35f + rnd.nextFloat() * 0.40f)
        }

        // ------------------------------------------------------------------------------------
        // Drawing
        // ------------------------------------------------------------------------------------

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            if (w <= 0f || h <= 0f || rows.isEmpty()) return

            // ---- envelopes ----
            val edgeI = smooth(clamp01(t / 0.16f)) * (1f - smooth(clamp01((t - 0.70f) / 0.25f)))
            val pulse = 0.82f + 0.18f * sin(t * DURATION_MS * 0.028f)
            val scrimI = min(smooth(clamp01(t / 0.10f)), 1f - smooth(clamp01((t - 0.72f) / 0.18f)))
            val dockT = clamp01((t - DOCK_START) / (DOCK_END - DOCK_START))
            val e = easeInOut(dockT)
            val panelA = smooth(clamp01((t - 0.02f) / 0.08f)) * (1f - smooth(clamp01((t - 0.70f) / 0.08f)))

            // turbine placement for this frame
            tcx = lerp(cx0, dockCx, e)
            tcy = lerp(cy0, dockCy, e)
            tScale = intro * lerp(1f, 0.20f, e)
            rotorFade = smooth(clamp01(t / 0.06f)) * (1f - smooth(clamp01((e - 0.35f) / 0.55f)))

            // 1. scrim
            if (scrimI > 0f) {
                scrimPaint.shader = scrimShader
                scrimPaint.alpha = (255f * scrimI).toInt()
                c.drawRect(0f, 0f, w, h, scrimPaint)
            }

            // 2. edge plasma + racing comets
            if (edgeI > 0.01f) drawEdges(c, w, h, edgeI * pulse)

            // 3. shockwave rings
            drawShock(c, w, h, clamp01((t - 0.50f) / 0.30f), 1f)
            drawShock(c, w, h, clamp01((t - 0.58f) / 0.30f), 0.6f)

            // 4. sparks
            drawSparks(c)

            // 5. disc that morphs into the pill, then the rotor on top of it
            if (e > 0f) drawMorphBody(c, e)
            if (rotorFade > 0.01f) drawTurbine(c)

            // 6. stat panel + RPM readout
            if (panelA > 0.01f) {
                drawPanel(c, panelA)
                drawRpm(c, panelA)
            }

            // 7. impact ring around the docked pill
            if (t >= DOCK_END) drawImpact(c, clamp01((t - DOCK_END) / (1f - DOCK_END)))
        }

        private fun drawEdges(c: Canvas, w: Float, h: Float, intensity: Float) {
            val a = (255f * intensity).toInt().coerceIn(0, 255)
            edgePaint.alpha = a
            edgePaint.shader = edgeTop
            c.drawRect(0f, 0f, w, edgeDepth, edgePaint)
            edgePaint.shader = edgeBottom
            c.drawRect(0f, h - edgeDepth, w, h, edgePaint)
            edgePaint.shader = edgeLeft
            c.drawRect(0f, 0f, edgeDepth, h, edgePaint)
            edgePaint.shader = edgeRight
            c.drawRect(w - edgeDepth, 0f, w, h, edgePaint)

            val shader = cometShader ?: return
            val turns = 1.75f * easeOutCubic(clamp01(t / 0.80f))
            cometMatrix.setRotate(360f * turns, w / 2f, h / 2f)
            shader.setLocalMatrix(cometMatrix)
            cometPaint.shader = shader

            cometPaint.strokeWidth = 18f * d
            cometPaint.alpha = (80f * intensity).toInt()
            c.drawRoundRect(borderRect, cornerPx, cornerPx, cometPaint)
            cometPaint.strokeWidth = 5f * d
            cometPaint.alpha = (255f * intensity).toInt()
            c.drawRoundRect(borderRect, cornerPx, cornerPx, cometPaint)
        }

        private fun drawShock(c: Canvas, w: Float, h: Float, p: Float, strength: Float) {
            if (p <= 0f || p >= 1f) return
            val maxR = hypot(w, h) * 0.55f
            val r = lerp(radius * 1.1f, maxR, easeOutCubic(p))
            val fade = (1f - p)
            strokePaint.shader = null
            strokePaint.color = HudThemes.blend(accent2, accent, p)
            strokePaint.strokeWidth = radius * 0.09f * fade + 2f * d
            strokePaint.alpha = (255f * fade * fade * strength).toInt()
            c.drawCircle(cx0, cy0, r, strokePaint)
        }

        private fun drawSparks(c: Canvas) {
            sparkPaint.strokeWidth = 2.2f * d
            for (i in 0 until MAX_SPARKS) {
                val life = slife[i]
                if (life <= 0f) continue
                sparkPaint.color = HudThemes.blend(accent, accent2, life)
                sparkPaint.alpha = (255f * min(1f, life * 1.6f)).toInt()
                c.drawLine(sx[i], sy[i], sx[i] - svx[i] * 0.035f, sy[i] - svy[i] * 0.035f, sparkPaint)
            }
        }

        private fun drawMorphBody(c: Canvas, e: Float) {
            val circleR = radius * 0.95f * intro.coerceAtLeast(0.6f)
            val extra = pop * 6f * d      // spring pop once docked
            tmpRect.set(
                lerp(cx0 - circleR, dock.left, e) - extra,
                lerp(cy0 - circleR, dock.top, e) - extra,
                lerp(cx0 + circleR, dock.right, e) + extra,
                lerp(cy0 + circleR, dock.bottom, e) + extra
            )
            val corner = lerp(circleR, min(dock.width(), dock.height()) / 2f, e)
            fillPaint.shader = null
            fillPaint.color = HudThemes.blend(0xFF0B0F14.toInt(), dockColor, e)
            fillPaint.alpha = (255f * min(1f, e * 1.7f)).toInt()
            c.drawRoundRect(tmpRect, corner, corner, fillPaint)

            if (e > 0.6f) {
                // same inner highlight EdgeTriggerView draws, so the hand-over to the real handle is seamless
                val k = (e - 0.6f) / 0.4f
                val thick = min(dock.width(), dock.height())
                val inset = thick * 0.28f
                tmpRect.inset(inset, inset)
                fillPaint.color = 0xFFFFFFFF.toInt()
                fillPaint.alpha = (70f * k).toInt()
                val r2 = max(0f, corner - inset)
                c.drawRoundRect(tmpRect, r2, r2, fillPaint)
            }
        }

        private fun drawTurbine(c: Canvas) {
            val f = rotorFade
            c.save()
            c.translate(tcx, tcy)
            c.scale(tScale, tScale)

            val flicker = 0.85f + 0.15f * sin(t * DURATION_MS * 0.05f)

            // afterburner halo
            haloPaint.shader = haloShader
            haloPaint.alpha = (255f * f * (0.10f + 0.90f * rpmF) * flicker).toInt().coerceIn(0, 255)
            c.drawCircle(0f, 0f, radius * 1.9f, haloPaint)

            // casing
            val ringColor = HudThemes.blend(accent, accent2, rpmF)
            strokePaint.shader = null
            strokePaint.color = ringColor
            strokePaint.strokeWidth = radius * 0.035f
            strokePaint.alpha = (255f * f).toInt()
            c.drawCircle(0f, 0f, radius, strokePaint)
            strokePaint.strokeWidth = radius * 0.012f
            strokePaint.alpha = (120f * f).toInt()
            c.drawCircle(0f, 0f, radius * 1.045f, strokePaint)

            // casing notches, counter-rotating
            strokePaint.strokeWidth = radius * 0.06f
            strokePaint.strokeCap = Paint.Cap.BUTT
            strokePaint.color = HudThemes.blend(accent2, 0xFFFFFFFF.toInt(), 0.25f)
            strokePaint.alpha = (230f * f).toInt()
            notchRect.set(-radius, -radius, radius, radius)
            for (k in 0 until 6) c.drawArc(notchRect, -angle * 0.35f + k * 60f, 16f, false, strokePaint)
            strokePaint.strokeCap = Paint.Cap.ROUND

            // ticks
            c.save()
            c.rotate(-angle * 0.18f)
            c.scale(radius, radius)
            strokePaint.strokeWidth = 0.014f
            strokePaint.color = HudThemes.blend(accent, 0xFFFFFFFF.toInt(), 0.35f)
            strokePaint.alpha = (200f * f).toInt()
            c.drawLines(tickLines, strokePaint)
            c.restore()

            // rotor: motion-blur ghosts first, then the solid blades
            c.save()
            c.scale(radius, radius)
            fillPaint.shader = null
            val bladeColor = HudThemes.blend(accent2, hot, 0.5f + 0.5f * sin(t * DURATION_MS * 0.012f)).let {
                HudThemes.blend(accent, it, min(1f, rpmF * 1.4f))
            }
            for (g in 3 downTo 1) {
                c.save()
                c.rotate(angle - g * ghostStep)
                fillPaint.color = bladeColor
                fillPaint.alpha = (255f * f * 0.16f * (4 - g) * min(1f, rpmF * 2f)).toInt().coerceIn(0, 255)
                for (k in 0 until 12) {
                    c.drawPath(blade, fillPaint)
                    c.rotate(30f)
                }
                c.restore()
            }
            c.rotate(angle)
            fillPaint.color = bladeColor
            fillPaint.alpha = (255f * f).toInt()
            strokePaint.strokeWidth = 0.012f
            strokePaint.color = HudThemes.blend(bladeColor, 0xFFFFFFFF.toInt(), 0.55f)
            strokePaint.alpha = (200f * f).toInt()
            for (k in 0 until 12) {
                c.drawPath(blade, fillPaint)
                c.drawPath(blade, strokePaint)
                c.rotate(30f)
            }
            c.restore()

            // intake ring + hub
            strokePaint.strokeWidth = radius * 0.02f
            strokePaint.color = ringColor
            strokePaint.alpha = (200f * f).toInt()
            c.drawCircle(0f, 0f, radius * 0.31f, strokePaint)
            hubPaint.shader = hubShader
            hubPaint.alpha = (255f * f).toInt()
            c.drawCircle(0f, 0f, radius * 0.27f, hubPaint)

            c.restore()
        }

        private fun drawPanel(c: Canvas, alpha: Float) {
            // header + sweeping underline
            val headerP = easeOutCubic(clamp01((t - 0.04f) / 0.20f))
            textPaint.textSize = rowH * 0.34f
            textPaint.color = 0xFFFFFFFF.toInt()
            textPaint.alpha = (255f * alpha * headerP).toInt()
            val title = "WILD BOOST ONLINE"
            c.drawText(title, panelX, panelY + headerH * 0.52f, textPaint)
            underlinePaint.shader = underlineShader
            underlinePaint.alpha = (255f * alpha).toInt()
            c.drawRect(panelX, panelY + headerH * 0.66f, panelX + panelW * headerP, panelY + headerH * 0.66f + 2.4f * d, underlinePaint)
            underlinePaint.shader = null

            textPaint.textSize = rowH * 0.30f
            for (i in rows.indices) {
                val row = rows[i]
                val rp = clamp01((t - (ROW_START + i * ROW_STEP)) / ROW_DUR)
                if (rp <= 0f) continue
                val ep = easeOutCubic(rp)
                val a = alpha * ep
                val slide = (1f - ep) * 44f * d
                val y = panelY + headerH + i * rowH

                c.save()
                c.translate(panelX - slide, y)

                // plate
                fillPaint.shader = null
                fillPaint.color = HudThemes.withAlpha(row.color, 255)
                fillPaint.alpha = (46f * a).toInt()
                c.drawPath(rowPlate, fillPaint)
                strokePaint.shader = null
                strokePaint.strokeWidth = 1.4f * d
                strokePaint.color = row.color
                strokePaint.alpha = (150f * a).toInt()
                c.drawPath(rowPlate, strokePaint)
                // accent bar on the left
                fillPaint.color = row.color
                fillPaint.alpha = (255f * a).toInt()
                c.drawRect(0f, rowH * 0.06f, 4f * d, rowH * 0.82f, fillPaint)

                val base = rowH * 0.58f
                // label
                textPaint.color = 0xFFFFFFFF.toInt()
                textPaint.alpha = (230f * a).toInt()
                c.drawText(row.labelChars, 0, row.labelChars.size, 16f * d, base, textPaint)

                // vector arrow
                strokePaint.strokeWidth = 2.2f * d
                strokePaint.color = row.color
                strokePaint.alpha = (255f * a).toInt()
                c.save()
                c.translate(panelW * 0.47f, rowH * 0.44f)
                c.drawPath(arrowPath, strokePaint)
                c.restore()

                // rolling value
                val n = writeValue(row, ep)
                valuePaint.color = row.color
                valuePaint.alpha = (255f * a).toInt()
                c.drawText(textBuf, 0, n, panelW * 0.56f, base + rowH * 0.02f, valuePaint)

                // check mark draws in once the value has settled
                val cp = clamp01((rp - 0.72f) / 0.28f)
                if (cp > 0f) {
                    checkSeg.rewind()
                    checkMeasure.getSegment(0f, checkMeasure.length * cp, checkSeg, true)
                    strokePaint.strokeWidth = 2.6f * d
                    strokePaint.color = good
                    strokePaint.alpha = (255f * a).toInt()
                    c.save()
                    c.translate(panelW * 0.90f, rowH * 0.26f)
                    c.drawPath(checkSeg, strokePaint)
                    c.restore()
                }
                c.restore()
            }
        }

        /** Writes the animated value of [row] into [textBuf]; returns its length. No allocation. */
        private fun writeValue(row: Row, p: Float): Int {
            when (row.kind) {
                K_NUM -> {
                    val v = (row.target * p).roundToInt()
                    return putInt(textBuf, 0, v, false)
                }
                K_PCT -> {
                    val v = (row.target * p).roundToInt()
                    var idx = 0
                    if (v < 0) textBuf[idx++] = '-' else if (v > 0) textBuf[idx++] = '+'
                    idx = putInt(textBuf, idx, v, false)
                    textBuf[idx++] = '%'
                    return idx
                }
                else -> {
                    // letters scramble, then lock in left to right
                    val src = row.textChars
                    val len = min(src.size, textBuf.size)
                    val resolved = p * 1.25f * len
                    val tick = (t * DURATION_MS / 45f).toInt()
                    for (k in 0 until len) {
                        val ch = src[k]
                        textBuf[k] = if (ch == ' ' || resolved >= k + 1) ch
                        else ('A' + ((tick * 7 + k * 11) % 26))
                    }
                    return len
                }
            }
        }

        private fun drawRpm(c: Canvas, alpha: Float) {
            val rpm = ((20000f * rpmF).toInt() / 10) * 10
            val n = putInt(textBuf, 0, rpm, true)
            val size = radius * 0.30f
            rpmPaint.textSize = size
            rpmPaint.color = HudThemes.blend(accent, accent2, rpmF)
            rpmPaint.alpha = (255f * alpha).toInt()
            val y = cy0 + radius * 1.32f + size
            c.drawText(textBuf, 0, n, cx0, y, rpmPaint)
            rpmPaint.textSize = size * 0.42f
            rpmPaint.color = 0xFFFFFFFF.toInt()
            rpmPaint.alpha = (200f * alpha).toInt()
            c.drawText(RPM_LABEL, 0, RPM_LABEL.size, cx0, y + size * 0.62f, rpmPaint)
        }

        private fun drawImpact(c: Canvas, p: Float) {
            val grow = easeOutCubic(p) * 28f * d
            val fade = 1f - p
            tmpRect.set(dock.left - grow, dock.top - grow, dock.right + grow, dock.bottom + grow)
            val corner = min(dock.width(), dock.height()) / 2f + grow
            strokePaint.shader = null
            strokePaint.strokeWidth = 3f * d
            strokePaint.color = dockColor
            strokePaint.alpha = (230f * fade).toInt()
            c.drawRoundRect(tmpRect, corner, corner, strokePaint)
        }

        // ------------------------------------------------------------------------------------
        // Helpers
        // ------------------------------------------------------------------------------------

        /** Writes [value] (absolute) into [buf] from [start]; optional thousands commas. Returns the end index. */
        private fun putInt(buf: CharArray, start: Int, value: Int, group: Boolean): Int {
            var v = abs(value)
            var n = 0
            if (v == 0) digitTmp[n++] = '0'
            while (v > 0 && n < digitTmp.size) {
                digitTmp[n++] = '0' + (v % 10)
                v /= 10
            }
            var idx = start
            for (pos in n - 1 downTo 0) {
                buf[idx++] = digitTmp[pos]
                if (group && pos > 0 && pos % 3 == 0) buf[idx++] = ','
            }
            return idx
        }
    }

    // =========================================================================================
    // Companion: timing, easing, spring properties, dock geometry
    // =========================================================================================

    companion object {
        const val DURATION_MS = 2200L

        internal const val SPIN_END = 0.62f
        internal const val ROW_START = 0.30f
        internal const val ROW_STEP = 0.085f
        internal const val ROW_DUR = 0.16f
        internal const val DOCK_START = 0.74f
        internal const val DOCK_END = 0.90f

        internal const val K_NUM = 0
        internal const val K_TEXT = 1
        internal const val K_PCT = 2

        internal const val MAX_SPARKS = 72
        internal val RPM_LABEL = "RPM".toCharArray()

        private val IntroProp = object : FloatPropertyCompat<IgnitionView>("intro") {
            override fun getValue(o: IgnitionView): Float = o.intro
            override fun setValue(o: IgnitionView, value: Float) {
                o.intro = value
                o.invalidate()
            }
        }

        private val PopProp = object : FloatPropertyCompat<IgnitionView>("pop") {
            override fun getValue(o: IgnitionView): Float = o.pop
            override fun setValue(o: IgnitionView, value: Float) {
                o.pop = value.coerceAtLeast(-0.6f)
                o.invalidate()
            }
        }

        /**
         * Screen-pixel rectangle of the visible edge trigger pill, mirroring how HudController places the
         * handle window and EdgeTriggerView draws the bar inside it.
         */
        fun dockRectFor(ctx: Context, handle: HandleConfig, screen: Point): RectF {
            val thick = Ui.dp(ctx, handle.widthDp.coerceIn(4, 16)).toFloat()
            val len = Ui.dp(ctx, handle.heightDp.coerceIn(40, 160)).toFloat()
            val off = Ui.dp(ctx, handle.offsetDp).toFloat()
            return when (handle.side) {
                EdgeSide.LEFT -> {
                    val top = off.coerceIn(0f, max(0f, screen.y - len))
                    RectF(0f, top, thick, top + len)
                }
                EdgeSide.RIGHT -> {
                    val top = off.coerceIn(0f, max(0f, screen.y - len))
                    RectF(screen.x - thick, top, screen.x.toFloat(), top + len)
                }
                EdgeSide.TOP -> {
                    val left = off.coerceIn(0f, max(0f, screen.x - len))
                    RectF(left, 0f, left + len, thick)
                }
            }
        }

        /**
         * A ready-to-play [Spec] built from the app's current settings: the HUD theme, the edge handle's
         * real position and colour, and the refresh rate the FPS enforcer is holding (144 when none).
         * Needs the application to be running (HyperApp).
         */
        fun specFromSettings(ctx: Context, force: Boolean = false): Spec {
            val app = HyperApp.instance
            val g = app.repository.global.value
            val wm = ctx.applicationContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val screen = OverlayKit.realSize(wm)
            val hz = app.fps.lockedHz.value
            return Spec(
                theme = HudThemes.resolve(g),
                dock = dockRectFor(ctx, g.handle, screen),
                dockColor = HudThemes.parse(g.handle.colorHex, 0xFF00E5FF.toInt()),
                fpsTarget = if (hz > 0) hz else 144,
                force = force
            )
        }

        /** Builds the turbine sound ahead of time so the first ignition starts on the frame it should. */
        fun prewarmSound() {
            if (TurbineSound.cached() != null) return
            Thread { TurbineSound.buffer() }.start()
        }

        internal fun clamp01(x: Float): Float = if (x < 0f) 0f else if (x > 1f) 1f else x
        internal fun lerp(a: Float, b: Float, k: Float): Float = a + (b - a) * k
        internal fun smooth(x: Float): Float = x * x * (3f - 2f * x)
        internal fun easeOutCubic(x: Float): Float {
            val k = 1f - x
            return 1f - k * k * k
        }
        internal fun easeInOut(x: Float): Float =
            if (x < 0.5f) 4f * x * x * x else 1f - Math.pow((-2.0 * x + 2.0), 3.0).toFloat() / 2f
    }
}
