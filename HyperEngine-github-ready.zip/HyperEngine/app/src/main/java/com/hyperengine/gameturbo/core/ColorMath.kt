package com.hyperengine.gameturbo.core

import android.graphics.Color
import com.hyperengine.gameturbo.data.VisualFilterConfig
import kotlin.math.abs
import kotlin.math.max

/**
 * What the screen overlay should show. Used as the fallback when no shell can install a real colour
 * matrix, and for the window-level brightness override.
 * All alphas are the EFFECTIVE on-screen opacity (0..1).
 */
data class OverlayState(
    val veilAlpha: Float = 0f,      // black dimmer
    val tintColor: Int = 0,         // ARGB colour (alpha ignored, see tintAlpha)
    val tintAlpha: Float = 0f,
    val liftAlpha: Float = 0f,      // white veil that raises the black level
    val brightness: Float = -1f     // 0..1 window brightness override, <0 = none
) {
    val isNeutral: Boolean
        get() = veilAlpha <= 0f && tintAlpha <= 0f && liftAlpha <= 0f && brightness < 0f
}

object ColorMath {

    fun isIdentity(c: VisualFilterConfig): Boolean =
        c.saturationPct == 100 && c.warmthPct == 50 && c.redPct == 100 && c.greenPct == 100 &&
            c.bluePct == 100 && c.shadowBoostPct == 0 && c.extraDimPct == 0

    /** Per-channel gain from the RGB sliders and the warm/cool slider. All values are <= 1. */
    private fun gains(c: VisualFilterConfig): FloatArray {
        var gr = c.redPct.coerceIn(0, 100) / 100f
        var gg = c.greenPct.coerceIn(0, 100) / 100f
        var gb = c.bluePct.coerceIn(0, 100) / 100f
        val w = ((c.warmthPct - 50) / 50f).coerceIn(-1f, 1f)
        if (w > 0f) {            // warm: less blue, a little less green
            gg *= 1f - 0.12f * w
            gb *= 1f - 0.35f * w
        } else if (w < 0f) {     // cool: less red, a little less green
            gr *= 1f - 0.30f * -w
            gg *= 1f - 0.10f * -w
        }
        return floatArrayOf(gr, gg, gb)
    }

    /**
     * Column-major 4x4 matrix for SurfaceFlinger: out = diag(gain) * Saturation * in + lift.
     *  - saturation 0..200 % (Rec.709 luma weights, 100 = unchanged)
     *  - shadow boost lifts the black level up to 15 % (white stays white) so dark corners become visible
     *  - extra dim scales everything down by up to 85 %, below the panel's hardware minimum
     */
    fun matrix(c: VisualFilterConfig): FloatArray {
        val s = c.saturationPct.coerceIn(0, 200) / 100f
        val g = gains(c)
        val dim = 1f - c.extraDimPct.coerceIn(0, 85) / 100f
        val lift = c.shadowBoostPct.coerceIn(0, 100) / 100f * 0.15f
        val k = dim * (1f - lift)
        val lr = 0.2126f
        val lg = 0.7152f
        val lb = 0.0722f
        val rows = arrayOf(
            floatArrayOf(lr * (1 - s) + s, lg * (1 - s), lb * (1 - s)),
            floatArrayOf(lr * (1 - s), lg * (1 - s) + s, lb * (1 - s)),
            floatArrayOf(lr * (1 - s), lg * (1 - s), lb * (1 - s) + s)
        )
        val m = FloatArray(16)
        for (row in 0..2) for (col in 0..2) m[col * 4 + row] = g[row] * k * rows[row][col]
        val t = lift * dim
        m[12] = t; m[13] = t; m[14] = t
        m[15] = 1f
        return m
    }

    /**
     * Approximation for devices without a shell: a translucent layer can only darken, tint and wash out,
     * it cannot change saturation. Effective opacity stays under 0.79 so Android's "obscured touch"
     * protection never blocks the game's input.
     */
    fun overlayFor(c: VisualFilterConfig, brightness: Float = -1f): OverlayState {
        val g = gains(c)
        val d = floatArrayOf(1f - g[0], 1f - g[1], 1f - g[2])
        val aMax = max(d[0], max(d[1], d[2])).coerceAtMost(0.45f)
        val tint = if (aMax < 0.02f) 0 else Color.rgb(
            (255 * (1f - d[0] / aMax).coerceIn(0f, 1f)).toInt(),
            (255 * (1f - d[1] / aMax).coerceIn(0f, 1f)).toInt(),
            (255 * (1f - d[2] / aMax).coerceIn(0f, 1f)).toInt()
        )
        return OverlayState(
            veilAlpha = (c.extraDimPct.coerceIn(0, 85) / 100f).coerceAtMost(MAX_OVERLAY_ALPHA),
            tintColor = tint,
            tintAlpha = if (tint == 0) 0f else aMax,
            liftAlpha = c.shadowBoostPct.coerceIn(0, 100) / 100f * 0.12f,
            brightness = brightness
        )
    }

    /**
     * What a plain overlay can show of a game colour filter when no shell can install the real matrix: night mode
     * (warm tint + dimmer) and the HDR shadow lift. Contrast, vibrance and colourblind assist need the real matrix.
     */
    fun overlayForGameFilter(c: GameFilterConfig): OverlayState {
        val n = c.nightPct.coerceIn(0, 100) / 100f
        val h = c.hdrPct.coerceIn(0, 100) / 100f
        return OverlayState(
            veilAlpha = 0.25f * n,
            tintColor = if (n > 0f) Color.rgb(255, 140, 40) else 0,
            tintAlpha = if (n > 0f) 0.22f * n else 0f,
            liftAlpha = 0.08f * h
        )
    }

    fun same(a: Float, b: Float) = abs(a - b) < 0.001f

    const val MAX_OVERLAY_ALPHA = 0.79f
}
