package com.hyperengine.gameturbo.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import com.hyperengine.gameturbo.R

/**
 * Microphone foreground service. Since Android 11 the system hands an app that is not in the foreground a stream of
 * digital silence from AudioRecord, with no error: this is the main reason a voice changer works in the app and then
 * "randomly" goes dead once a game is in front. A foreground service of type `microphone` is what keeps the mic
 * live for an app that is not on screen, so the voice engine holds one for as long as it captures.
 *
 * Reference counted through [hold]: the service starts with the first holder and stops with the last release.
 * The count says who wants the service; [running] says whether it really is in the foreground. If Android refuses the
 * foreground start the service stops itself, [running] goes back to false, and the next [hold] tries again.
 */
class VoiceForegroundService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        goForeground()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground()
        return START_NOT_STICKY
    }

    private fun goForeground() {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CHANNEL) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL, "Voice changer", NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) }
                )
            }
            val n = Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_voice_changer_mic)
                .setContentTitle("Voice changer is listening")
                .setContentText("Keeps the microphone open while you play.")
                .setOngoing(true)
                .build()
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(NOTIF_ID, n)
            }
            running = true
        } catch (_: Throwable) {
            running = false
            stopSelf()
        }
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }

    /** One claim on the service. [release] is safe to call more than once. */
    class Hold internal constructor(private val ctx: Context) {
        @Volatile private var released = false
        fun release() {
            if (released) return
            released = true
            drop(ctx)
        }
    }

    companion object {
        private const val CHANNEL = "hyper_voice"
        private const val NOTIF_ID = 4103
        private var holders = 0

        /** True only while the service is really in the foreground with the microphone type. */
        @Volatile private var running = false

        @Synchronized
        fun hold(context: Context): Hold {
            val app = context.applicationContext
            holders++
            // Not only for the first holder: when an earlier start was refused, any later holder starts it again. A
            // start that is already on its way just runs onStartCommand once more, which is harmless.
            if (!running) {
                runCatching { app.startForegroundService(Intent(app, VoiceForegroundService::class.java)) }
            }
            return Hold(app)
        }

        @Synchronized
        private fun drop(app: Context) {
            if (holders > 0) holders--
            if (holders == 0) runCatching { app.stopService(Intent(app, VoiceForegroundService::class.java)) }
        }
    }
}
