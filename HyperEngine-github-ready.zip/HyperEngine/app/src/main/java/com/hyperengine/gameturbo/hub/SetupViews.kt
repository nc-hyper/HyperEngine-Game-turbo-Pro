package com.hyperengine.gameturbo.hub

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.hyperengine.gameturbo.HyperApp
import com.hyperengine.gameturbo.R
import com.hyperengine.gameturbo.core.BridgeState
import com.hyperengine.gameturbo.core.EngineStatus
import com.hyperengine.gameturbo.core.ShellProvider
import com.hyperengine.gameturbo.core.TelemetrySample
import com.hyperengine.gameturbo.service.DanmakuNotificationService
import com.hyperengine.gameturbo.service.GameDetectorService
import com.hyperengine.gameturbo.service.TouchMacroService
import com.hyperengine.gameturbo.ui.HudThemes
import com.hyperengine.gameturbo.ui.Ui
import com.hyperengine.gameturbo.ui.VIcon
import kotlinx.coroutines.launch
import java.util.Locale

// =============================================================================================
// Live status strip: engine state, watcher state, RAM / temperature / battery
// =============================================================================================

class StatusStrip(private val host: HubHost) : LinearLayout(host.activity) {

    private val theme = host.theme
    private val engineLine = Ui.label(host.activity, "", 12f, theme.textPrimary, true)
    private val restoreBtn: TextView
    private val watcherLine = Ui.label(host.activity, "", 11f, theme.warn)
    private val systemLine = Ui.label(host.activity, "", 11f, theme.textSecondary)

    private var engine = EngineStatus()
    private var detector = GameDetectorService.DetectorState()

    init {
        orientation = VERTICAL
        setPadding(host.dp(12), host.dp(8), host.dp(12), host.dp(8))
        background = Ui.rounded(theme.tile, HubStyle.radius(host.activity, theme, 12), theme.stroke, host.dp(1))

        val top = Ui.hbox(host.activity)
        top.gravity = Gravity.CENTER_VERTICAL
        top.addView(engineLine, Ui.lp(0, Ui.WRAP, 1f))
        restoreBtn = Ui.button(host.activity, theme, "Restore now", false) {
            host.scope.launch {
                val rep = host.engine.restoreAll("Restore now button in the hub")
                host.toast(
                    if (rep.complete) "Phone settings restored"
                    else "Restore incomplete: ${rep.steps.firstOrNull { !it.ok }?.detail?.take(80) ?: "see developer console"}",
                    !rep.complete
                )
            }
        }.apply {
            textSize = 11f
            setPadding(host.dp(10), host.dp(6), host.dp(10), host.dp(6))
            visibility = View.GONE
        }
        top.addView(restoreBtn, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, host.dp(8), 0, 0, 0))
        addView(top, Ui.lp(Ui.MATCH, Ui.WRAP))

        watcherLine.visibility = View.GONE
        addView(watcherLine, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(3), 0, 0))
        addView(systemLine, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(3), 0, 0))
        renderEngine()
    }

    fun update(st: EngineStatus) {
        engine = st
        renderEngine()
    }

    fun update(d: GameDetectorService.DetectorState) {
        detector = d
        renderEngine()
    }

    fun update(t: TelemetrySample) {
        val parts = ArrayList<String>()
        if (t.totalRamMb > 0) parts += "RAM ${Fmt.gb(t.availRamMb)} of ${Fmt.gb(t.totalRamMb)} GB free"
        if (t.batteryPct >= 0) {
            parts += String.format(Locale.US, "%.1f°C", t.batteryTempC)
            parts += "${t.batteryPct}%" + if (t.charging) " charging" else ""
        }
        if (t.powerW >= 0f) parts += String.format(Locale.US, "%.1f W", t.powerW)
        systemLine.text = parts.joinToString("  |  ")
        systemLine.setTextColor(if (t.overTemp) theme.hot else theme.textSecondary)
    }

    private fun gameLabel(pkg: String?): String =
        pkg?.let { host.repo.profile(it)?.label?.ifBlank { it } ?: it } ?: ""

    private fun renderEngine() {
        val e = engine
        when {
            e.busy != null -> {
                engineLine.text = "Working: ${e.busy}"
                engineLine.setTextColor(theme.accent)
                restoreBtn.visibility = View.GONE
            }
            e.restoreCountdownSec != null -> {
                engineLine.text = "Restoring phone settings in ${e.restoreCountdownSec}s"
                engineLine.setTextColor(theme.warn)
                restoreBtn.visibility = View.VISIBLE
            }
            e.sessionActive -> {
                engineLine.text = "Boost active" + (e.activeGame?.let { " | " + gameLabel(it) } ?: "")
                engineLine.setTextColor(theme.accent2)
                restoreBtn.visibility = View.VISIBLE
            }
            else -> {
                engineLine.text = "Phone settings are original"
                engineLine.setTextColor(theme.good)
                restoreBtn.visibility = View.GONE
            }
        }
        val d = detector
        val warn = when {
            !d.running -> "Game watcher is off: games are not detected, so nothing boosts or restores automatically."
            d.problem != null -> d.problem
            else -> null
        }
        watcherLine.text = warn.orEmpty()
        watcherLine.visibility = if (warn == null) View.GONE else View.VISIBLE
    }
}

// =============================================================================================
// Setup banner: execution mode (Shizuku / root / ADB grant / standard) + permission checklist
// =============================================================================================

class SetupBanner(private val host: HubHost) : LinearLayout(host.activity) {

    private enum class Level { FULL, PARTIAL, LIMITED }

    private class Req(
        val title: String,
        val why: String,
        val ok: Boolean,
        val required: Boolean,
        val actionLabel: String?,
        val alwaysAction: Boolean = false,
        val action: (() -> Unit)? = null
    )

    private val ctx = host.activity
    private val theme = host.theme
    private val dot = View(ctx)
    private val titleView = Ui.label(ctx, "", 13f, theme.textPrimary, true)
    private val subView = Ui.label(ctx, "", 11f, theme.textSecondary)
    private val chevron = Ui.label(ctx, "", 14f, theme.textSecondary, true)
    private val primary: TextView
    private val list = Ui.vbox(ctx)

    private var state = BridgeState()
    private var expanded: Boolean? = null   // null = decide automatically from what is missing

    init {
        orientation = VERTICAL
        setPadding(host.dp(12), host.dp(10), host.dp(12), host.dp(10))

        val head = Ui.hbox(ctx)
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(dot, Ui.lp(host.dp(10), host.dp(10), 0f, 0, 0, host.dp(10), 0))
        val col = Ui.vbox(ctx)
        col.addView(titleView)
        col.addView(subView, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(2), 0, 0))
        head.addView(col, Ui.lp(0, Ui.WRAP, 1f))
        head.addView(chevron, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, host.dp(8), 0, 0, 0))
        // the full checklist lives on the diagnostics screen; the banner stays one line tall
        head.setOnClickListener {
            host.activity.startActivity(android.content.Intent(host.activity, com.hyperengine.gameturbo.DiagnosticsActivity::class.java))
        }
        addView(head, Ui.lp(Ui.MATCH, Ui.WRAP))

        primary = Ui.button(ctx, theme, "", true) { primaryAction() }
        addView(primary, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(8), 0, 0))
        addView(list, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(4), 0, 0))
        render(state)
    }

    /** Re-reads every permission. Call from onResume and after a permission dialog. */
    fun refresh() {
        host.bridge.refresh()
        render(state)
    }

    fun render(st: BridgeState) {
        state = st
        val reqs = requirements(st)
        val missingRequired = reqs.filter { it.required && !it.ok }
        val level = when {
            st.provider != ShellProvider.NONE -> Level.FULL
            st.writeSecureSettings -> Level.PARTIAL
            else -> Level.LIMITED
        }
        val color = when (level) {
            Level.FULL -> theme.good
            Level.PARTIAL -> theme.warn
            Level.LIMITED -> theme.hot
        }
        val bgTint = if (missingRequired.isNotEmpty()) theme.hot else color
        background = Ui.rounded(
            HudThemes.withAlpha(bgTint, 0x1F), HubStyle.radius(ctx, theme, 12),
            HudThemes.withAlpha(bgTint, 0x99), host.dp(1)
        )
        dot.background = Ui.rounded(color, host.dp(5).toFloat())
        titleView.text = st.mode.label
        subView.text = when {
            missingRequired.isNotEmpty() -> "Needs: " + missingRequired.joinToString(", ") { it.title.lowercase() }
            level == Level.FULL -> "Everything is ready. Games are detected, boosted and restored automatically."
            else -> "Works with limited power. Start Shizuku (or grant root) for game mode, force-stop and compile."
        }

        val action = primaryLabel(st, missingRequired)
        primary.visibility = if (action == null) View.GONE else View.VISIBLE
        primary.text = action.orEmpty()

        val open = false
        chevron.text = "Diagnostics >"
        list.removeAllViews()
        list.visibility = if (open) View.VISIBLE else View.GONE
        if (open) reqs.forEach { list.addView(row(it), Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(6), 0, 0)) }
    }

    private fun autoExpand(missing: Boolean = requirements(state).any { it.required && !it.ok }) = missing

    // ── what the primary button does ──

    private fun primaryLabel(st: BridgeState, missingRequired: List<Req>): String? = when {
        st.provider == ShellProvider.NONE && !st.shizukuInstalled -> "Get Shizuku"
        st.provider == ShellProvider.NONE && !st.shizukuRunning -> "Open Shizuku and start it"
        st.shizukuRunning && !st.shizukuGranted -> "Allow Hyper Engine in Shizuku"
        !st.overlay -> "Allow display over other apps"
        !st.usageAccess && !host.bridge.hasShell() -> "Allow usage access"
        st.provider != ShellProvider.NONE && !st.writeSecureSettings ->
            "Self-grant permissions (keeps working without Shizuku)"
        missingRequired.isNotEmpty() -> "Fix: " + missingRequired.first().title
        else -> null
    }

    private fun primaryAction() {
        val st = state
        val none = st.provider == ShellProvider.NONE
        when {
            none && !st.shizukuInstalled -> HubIntents.shizuku(host)
            none && !st.shizukuRunning -> {
                host.toast("In Shizuku: start it with Wireless debugging (or root), then come back here.", true)
                HubIntents.shizuku(host)
            }
            st.shizukuRunning && !st.shizukuGranted -> {
                if (!host.bridge.requestShizukuPermission()) host.toast("Shizuku is not running", true)
            }
            !st.overlay -> HubIntents.overlay(host)
            !st.usageAccess && !host.bridge.hasShell() -> HubIntents.usageAccess(host)
            !none && !st.writeSecureSettings -> selfGrant()
            else -> requirements(st).firstOrNull { it.required && !it.ok }?.action?.invoke()
        }
    }

    private fun selfGrant() {
        host.toast("Granting permissions...")
        host.scope.launch {
            val results = host.bridge.selfGrant()
            val ok = results.count { it.second.ok }
            val lines = results.joinToString("\n") { (cmd, r) ->
                (if (r.ok) "OK    " else "FAIL  ") + cmd.removePrefix("pm grant ${ctx.packageName} ").removePrefix("appops set ${ctx.packageName} ") +
                    (if (r.ok) "" else "\n      " + r.message.take(90))
            }
            HubDialog.info(host, "Permissions: $ok of ${results.size} granted", lines, mono = true)
            render(host.bridge.state.value)
        }
    }

    // ── checklist ──

    private fun requirements(st: BridgeState): List<Req> {
        val shell = st.provider != ShellProvider.NONE
        val list = ArrayList<Req>()

        list += Req(
            "Shizuku",
            when {
                st.shizukuGranted -> "Running and allowed. Unlocks game mode, downscaler, force-stop, compile, DNS and network policy."
                st.shizukuRunning -> "Running, but Hyper Engine is not allowed yet."
                st.shizukuInstalled -> "Installed but not started. Start it with Wireless debugging or root."
                else -> "Not installed. Needed for the privileged features."
            },
            st.shizukuGranted, false,
            when {
                st.shizukuGranted -> null
                st.shizukuRunning -> "Allow"
                st.shizukuInstalled -> "Open"
                else -> "Get"
            }
        ) {
            if (st.shizukuRunning) {
                if (!host.bridge.requestShizukuPermission()) host.toast("Shizuku is not running", true)
            } else {
                HubIntents.shizuku(host)
            }
        }

        if (!st.shizukuGranted) {
            list += Req(
                "Root (su)", "Alternative to Shizuku on rooted phones.", st.rootGranted, false,
                if (st.rootGranted) null else "Try"
            ) {
                host.scope.launch {
                    host.toast(if (host.bridge.probeRoot()) "Root granted" else "Root is not available or was denied", true)
                }
            }
        }

        list += Req(
            "Display over other apps", "Draws the sidebar, FPS pill, crosshair and filters on top of games.",
            st.overlay, true, if (st.overlay) null else "Allow"
        ) { HubIntents.overlay(host) }

        list += Req(
            "Game detection",
            if (st.usageAccess) "Usage Access is on: detects games and shows play time."
            else if (shell) "Detecting through the privileged shell. Usage Access also adds play time."
            else "Needs Usage Access (or Shizuku) to see which game is on screen.",
            st.usageAccess || shell, true, if (st.usageAccess) null else "Allow"
        ) { HubIntents.usageAccess(host) }

        list += Req(
            "Modify system settings", "Lets refresh rate, animation scales and brightness be changed without a shell.",
            st.writeSystemSettings || st.writeSecureSettings || shell, false,
            if (st.writeSystemSettings) null else "Allow"
        ) { HubIntents.writeSettings(host) }

        list += Req(
            "Secure settings grant",
            if (st.writeSecureSettings) "Granted: DNS, accessibility auto-enable and more keep working without Shizuku."
            else "One-time grant. With Shizuku running, use the Self-grant button above, or run the ADB commands from a PC.",
            st.writeSecureSettings, false,
            if (st.writeSecureSettings) null else if (shell) "Grant" else "Copy ADB"
        ) {
            if (shell) selfGrant() else copyAdb()
        }

        val a11y = accessibilityEnabled()
        list += Req(
            "Auto tapper (Accessibility)",
            if (TouchMacroService.connected.value) "Connected. The macro pill can inject taps."
            else if (a11y) "Enabled, waiting for Android to connect it."
            else "Needed only for the auto tapper. It never reads what is on screen.",
            TouchMacroService.connected.value || a11y, false,
            if (TouchMacroService.connected.value || a11y) null else "Enable"
        ) { enableAccessibility() }

        val heal = HyperApp.instance.selfHealer
        val hs = heal.state.value
        list += Req(
            "Keep running after closing the app",
            if (heal.autoHeal) {
                (if (hs.summary.isBlank()) "On: the game watcher and auto tapper stay alive after you close the app, and are re-enabled when the system drops them." else hs.summary) +
                    if (shell || st.writeSecureSettings) "" else " Needs Shizuku, root or the secure-settings grant to re-enable the auto tapper."
            } else "Off (default). Closing the app from Recents stops the game watcher and the HUD. Turn on only if you want them to keep running.",
            heal.autoHeal && hs.lastOk, false,
            if (heal.autoHeal) "Turn off" else "Turn on",
            alwaysAction = true
        ) {
            if (heal.autoHeal) {
                heal.setAutoHeal(false)
            } else {
                heal.setAutoHeal(true)
                heal.heal("setup switch", force = true)
            }
            refresh()
        }

        val listener = notificationListenerEnabled()
        list += Req(
            "Notification ticker",
            if (DanmakuNotificationService.connected.value) "Connected. Notifications can scroll across the game."
            else if (listener) "Enabled, waiting for Android to connect it."
            else "Needed only for the Danmaku bullet ticker.",
            DanmakuNotificationService.connected.value || listener, false,
            if (DanmakuNotificationService.connected.value || listener) null else "Enable"
        ) { enableListener() }

        if (Build.VERSION.SDK_INT >= 33) {
            val granted = ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            list += Req(
                "Notifications", "Shows the game-watcher status notification.", granted, false,
                if (granted) null else "Allow"
            ) { ctx.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIFICATIONS) }
        }

        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        val unrestricted = runCatching { pm.isIgnoringBatteryOptimizations(ctx.packageName) }.getOrDefault(false)
        list += Req(
            "Battery: unrestricted", "Stops the system from killing the game watcher while you play.",
            unrestricted, false, if (unrestricted) null else "Allow"
        ) { HubIntents.batteryOptimization(host) }

        return list
    }

    private fun row(r: Req): View {
        val row = Ui.hbox(ctx)
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(host.dp(10), host.dp(8), host.dp(10), host.dp(8))
        row.background = Ui.rounded(theme.tile, Ui.tileRadius(ctx, theme))
        val markRes = if (r.ok) R.drawable.ic_check else if (r.required) R.drawable.ic_alert else R.drawable.ic_dash
        val markTint = if (r.ok) theme.good else if (r.required) theme.hot else theme.textSecondary
        val mark = VIcon.view(ctx, markRes, 16, markTint)
        row.addView(mark, Ui.lp(host.dp(18), host.dp(18), 0f, 0, 0, host.dp(4), 0))
        val col = Ui.vbox(ctx)
        col.addView(Ui.label(ctx, r.title, 12f, theme.textPrimary, true))
        col.addView(Ui.label(ctx, r.why, 10f, theme.textSecondary).apply { setLineSpacing(0f, 1.1f) }, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(2), 0, 0))
        row.addView(col, Ui.lp(0, Ui.WRAP, 1f))
        if ((!r.ok || r.alwaysAction) && r.actionLabel != null && r.action != null) {
            val b = Ui.button(ctx, theme, r.actionLabel, false) { r.action.invoke() }
            b.textSize = 11f
            b.setPadding(host.dp(10), host.dp(6), host.dp(10), host.dp(6))
            row.addView(b, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, host.dp(8), 0, 0, 0))
        }
        return row
    }

    // ── accessibility / notification listener ──

    private fun accessibilityEnabled(): Boolean {
        val cn = ComponentName(ctx, TouchMacroService::class.java)
        val s = Settings.Secure.getString(ctx.contentResolver, "enabled_accessibility_services").orEmpty()
        return s.split(':').any { it.equals(cn.flattenToString(), true) || it.equals(cn.flattenToShortString(), true) }
    }

    private fun notificationListenerEnabled(): Boolean {
        val cn = ComponentName(ctx, DanmakuNotificationService::class.java)
        val s = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners").orEmpty()
        return s.split(':').any { it.equals(cn.flattenToString(), true) || it.equals(cn.flattenToShortString(), true) }
    }

    private fun enableAccessibility() {
        if (host.bridge.state.value.writeSecureSettings || host.bridge.hasShell()) {
            host.scope.launch {
                val steps = HyperApp.instance.selfHealer.enableNow("setup button")
                val bad = steps.firstOrNull { !it.ok }
                if (bad == null) host.toast("Auto tapper enabled") else {
                    host.toast("Could not enable it automatically: ${bad.detail.take(80)}", true)
                    HubIntents.accessibility(host)
                }
                refresh()
            }
        } else {
            host.toast("Find \"HyperEngine Touch Macro\" in the list and turn it on.", true)
            HubIntents.accessibility(host)
        }
    }

    private fun enableListener() {
        if (host.bridge.state.value.writeSecureSettings || host.bridge.hasShell()) {
            host.scope.launch {
                val r = host.bridge.enableNotificationListener(ComponentName(ctx, DanmakuNotificationService::class.java))
                if (r.ok) host.toast("Notification ticker enabled") else {
                    host.toast("Could not enable it automatically: ${r.message.take(80)}", true)
                    HubIntents.notificationListener(host)
                }
                refresh()
            }
        } else {
            host.toast("Find \"HyperEngine Danmaku Ticker\" in the list and turn it on.", true)
            HubIntents.notificationListener(host)
        }
    }

    private fun copyAdb() {
        val text = host.bridge.adbCommands().joinToString("\n")
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("adb", text))
        HubDialog.info(host, "ADB commands copied", "Run these once from a PC with USB debugging on:\n\n$text", mono = true)
    }

    companion object {
        const val REQ_NOTIFICATIONS = 7001
    }
}
