package com.hyperengine.gameturbo.ui

import android.content.Context
import android.graphics.drawable.Animatable
import android.graphics.drawable.Drawable
import android.graphics.drawable.DrawableWrapper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.annotation.DrawableRes
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce

/**
 * Entry point for the custom vector icon pack in res/drawable (ic_*.xml, avd_*.xml).
 *
 * Two families of icon exist:
 *  - Feature icons (ic_wild_boost_turbine, ic_low_latency, ...) carry their own neon gradients. Show them
 *    as they are; pass a [tint] only for a disabled / locked look.
 *  - Utility icons (ic_plus, ic_close, ic_check, ic_chevron_*, ...) are flat white on purpose, so a [tint]
 *    recolours them from the HUD theme.
 *
 * Everything here runs on the main thread.
 */
object VIcon {

    /** A fresh, independently tintable copy of the drawable. */
    fun drawable(ctx: Context, @DrawableRes res: Int, tint: Int? = null): Drawable {
        val d = requireNotNull(ctx.getDrawable(res)) { "missing drawable $res" }.mutate()
        if (tint != null) d.setTint(tint)
        return d
    }

    /** Same, with its bounds set to a square of [sizeDp] so it can be used as a compound drawable. */
    fun sized(ctx: Context, @DrawableRes res: Int, sizeDp: Int, tint: Int? = null): Drawable {
        val d = drawable(ctx, res, tint)
        val px = Ui.dp(ctx, sizeDp)
        d.setBounds(0, 0, px, px)
        return d
    }

    /** A square ImageView showing the icon. Not clickable by itself. */
    fun view(ctx: Context, @DrawableRes res: Int, sizeDp: Int, tint: Int? = null): ImageView =
        ImageView(ctx).apply {
            setImageDrawable(drawable(ctx, res, tint))
            scaleType = ImageView.ScaleType.FIT_CENTER
            minimumWidth = Ui.dp(ctx, sizeDp)
            minimumHeight = Ui.dp(ctx, sizeDp)
        }

    /**
     * Puts an icon on a TextView, replacing a text glyph.
     *  - Empty text: an icon-only face. The icon is drawn as the view's foreground, centred, so it stays
     *    centred whatever width the layout gives the view (compound drawables would hug the left edge of
     *    a weighted-width view such as a calculator key).
     *  - Non-empty text: the icon sits before the label ([atStart]) or after it, as a compound drawable.
     */
    fun setOnText(
        tv: TextView,
        @DrawableRes res: Int,
        sizeDp: Int,
        tint: Int? = null,
        atStart: Boolean = false,
        gapDp: Int = 6
    ) {
        val ctx = tv.context
        if (tv.text.isNullOrEmpty()) {
            tv.foreground = FixedSize(drawable(ctx, res, tint), Ui.dp(ctx, sizeDp))
            tv.foregroundGravity = Gravity.CENTER
            return
        }
        val d = sized(ctx, res, sizeDp, tint)
        if (atStart) tv.setCompoundDrawablesRelative(d, null, null, null)
        else tv.setCompoundDrawablesRelative(null, null, d, null)
        tv.compoundDrawablePadding = Ui.dp(ctx, gapDp)
    }

    /** Gives a drawable a fixed intrinsic size so View.foregroundGravity can centre it at that size. */
    private class FixedSize(inner: Drawable, private val px: Int) : DrawableWrapper(inner) {
        override fun getIntrinsicWidth(): Int = px
        override fun getIntrinsicHeight(): Int = px
    }

    /**
     * A themed, tappable icon button (rounded tile, stroke, spring press). [res] may be a plain vector or
     * an animated one; animated icons start playing immediately.
     */
    fun button(
        ctx: Context,
        theme: HudTheme,
        @DrawableRes res: Int,
        sizeDp: Int = 18,
        tint: Int? = null,
        onClick: () -> Unit
    ): ImageView {
        val v = view(ctx, res, sizeDp, tint)
        val pad = Ui.dp(ctx, 9)
        v.setPadding(pad, pad, pad, pad)
        v.background = Ui.rounded(theme.tile, Ui.tileRadius(ctx, theme), theme.stroke, Ui.dp(ctx, 1))
        v.isClickable = true
        v.setOnClickListener { onClick() }
        pressSpring(v)
        start(v.drawable)
        return v
    }

    // ---- animated vector drawables ---------------------------------------------------------

    /** Starts an AnimatedVectorDrawable (no-op for a plain vector). */
    fun start(d: Drawable?) {
        (d as? Animatable)?.let { if (!it.isRunning) it.start() }
    }

    fun stop(d: Drawable?) {
        (d as? Animatable)?.let { if (it.isRunning) it.stop() }
    }

    // ---- press feedback ----------------------------------------------------------------------

    /**
     * Spring press feedback: the view squashes to [pressedScale] on touch-down and rebounds with a small
     * overshoot on release. The touch listener never consumes the event, so clicks still fire.
     */
    fun pressSpring(v: View, pressedScale: Float = 0.84f) {
        fun spring(prop: DynamicAnimation.ViewProperty): SpringAnimation {
            val force = SpringForce()
            force.setDampingRatio(SpringForce.DAMPING_RATIO_MEDIUM_BOUNCY)
            force.setStiffness(SpringForce.STIFFNESS_MEDIUM)
            val anim = SpringAnimation(v, prop)
            anim.setSpring(force)
            return anim
        }
        val sx = spring(DynamicAnimation.SCALE_X)
        val sy = spring(DynamicAnimation.SCALE_Y)
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx.animateToFinalPosition(pressedScale)
                    sy.animateToFinalPosition(pressedScale)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    sx.animateToFinalPosition(1f)
                    sy.animateToFinalPosition(1f)
                }
            }
            false
        }
    }
}
