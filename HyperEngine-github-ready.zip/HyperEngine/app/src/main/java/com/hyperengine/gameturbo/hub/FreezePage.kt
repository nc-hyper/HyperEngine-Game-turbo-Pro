package com.hyperengine.gameturbo.hub

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.provider.Settings
import android.telecom.TelecomManager
import android.provider.Telephony
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.hyperengine.gameturbo.R
import com.hyperengine.gameturbo.core.FreezeReport
import com.hyperengine.gameturbo.core.Validators
import com.hyperengine.gameturbo.ui.HudThemes
import com.hyperengine.gameturbo.ui.Ui
import com.hyperengine.gameturbo.ui.VIcon
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

/**
 * Global Freeze List manager (Brevent style).
 *
 * The list is stored in GlobalSettings.freezeList and is exactly what the optimization engine freezes
 * when a game starts: with a shell (Shizuku or root) each app gets RUN_ANY_IN_BACKGROUND = ignore and
 * am force-stop, then RUN_ANY_IN_BACKGROUND = allow again when the game session ends. Without a shell
 * the engine can only call killBackgroundProcesses once.
 *
 * "Freeze now" runs the same code path as a game launch and shows the real measured RAM difference.
 */
class FreezePage(private val host: HubHost) : HubPage {

    override val id = "freeze"
    override val title = "Freeze List"
    override val glyph = ""

    private val ctx = host.activity
    private val theme = host.theme
    private val repo = host.repo
    private val pm: PackageManager = ctx.packageManager

    private lateinit var countLine: TextView
    private lateinit var reportLine: TextView
    private lateinit var listBox: LinearLayout
    private lateinit var search: android.widget.EditText

    private var query = ""
    private var busy = false
    private var lastList: List<String>? = null

    // ── view ──

    override fun createView(): View {
        val scroll = ScrollView(ctx)
        scroll.isFillViewport = false
        val root = Ui.vbox(ctx)
        root.setPadding(0, 0, 0, host.dp(12))
        scroll.addView(root, android.widget.FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        // intro + actions
        val card = Forms.card(host)
        card.addView(Ui.label(ctx, "Auto-freeze on game launch", 15f, theme.textPrimary, true))
        countLine = Ui.label(ctx, "", 12f, theme.accent, true)
        card.addRow(host, countLine, 4)
        card.addRow(
            host,
            Forms.note(
                host,
                "Apps on this list are stopped and kept from running in the background while a game is active, " +
                    "then allowed again afterwards. With Shizuku or root every app gets RUN_ANY_IN_BACKGROUND set to " +
                    "ignore plus a force-stop. Without them Android only allows killing the app's background processes once."
            ),
            4
        )
        reportLine = Ui.label(ctx, "", 11f, theme.textPrimary).apply { setLineSpacing(0f, 1.15f) }
        card.addRow(host, reportLine, 6)

        val actions = Ui.hbox(ctx)
        actions.addView(Ui.button(ctx, theme, "Freeze now", true) { freezeNow() }, Ui.lp(0, Ui.WRAP, 1f))
        actions.addView(Ui.button(ctx, theme, "Unfreeze now", false) { unfreezeNow() }, Ui.lp(0, Ui.WRAP, 1f, host.dp(8), 0, 0, 0))
        card.addRow(host, actions, 10)
        root.addView(card, Ui.lp(Ui.MATCH, Ui.WRAP))

        // search + add
        val row = Ui.hbox(ctx)
        row.gravity = Gravity.CENTER_VERTICAL
        search = hubInput(host, "Search the list")
        search.onTextChanged {
            query = it
            fill()
        }
        row.addView(search, Ui.lp(0, Ui.WRAP, 1f))
        row.addView(Ui.button(ctx, theme, "Add", true) { showPicker(suggestions = false) }.also { VIcon.setOnText(it, R.drawable.ic_plus, 14, HudThemes.onAccent(theme.accent), atStart = true) }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, host.dp(8), 0, 0, 0))
        root.addRow(host, row, 12)
        root.addRow(host, Ui.button(ctx, theme, "Suggest heavy apps (social, news, video, shopping)", false) { showPicker(suggestions = true) }, 8)

        listBox = Ui.vbox(ctx)
        root.addRow(host, listBox, 8)

        host.scope.launch {
            repo.global.collect { g ->
                if (g.freezeList != lastList) fill()
            }
        }
        host.scope.launch { host.engine.status.collect { renderReport(it.lastFreeze) } }
        fill()
        return scroll
    }

    override fun onShow() = fill()

    // ── list ──

    private fun labelOf(pkg: String): String = try {
        @Suppress("DEPRECATION")
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString().ifBlank { pkg }
    } catch (_: Throwable) {
        pkg
    }

    private fun installed(pkg: String): Boolean = try {
        @Suppress("DEPRECATION")
        pm.getApplicationInfo(pkg, 0)
        true
    } catch (_: Throwable) {
        false
    }

    /** Same set the engine refuses to freeze. Shown in the list so nobody is surprised. */
    private fun protectedNow(): Set<String> {
        val set = hashSetOf(
            ctx.packageName, "android", "com.android.systemui", "com.android.phone",
            "com.android.server.telecom", "com.android.providers.telephony",
            "com.android.providers.settings", "moe.shizuku.privileged.api"
        )
        runCatching {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            pm.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName?.let { set += it }
        }
        runCatching {
            Settings.Secure.getString(ctx.contentResolver, "default_input_method")
                ?.substringBefore('/')?.takeIf { it.isNotBlank() }?.let { set += it }
        }
        runCatching {
            (ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).defaultDialerPackage?.let { set += it }
        }
        runCatching { Telephony.Sms.getDefaultSmsPackage(ctx)?.let { set += it } }
        return set
    }

    private fun fill() {
        if (!this::listBox.isInitialized) return
        val list = repo.global.value.freezeList
        lastList = list
        countLine.text = when (list.size) {
            0 -> "No apps on the list"
            1 -> "1 app on the list"
            else -> "${list.size} apps on the list"
        }
        listBox.removeAllViews()
        if (list.isEmpty()) {
            listBox.addView(
                Forms.note(host, "Nothing will be frozen yet. Tap Add to pick apps, or Suggest heavy apps for a quick start."),
                Ui.lp(Ui.MATCH, Ui.WRAP)
            )
            return
        }
        val q = query.trim().lowercase(Locale.getDefault())
        val protectedSet = protectedNow()
        val rows = list.map { it to labelOf(it) }
            .filter { q.isEmpty() || it.first.lowercase(Locale.US).contains(q) || it.second.lowercase(Locale.getDefault()).contains(q) }
            .sortedBy { it.second.lowercase(Locale.getDefault()) }
        if (rows.isEmpty()) {
            listBox.addView(Forms.note(host, "No app in the list matches \"${query.trim()}\"."), Ui.lp(Ui.MATCH, Ui.WRAP))
            return
        }
        for ((pkg, label) in rows) {
            val row = Ui.hbox(ctx)
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(host.dp(8), host.dp(8), host.dp(8), host.dp(8))
            row.background = Ui.rounded(theme.tile, Ui.tileRadius(ctx, theme), theme.stroke, host.dp(1))

            val icon = ImageView(ctx)
            GameIcons.load(ctx, pkg, label, host.dp(38), icon, HudThemes.withAlpha(theme.accent, 0x99))
            row.addView(icon, Ui.lp(host.dp(38), host.dp(38)))

            val col = Ui.vbox(ctx)
            col.addView(Ui.label(ctx, label, 13f, theme.textPrimary, true).apply { maxLines = 1 })
            col.addView(Ui.label(ctx, pkg, 10f, theme.textSecondary).apply { maxLines = 1 })
            val tag = when {
                !installed(pkg) -> "Not installed, skipped" to theme.warn
                pkg in protectedSet -> "Protected, never frozen" to theme.warn
                else -> null
            }
            if (tag != null) col.addView(Ui.label(ctx, tag.first, 10f, tag.second, true).apply { setPadding(0, host.dp(2), 0, 0) })
            row.addView(col, Ui.lp(0, Ui.WRAP, 1f, host.dp(10), 0, host.dp(8), 0))

            row.addView(Forms.smallButton(host, "Remove", danger = true) {
                repo.removeFromFreezeList(pkg)
                host.toast("$label removed from the list")
            })
            listBox.addView(row, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(5), 0, 0))
        }
    }

    private fun renderReport(r: FreezeReport?) {
        if (!this::reportLine.isInitialized) return
        if (r == null) {
            reportLine.text = "No freeze has run in this session yet."
            reportLine.setTextColor(theme.textSecondary)
            return
        }
        reportLine.setTextColor(theme.textPrimary)
        reportLine.text = "Last run: ${r.frozen} of ${r.requested} frozen, free RAM ${r.availBeforeMb} to ${r.availAfterMb} MB " +
            "(${signed(r.reclaimedMb)} MB)" + if (r.usedShell) "" else ", background processes killed only"
    }

    private fun signed(v: Long) = if (v >= 0) "+$v" else v.toString()

    // ── freeze / unfreeze ──

    private fun freezeNow() {
        if (busy) return
        if (repo.global.value.freezeList.isEmpty()) {
            host.toast("The freeze list is empty")
            return
        }
        HubDialog.confirm(
            host, "Freeze the list now?",
            "Every app on the list is stopped and blocked from the background until you tap Unfreeze now, " +
                "or until the next game session ends and the engine restores the phone.",
            "Freeze"
        ) {
            busy = true
            host.scope.launch {
                try {
                    val game = host.engine.status.value.activeGame.orEmpty()
                    showReport(host.engine.freezeNow(game))
                } catch (t: Throwable) {
                    host.toast("Freeze failed: ${t.message ?: t.javaClass.simpleName}", true)
                } finally {
                    busy = false
                }
            }
        }
    }

    private fun showReport(r: FreezeReport) {
        val lines = buildString {
            append("Requested: ${r.requested}\n")
            append("Frozen: ${r.frozen}\n")
            if (r.skippedAlreadyRestricted > 0) append("Already restricted by you: ${r.skippedAlreadyRestricted}\n")
            if (r.skippedProtected > 0) append("Protected, skipped: ${r.skippedProtected}\n")
            if (r.notInstalled > 0) append("Not installed: ${r.notInstalled}\n")
            if (r.failed > 0) append("Failed: ${r.failed}\n")
            append("\nFree RAM before: ${r.availBeforeMb} MB\n")
            append("Free RAM after: ${r.availAfterMb} MB\n")
            append("Difference: ${signed(r.reclaimedMb)} MB\n")
            append("\nMethod: ")
            append(if (r.usedShell) "appops RUN_ANY_IN_BACKGROUND ignore, force-stop, kill-all" else "killBackgroundProcesses (no shell available)")
        }
        val d = HubDialog(host, "Freeze result")
        d.text(lines, theme.textPrimary, 12f, mono = true)
        if (r.failed > 0 && !r.usedShell) {
            d.text("Connect Shizuku or root to freeze apps properly and keep them frozen.", theme.warn, 11f)
        }
        d.button("Keep frozen")
        d.button("Unfreeze now", filled = true) { unfreezeNow() }
        d.show()
    }

    private fun unfreezeNow() {
        if (busy) return
        if (!host.engine.hasPendingRestore()) {
            host.toast("Nothing is frozen by the engine right now")
            return
        }
        HubDialog.confirm(
            host, "Unfreeze now?",
            "This restores everything the engine changed, not only the frozen apps: game mode, refresh rate, DNS, animation scales and background data.",
            "Restore everything"
        ) {
            busy = true
            host.scope.launch {
                try {
                    val rep = host.engine.restoreAll("Unfreeze now in the Freeze List")
                    host.toast(
                        if (rep.complete) "Apps unfrozen, phone settings restored"
                        else "Restore incomplete: ${rep.steps.firstOrNull { !it.ok }?.detail?.take(80) ?: "see developer console"}",
                        !rep.complete
                    )
                } finally {
                    busy = false
                }
            }
        }
    }

    // ── add apps ──

    private class Candidate(val pkg: String, val label: String, val system: Boolean)

    @Suppress("DEPRECATION")
    private suspend fun scan(includeSystem: Boolean, onlyHeavy: Boolean, exclude: Set<String>): List<Candidate> =
        withContext(Dispatchers.Default) {
            val out = ArrayList<Candidate>()
            val protectedSet = protectedNow()
            for (ai in runCatching { pm.getInstalledApplications(0) }.getOrDefault(emptyList())) {
                val pkg = ai.packageName
                if (pkg in exclude || pkg in protectedSet || !Validators.PACKAGE.matches(pkg)) continue
                val system = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 && (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
                if (system && !includeSystem) continue
                if (pm.getLaunchIntentForPackage(pkg) == null) continue
                if (isGame(ai)) continue                    // games are what we are protecting, not freezing
                if (onlyHeavy && !isHeavy(ai)) continue
                val label = runCatching { pm.getApplicationLabel(ai).toString() }.getOrDefault(pkg).ifBlank { pkg }
                out += Candidate(pkg, label, system)
            }
            out.sortedBy { it.label.lowercase(Locale.getDefault()) }
        }

    @Suppress("DEPRECATION")
    private fun isGame(ai: ApplicationInfo): Boolean =
        ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0

    @Suppress("DEPRECATION")
    private fun isHeavy(ai: ApplicationInfo): Boolean {
        when (ai.category) {
            ApplicationInfo.CATEGORY_SOCIAL, ApplicationInfo.CATEGORY_NEWS, ApplicationInfo.CATEGORY_VIDEO -> return true
        }
        val p = ai.packageName
        return HEAVY_PREFIXES.any { p == it || p.startsWith("$it.") }
    }

    private fun showPicker(suggestions: Boolean) {
        val d = HubDialog(host, if (suggestions) "Suggested heavy apps" else "Add apps to freeze")
        val box = hubInput(host, "Search installed apps")
        val list = Ui.vbox(ctx)
        val selected = LinkedHashSet<String>()
        val rowViews = HashMap<String, View>()
        var includeSystem = false
        var apps: List<Candidate> = emptyList()
        var loaded = false
        val selectedLine = Ui.label(ctx, "Tap apps to select them", 11f, theme.textSecondary, true)

        fun restyle(pkg: String) {
            val on = pkg in selected
            rowViews[pkg]?.background = Ui.rounded(
                if (on) HudThemes.withAlpha(theme.accent, 0x33) else theme.tile, Ui.tileRadius(ctx, theme),
                if (on) theme.accent else theme.stroke, host.dp(if (on) 2 else 1)
            )
        }

        fun fillList() {
            list.removeAllViews()
            rowViews.clear()
            if (!loaded) {
                list.addView(Ui.label(ctx, "Loading apps...", 12f, theme.textSecondary))
                return
            }
            val q = box.text.toString().trim().lowercase(Locale.getDefault())
            val matches = if (q.isEmpty()) apps else apps.filter {
                it.label.lowercase(Locale.getDefault()).contains(q) || it.pkg.lowercase(Locale.US).contains(q)
            }
            if (matches.isEmpty()) {
                list.addView(
                    Ui.label(
                        ctx,
                        if (suggestions && q.isEmpty()) "No heavy apps found. Use Add to pick any app." else "No app matches.",
                        12f, theme.textSecondary
                    )
                )
                return
            }
            for (a in matches.take(MAX_PICKER_ROWS)) {
                val row = Ui.hbox(ctx)
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(host.dp(8), host.dp(8), host.dp(8), host.dp(8))
                val icon = ImageView(ctx)
                GameIcons.load(ctx, a.pkg, a.label, host.dp(36), icon, HudThemes.withAlpha(theme.accent, 0x99))
                row.addView(icon, Ui.lp(host.dp(36), host.dp(36)))
                val col = Ui.vbox(ctx)
                col.addView(Ui.label(ctx, a.label + if (a.system) "  (system)" else "", 13f, theme.textPrimary, true).apply { maxLines = 1 })
                col.addView(Ui.label(ctx, a.pkg, 10f, theme.textSecondary).apply { maxLines = 1 })
                row.addView(col, Ui.lp(0, Ui.WRAP, 1f, host.dp(10), 0, 0, 0))
                rowViews[a.pkg] = row
                restyle(a.pkg)
                row.setOnClickListener {
                    if (!selected.add(a.pkg)) selected.remove(a.pkg)
                    restyle(a.pkg)
                    selectedLine.text = if (selected.isEmpty()) "Tap apps to select them" else "${selected.size} selected"
                }
                list.addView(row, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(5), 0, 0))
            }
            if (matches.size > MAX_PICKER_ROWS) {
                list.addView(
                    Ui.label(ctx, "Showing the first $MAX_PICKER_ROWS of ${matches.size}. Type to narrow it down.", 11f, theme.textSecondary)
                        .apply { setPadding(0, host.dp(8), 0, 0) }
                )
            }
        }

        fun load() {
            loaded = false
            fillList()
            host.scope.launch {
                apps = scan(includeSystem, suggestions, repo.global.value.freezeList.toSet())
                loaded = true
                if (d.isShowing) fillList()
            }
        }

        box.onTextChanged { fillList() }
        d.add(box)
        d.add(
            Forms.switchRow(
                host, "Include system apps",
                "Pre-installed apps such as vendor bloatware. Core phone, launcher, keyboard and messaging apps are always protected.",
                false
            ) { on ->
                includeSystem = on
                load()
            },
            6
        )
        d.add(selectedLine, 8)
        d.add(list, 4)
        d.button("Cancel")
        d.button("Add selected", filled = true) {
            val picked = selected.toList()
            if (picked.isEmpty()) {
                host.toast("Nothing selected")
            } else {
                repo.updateGlobal { g -> g.copy(freezeList = (g.freezeList + picked).distinct()) }
                host.toast("${picked.size} app(s) added to the freeze list")
            }
        }
        d.show()
        load()
    }

    companion object {
        private const val MAX_PICKER_ROWS = 80

        /** Package roots of popular background-heavy apps that Android does not categorise as social or news. */
        private val HEAVY_PREFIXES = listOf(
            "com.facebook.katana", "com.facebook.lite", "com.facebook.orca", "com.instagram.android",
            "com.twitter.android", "com.snapchat.android", "com.zhiliaoapp.musically", "com.ss.android.ugc.trill",
            "com.reddit.frontpage", "com.pinterest", "com.linkedin.android",
            "com.amazon.mShop.android.shopping", "in.amazon.mShop.android.shopping", "com.flipkart.android",
            "com.shopee", "com.lazada.android", "com.alibaba.aliexpresshd", "com.ebay.mobile", "com.einnovation.temu",
            "com.zhiliaoapp", "com.google.android.apps.youtube.music", "com.netflix.mediaclient"
        )
    }
}
