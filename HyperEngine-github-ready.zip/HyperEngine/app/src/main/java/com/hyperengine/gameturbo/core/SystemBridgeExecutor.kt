package com.hyperengine.gameturbo.core

import android.Manifest
import android.app.ActivityManager
import android.app.AppOpsManager
import android.content.ComponentName
import android.content.ContentResolver
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Resources
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.PowerManager
import android.widget.Toast
import com.hyperengine.gameturbo.service.DanmakuNotificationService
import com.hyperengine.gameturbo.service.TouchMacroService
import android.net.ConnectivityManager
import android.provider.Settings
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.runInterruptible
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import rikka.shizuku.Shizuku
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.lang.reflect.InvocationTargetException
import java.util.concurrent.ConcurrentHashMap
import java.util.Locale

// ───────────────────────────── Types ─────────────────────────────

enum class ExecMode(val label: String) {
    SHIZUKU("Shizuku (shell) - full power"),
    ROOT("Root (su) - full power"),
    SECURE_GRANT("ADB-granted permissions - settings only"),
    STANDARD("Standard APIs - limited")
}

enum class ShellProvider { SHIZUKU, ROOT, NONE }

enum class Ns(val cmd: String) { SYSTEM("system"), SECURE("secure"), GLOBAL("global") }

enum class GameModeLevel(val cmd: String) {
    BATTERY("battery"), STANDARD("standard"), PERFORMANCE("performance")
}

enum class CompileMode(val cmd: String) { FAST("speed-profile"), FULL("speed") }

data class CommandResult(
    val ok: Boolean,
    val stdout: String = "",
    val stderr: String = "",
    val exitCode: Int = if (ok) 0 else -1,
    val via: String = "",
    /** Wall-clock time the process took (0 for results that never spawned one). */
    val ms: Long = 0L
) {
    /** Human readable outcome (never fabricated: comes from the real command output). */
    val message: String
        get() = if (ok) stdout.ifBlank { "OK" } else stderr.ifBlank { stdout }.ifBlank { "exit $exitCode" }
}

data class BridgeState(
    val shizukuInstalled: Boolean = false,
    val shizukuRunning: Boolean = false,
    val shizukuGranted: Boolean = false,
    val rootGranted: Boolean = false,
    val writeSecureSettings: Boolean = false,
    val writeSystemSettings: Boolean = false,
    val usageAccess: Boolean = false,
    val overlay: Boolean = false,
    // Added in Phase 1 completion (default-valued, used by the diagnostics screen)
    val shizukuVersion: Int = -1,
    val shizukuUid: Int = -1,
    val inputInjection: Boolean = false,      // IInputManager binder is bound and alive
    val accessibilityEnabled: Boolean = false,
    val accessibilityConnected: Boolean = false,
    val notificationListenerEnabled: Boolean = false,
    val notificationListenerConnected: Boolean = false,
    val readPhoneState: Boolean = false,
    val answerCalls: Boolean = false,
    val recordAudio: Boolean = false,
    val readContacts: Boolean = false,        // optional: caller names on the call banner
    val postNotifications: Boolean = true
) {
    val phoneCall: Boolean get() = readPhoneState && answerCalls

    val provider: ShellProvider
        get() = when {
            shizukuGranted -> ShellProvider.SHIZUKU
            rootGranted -> ShellProvider.ROOT
            else -> ShellProvider.NONE
        }
    val mode: ExecMode
        get() = when {
            provider == ShellProvider.SHIZUKU -> ExecMode.SHIZUKU
            provider == ShellProvider.ROOT -> ExecMode.ROOT
            writeSecureSettings -> ExecMode.SECURE_GRANT
            else -> ExecMode.STANDARD
        }
}

/** Input validation: every value that reaches a shell string must pass one of these. */
object Validators {
    val PACKAGE = Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$")
    val HOST = Regex("^[A-Za-z0-9]([A-Za-z0-9.-]{0,251}[A-Za-z0-9])?$")
    val SETTING_KEY = Regex("^[A-Za-z0-9_.:-]+$")
    val SETTING_VALUE = Regex("^[A-Za-z0-9_.:,/=+@-]+\$")
    val APPOP = Regex("^[A-Z][A-Z0-9_]*$")
    val APPOP_MODES = setOf("allow", "ignore", "deny", "default", "foreground")
    val PERMISSION = Regex("^android\\.permission\\.[A-Z][A-Z0-9_]*$")
    val PROP_KEY = Regex("^[A-Za-z][A-Za-z0-9_.-]{0,95}$")
    val NAMESPACE = Regex("^[a-z][a-z0-9_]{0,63}$")

    /** One token of a typed `cmd ...` line in a [BatchBuilder]: no spaces, quotes, `;`, `|`, `&`, `$` or redirection. */
    val ARG = Regex("^[A-Za-z0-9_.:,/=+@-]+$")
}

// ───────────────────────── The executor ─────────────────────────

/**
 * Dual-mode execution engine.
 *
 * Tier 1: Shizuku (shell uid) -> every `cmd`, `am`, `pm`, `settings` command works.
 * Tier 2: Root (su)           -> same as Tier 1.
 * Tier 3: Permissions granted once over ADB (WRITE_SECURE_SETTINGS, DUMP, ...) -> all `settings put`
 *         features, accessibility/notification-listener auto-enable and dumpsys work with NO shell.
 * Tier 4: Plain Android APIs -> killBackgroundProcesses, master sync, user-granted WRITE_SETTINGS.
 *
 * Every function returns the REAL result. If the device/ROM rejects a command you get its stderr.
 */
class SystemBridgeExecutor(context: Context) {

    private val ctx: Context = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val cr: ContentResolver get() = ctx.contentResolver

    private val _state = MutableStateFlow(BridgeState())
    val state: StateFlow<BridgeState> = _state.asStateFlow()

    @Volatile
    private var rootOk = false

    private val mainHandler = Handler(Looper.getMainLooper())
    private var lastToastAt = 0L

    /** At most this many short shell processes run at once; a burst of toggles queues instead of spawning a storm. */
    private val shellGate = Semaphore(SHELL_PARALLELISM)

    private val _pending = MutableStateFlow(0)

    /** Number of shell processes currently running or waiting for a slot (drive a spinner from this, never block on it). */
    val pendingShell: StateFlow<Int> = _pending.asStateFlow()

    private val keyedJobs = ConcurrentHashMap<String, Job>()

    /** Cached Shizuku verdict so hasShell() is safe on the UI thread (the raw check is a binder IPC). */
    @Volatile private var shizukuCache = false
    @Volatile private var shizukuCacheAt = 0L

    /**
     * Hardware touch / key injection through the system `input` service (Shizuku binder).
     * Phase 4's auto-touch and shoulder triggers inject through [pointers].
     */
    val input = InputManagerBridge().also { it.onProblem = { msg -> feedback(msg) } }

    /** Synthetic fingers (pointer ids 3..6) on top of [input]. */
    val pointers = SyntheticPointerTable(input)

    private val onBinderReceived = Shizuku.OnBinderReceivedListener {
        shizukuCacheAt = 0L
        input.invalidate()
        refresh()
    }
    private val onBinderDead = Shizuku.OnBinderDeadListener {
        shizukuCacheAt = 0L
        input.invalidate("Shizuku stopped")
        refresh()
    }
    private val onPermissionResult =
        Shizuku.OnRequestPermissionResultListener { _, _ ->
            shizukuCacheAt = 0L
            input.invalidate()
            refresh()
        }

    /** Live user feedback from any thread: a throttled Toast (max one per 1.5 s). */
    fun feedback(message: String) {
        val now = android.os.SystemClock.uptimeMillis()
        if (now - lastToastAt < 1_500L) return
        lastToastAt = now
        mainHandler.post {
            runCatching { Toast.makeText(ctx, message, Toast.LENGTH_SHORT).show() }
        }
    }

    // ── lifecycle ──

    fun start() {
        Shizuku.addBinderReceivedListenerSticky(onBinderReceived)
        Shizuku.addBinderDeadListener(onBinderDead)
        Shizuku.addRequestPermissionResultListener(onPermissionResult)
        refresh()
    }

    fun stop() {
        runCatching { scope.coroutineContext.cancelChildren() }
        keyedJobs.clear()
        runCatching { pointers.releaseAll() }
        input.invalidate()
        runCatching { Shizuku.removeBinderReceivedListener(onBinderReceived) }
        runCatching { Shizuku.removeBinderDeadListener(onBinderDead) }
        runCatching { Shizuku.removeRequestPermissionResultListener(onPermissionResult) }
    }

    fun refresh() {
        scope.launch { refreshNow() }
    }

    fun refreshNow(): BridgeState {
        val running = shizukuRunning()
        val granted = running && shizukuGranted()
        val s = BridgeState(
            shizukuInstalled = shizukuInstalled(),
            shizukuRunning = running,
            shizukuGranted = granted,
            rootGranted = rootOk,
            writeSecureSettings = canWriteSecure(),
            writeSystemSettings = runCatching { Settings.System.canWrite(ctx) }.getOrDefault(false),
            usageAccess = hasUsageAccess(),
            overlay = runCatching { Settings.canDrawOverlays(ctx) }.getOrDefault(false),
            shizukuVersion = if (running) runCatching { Shizuku.getVersion() }.getOrDefault(-1) else -1,
            shizukuUid = if (granted) runCatching { Shizuku.getUid() }.getOrDefault(-1) else -1,
            inputInjection = input.isConnected,
            accessibilityEnabled = isAccessibilityEnabled(),
            accessibilityConnected = TouchMacroService.connected.value,
            notificationListenerEnabled = isNotificationListenerEnabled(),
            notificationListenerConnected = DanmakuNotificationService.connected.value,
            readPhoneState = hasRuntime(Manifest.permission.READ_PHONE_STATE),
            answerCalls = hasRuntime(Manifest.permission.ANSWER_PHONE_CALLS),
            recordAudio = hasRuntime(Manifest.permission.RECORD_AUDIO),
            readContacts = hasRuntime(Manifest.permission.READ_CONTACTS),
            postNotifications = android.os.Build.VERSION.SDK_INT < 33 ||
                hasRuntime(Manifest.permission.POST_NOTIFICATIONS)
        )
        _state.value = s
        return s
    }

    // ── capability checks ──

    private fun shizukuRunning(): Boolean = try { Shizuku.pingBinder() } catch (_: Throwable) { false }

    private fun shizukuGranted(): Boolean {
        val now = SystemClock.elapsedRealtime()
        if (now - shizukuCacheAt < SHIZUKU_CACHE_MS) return shizukuCache
        val v = try {
            shizukuRunning() && !Shizuku.isPreV11() &&
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (_: Throwable) {
            false
        }
        shizukuCache = v
        shizukuCacheAt = now
        return v
    }

    private fun shizukuInstalled(): Boolean = try {
        @Suppress("DEPRECATION")
        ctx.packageManager.getPackageInfo("moe.shizuku.privileged.api", 0)
        true
    } catch (_: Throwable) {
        false
    }

    private fun canWriteSecure(): Boolean =
        ctx.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED

    private fun hasUsageAccess(): Boolean = try {
        val ao = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        ao.checkOpNoThrow("android:get_usage_stats", android.os.Process.myUid(), ctx.packageName) ==
            AppOpsManager.MODE_ALLOWED
    } catch (_: Throwable) {
        false
    }

    private fun hasRuntime(permission: String): Boolean = try {
        ctx.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) {
        false
    }

    private fun componentInSetting(key: String, cn: ComponentName): Boolean = try {
        Settings.Secure.getString(cr, key).orEmpty().split(':').any {
            it.equals(cn.flattenToString(), true) || it.equals(cn.flattenToShortString(), true)
        }
    } catch (_: Throwable) {
        false
    }

    /** True when the user (or a self-grant) switched the auto-tapper accessibility service on. */
    fun isAccessibilityEnabled(): Boolean =
        componentInSetting("enabled_accessibility_services", ComponentName(ctx, TouchMacroService::class.java))

    /** True when the notification listener (danmaku ticker, call banner helper) is switched on. */
    fun isNotificationListenerEnabled(): Boolean =
        componentInSetting("enabled_notification_listeners", ComponentName(ctx, DanmakuNotificationService::class.java))

    fun hasShell(): Boolean = shizukuGranted() || rootOk

    /** Asks Shizuku for permission. Returns false when Shizuku is not running (nothing to ask). */
    fun requestShizukuPermission(requestCode: Int = 1001): Boolean = try {
        if (!shizukuRunning() || Shizuku.isPreV11()) false
        else {
            Shizuku.requestPermission(requestCode)
            true
        }
    } catch (_: Throwable) {
        false
    }

    /** Triggers the su prompt (Magisk/KernelSU) once. Call from a button, not at start-up. */
    suspend fun probeRoot(): Boolean = withContext(Dispatchers.IO) {
        val r = exec("root", 15_000) { Runtime.getRuntime().exec(arrayOf("su", "-c", "id")) }
        rootOk = r.ok && r.stdout.contains("uid=0")
        refreshNow()
        rootOk
    }

    // ── raw shell ──

    /** Runs a command in a privileged shell. Fails honestly when no Shizuku/root is available. */
    suspend fun shell(command: String, timeoutMs: Long = 20_000): CommandResult = when {
        shizukuGranted() -> exec("shizuku", timeoutMs) { newShizukuProcess(arrayOf("sh", "-c", command)) }
        rootOk -> exec("root", timeoutMs) { Runtime.getRuntime().exec(arrayOf("su", "-c", command)) }
        else -> CommandResult(
            false, stderr = "No privileged shell. Start Shizuku (or root) and grant access.", via = "none"
        )
    }

    /** Shizuku keeps newProcess() private since API 13; reflection is the documented workaround. */
    private val newProcessMethod by lazy(LazyThreadSafetyMode.NONE) {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        ).apply { isAccessible = true }
    }

    private fun newShizukuProcess(cmd: Array<String>): Process =
        newProcessMethod.invoke(null, cmd, null, null) as Process

    private suspend fun exec(via: String, timeoutMs: Long, start: () -> Process): CommandResult =
        if (timeoutMs <= LONG_COMMAND_MS) shellGate.withPermit { execNow(via, timeoutMs, start) }
        else execNow(via, timeoutMs, start) // compile / trim: never starve the short toggles behind them

    private suspend fun execNow(via: String, timeoutMs: Long, start: () -> Process): CommandResult =
        withContext(Dispatchers.IO) {
            val t0 = SystemClock.elapsedRealtime()
            _pending.update { it + 1 }
            try {
                val p = try {
                    start()
                } catch (t: Throwable) {
                    val c = (t as? InvocationTargetException)?.targetException ?: t
                    return@withContext CommandResult(false, stderr = c.message ?: c.javaClass.simpleName, via = via)
                }
                try {
                    val out = async { drain(p.inputStream) }
                    val err = async { drain(p.errorStream) }
                    val code = withTimeoutOrNull(timeoutMs) { runInterruptible { p.waitFor() } }
                    val ms = SystemClock.elapsedRealtime() - t0
                    if (code == null) {
                        kill(p)
                        // partial output survives a timeout (a batch still reports the items that finished)
                        return@withContext CommandResult(
                            false, out.await().trim(), "Timed out after ${timeoutMs}ms", -2, via, ms
                        )
                    }
                    CommandResult(code == 0, out.await().trim(), err.await().trim(), code, via, ms)
                } catch (e: CancellationException) {
                    kill(p) // a superseded keyed job must not leave its process running
                    throw e
                }
            } finally {
                _pending.update { it - 1 }
            }
        }

    /** Reads a stream to EOF without ever throwing; whatever arrived before an error or a kill is kept (1 MB cap). */
    private fun drain(s: InputStream): String {
        val buf = ByteArray(4096)
        val bos = ByteArrayOutputStream()
        try {
            while (true) {
                val n = s.read(buf)
                if (n < 0) break
                if (bos.size() < MAX_OUTPUT_BYTES) bos.write(buf, 0, n)
            }
        } catch (_: Throwable) {
        }
        runCatching { s.close() }
        return bos.toString("UTF-8")
    }

    /** Destroys the process and closes its pipes so a blocked reader wakes up. */
    private fun kill(p: Process) {
        runCatching { p.destroy() }
        runCatching { p.inputStream.close() }
        runCatching { p.errorStream.close() }
    }

    /** Some Android `cmd` tools print an error or usage text and still exit 0; this spots them. */
    private fun softFail(out: String, err: String, strict: Boolean): Boolean {
        // strict = `cmd game ...`: these print usage / error text but still exit 0 when the ROM rejects them
        val strictHit = strict && STRICT_HINTS.any { out.contains(it, true) }
        return strictHit || err.contains("Exception") || out.startsWith("Error") ||
            out.contains("Unknown command") || out.contains("Bad argument")
    }

    /** Privileged-only command; some Android `cmd` tools print errors but still exit 0, so we check output too. */
    private suspend fun priv(command: String, what: String, timeoutMs: Long = 20_000, strict: Boolean = false): CommandResult {
        if (!hasShell()) {
            return CommandResult(false, stderr = "$what needs Shizuku or root", via = "none")
        }
        val r = shell(command, timeoutMs)
        val soft = r.ok && softFail(r.stdout, r.stderr, strict)
        return if (soft) r.copy(ok = false, exitCode = 1, stderr = r.stderr.ifBlank { r.stdout }) else r
    }

    private fun invalid(what: String) = CommandResult(false, stderr = "Rejected unsafe/invalid $what", via = "validate")

    // ───────────────────── Settings (system / secure / global) ─────────────────────

    /** Reads never need a shell. Returns null when the key is unset. */
    fun getSetting(ns: Ns, key: String): String? = try {
        when (ns) {
            Ns.SYSTEM -> Settings.System.getString(cr, key)
            Ns.SECURE -> Settings.Secure.getString(cr, key)
            Ns.GLOBAL -> Settings.Global.getString(cr, key)
        }
    } catch (_: Throwable) {
        null
    }

    suspend fun putSetting(ns: Ns, key: String, value: String): CommandResult {
        if (!Validators.SETTING_KEY.matches(key) || !Validators.SETTING_VALUE.matches(value)) {
            return invalid("setting $key")
        }
        if (hasShell()) {
            val r = priv("settings put ${ns.cmd} $key $value", "settings put")
            if (r.ok) return r
        }
        return writeViaApi(ns, key, value)
    }

    /** Settings write through the public API (needs WRITE_SETTINGS / WRITE_SECURE_SETTINGS). value == null deletes. */
    private suspend fun writeViaApi(ns: Ns, key: String, value: String?): CommandResult = withContext(Dispatchers.IO) {
        runCatching {
            val ok = when (ns) {
                Ns.SYSTEM -> Settings.System.canWrite(ctx) && Settings.System.putString(cr, key, value)
                Ns.SECURE -> canWriteSecure() && Settings.Secure.putString(cr, key, value)
                Ns.GLOBAL -> canWriteSecure() && Settings.Global.putString(cr, key, value)
            }
            CommandResult(
                ok,
                stderr = if (ok) "" else "No permission to ${if (value == null) "delete" else "write"} ${ns.cmd}/$key " +
                    "(use Shizuku or grant WRITE_SECURE_SETTINGS over ADB)",
                via = "settings-api"
            )
        }.getOrElse { CommandResult(false, stderr = it.message ?: "settings error", via = "settings-api") }
    }

    suspend fun deleteSetting(ns: Ns, key: String): CommandResult {
        if (!Validators.SETTING_KEY.matches(key)) return invalid("setting key")
        if (hasShell()) {
            val r = priv("settings delete ${ns.cmd} $key", "settings delete")
            if (r.ok) return r
        }
        return writeViaApi(ns, key, null)
    }

    /** Restores a value captured earlier: null original means "was unset". */
    suspend fun restoreSetting(ns: Ns, key: String, original: String?): CommandResult =
        if (original == null) deleteSetting(ns, key) else putSetting(ns, key, original)

    // ───────────────────── Game Mode / FPS booster ─────────────────────

    suspend fun setGameMode(pkg: String, level: GameModeLevel): CommandResult {
        if (!Validators.PACKAGE.matches(pkg)) return invalid("package")
        return priv("cmd game mode ${level.cmd} $pkg", "Game mode switching", strict = true)
    }

    /**
     * downscale: 0.3..0.9 (snapped to 0.05 steps); null or >= 0.95 means "disable".
     * fps: target fps; 0 means "disable".
     * STANDARD has no per-game config in Android, so it resets the override.
     */
    suspend fun setGameConfig(pkg: String, level: GameModeLevel, downscale: Float?, fps: Int): CommandResult {
        if (!Validators.PACKAGE.matches(pkg)) return invalid("package")
        if (level == GameModeLevel.STANDARD) return resetGameConfig(pkg)
        val ds = formatDownscale(downscale)
        // Some ROMs only accept the fps values GameManager lists (30/45/60/90/120). A rejected fps used to make the
        // whole command fail, so the downscale was never applied. Try the exact value, then the nearest listed one
        // below it, then "disable"; the downscale is part of every attempt.
        val tries = LinkedHashSet<String>()
        if (fps in 1..360) tries += fps.toString()
        GAME_FPS_STEPS.filter { it <= fps }.maxOrNull()?.let { tries += it.toString() }
        tries += "disable"
        var last = CommandResult(false, stderr = "cmd game set failed", via = "none")
        for (f in tries) {
            val r = priv(
                "cmd game set --mode ${level.cmd} --downscale $ds --fps $f $pkg",
                "Resolution downscaler",
                strict = true
            )
            if (r.ok) return r
            last = r
        }
        return last
    }

    /** Raw `cmd game list-configs` text for [pkg] (empty when the ROM has no such command). Used to confirm a downscale. */
    suspend fun readGameConfig(pkg: String): String {
        if (!Validators.PACKAGE.matches(pkg) || !hasShell()) return ""
        val r = shell("cmd game list-configs $pkg", 8_000L)
        return if (r.ok) r.stdout.take(1500) else ""
    }

    suspend fun resetGameConfig(pkg: String): CommandResult {
        if (!Validators.PACKAGE.matches(pkg)) return invalid("package")
        return priv("cmd game reset $pkg", "Game config reset", strict = true)
    }

    private val GAME_FPS_STEPS = listOf(30, 45, 60, 90, 120)

    private fun formatDownscale(v: Float?): String {
        if (v == null || v >= 0.95f) return "disable"
        val steps = Math.round(v * 20f).coerceIn(6, 18) // 0.30 .. 0.90
        return String.format(Locale.US, "%.2f", steps / 20f).trimEnd('0').trimEnd('.')
    }

    // ───────────────────── Display refresh rate ─────────────────────

    /** hz <= 0 clears the lock (deletes the keys we own). Writes the four keys from the spec. */
    suspend fun setRefreshRate(hz: Int): List<CommandResult> {
        if (hz <= 0) {
            return applySettings(
                listOf(
                    SettingWrite(Ns.SYSTEM, "peak_refresh_rate", null),
                    SettingWrite(Ns.SYSTEM, "min_refresh_rate", null),
                    SettingWrite(Ns.SECURE, "user_refresh_rate", null),
                    SettingWrite(Ns.SECURE, "miui_refresh_rate", null)
                )
            )
        }
        val f = String.format(Locale.US, "%.1f", hz.toFloat())
        return applySettings(
            listOf(
                SettingWrite(Ns.SYSTEM, "peak_refresh_rate", f),
                SettingWrite(Ns.SYSTEM, "min_refresh_rate", f),
                SettingWrite(Ns.SECURE, "user_refresh_rate", f),
                SettingWrite(Ns.SECURE, "miui_refresh_rate", hz.toString())
            )
        )
    }

    // ───────────────────── ART compiler & caches ─────────────────────

    suspend fun compilePackage(pkg: String, mode: CompileMode): CommandResult {
        if (!Validators.PACKAGE.matches(pkg)) return invalid("package")
        return priv("cmd package compile -m ${mode.cmd} -f $pkg", "ART compile", timeoutMs = 600_000)
    }

    suspend fun trimCaches(): CommandResult = priv("pm trim-caches 999G", "Cache trim", timeoutMs = 120_000)

    suspend fun idleMaintenance(): CommandResult =
        priv("cmd activity idle-maintenance", "Idle maintenance", timeoutMs = 120_000)

    // ───────────────────── Process control / app ops ─────────────────────

    suspend fun forceStop(pkg: String): CommandResult {
        if (!Validators.PACKAGE.matches(pkg)) return invalid("package")
        if (hasShell()) {
            val r = priv("am force-stop $pkg", "force-stop")
            if (r.ok) return r
        }
        return withContext(Dispatchers.IO) {
            runCatching {
                (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).killBackgroundProcesses(pkg)
                CommandResult(true, "killBackgroundProcesses (background only; no shell available)", via = "activity-manager")
            }.getOrElse { CommandResult(false, stderr = it.message ?: "kill failed", via = "activity-manager") }
        }
    }

    suspend fun killAllBackground(): CommandResult = priv("am kill-all", "kill-all")

    suspend fun setAppOp(pkg: String, op: String, mode: String): CommandResult {
        if (!Validators.PACKAGE.matches(pkg)) return invalid("package")
        if (!Validators.APPOP.matches(op) || mode !in Validators.APPOP_MODES) return invalid("appop")
        return priv("cmd appops set $pkg $op $mode", "App ops")
    }

    // ───────────────────── Network ─────────────────────

    suspend fun setRestrictBackground(on: Boolean): CommandResult =
        priv("cmd netpolicy set restrict-background $on", "Background data blocker")

    /** Real current state, readable without a shell. */
    fun isRestrictBackgroundOn(): Boolean = try {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        cm.restrictBackgroundStatus != ConnectivityManager.RESTRICT_BACKGROUND_STATUS_DISABLED
    } catch (_: Throwable) {
        false
    }

    /** mode: "off" | "opportunistic" | "hostname" (host required for hostname). */
    suspend fun setPrivateDns(mode: String, host: String?): List<CommandResult> {
        if (mode != "off" && mode != "opportunistic" && mode != "hostname") return listOf(invalid("dns mode"))
        val out = mutableListOf<CommandResult>()
        if (mode == "hostname") {
            if (host == null || !Validators.HOST.matches(host)) return listOf(invalid("dns host"))
            out += putSetting(Ns.GLOBAL, "private_dns_specifier", host)
        }
        out += putSetting(Ns.GLOBAL, "private_dns_mode", mode)
        return out
    }

    // ───────────────────── Colour matrix (Visual filter) ─────────────────────

    /**
     * Installs a full-screen 4x4 colour matrix (column-major, translation in 12..14) in SurfaceFlinger
     * via `service call SurfaceFlinger 1015`. This is the same call Android's Night Light uses, so it is
     * real per-pixel colour grading: saturation, RGB gain, black-level lift and true dimming.
     * null removes it. Needs a shell (Shizuku / root); reports honestly when the ROM refuses.
     */
    suspend fun setColorMatrix(m: FloatArray?): CommandResult {
        if (m != null && m.size != 16) return invalid("colour matrix")
        val cmd = if (m == null) "service call SurfaceFlinger 1015 i32 0"
        else "service call SurfaceFlinger 1015 i32 1 " +
            m.joinToString(" ") { "f " + String.format(Locale.US, "%.4f", it) }
        val r = priv(cmd, "Colour filter")
        if (!r.ok) return r
        val out = r.stdout + " " + r.stderr
        val refused = out.contains("Error", true) || out.contains("Exception", true) ||
            out.contains("not found", true) || out.contains("denied", true) || !out.contains("Parcel(")
        return if (refused) r.copy(ok = false, exitCode = 1, stderr = "SurfaceFlinger refused the colour matrix: " + out.trim().take(160))
        else r
    }

    /**
     * Highest value the `screen_brightness` setting accepts on THIS device. Many ROMs (Xiaomi/HyperOS,
     * some Samsung/OnePlus) use 2047/4095 instead of 255, so a fixed 0..255 range barely changes anything.
     */
    fun brightnessMax(): Int {
        var max = 255
        runCatching {
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            val v = PowerManager::class.java.getMethod("getMaximumScreenBrightnessSetting").invoke(pm) as Int
            if (v > 0) max = v
        }.onFailure {
            runCatching {
                val id = Resources.getSystem().getIdentifier("config_screenBrightnessSettingMaximum", "integer", "android")
                if (id != 0) max = Resources.getSystem().getInteger(id).takeIf { it > 0 } ?: 255
            }
        }
        val cur = getSetting(Ns.SYSTEM, "screen_brightness")?.toIntOrNull() ?: 0
        return maxOf(max, cur, 255)
    }

    // ───────────────────── Compositor / input / sync ─────────────────────

    suspend fun setAnimationScales(scale: Float): List<CommandResult> {
        val v = String.format(Locale.US, "%.1f", scale.coerceIn(0f, 10f))
        return applySettings(
            listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale")
                .map { SettingWrite(Ns.GLOBAL, it, v) }
        )
    }

    suspend fun setPointerSpeed(speed: Int): CommandResult =
        putSetting(Ns.SYSTEM, "pointer_speed", speed.coerceIn(-7, 7).toString())

    fun isMasterSyncOn(): Boolean = runCatching { ContentResolver.getMasterSyncAutomatically() }.getOrDefault(true)

    fun setMasterSync(on: Boolean): Boolean =
        runCatching { ContentResolver.setMasterSyncAutomatically(on); true }.getOrDefault(false)

    // ───────────────────── Services auto-enable (needs WRITE_SECURE_SETTINGS) ─────────────────────

    suspend fun enableAccessibilityService(component: ComponentName): CommandResult {
        val r = appendToColonList(Ns.SECURE, "enabled_accessibility_services", component.flattenToString())
        if (!r.ok) return r
        return putSetting(Ns.SECURE, "accessibility_enabled", "1")
    }

    suspend fun enableNotificationListener(component: ComponentName): CommandResult =
        appendToColonList(Ns.SECURE, "enabled_notification_listeners", component.flattenToString())

    private suspend fun appendToColonList(ns: Ns, key: String, item: String): CommandResult {
        val items = getSetting(ns, key).orEmpty().split(':').filter { it.isNotBlank() }.toMutableList()
        if (item !in items) items += item
        return putSetting(ns, key, items.joinToString(":"))
    }

    // ───────────────────── Privileged helpers added in Phase 1 completion ─────────────────────

    /** Grants one runtime permission to this app without a dialog. Needs Shizuku or root. */
    suspend fun grantRuntimePermission(permission: String): CommandResult {
        if (!Validators.PERMISSION.matches(permission)) return invalid("permission")
        val r = priv("pm grant ${ctx.packageName} $permission", "Runtime grant")
        withContext(Dispatchers.IO) { refreshNow() }
        return r
    }

    /** `setprop key value` (debug.* properties are writable by the shell user). */
    suspend fun setProp(key: String, value: String): CommandResult {
        if (!Validators.PROP_KEY.matches(key) || !Validators.SETTING_VALUE.matches(value)) return invalid("property $key")
        return priv("setprop $key $value", "setprop")
    }

    /** `device_config put <namespace> <key> <value>` (used by the GameManager overrides). */
    suspend fun deviceConfigPut(namespace: String, key: String, value: String): CommandResult {
        if (!Validators.NAMESPACE.matches(namespace) || !Validators.SETTING_KEY.matches(key) ||
            !Validators.SETTING_VALUE.matches(value)
        ) return invalid("device_config $namespace/$key")
        return priv("device_config put $namespace $key $value", "device_config")
    }

    /**
     * Sends a key through the real input service (fast path, no process spawn) and falls back to
     * `input keyevent N` through the shell. Returns the real outcome of whichever path ran.
     */
    suspend fun pressKey(keyCode: Int): CommandResult = withContext(Dispatchers.IO) {
        if (shizukuGranted() && input.pressKey(keyCode)) {
            return@withContext CommandResult(true, "key $keyCode injected", via = "input-binder")
        }
        priv("input keyevent $keyCode", "Key event")
    }

    /** Single-finger tap through the shell (`input tap`). Fallback when the binder injector is down. */
    suspend fun tapViaShell(x: Int, y: Int): CommandResult =
        priv("input tap ${x.coerceIn(0, 20_000)} ${y.coerceIn(0, 20_000)}", "Shell tap")

    /** Single-finger swipe through the shell (`input swipe`). */
    suspend fun swipeViaShell(x1: Int, y1: Int, x2: Int, y2: Int, durationMs: Int): CommandResult =
        priv(
            "input swipe ${x1.coerceIn(0, 20_000)} ${y1.coerceIn(0, 20_000)} " +
                "${x2.coerceIn(0, 20_000)} ${y2.coerceIn(0, 20_000)} ${durationMs.coerceIn(1, 60_000)}",
            "Shell swipe"
        )

    /**
     * Connects the IInputManager binder and reports the real result. Nothing is injected: this only
     * proves that Shizuku, the hidden-API exemption and the method lookup all work on this ROM.
     */
    suspend fun probeInputInjection(): CommandResult = withContext(Dispatchers.IO) {
        input.invalidate()
        val ok = runCatching { input.connect() }.getOrDefault(false)
        refreshNow()
        if (ok) CommandResult(true, "Bound " + input.description, via = "input-binder")
        else CommandResult(false, stderr = input.lastError ?: "Could not bind the input service", via = "input-binder")
    }

    // ───────────────────── One-time permission setup ─────────────────────

    /** The commands that make the app independent of Shizuku for most features. Shown in UI and run by selfGrant(). */
    fun grantShellCommands(): List<String> {
        val p = ctx.packageName
        return listOf(
            "pm grant $p android.permission.WRITE_SECURE_SETTINGS",
            "pm grant $p android.permission.DUMP",
            "pm grant $p android.permission.READ_LOGS",
            "pm grant $p android.permission.POST_NOTIFICATIONS",
            "pm grant $p android.permission.RECORD_AUDIO",
            "pm grant $p android.permission.READ_PHONE_STATE",
            "pm grant $p android.permission.ANSWER_PHONE_CALLS",
            "pm grant $p android.permission.READ_CONTACTS",
            "appops set $p GET_USAGE_STATS allow",
            "appops set $p SYSTEM_ALERT_WINDOW allow",
            "appops set $p WRITE_SETTINGS allow",
            "cmd deviceidle whitelist +$p"
        )
    }

    /** Same commands formatted for a PC / another phone running adb. */
    fun adbCommands(): List<String> = grantShellCommands().map { "adb shell $it" }

    /** Needs Shizuku or root once. Afterwards most features keep working without it. */
    suspend fun selfGrant(): List<Pair<String, CommandResult>> {
        val cmds = grantShellCommands()
        // one shell process for all twelve commands instead of twelve
        val batch = runBatch(cmds.map { BatchCmd(it, it) }, timeoutMs = 30_000L)
        withContext(Dispatchers.IO) { refreshNow() }
        return cmds.mapIndexed { i, c -> c to batch.items[i].result }
    }

    // ───────────────────── Async, non-blocking entry points (safe from the UI thread) ─────────────────────

    /** Fire a coroutine on the bridge scope (IO). Nothing here ever runs on, or waits for, the main thread. */
    fun launch(block: suspend CoroutineScope.() -> Unit): Job = scope.launch(block = block)

    /**
     * Like [launch], but a newer call with the same [key] cancels the older one first (and kills its process).
     * Use for sliders and repeated toggles: only the last value matters, the older shell run is dropped.
     */
    fun launchKeyed(key: String, block: suspend CoroutineScope.() -> Unit): Job {
        val job = scope.launch(start = CoroutineStart.LAZY, block = block)
        keyedJobs.put(key, job)?.cancel()
        job.invokeOnCompletion { keyedJobs.remove(key, job) }
        job.start()
        return job
    }

    /** Runs one shell command off-thread; [onResult] (optional) is delivered on the main thread. */
    fun shellAsync(command: String, timeoutMs: Long = 20_000, onResult: ((CommandResult) -> Unit)? = null): Job =
        scope.launch {
            val r = shell(command, timeoutMs)
            if (onResult != null) mainHandler.post { onResult(r) }
        }

    /** Builds and runs a batch off-thread; [onDone] (optional) is delivered on the main thread. */
    fun batchAsync(
        timeoutMs: Long = 0L,
        stopOnError: Boolean = false,
        onDone: ((BatchResult) -> Unit)? = null,
        build: BatchBuilder.() -> Unit
    ): Job = scope.launch {
        val r = runBatch(timeoutMs, stopOnError, build)
        if (onDone != null) mainHandler.post { onDone(r) }
    }

    // ───────────────────── Shell batching: many commands, ONE privileged process ─────────────────────

    /** Typed DSL variant: `runBatch { setting(Ns.SYSTEM, "peak_refresh_rate", "144.0"); prop("debug.x", "1") }`. */
    suspend fun runBatch(
        timeoutMs: Long = 0L,
        stopOnError: Boolean = false,
        build: BatchBuilder.() -> Unit
    ): BatchResult = runBatch(BatchBuilder().apply(build).items, timeoutMs, stopOnError)

    /**
     * Runs [cmds] inside a single `sh -c` script (one Shizuku/root process instead of one per command, which is what
     * keeps a 12-step boost from taking seconds). Every command gets its own result: output and exit code are
     * delimited by markers, so a failing step never hides the others unless [stopOnError] is set (hard non-zero exits
     * only; the remaining steps then report "skipped"). Do not put long jobs (compile, fstrim) in a batch: they share
     * one timeout, so run them with their own call. [timeoutMs] <= 0 picks 15 s + 2.5 s per command, capped at 120 s.
     */
    suspend fun runBatch(cmds: List<BatchCmd>, timeoutMs: Long = 0L, stopOnError: Boolean = false): BatchResult {
        val t0 = SystemClock.elapsedRealtime()
        if (cmds.isEmpty()) return BatchResult(emptyList(), 0L)
        val results = arrayOfNulls<CommandResult>(cmds.size)
        // Items that failed validation never reach the shell.
        val runnable = ArrayList<Int>()
        cmds.forEachIndexed { i, c ->
            val bad = c.invalid ?: if (c.line.contains('\n') || c.line.contains('\r')) "newline in command" else null
            if (bad != null) results[i] = CommandResult(false, stderr = "Rejected unsafe/invalid ${c.label}: $bad", via = "validate")
            else runnable += i
        }
        if (runnable.isNotEmpty() && !hasShell()) {
            for (i in runnable) {
                results[i] = CommandResult(false, stderr = "${cmds[i].label} needs Shizuku or root", via = "none")
            }
        } else {
            var aborted = false
            for (chunk in runnable.chunked(BATCH_CHUNK)) {
                if (aborted) {
                    for (i in chunk) results[i] = CommandResult(false, stderr = "skipped (an earlier command failed)", exitCode = -3, via = "batch")
                    continue
                }
                val script = buildScript(chunk.map { cmds[it] }, stopOnError)
                val limit = if (timeoutMs > 0) timeoutMs else (15_000L + 2_500L * chunk.size).coerceAtMost(120_000L)
                val raw = shell(script, limit)
                val parsed = parseBatch(raw.stdout, chunk.size)
                chunk.forEachIndexed { k, i ->
                    val p = parsed[k]
                    results[i] = when {
                        p != null -> {
                            val c = cmds[i]
                            val text = p.first.trim()
                            val soft = p.second == 0 && softFail(text, text, c.strict)
                            val ok = p.second == 0 && !soft
                            CommandResult(
                                ok,
                                stdout = if (ok) text else "",
                                stderr = if (ok) "" else text,
                                exitCode = if (soft) 1 else p.second,
                                via = raw.via
                            )
                        }
                        stopOnError && aborted -> CommandResult(false, stderr = "skipped (an earlier command failed)", exitCode = -3, via = "batch")
                        raw.exitCode == -2 -> CommandResult(false, stderr = "Timed out after ${limit}ms", exitCode = -2, via = raw.via)
                        else -> CommandResult(
                            false, stderr = raw.stderr.ifBlank { "no result from batch (exit ${raw.exitCode})" },
                            exitCode = if (raw.exitCode == 0) -1 else raw.exitCode, via = raw.via
                        )
                    }
                    if (stopOnError && p != null && p.second != 0) aborted = true
                }
            }
        }
        val items = cmds.indices.map { BatchItemResult(cmds[it].label, results[it]!!) }
        return BatchResult(items, SystemClock.elapsedRealtime() - t0)
    }

    private fun buildScript(cmds: List<BatchCmd>, stopOnError: Boolean): String {
        val sb = StringBuilder()
        cmds.forEachIndexed { i, c ->
            sb.append("echo \"").append(MARK_BEGIN).append(i).append("\"\n")
            sb.append("{ ").append(c.line).append("\n} 2>&1 </dev/null\n")
            sb.append("rc=\$?\n")
            sb.append("echo \"").append(MARK_END).append(i).append(":\$rc\"\n")
            if (stopOnError) sb.append("[ \"\$rc\" -ne 0 ] && exit 0\n")
        }
        return sb.toString()
    }

    /** index -> (merged output, exit code); null when a command never reported (timeout / abort). */
    private fun parseBatch(raw: String, n: Int): Array<Pair<String, Int>?> {
        val out = arrayOfNulls<Pair<String, Int>>(n)
        var cur = -1
        val sb = StringBuilder()
        for (line in raw.lineSequence()) {
            val e = line.indexOf(MARK_END)
            if (e >= 0) {
                // the command's last line may not end with a newline, so its text can sit in front of the marker
                if (e > 0) sb.append(line, 0, e).append('\n')
                val parts = line.substring(e + MARK_END.length).split(':')
                val idx = parts.getOrNull(0)?.toIntOrNull()
                val rc = parts.getOrNull(1)?.trim()?.toIntOrNull() ?: -1
                if (idx != null && idx in 0 until n) out[idx] = sb.toString() to rc
                sb.setLength(0)
                cur = -1
            } else if (line.startsWith(MARK_BEGIN)) {
                cur = line.substring(MARK_BEGIN.length).trim().toIntOrNull() ?: -1
                sb.setLength(0)
            } else if (cur >= 0) {
                sb.append(line).append('\n')
            }
        }
        return out
    }

    // ───────────────────── Batched settings writes + snapshots (restore on game exit) ─────────────────────

    /**
     * Applies many settings in ONE shell process. Each entry that the shell rejects (or when there is no shell at all)
     * is retried through the Settings API, so the result list (same order as [writes]) is the real per-key outcome.
     */
    suspend fun applySettings(writes: List<SettingWrite>): List<CommandResult> {
        if (writes.isEmpty()) return emptyList()
        val out = arrayOfNulls<CommandResult>(writes.size)
        val shellIdx = ArrayList<Int>()
        writes.forEachIndexed { i, w ->
            val validKey = Validators.SETTING_KEY.matches(w.key)
            val validVal = w.value == null || Validators.SETTING_VALUE.matches(w.value)
            if (!validKey || !validVal) out[i] = invalid("setting ${w.key}") else shellIdx += i
        }
        if (shellIdx.isNotEmpty() && hasShell()) {
            val batch = runBatch(
                shellIdx.map { i ->
                    val w = writes[i]
                    val line = if (w.value == null) "settings delete ${w.ns.cmd} ${w.key}"
                    else "settings put ${w.ns.cmd} ${w.key} ${w.value}"
                    BatchCmd("${if (w.value == null) "delete" else "put"} ${w.ns.cmd}/${w.key}", line)
                }
            )
            shellIdx.forEachIndexed { k, i -> out[i] = batch.items[k].result }
        }
        for (i in shellIdx) {
            if (out[i]?.ok == true) continue
            val w = writes[i]
            val api = writeViaApi(w.ns, w.key, w.value)
            // keep the shell's message when the API fallback has nothing better to say
            out[i] = if (api.ok || out[i] == null) api else out[i]
        }
        return out.map { it!! }
    }

    /** Reads the current values of [keys] (null = unset) so [restoreSnapshots] can put the phone back exactly. */
    suspend fun snapshotSettings(keys: List<Pair<Ns, String>>): List<SettingSnapshot> =
        withContext(Dispatchers.IO) { keys.map { (ns, k) -> SettingSnapshot(ns, k, getSetting(ns, k)) } }

    /** Restores a snapshot in one shell process (unset keys are deleted). */
    suspend fun restoreSnapshots(snaps: List<SettingSnapshot>): List<CommandResult> =
        applySettings(snaps.map { SettingWrite(it.ns, it.key, it.original) })

    private companion object {
        const val SHELL_PARALLELISM = 4
        const val LONG_COMMAND_MS = 60_000L
        const val SHIZUKU_CACHE_MS = 1_500L
        const val MAX_OUTPUT_BYTES = 1_000_000
        const val BATCH_CHUNK = 40
        const val MARK_BEGIN = "@@HE:B:"
        const val MARK_END = "@@HE:E:"
        val STRICT_HINTS = listOf("Usage", "Invalid", "Unknown option", "not supported", "not found", "Unrecognized")
    }
}

// ───────────────────────── Batch / settings types ─────────────────────────

/** One entry of a batch. [invalid] non-null means the typed builder rejected it (it is reported, never executed). */
data class BatchCmd(
    val label: String,
    val line: String,
    val strict: Boolean = false,
    val invalid: String? = null
)

data class BatchItemResult(val label: String, val result: CommandResult)

data class BatchResult(val items: List<BatchItemResult>, val totalMs: Long) {
    val okCount: Int get() = items.count { it.result.ok }
    val failCount: Int get() = items.size - okCount
    val allOk: Boolean get() = items.isNotEmpty() && failCount == 0
    val failed: List<BatchItemResult> get() = items.filter { !it.result.ok }
    operator fun get(label: String): CommandResult? = items.firstOrNull { it.label == label }?.result

    /** "9/10 ok in 142 ms (failed: put system/oplus_x)" for a log line or Toast. */
    fun summary(): String = "$okCount/${items.size} ok in $totalMs ms" +
        if (failCount == 0) "" else " (failed: " + failed.joinToString { it.label }.take(120) + ")"
}

/** value == null means "delete the key". */
data class SettingWrite(val ns: Ns, val key: String, val value: String?)

data class SettingSnapshot(val ns: Ns, val key: String, val original: String?)

/**
 * Collects commands for [SystemBridgeExecutor.runBatch]. Every typed method validates its inputs with [Validators];
 * an invalid one becomes a failed item instead of reaching the shell. [raw] is for constant, trusted command text only.
 */
class BatchBuilder {
    internal val items = ArrayList<BatchCmd>()

    fun raw(label: String, line: String, strict: Boolean = false) {
        items += BatchCmd(label, line, strict)
    }

    fun setting(ns: Ns, key: String, value: String) {
        val ok = Validators.SETTING_KEY.matches(key) && Validators.SETTING_VALUE.matches(value)
        items += BatchCmd(
            "put ${ns.cmd}/$key", "settings put ${ns.cmd} $key $value",
            invalid = if (ok) null else "setting $key"
        )
    }

    fun deleteSetting(ns: Ns, key: String) {
        items += BatchCmd(
            "delete ${ns.cmd}/$key", "settings delete ${ns.cmd} $key",
            invalid = if (Validators.SETTING_KEY.matches(key)) null else "setting key"
        )
    }

    fun prop(key: String, value: String) {
        val ok = Validators.PROP_KEY.matches(key) && Validators.SETTING_VALUE.matches(value)
        items += BatchCmd("setprop $key", "setprop $key $value", invalid = if (ok) null else "property $key")
    }

    fun deviceConfig(namespace: String, key: String, value: String) {
        val ok = Validators.NAMESPACE.matches(namespace) && Validators.SETTING_KEY.matches(key) &&
            Validators.SETTING_VALUE.matches(value)
        items += BatchCmd(
            "device_config $namespace/$key", "device_config put $namespace $key $value",
            invalid = if (ok) null else "device_config $namespace/$key"
        )
    }

    fun deviceConfigDelete(namespace: String, key: String) {
        val ok = Validators.NAMESPACE.matches(namespace) && Validators.SETTING_KEY.matches(key)
        items += BatchCmd(
            "device_config delete $namespace/$key", "device_config delete $namespace $key",
            invalid = if (ok) null else "device_config $namespace/$key"
        )
    }

    fun appOp(pkg: String, op: String, mode: String) {
        val ok = Validators.PACKAGE.matches(pkg) && Validators.APPOP.matches(op) && mode in Validators.APPOP_MODES
        items += BatchCmd("appops $pkg $op", "cmd appops set $pkg $op $mode", invalid = if (ok) null else "appop")
    }

    fun forceStop(pkg: String) {
        items += BatchCmd(
            "force-stop $pkg", "am force-stop $pkg",
            invalid = if (Validators.PACKAGE.matches(pkg)) null else "package"
        )
    }

    /** `cmd <tokens...>`: every token must match [Validators.ARG]. Example: `cmd("thermalservice", "override-status", "0")`. */
    fun cmd(vararg tokens: String, strict: Boolean = false) {
        val ok = tokens.isNotEmpty() && tokens.all { Validators.ARG.matches(it) }
        val line = "cmd " + tokens.joinToString(" ")
        items += BatchCmd(line, line, strict, invalid = if (ok) null else "cmd arguments")
    }
}
