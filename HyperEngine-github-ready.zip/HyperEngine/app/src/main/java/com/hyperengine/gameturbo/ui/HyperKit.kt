package com.hyperengine.gameturbo.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.LinearLayout
import android.widget.TextView

/**
 * The HyperOS x RedMagic component kit (UI redesign, part 1).
 *
 * Every new screen in parts 2 to 6 is assembled from these pieces, so the whole app shares one look:
 *  - [card]        rounded surface that groups related rows (HyperOS "settings group")
 *  - [switchRow]   title + optional subtitle + animated [HyperSwitch]
 *  - [badge]       small tinted status chip ("ON", "SHIZUKU", "LIMITED")
 *  - [GradientStrip] a horizontal colour bar (palette previews)
 *
 * Gamepad / keyboard friendly: every interactive piece is focusable and draws a focus ring.
 */
object Hyper {

    /** Corner radius of a card, in dp. Sharper on the angular RedMagic / Realme themes. */
    fun cardRadiusDp(theme: HudTheme): Float = when (theme.style) {
        PanelStyle.GLASS -> 22f
        PanelStyle.FLAT -> 18f
        PanelStyle.MECHA -> 8f
        PanelStyle.CYBER_ANGULAR -> 4f
    }

    /** Vertical group with the theme's surface colour. Add rows to it; use [divider] between rows. */
    fun card(ctx: Context, theme: HudTheme): LinearLayout = Ui.vbox(ctx).apply {
        val soft = theme.style == PanelStyle.GLASS || theme.style == PanelStyle.FLAT
        background = Ui.rounded(
            theme.surface, Ui.dpf(ctx, cardRadiusDp(theme)),
            if (soft) 0 else theme.stroke, if (soft) 0 else Ui.dp(ctx, 1)
        )
        setPadding(Ui.dp(ctx, 14), Ui.dp(ctx, 8), Ui.dp(ctx, 14), Ui.dp(ctx, 10))
    }

    fun divider(ctx: Context, theme: HudTheme): View = View(ctx).apply { setBackgroundColor(theme.divider) }

    /** Add a divider line to [parent] (a vertical LinearLayout). */
    fun addDivider(ctx: Context, theme: HudTheme, parent: LinearLayout) {
        parent.addView(divider(ctx, theme), Ui.lp(Ui.MATCH, 1, 0f, 0, Ui.dp(ctx, 2), 0, Ui.dp(ctx, 2)))
    }

    /** One setting: text on the left, switch on the right. The whole row is tappable. */
    fun switchRow(
        ctx: Context,
        theme: HudTheme,
        title: String,
        subtitle: String? = null,
        checked: Boolean,
        onChange: (Boolean) -> Unit
    ): LinearLayout {
        val row = Ui.hbox(ctx)
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(Ui.dp(ctx, 2), Ui.dp(ctx, 9), Ui.dp(ctx, 2), Ui.dp(ctx, 9))
        val texts = Ui.vbox(ctx)
        texts.addView(Ui.label(ctx, title, 13f, theme.textPrimary))
        if (!subtitle.isNullOrBlank()) {
            texts.addView(Ui.label(ctx, subtitle, 11f, theme.textSecondary), Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, Ui.dp(ctx, 2), 0, 0))
        }
        val sw = HyperSwitch(ctx, theme, checked, onChange)
        row.addView(texts, Ui.lp(0, Ui.WRAP, 1f))
        row.addView(sw, Ui.lp(Ui.dp(ctx, 48), Ui.dp(ctx, 28), 0f, Ui.dp(ctx, 12), 0, 0, 0))
        row.isClickable = true
        row.setOnClickListener { sw.performClick() }
        return row
    }

    /** Small tinted status chip. */
    fun badge(ctx: Context, theme: HudTheme, text: String, color: Int): TextView =
        Ui.label(ctx, text, 10f, color, true).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.06f
            setPadding(Ui.dp(ctx, 9), Ui.dp(ctx, 4), Ui.dp(ctx, 9), Ui.dp(ctx, 4))
            background = Ui.rounded(HudThemes.withAlpha(color, 38), Ui.dpf(ctx, 20f))
        }
}

/**
 * HyperOS-style switch: a pill track that fills with the accent colour and a white knob that slides.
 * Built as a custom view because the platform Switch ignores themes inside overlay windows.
 */
class HyperSwitch(
    ctx: Context,
    private val theme: HudTheme,
    checked: Boolean,
    private val onChange: (Boolean) -> Unit
) : View(ctx) {

    var isOn: Boolean = checked
        private set

    private var t = if (checked) 1f else 0f
    private var anim: ValueAnimator? = null
    private val d = resources.displayMetrics.density
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val knobPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * d
        color = theme.accent2
    }
    private val rect = RectF()

    init {
        isClickable = true
        isFocusable = true
        setOnClickListener { set(!isOn, true) }
        onFocusChangeListener = OnFocusChangeListener { _, _ -> invalidate() }
    }

    /** Sets the state from code. [notify] true also calls the change listener. */
    fun set(on: Boolean, notify: Boolean) {
        if (on == isOn) return
        isOn = on
        anim?.cancel()
        val target = if (on) 1f else 0f
        if (theme.animations && isAttachedToWindow) {
            anim = ValueAnimator.ofFloat(t, target).apply {
                duration = 160L
                interpolator = DecelerateInterpolator()
                addUpdateListener { t = it.animatedValue as Float; invalidate() }
                start()
            }
        } else {
            t = target
            invalidate()
        }
        if (notify) onChange(on)
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        setMeasuredDimension(
            resolveSize((48 * d).toInt(), wSpec),
            resolveSize((28 * d).toInt(), hSpec)
        )
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val r = h / 2f
        trackPaint.color = HudThemes.blend(theme.knobOff, theme.accent, t)
        rect.set(0f, 0f, w, h)
        c.drawRoundRect(rect, r, r, trackPaint)
        val pad = 3f * d
        val kr = r - pad
        val cx = (r) + (w - 2f * r) * t
        c.drawCircle(cx, h / 2f, kr, knobPaint)
        if (hasFocus()) {
            rect.set(1f * d, 1f * d, w - 1f * d, h - 1f * d)
            c.drawRoundRect(rect, r, r, ringPaint)
        }
    }
}

/** Horizontal gradient bar. Used by the edge-lighting page to preview a palette. */
class GradientStrip(ctx: Context, private var colors: IntArray, private val radiusDp: Float = 10f) : View(ctx) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    fun setColors(c: IntArray) {
        colors = c
        rebuild()
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        rebuild()
    }

    private fun rebuild() {
        if (width <= 0 || colors.isEmpty()) return
        val cols = if (colors.size == 1) intArrayOf(colors[0], colors[0]) else colors
        paint.shader = LinearGradient(0f, 0f, width.toFloat(), 0f, cols, null, Shader.TileMode.CLAMP)
    }

    override fun onDraw(c: Canvas) {
        if (width <= 0) return
        val r = radiusDp * resources.displayMetrics.density
        rect.set(0f, 0f, width.toFloat(), height.toFloat())
        c.drawRoundRect(rect, r, r, paint)
    }
}
