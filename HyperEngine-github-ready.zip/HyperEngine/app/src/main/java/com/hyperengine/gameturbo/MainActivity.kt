package com.hyperengine.gameturbo

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.hyperengine.gameturbo.core.BridgeState
import com.hyperengine.gameturbo.core.ConsoleWindow
import com.hyperengine.gameturbo.core.CompileMode
import com.hyperengine.gameturbo.core.EngineStatus
import com.hyperengine.gameturbo.core.FpsSource
import com.hyperengine.gameturbo.core.TelemetrySample
import com.hyperengine.gameturbo.hub.GameLibrary
import com.hyperengine.gameturbo.hub.RomLabCard
import com.hyperengine.gameturbo.service.GameDetectorService
import com.hyperengine.gameturbo.ui.HudThemes
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Developer console (the Phase 1/2 bootstrap screen). Phase 6 made the Game Space hub the launcher
 * screen; this one stays reachable from the hub's menu for raw testing of every engine function.
 */
class MainActivity : Activity() {

    private val uiScope = MainScope()
    private lateinit var statusView: TextView
    private lateinit var logView: TextView
    private lateinit var telemetryView: TextView
    private lateinit var engineLogView: TextView
    private lateinit var watcherView: TextView
    private lateinit var gameField: EditText
    private lateinit var freezeField: EditText
    private lateinit var romLab: RomLabCard
    private val bridge get() = HyperApp.instance.bridge
    private val engine get() = HyperApp.instance.engine
    private val telemetry get() = HyperApp.instance.telemetry
    private val repo get() = HyperApp.instance.repository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ConsoleWindow.lockPanel(this) // Part 9: run this screen at the panel's top refresh rate

        val pad = dp(16)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "HyperEngine Game Turbo Pro"
            textSize = 20f
            setTextColor(0xFF00E5FF.toInt())
            typeface = Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "Developer console - engine tests and the ROM & Benchmark Optimizer Lab"
            textSize = 12f
            setTextColor(0xFF9AA5B1.toInt())
        })

        statusView = TextView(this).apply {
            textSize = 13f
            typeface = Typeface.MONOSPACE
            setTextColor(0xFFE0E0E0.toInt())
            setPadding(0, pad, 0, pad)
        }
        root.addView(statusView)

        // Part 9: ROM & Benchmark Optimizer Lab (live Hz / 1% low / temperature, AOT speed compile, AnTuTu prep, panel lock)
        romLab = RomLabCard(this, HudThemes.resolve(repo.global.value), GameLibrary(applicationContext, repo, bridge)) { msg, long ->
            Toast.makeText(applicationContext, msg, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show()
        }
        root.addView(romLab.root, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = pad })

        root.addView(button("Request Shizuku permission") {
            if (!bridge.requestShizukuPermission()) {
                toast("Shizuku is not running. Start it first (Wireless debugging or root).")
            }
        })
        root.addView(button("Open Shizuku app") {
            val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
            if (i != null) startActivity(i) else toast("Shizuku is not installed")
        })
        root.addView(button("Use root instead (su)") {
            uiScope.launch {
                val ok = bridge.probeRoot()
                log(if (ok) "Root granted" else "Root not available / denied")
            }
        })
        root.addView(button("Self-grant permissions (needs Shizuku/root once)") {
            uiScope.launch {
                log("Running grants...")
                bridge.selfGrant().forEach { (cmd, r) ->
                    log((if (r.ok) "OK   " else "FAIL ") + cmd + (if (r.ok) "" else "  -> " + r.message))
                }
            }
        })
        root.addView(button("Run privileged test: id") {
            uiScope.launch {
                val r = bridge.shell("id")
                log("[" + r.via + "] " + r.message)
            }
        })
        root.addView(button("Show + copy ADB commands (no Shizuku needed)") {
            val text = bridge.adbCommands().joinToString("\n")
            log(text)
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("adb", text))
            toast("Copied")
        })
        root.addView(button("Overlay permission") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        root.addView(button("Modify system settings permission") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))
            )
        })
        root.addView(button("Usage access permission") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        })

        // ---------------- Phase 2 test panel ----------------
        root.addView(TextView(this).apply {
            text = "Optimization engine"
            textSize = 16f
            setTextColor(0xFF00E5FF.toInt())
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, pad, 0, 0)
        })
        gameField = EditText(this).apply {
            hint = "Game package (e.g. com.activision.callofduty.shooter)"
            setTextColor(0xFFE0E0E0.toInt())
            setHintTextColor(0xFF6B7785.toInt())
            setSingleLine()
        }
        root.addView(gameField)

        // ---------------- Phase 3: game watcher + HUD ----------------
        watcherView = TextView(this).apply {
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setTextColor(0xFF69F0AE.toInt())
            setPadding(0, pad / 2, 0, pad / 2)
            text = "Game watcher: stopped"
        }
        root.addView(watcherView)
        root.addView(button("Start game watcher") {
            if (!bridge.state.value.overlay) toast("Grant the Overlay permission first (button above)")
            GameDetectorService.start(this)
        })
        root.addView(button("Stop game watcher (restores settings)") {
            GameDetectorService.stop(this)
        })
        root.addView(button("Show HUD for this package (demo, no game needed)") {
            val pkg = gameField.text.toString().trim()
            if (pkg.isEmpty()) { toast("Enter a package name"); return@button }
            if (!bridge.state.value.overlay) { toast("Grant the Overlay permission first"); return@button }
            GameDetectorService.showDemo(this, pkg)
        })
        root.addView(button("Hide demo HUD") {
            GameDetectorService.hideDemo(this)
        })
        root.addView(button("Apply profile to this package") {
            val pkg = gameField.text.toString().trim()
            if (pkg.isEmpty()) { toast("Enter a package name"); return@button }
            telemetry.setTargetPackage(pkg)
            uiScope.launch {
                val rep = engine.applyProfile(pkg)
                log("Applied ${rep.game} in ${rep.durationMs} ms, ${rep.failures} failed step(s)")
                rep.steps.forEach { log((if (it.ok) "OK   " else "FAIL ") + it.step + "  " + it.detail) }
                rep.freeze?.let { log("RAM before ${it.availBeforeMb} MB, after ${it.availAfterMb} MB, reclaimed ${it.reclaimedMb} MB") }
            }
        })
        root.addView(button("Restore everything now") {
            uiScope.launch {
                val rep = engine.restoreAll("manual button")
                log(if (rep.complete) "Restore complete" else "Restore incomplete, will retry")
                rep.steps.forEach { log((if (it.ok) "OK   " else "FAIL ") + it.step + "  " + it.detail) }
            }
        })
        root.addView(button("Simulate game leaving screen (timed restore)") {
            engine.onGameBackground()
        })
        root.addView(button("Simulate game returning to screen") {
            val pkg = gameField.text.toString().trim()
            if (pkg.isNotEmpty()) engine.onGameForeground(pkg)
        })
        root.addView(button("Compile: fast (speed-profile)") {
            val pkg = gameField.text.toString().trim()
            if (pkg.isEmpty()) { toast("Enter a package name"); return@button }
            uiScope.launch { val r = engine.compileGame(pkg, CompileMode.FAST); log(r.step + ": " + r.detail) }
        })
        root.addView(button("Compile: full (speed)") {
            val pkg = gameField.text.toString().trim()
            if (pkg.isEmpty()) { toast("Enter a package name"); return@button }
            uiScope.launch { val r = engine.compileGame(pkg, CompileMode.FULL); log(r.step + ": " + r.detail) }
        })
        root.addView(button("Trim shader and Dalvik caches") {
            uiScope.launch { val r = engine.trimShaderCaches(false); log(r.step + ": " + r.detail) }
        })
        root.addView(button("Show supported refresh rates") {
            val rates = engine.supportedRefreshRates()
            log("Supported: " + rates.joinToString(" / ") + " Hz, current " + engine.currentRefreshRate() + " Hz")
        })
        root.addView(button("Probe all ping regions") {
            uiScope.launch {
                log("Probing regions...")
                telemetry.probeAllTargets().forEach {
                    log(it.targetName + ": avg " + it.avgMs + " ms, jitter " +
                        String.format(Locale.US, "%.1f", it.jitterMs) + " ms, loss " + it.lossPct + "%")
                }
            }
        })
        freezeField = EditText(this).apply {
            hint = "Package to add to the Freeze List"
            setTextColor(0xFFE0E0E0.toInt())
            setHintTextColor(0xFF6B7785.toInt())
            setSingleLine()
        }
        root.addView(freezeField)
        root.addView(button("Add to Freeze List") {
            val p = freezeField.text.toString().trim()
            repo.addToFreezeList(p)
            log("Freeze list: " + repo.global.value.freezeList.joinToString(", "))
        })
        root.addView(button("Freeze Freeze-List now (measure RAM)") {
            uiScope.launch {
                val r = engine.freezeNow(gameField.text.toString().trim())
                log("Frozen ${r.frozen}, protected ${r.skippedProtected}, already restricted ${r.skippedAlreadyRestricted}, " +
                    "failed ${r.failed}, RAM ${r.availBeforeMb} -> ${r.availAfterMb} MB (${r.reclaimedMb} MB)")
            }
        })

        telemetryView = TextView(this).apply {
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setTextColor(0xFFFFD54F.toInt())
            setPadding(0, pad, 0, 0)
        }
        root.addView(telemetryView)
        engineLogView = TextView(this).apply {
            textSize = 11f
            typeface = Typeface.MONOSPACE
            setTextColor(0xFF9AA5B1.toInt())
            setPadding(0, pad / 2, 0, 0)
        }
        root.addView(engineLogView)

        logView = TextView(this).apply {
            textSize = 11f
            typeface = Typeface.MONOSPACE
            setTextColor(0xFF7CFFB2.toInt())
            setTextIsSelectable(true)
            setPadding(0, pad, 0, 0)
        }
        root.addView(logView)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(0xFF0B0F14.toInt())
            addView(root)
        })

        uiScope.launch { bridge.state.collect { render(it) } }
        uiScope.launch { telemetry.sample.collect { renderTelemetry(it) } }
        uiScope.launch { engine.status.collect { renderEngine(it) } }
        uiScope.launch { GameDetectorService.state.collect { renderWatcher(it) } }
    }

    override fun onResume() {
        super.onResume()
        bridge.refresh()
        telemetry.acquire("main")
        romLab.attach(uiScope)
    }

    override fun onPause() {
        romLab.detach()
        telemetry.release("main")
        super.onPause()
    }

    override fun onDestroy() {
        ConsoleWindow.unlockPanel(this)
        uiScope.cancel()
        super.onDestroy()
    }

    private fun render(s: BridgeState) {
        fun yn(b: Boolean) = if (b) "YES" else "no"
        statusView.text = buildString {
            appendLine("Mode             : ${s.mode.label}")
            appendLine("Shizuku installed: ${yn(s.shizukuInstalled)}")
            appendLine("Shizuku running  : ${yn(s.shizukuRunning)}")
            appendLine("Shizuku granted  : ${yn(s.shizukuGranted)}")
            appendLine("Root granted     : ${yn(s.rootGranted)}")
            appendLine("WRITE_SECURE_SET : ${yn(s.writeSecureSettings)}")
            appendLine("Write settings   : ${yn(s.writeSystemSettings)}")
            appendLine("Usage access     : ${yn(s.usageAccess)}")
            append("Overlay          : ${yn(s.overlay)}")
        }
    }

    private fun renderTelemetry(t: TelemetrySample) {
        fun f1(v: Float) = String.format(Locale.US, "%.1f", v)
        val fpsText = when (t.fpsSource) {
            FpsSource.SURFACE_FLINGER -> f1(t.fps) + "  (game layer)"
            FpsSource.VSYNC -> f1(t.fps) + "  (display vsync, not game FPS)"
            FpsSource.NONE -> "--  (set a package and start a game)"
        }
        val cpuText = if (t.cpuPct >= 0f) f1(t.cpuPct) + "%" else "--  (needs Shizuku/root)"
        val power = if (t.powerW >= 0f) f1(t.powerW) + " W" else "n/a"
        val p = t.ping
        telemetryView.text = buildString {
            appendLine("FPS     : $fpsText")
            appendLine("CPU     : $cpuText  peak core ${f1(t.peakCoreGhz)} GHz")
            appendLine("Cores   : " + t.coreCurMhz.joinToString(" "))
            appendLine("RAM     : free ${t.availRamMb} / ${t.totalRamMb} MB")
            appendLine("Battery : ${f1(t.batteryTempC)} C  ${t.batteryPct}%  ${f1(t.voltageV)} V  ${t.currentMa} mA  $power" +
                (if (t.charging) "  charging" else "  discharging") + (if (t.overTemp) "  OVER LIMIT" else ""))
            append("Ping    : " + (if (p.lastMs >= 0) "${p.lastMs} ms" else "--") +
                "  avg ${p.avgMs}  jitter ${f1(p.jitterMs)}  loss ${p.lossPct}%  " + p.targetName)
        }
    }

    private fun renderWatcher(st: GameDetectorService.DetectorState) {
        watcherView.text = if (!st.running) {
            "Game watcher: stopped"
        } else {
            "Game watcher: running (" + st.source + ")\n" +
                "Foreground: " + (st.foreground ?: "-") + "\n" +
                "Game: " + (st.game ?: "-") + (st.demo?.let { "   demo HUD: $it" } ?: "") +
                (st.problem?.let { "\nProblem: $it" } ?: "")
        }
    }

    private fun renderEngine(st: EngineStatus) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.US)
        engineLogView.text = buildString {
            appendLine(
                "Session: " + (if (st.sessionActive) "ACTIVE (changes pending restore)" else "clean") +
                    (st.activeGame?.let { "  game=$it" } ?: "") +
                    (st.restoreCountdownSec?.let { "  restore in ${it}s" } ?: "") +
                    (st.busy?.let { "  busy: $it" } ?: "")
            )
            st.log.takeLast(12).forEach {
                appendLine(time.format(Date(it.time)) + (if (it.ok) " OK   " else " FAIL ") + it.step + "  " + it.detail)
            }
        }
    }

    private fun log(line: String) {
        logView.append(line + "\n")
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
