package com.hyperengine.gameturbo.ui

import android.content.Context
import android.content.res.ColorStateList
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import com.hyperengine.gameturbo.HyperApp
import com.hyperengine.gameturbo.R
import com.hyperengine.gameturbo.core.ColorblindMode
import com.hyperengine.gameturbo.core.GameFilterConfig
import com.hyperengine.gameturbo.core.HyperBoostQuality
import com.hyperengine.gameturbo.core.StepResult
import com.hyperengine.gameturbo.core.UpscalerState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * The "HyperLab" page: low-latency mode, the clip buffer (with the Save button), game colour filters, refresh-rate matching and
 * the HyperBoost quality picker. One implementation for both the in-game HUD tab and the Game Space lobby.
 *
 * [liveGame] is true when [game] is the game in front right now (always in the HUD). Live-only switches (low-latency mode,
 * HyperBoost on/off) are replaced by an explanation otherwise, so nothing system-wide is switched on for a game
 * that is not running. Colour filters, refresh matching and the HyperBoost quality are saved per game either way.
 *
 * Live readouts are collected while the view is attached and stopped when it is detached, so the panel can be torn
 * down and re-added by the HUD without leaking collectors or going stale.
 */
class LabPanel(
    private val ctx: Context,
    private val theme: HudTheme,
    private val game: String,
    private val liveGame: Boolean,
    private val toast: (String, Boolean) -> Unit
) {
    private val app = HyperApp.instance
    private val nv = app.suite
    private val hb = app.hyperBoost
    private val up = app.upscaler
    private val prefs = ctx.getSharedPreferences("hyper_lab", Context.MODE_PRIVATE)
    private val actions = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var collectors: Job? = null
    private var syncing = false

    private var fs: GameFilterConfig = nv.gameFilter(game)
    private var windowSec = prefs.getInt(KEY_WINDOW, 30).takeIf { it in listOf(15, 30, 60) } ?: 30
    private var replayPendingUntil = 0L

    private lateinit var root: LinearLayout
    private lateinit var lowLatencySwitch: Switch
    private lateinit var latencyView: TextView
    private lateinit var lowLatencyResult: TextView
    private lateinit var replaySwitch: Switch
    private lateinit var replayStatus: TextView
    private lateinit var saveButton: TextView
    private lateinit var fsResult: TextView
    private lateinit var refreshSyncSwitch: Switch
    private lateinit var refreshSyncStatus: TextView
    private lateinit var hbSwitch: Switch
    private lateinit var hbNote: TextView
    private lateinit var hbResult: TextView
    private lateinit var hbMethod: TextView
    private lateinit var hbSysSwitch: Switch
    private lateinit var upButton: TextView
    private lateinit var upStatus: TextView
    private lateinit var upResult: TextView

    fun build(): View {
        root = Ui.vbox(ctx)

        val head = Ui.hbox(ctx)
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(VIcon.view(ctx, R.drawable.ic_low_latency, 34), Ui.lp(Ui.dp(ctx, 38), Ui.dp(ctx, 38), 0f, 0, 0, Ui.dp(ctx, 10), 0))
        val titles = Ui.vbox(ctx)
        titles.addView(Ui.label(ctx, Brand.LAB_TITLE, 15f, theme.textPrimary, true))
        val label = app.repository.profile(game)?.label?.ifBlank { game } ?: game
        titles.addView(Ui.label(ctx, label, 11f, theme.textSecondary))
        head.addView(titles, Ui.lp(0, Ui.WRAP, 1f))
        root.addView(head, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, 0, 0, Ui.dp(ctx, 4)))

        buildLowLatency()
        buildReplay()
        buildGameFilter()
        buildRefreshSync()
        buildHyperBoost()
        buildUpscaler()

        root.addView(
            Ui.label(
                ctx,
                "Independent software. Not made by, licensed from or affiliated with NVIDIA, AMD or any game publisher. These are original approximations, not the vendors' technologies.",
                10f, theme.textSecondary
            ).apply { setPadding(0, Ui.dp(ctx, 14), 0, Ui.dp(ctx, 6)) }
        )

        root.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) = startCollectors()
            override fun onViewDetachedFromWindow(v: View) = stopCollectors()
        })
        return root
    }

    // =========================================================================================
    // Pieces
    // =========================================================================================

    private fun card(title: String, iconRes: Int, body: LinearLayout.() -> Unit) {
        val c = Ui.vbox(ctx)
        c.setPadding(Ui.dp(ctx, 12), Ui.dp(ctx, 10), Ui.dp(ctx, 12), Ui.dp(ctx, 12))
        c.background = Ui.rounded(theme.tile, Ui.tileRadius(ctx, theme), theme.stroke, Ui.dp(ctx, 1))
        val row = Ui.hbox(ctx)
        row.gravity = Gravity.CENTER_VERTICAL
        val ic = VIcon.view(ctx, iconRes, 20)
        VIcon.start(ic.drawable)
        row.addView(ic, Ui.lp(Ui.dp(ctx, 22), Ui.dp(ctx, 22), 0f, 0, 0, Ui.dp(ctx, 8), 0))
        row.addView(Ui.label(ctx, title, 13f, theme.textPrimary, true), Ui.lp(0, Ui.WRAP, 1f))
        c.addView(row)
        c.body()
        root.addView(c, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 10), 0, 0))
    }

    private fun note(text: String): TextView =
        Ui.label(ctx, text, 10f, theme.textSecondary).apply {
            setLineSpacing(0f, 1.12f)
            setPadding(0, Ui.dp(ctx, 4), 0, Ui.dp(ctx, 2))
        }

    private fun status(): TextView =
        Ui.label(ctx, "", 11f, theme.textSecondary).apply { setPadding(0, Ui.dp(ctx, 6), 0, 0) }

    private fun makeSwitch(checked: Boolean, onChange: (Boolean) -> Unit): Switch {
        val sw = Switch(ctx)
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(theme.accent, theme.textSecondary))
        sw.trackTintList = ColorStateList(
            states,
            intArrayOf(HudThemes.withAlpha(theme.accent, 0x80), HudThemes.withAlpha(theme.textSecondary, 0x55))
        )
        sw.isChecked = checked
        sw.setOnCheckedChangeListener { _, on -> if (!syncing) onChange(on) }
        return sw
    }

    private fun switchRow(into: LinearLayout, title: String, sub: String?, sw: Switch) {
        val row = Ui.hbox(ctx)
        row.gravity = Gravity.CENTER_VERTICAL
        val col = Ui.vbox(ctx)
        col.addView(Ui.label(ctx, title, 12f, theme.textPrimary, true))
        if (!sub.isNullOrBlank()) col.addView(Ui.label(ctx, sub, 10f, theme.textSecondary).apply { setPadding(0, Ui.dp(ctx, 2), 0, 0) })
        row.addView(col, Ui.lp(0, Ui.WRAP, 1f, 0, 0, Ui.dp(ctx, 8), 0))
        row.addView(sw, Ui.lp(Ui.WRAP, Ui.WRAP))
        row.setOnClickListener { if (sw.isEnabled) sw.toggle() }
        into.addView(row, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 8), 0, 0))
    }

    private fun setChecked(sw: Switch, on: Boolean) {
        if (sw.isChecked == on) return
        syncing = true
        sw.isChecked = on
        syncing = false
    }

    private fun show(tv: TextView, steps: List<StepResult>) {
        if (steps.isEmpty()) {
            tv.text = ""
            return
        }
        val (ok, text) = GameActions.summary(steps)
        tv.setTextColor(if (ok) theme.good else theme.hot)
        tv.text = text
    }

    private fun showOne(tv: TextView, r: StepResult) {
        tv.setTextColor(if (r.ok) theme.good else theme.hot)
        tv.text = if (r.detail.isBlank()) r.step else r.step + ": " + r.detail
    }

    // ---- Low-latency mode ------------------------------------------------------------------------------

    private fun buildLowLatency() {
        card(Brand.LOW_LATENCY, R.drawable.avd_low_latency_pulse) {
            if (liveGame) {
                lowLatencySwitch = makeSwitch(nv.lowLatency.value.on) { on ->
                    actions.launch {
                        val steps = if (on) nv.lowLatencyOn(game) else nv.lowLatencyOff()
                        show(lowLatencyResult, steps)
                    }
                }
                switchRow(this, "Boost + On", "Lowers latched-frame delay and touch hold time. Also turns on with Wild Boost.", lowLatencySwitch)
                latencyView = Ui.label(ctx, "", 12f, theme.accent, true).apply { setPadding(0, Ui.dp(ctx, 8), 0, 0) }
                addView(latencyView)
                lowLatencyResult = status()
                addView(lowLatencyResult)
                addView(note("The latency figure is an estimate: frame time + half a refresh + the average wait for the next touch sample. It is not a measurement."))
            } else {
                // not built: the lateinit views below are only touched in live mode
                addView(note("Low-latency mode turns on with Wild Boost when this game starts. Open this tab from the in-game HUD to switch it by hand and see the live latency estimate."))
            }
        }
    }

    // ---- Clip buffer ------------------------------------------------------------------------

    private fun buildReplay() {
        card(Brand.REPLAY, R.drawable.avd_clip_rec_pulse) {
            addView(note("Keeps only the last few seconds of screen video in RAM. Save it after the clutch; nothing is written to storage until you do."))
            val idx = listOf(15, 30, 60).indexOf(windowSec)
            addView(ChipGroup(ctx, theme, listOf("15 s", "30 s", "60 s"), idx, 3) { i ->
                windowSec = listOf(15, 30, 60)[i]
                prefs.edit().putInt(KEY_WINDOW, windowSec).apply()
                if (nv.replay.running.value) nv.startReplay(windowSec)
            })
            replaySwitch = makeSwitch(nv.replay.running.value) { on ->
                if (on) {
                    if (!nv.startReplay(windowSec)) {
                        replayPendingUntil = System.currentTimeMillis() + PENDING_MS
                        toast("Allow screen capture in the dialog. The buffer starts when you accept.", false)
                        root.postDelayed({ syncReplay() }, PENDING_MS + 500L)
                    }
                } else {
                    replayPendingUntil = 0L
                    nv.stopReplay()
                }
                syncReplay()
            }
            switchRow(this, "Replay buffer (RAM only)", null, replaySwitch)
            replayStatus = status()
            addView(replayStatus)

            saveButton = Ui.button(ctx, theme, Brand.REPLAY_SAVE, true) {
                actions.launch {
                    val where = nv.saveReplay()
                    if (where != null) toast("Saved to $where", false)
                    else toast("Nothing buffered yet. Turn the buffer on and play a little first.", true)
                }
            }
            VIcon.setOnText(saveButton, R.drawable.ic_clip_buffer, 22, atStart = true)
            VIcon.pressSpring(saveButton, 0.94f)
            addView(saveButton, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 10), 0, 0))
            addView(note("Video only (no game sound). Games that block screen capture record black. Clips go to Movies/HyperEngine_Clips."))
        }
    }

    private fun syncReplay() {
        val running = nv.replay.running.value
        val pending = !running && System.currentTimeMillis() < replayPendingUntil
        if (running) replayPendingUntil = 0L
        setChecked(replaySwitch, running || pending)
        val sec = nv.replay.bufferedSec.value
        replayStatus.setTextColor(if (running) theme.good else theme.textSecondary)
        replayStatus.text = when {
            running -> "Buffering: $sec s of $windowSec s"
            pending -> "Waiting for screen-capture permission"
            else -> "Buffer is off"
        }
        saveButton.alpha = if (running) 1f else 0.6f
    }

    // ---- Colour filters -----------------------------------------------------------------------------

    private fun buildGameFilter() {
        card(Brand.GAME_FILTERS, R.drawable.ic_game_filters) {
            addView(note("A colour layer, not true sharpening: it can change contrast and colour but cannot read neighbouring pixels, so there is no edge sharpening. Saved for this game."))
            val sw = makeSwitch(fs.enabled) { on ->
                fs = fs.copy(enabled = on)
                commitGameFilter()
            }
            switchRow(this, "Colour filters on", null, sw)
            fun slider(title: String, v: Int, set: (GameFilterConfig, Int) -> GameFilterConfig) {
                addView(Ui.labeledSlider(ctx, theme, title, "%", 0, 100, v) { n ->
                    fs = set(fs, n).let { if (!it.enabled && !it.isNeutral) it.copy(enabled = true) else it }
                    setChecked(sw, fs.enabled)
                    commitGameFilter()
                }, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 6), 0, 0))
            }
            slider("Clarity (contrast)", fs.clarityPct) { c, n -> c.copy(clarityPct = n) }
            slider("Digital vibrance (saturation)", fs.vibrancePct) { c, n -> c.copy(vibrancePct = n) }
            slider("HDR toning (shadow lift, highlight roll-off)", fs.hdrPct) { c, n -> c.copy(hdrPct = n) }
            slider("Night mode", fs.nightPct) { c, n -> c.copy(nightPct = n) }
            addView(Ui.section(ctx, theme, "Colourblind assist"))
            val modes = ColorblindMode.values().toList()
            addView(ChipGroup(ctx, theme, modes.map { it.label }, modes.indexOf(fs.colorblind), 2) { i ->
                fs = fs.copy(colorblind = modes[i]).let { if (!it.enabled && !it.isNeutral) it.copy(enabled = true) else it }
                setChecked(sw, fs.enabled)
                commitGameFilter()
            })
            fsResult = status()
            addView(fsResult)
        }
    }

    private fun commitGameFilter() {
        val cfg = fs
        actions.launch { showOne(fsResult, nv.setGameFilter(game, cfg, liveGame)) }
    }

    // ---- Refresh-rate matching -----------------------------------------------------------------

    private fun buildRefreshSync() {
        card(Brand.REFRESH_SYNC, R.drawable.ic_hyperboost_scale) {
            addView(note("Android has no variable refresh rate for apps. This follows the game's real FPS and moves the panel to the nearest rate that is a whole multiple of it (45 fps on 90 Hz, 60 on 120), so every frame is held equally long."))
            refreshSyncSwitch = makeSwitch(nv.refreshSyncEnabled(game)) { on ->
                actions.launch { showOne(refreshSyncStatus, nv.setRefreshSync(game, on)) }
            }
            switchRow(this, "Stabilize frame delivery", null, refreshSyncSwitch)
            refreshSyncStatus = status()
            addView(refreshSyncStatus)
        }
    }

    // ---- HyperBoost ------------------------------------------------------------------------------

    private fun gainShort(q: HyperBoostQuality): String = when (q) {
        HyperBoostQuality.ULTRA_QUALITY -> "~25% FPS"
        HyperBoostQuality.QUALITY -> "~40% FPS"
        HyperBoostQuality.BALANCED -> "~60% FPS"
        HyperBoostQuality.ULTRA_PERFORMANCE -> "up to 2x FPS"
    }

    private fun buildHyperBoost() {
        card(Brand.HYPERBOOST, R.drawable.avd_hyperboost_trace) {
            val qs = HyperBoostQuality.values().toList()
            var current = hb.quality(game)
            hbNote = note("")
            fun describe() {
                hbNote.text = current.label + " renders at " + String.format(Locale.US, "%.2f", current.scale) + "x and is shown at native size: " +
                    current.gainHint + ". Estimates for GPU-bound games, not measurements. Needs Android 12+ and a game that honours the system's render scale."
            }
            hbResult = status()
            addView(ChipGroup(
                ctx, theme,
                qs.map { it.label + "\n" + String.format(Locale.US, "%.2f", it.scale) + "x  " + gainShort(it) },
                qs.indexOf(current), 2
            ) { i ->
                current = qs[i]
                describe()
                actions.launch { show(hbResult, hb.setQuality(game, current)) }
            })
            describe()
            addView(hbNote)
            hbSysSwitch = makeSwitch(hb.systemScaleForced(game)) { on ->
                actions.launch { show(hbResult, hb.setSystemScaleForced(game, on)) }
            }
            switchRow(
                this, "Use system resolution (every game)",
                "Lowers the whole screen resolution while the game runs, so it works even when the game ignores Android's render scale. " +
                    "Needs Shizuku or root. It is used automatically when the system refuses the normal route, and restored when the game ends.",
                hbSysSwitch
            )
            hbMethod = status()
            addView(hbMethod)
            if (liveGame) {
                hbSwitch = makeSwitch(hb.state.value.active && hb.state.value.game == game) { on ->
                    actions.launch { show(hbResult, if (on) hb.apply(game, current) else hb.release(game)) }
                }
                switchRow(this, "HyperBoost on", "Also turns on with Wild Boost.", hbSwitch)
                val restart = Ui.button(ctx, theme, "Restart game to apply the scale", false) {
                    actions.launch { showOne(hbResult, hb.restartGame(game)) }
                }
                addView(restart, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 8), 0, 0))
                addView(note("Android's own render scale is read when a game starts. If the game was already running, restart it once. Restarting closes the game without saving."))
            } else {
                addView(note("The choice is saved and used when Wild Boost starts this game."))
            }
            addView(hbResult)
        }
    }

    // ---- Virtual-display upscaler ----------------------------------------------------------------

    private fun buildUpscaler() {
        card(Brand.UPSCALER, R.drawable.ic_hyperboost_scale) {
            addView(note(
                "The game runs on a private low-resolution display. The picture is stretched to your screen with a bicubic filter and " +
                    "sharpened (contrast-adaptive, like AMD's open CAS). The real screen and the HUD stay at native resolution; " +
                    "nothing system-wide is changed. Needs Shizuku."
            ))
            val qs = HyperBoostQuality.values().toList()
            val savedScale = up.scale(game)
            val startIdx = qs.indices.minByOrNull { Math.abs(qs[it].scale - savedScale) } ?: 2
            addView(ChipGroup(
                ctx, theme,
                qs.map { it.label + "\n" + String.format(Locale.US, "%.2f", it.scale) + "x" },
                startIdx, 2
            ) { i ->
                up.setScale(game, qs[i].scale)
                toast(
                    if (up.isActive()) "Render scale " + String.format(Locale.US, "%.2f", qs[i].scale) + "x is used the next time the upscaler starts."
                    else "Render scale " + String.format(Locale.US, "%.2f", qs[i].scale) + "x saved.",
                    false
                )
            })
            addView(Ui.labeledSlider(ctx, theme, "Sharpening", "%", 0, 100, up.sharpness()) { n ->
                up.setSharpness(n)
            }, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 6), 0, 0))
            addView(note("0 = smooth upscale only. Around 50 to 70 looks natural; higher can look crunchy. Changes apply to the running picture at once."))

            upButton = Ui.button(ctx, theme, "", true) {
                actions.launch {
                    val st = up.state.value
                    if (st.active) {
                        showOne(upResult, up.stop())
                    } else {
                        upResult.text = ""
                        show(upResult, up.start(game, restartGame = true))
                    }
                }
            }
            addView(upButton, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 10), 0, 0))
            upStatus = status()
            addView(upStatus)
            upResult = status()
            addView(upResult)
            addView(note(
                "Starting closes the game and reopens it on the virtual display, so unsaved progress is lost. While it runs: use the small Back / Stop pill " +
                    "on screen (the system back gesture goes to the phone screen, not to the game). Virtual displays usually run at 60 Hz, so a 90/120 fps game is " +
                    "capped. Games that block screen capture show black, and some games refuse to run on a second display; then it stops itself and says why. " +
                    "Do not combine with HyperBoost's \"Use system resolution\"."
            ))
            syncUpscaler(up.state.value)
        }
    }

    private fun syncUpscaler(st: UpscalerState) {
        val mine = st.active && st.game == game
        upButton.text = when {
            mine -> "Stop upscaler"
            liveGame -> "Start upscaled (restarts the game)"
            else -> "Launch game upscaled"
        }
        upButton.alpha = if (st.busy) 0.6f else 1f
        val scaleText = String.format(Locale.US, "%.2f", st.scale)
        when {
            mine -> {
                val where = when (st.onDisplay) {
                    true -> "game confirmed on virtual display #" + st.displayId
                    false -> "waiting for the game to open on the virtual display"
                    null -> "could not check which display the game is on (this ROM's dump format)"
                }
                upStatus.setTextColor(if (st.onDisplay == false) theme.hot else theme.good)
                upStatus.text = "Running: the game renders " + st.srcW + "x" + st.srcH + ", shown at " + st.outW + "x" + st.outH +
                    " (" + scaleText + "x), " + st.fps + " fps on screen. " + where + "."
            }
            st.active -> {
                upStatus.setTextColor(theme.hot)
                upStatus.text = "The upscaler is running for another game. Stop it there first."
            }
            st.note.isNotBlank() -> {
                upStatus.setTextColor(theme.hot)
                upStatus.text = "Stopped: " + st.note
            }
            else -> upStatus.text = ""
        }
    }

    // =========================================================================================
    // Live readouts
    // =========================================================================================

    private fun startCollectors() {
        if (collectors?.isActive == true) return
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
        collectors = scope.coroutineContext[Job]
        syncReplay()
        scope.launch { up.state.collect { syncUpscaler(it) } }
        scope.launch { nv.replay.running.collect { syncReplay() } }
        scope.launch { nv.replay.bufferedSec.collect { syncReplay() } }
        scope.launch {
            nv.refreshSyncState.collect { g ->
                setChecked(refreshSyncSwitch, nv.refreshSyncEnabled(game))
                refreshSyncStatus.setTextColor(theme.textSecondary)
                if (refreshSyncStatus.text.isNullOrBlank() || g.on || g.note.isNotBlank()) {
                    refreshSyncStatus.text = when {
                        g.note.isNotBlank() -> g.note
                        g.on && g.fps > 0 -> "Game " + g.fps + " fps, panel " + g.hz + " Hz"
                        g.on -> "Watching the game's FPS"
                        else -> ""
                    }
                }
            }
        }
        if (liveGame) {
            scope.launch { nv.lowLatency.collect { setChecked(lowLatencySwitch, it.on && it.game == game) } }
            scope.launch {
                hb.state.collect {
                    setChecked(hbSwitch, it.active && it.game == game)
                    val mine = it.active && it.game == game
                    hbMethod.setTextColor(if (mine && it.scaleApplied) theme.good else theme.hot)
                    hbMethod.text = when {
                        !mine -> ""
                        it.scaleApplied -> "Render scale is applied through " + it.scaleMethod +
                            (if (it.needsRestart) ". Restart the game once if it does not look lower-resolution." else ".")
                        else -> "Render scale is NOT applied: the system refused it. See the lines below."
                    }
                }
            }
            scope.launch {
                app.telemetry.sample.collect { s ->
                    val locked = app.fps.lockedHz.value
                    val hz = if (locked > 0) locked else panelHz
                    val parts = nv.latencyParts(s, hz)
                    latencyView.text = if (parts == null) "System latency: -- ms (FPS is not readable yet)"
                    else String.format(
                        Locale.US, "System latency about %d ms  (frame %.1f + scan-out %.1f + touch %.1f)",
                        (parts.first + parts.second + parts.third).toInt(), parts.first, parts.second, parts.third
                    )
                }
            }
        }
    }

    private val panelHz: Int by lazy {
        runCatching { app.engine.supportedRefreshRates().maxOrNull() }.getOrNull() ?: 60
    }

    private fun stopCollectors() {
        collectors?.cancel()
        collectors = null
    }

    private companion object {
        const val KEY_WINDOW = "replay.sec"
        const val PENDING_MS = 45_000L
    }
}
