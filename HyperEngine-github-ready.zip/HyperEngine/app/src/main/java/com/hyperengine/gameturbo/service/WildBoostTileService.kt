package com.hyperengine.gameturbo.service

import android.graphics.drawable.Icon
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.hyperengine.gameturbo.HyperApp
import com.hyperengine.gameturbo.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Control Center / Quick Settings tile "Wild Boost".
 *
 *   inactive  Balanced
 *   active    "<hz>Hz - MAX BOOST" (the real, panel-limited rate), or "Starts with next game" when no game is in
 *             front yet, or the problem text ("PARTIAL BOOST", "Needs Shizuku")
 *
 * A tap hands everything to [WildBoostController]: it collapses the shade (Shizuku `cmd statusbar collapse`,
 * accessibility Back as fallback), applies the full boost, and plays the ignition overlay. The tile itself holds
 * no state, it only mirrors the controller while the shade is open, so the HUD and the tile always agree.
 *
 * The work runs in the application-wide controller, not in this service, because Android unbinds a tile service
 * a moment after the shade closes and that would cut the boost off half way.
 */
class WildBoostTileService : TileService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var observer: Job? = null

    private val controller: WildBoostController get() = HyperApp.instance.wildBoost

    override fun onTileAdded() {
        super.onTileAdded()
        render(controller.state.value)
    }

    override fun onStartListening() {
        super.onStartListening()
        observer?.cancel()
        observer = scope.launch { controller.state.collect { render(it) } }
    }

    override fun onStopListening() {
        observer?.cancel()
        observer = null
        super.onStopListening()
    }

    override fun onClick() {
        super.onClick()
        HyperApp.instance.selfHealer.heal("tile tap")
        // Wild Boost is for a running game; on the lock screen, ask for the unlock first.
        if (isLocked) {
            unlockAndRun { controller.toggle(WildBoostController.Source.TILE) }
        } else {
            controller.toggle(WildBoostController.Source.TILE)
        }
    }

    override fun onDestroy() {
        observer?.cancel()
        scope.cancel()
        super.onDestroy()
    }

    private fun render(s: WildBoostController.UiState) {
        val tile = qsTile ?: return
        tile.label = getString(R.string.wild_boost_tile_label)
        tile.icon = Icon.createWithResource(this, R.drawable.ic_qs_wild_boost)
        tile.state = if (s.on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE

        val subtitle = when {
            s.note != null -> s.note
            s.on && s.pending -> getString(R.string.wild_boost_tile_sub_pending)
            s.on -> getString(R.string.wild_boost_tile_sub_on, s.hz)
            else -> getString(R.string.wild_boost_tile_sub_off)
        }
        if (Build.VERSION.SDK_INT >= 29) tile.subtitle = subtitle
        if (Build.VERSION.SDK_INT >= 30) tile.stateDescription = subtitle
        tile.updateTile()
    }
}
