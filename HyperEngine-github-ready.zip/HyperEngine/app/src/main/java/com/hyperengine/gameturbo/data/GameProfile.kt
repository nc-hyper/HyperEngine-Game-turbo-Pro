package com.hyperengine.gameturbo.data

import com.hyperengine.gameturbo.core.GameModeLevel

// ───────────────────────────── Enums ─────────────────────────────

enum class DnsPreset(val label: String, val mode: String, val host: String?) {
    NO_CHANGE("Don't change", "", null),
    CLOUDFLARE("Cloudflare Gaming", "hostname", "one.one.one.one"),
    GOOGLE("Google Public DNS", "hostname", "dns.google"),
    QUAD9("Quad9 Security", "hostname", "dns.quad9.net"),
    ADGUARD("AdGuard No-Ads", "hostname", "dns.adguard-dns.com"),
    SYSTEM_DEFAULT("System Default", "opportunistic", null),
    OFF("Off", "off", null)
}

enum class PrecompileMode { NONE, FAST, FULL }

enum class ThemeId { HYPEROS_WILD_BOOST, REALME_GT_CYBER, MECHA_REDMAGIC, AMOLED_BLACK }

enum class CrosshairShape {
    CLASSIC_CROSS, DOT, CIRCLE_DOT, T_CROSS, CHEVRON, BOX_RETICLE, HOLLOW_RING, X_MARKER
}

enum class PillLayout { HORIZONTAL, VERTICAL_STACK, CORNER_TEXT }

enum class EdgeSide { LEFT, RIGHT, TOP }

enum class AudioPreset { OFF, FPS_FOOTSTEP, BR_GUNFIRE_DAMPER, RPG_ORCHESTRAL, CUSTOM }

enum class VoicePreset { ORIGINAL, CYBORG, DEEP_TITAN, HELIUM, ANIME_GIRL, WALKIE_TALKIE }

/** Virtual turbo fan (Phase 2). maxRpm drives the HUD turbine; the real cooling actions run in every mode but OFF. */
enum class FanMode(val label: String, val maxRpm: Int) {
    OFF("Off", 0),
    AUTO_THERMAL("Auto thermal", 12_000),
    SMART_COOL("Smart cool", 16_000),
    MAX_CYCLONE("Max 20,000 RPM", 20_000)
}

/** Stable ids for sidebar tools (used for ordering / visibility in the customizer). */
object ToolIds {
    val ALL = listOf(
        "game_mode", "boost", "freeze", "dns", "refresh", "downscale", "crosshair", "pill",
        "filter", "brightness", "edge_guard", "pointer", "macro", "audio", "voice",
        "timers", "danmaku", "afk", "turbo",
        // Phase 3 (landscape HUD / system tools)
        "shot", "record", "cast", "kbm", "calls", "console",
        // Phase 3 (HyperLab)
        "lab", "replay",
        // UI redesign part 3: opens the slide bar
        "slidebar"
    )

    /**
     * Tools that moved out of the HUD into the slide bar (UI redesign part 3): All apps, Mini browser, Calculator,
     * Quick notes and Chat apps. Saved tool orders, hidden lists and rail lists are cleaned of these ids on load.
     */
    val MOVED_TO_SLIDE_BAR = listOf("apps", "browser", "calculator", "notes", "social")
}

// ───────────────────────────── Per-feature configs ─────────────────────────────

data class CrosshairConfig(
    val enabled: Boolean = false,
    val shape: CrosshairShape = CrosshairShape.CLASSIC_CROSS,
    val sizePx: Int = 24,          // 4..80
    val strokePx: Int = 2,         // 1..10
    val gapPx: Int = 4,            // 0..30
    val outlinePx: Int = 1,        // 0..4
    val opacityPct: Int = 100,     // 10..100
    val colorHex: String = "#00FF66",
    val invertedOutline: Boolean = false,
    val chroma: Boolean = false,
    val tapExpansion: Boolean = false,
    val offsetX: Int = 0,          // micro-calibration, px
    val offsetY: Int = 0
)

data class EdgeGuardConfig(
    val enabled: Boolean = false,
    val leftPx: Int = 0,           // 0..120
    val rightPx: Int = 0,
    val topPx: Int = 0,
    val bottomPx: Int = 0,
    val showCalibration: Boolean = false
)

data class VisualFilterConfig(
    val enabled: Boolean = false,
    val shadowBoostPct: Int = 0,      // black equalizer
    val saturationPct: Int = 100,
    val warmthPct: Int = 50,          // 0 cool .. 100 warm
    val redPct: Int = 100,
    val greenPct: Int = 100,
    val bluePct: Int = 100,
    val extraDimPct: Int = 0,         // 0..85 black veil
    val brightnessLock: Boolean = false,
    val brightnessLevel: Int = 128    // 0..255
)

data class AudioConfig(
    val preset: AudioPreset = AudioPreset.OFF,
    val preampDb: Float = 0f,
    val bandGainsDb: List<Float> = List(10) { 0f },
    val bassBoost: Int = 0,           // 0..1000
    val virtualizer: Int = 0,         // 0..1000
    val loudnessMb: Int = 0,          // millibels
    val voice: VoicePreset = VoicePreset.ORIGINAL
)

data class MacroPoint(val x: Float = 0.5f, val y: Float = 0.5f) // fractions of the screen

data class MacroConfig(
    val enabled: Boolean = false,
    val points: List<MacroPoint> = listOf(MacroPoint()),   // 1 or 3 points
    val intervalMs: Int = 200,       // 50..5000
    val tapDurationMs: Int = 40,
    // Added in Phase 5 (default-valued, so older profiles still load)
    val maxTaps: Int = 0,            // 0 = run until stopped
    val controlX: Int = -1,          // Play/Pause pill position in px, -1 = default spot
    val controlY: Int = -1
)

data class PillConfig(
    val enabled: Boolean = false,
    val layout: PillLayout = PillLayout.HORIZONTAL,
    val showFps: Boolean = true,
    val showCpu: Boolean = false,
    val showCoreGhz: Boolean = false,
    val showRam: Boolean = false,
    val showTemp: Boolean = true,
    val showPing: Boolean = true,
    val showBattery: Boolean = false,
    val showClock: Boolean = false,
    val textSizeSp: Int = 12,        // 8..16
    val textColorHex: String = "#FFFFFF",
    val dynamicFpsColor: Boolean = true,
    val bgAlphaPct: Int = 60,
    val posX: Int = 24,
    val posY: Int = 80,
    val pinned: Boolean = false      // Phase 4: true = position locked (long-press the pill to toggle)
)

// ───────────────────────────── Phase 5 configs ─────────────────────────────

/** One of the 4 floating cooldown timers. Duration lives in GameProfile.cooldownSeconds[index]. */
data class TimerSlot(
    val label: String = "",
    val enabled: Boolean = false,
    val x: Int = -1,                 // px, -1 = default spot
    val y: Int = -1
)

data class MicroConfig(
    val timers: List<TimerSlot> = List(4) { TimerSlot() },
    val timerBeep: Boolean = true,
    val timerVibrate: Boolean = true,
    val afkBlockTouch: Boolean = true,   // false = touches pass through to the game (needed for the auto tapper)
    val afkShowStats: Boolean = true,
    val browserHome: String = ""         // "" = the first preset for this game
)

/** Notification bullet ticker. Global: the same look and whitelist for every game. */
data class DanmakuConfig(
    val enabled: Boolean = false,
    val speedDpPerSec: Int = 140,    // 60..400
    val fontSp: Int = 14,            // 10..24
    val lanes: Int = 3,              // 1..5
    val textAlphaPct: Int = 100,     // 30..100
    val topOffsetDp: Int = 24,       // 0..200
    val showAppName: Boolean = true,
    val whitelist: List<String> = emptyList(),   // empty = every app
    val blockMode: Int = 0,          // 0 = off, 1 = Do Not Disturb (priority only), 2 = Do Not Disturb (alarms only)
    val snoozeOriginals: Boolean = false
)

// ───────────────────────────── Notification edge lighting (UI redesign, part 1) ─────────────────────────────

/** Colour source of the notification edge light. */
enum class EdgePalette { APP_COLOR, RAINBOW, AURORA, SUNSET, REDMAGIC, CYCLE, FIXED }

/** How the light moves: FLOW = two comets circling the screen, BREATHE = a soft full ring, PULSE = two quick flashes. */
enum class EdgeStyle { FLOW, BREATHE, PULSE }

/**
 * The light that runs around the screen edge whenever a notification arrives (it no longer needs the danmaku ticker).
 * Everything is default-valued so older global.json files still load.
 */
data class EdgeLightConfig(
    val enabled: Boolean = true,
    val palette: EdgePalette = EdgePalette.APP_COLOR,
    val style: EdgeStyle = EdgeStyle.FLOW,
    val fixedHex: String = "#4C8DFF",
    val thicknessDp: Int = 4,        // 2..10
    val intensityPct: Int = 90,      // 30..100
    val durationMs: Int = 2600,      // 1200..6000
    val cornerDp: Int = 0,           // 0 = follow the screen's own corners (Android 12+), else 10..60 dp
    val everywhere: Boolean = true   // also light the edge outside games (home screen, other apps)
)

// ───────────────────────────── Phase 2 config ─────────────────────────────

/** Per-game settings of the Phase 2 engines (FPS unlocker, Wild Boost, fan, charge separation, battery saver). */
data class TurboConfig(
    val unlockFps: Int = 0,                       // 0 = off, else 90 / 120 / 144 ... (5-layer FPS override)
    val motionSmoothing: Boolean = false,         // lock the panel to its maximum rate + SurfaceFlinger pacing
    val bfiPct: Int = 0,                          // 0 = off, 10..60 = black-frame insertion strength (needs >= 90 Hz)
    val wildBoost: Boolean = false,               // CustomWildBoostEngine on while the game runs
    val diablo: Boolean = false,                  // Wild Boost + thermal API override (apps are told the phone is cool)
    val fan: FanMode = FanMode.OFF,
    val chargeSeparation: Boolean = false,        // stop charging while this game runs (hardware node, or software fallback)
    val chargeFloorPct: Int = 20,                 // charging resumes below this battery level
    val softwareUnplugFallback: Boolean = true,   // allow `cmd battery unplug` when no hardware charge node is writable
    val nativeBatterySaver: Boolean = false,      // switch the phone's real Battery Saver on while this game runs
    val thermalCutoffC: Int = 41                  // battery temperature that triggers automatic thermal protection
)

// ───────────────────────────── Phase 3 configs ─────────────────────────────

/** Look and behaviour of the landscape dual-wing HUD. */
data class HudLayoutConfig(
    val mode: Int = 0,               // 0 = automatic (wings in landscape, sidebar in portrait), 1 = always wings, 2 = always sidebar
    val scrimPct: Int = 38,          // 0..80, dim layer behind the wings
    val wingWidthDp: Int = 300,      // 240..380
    val cubeFace: Int = 0,           // last Energy Cube face shown (0..3)
    val controllerNav: Boolean = true, // while the HUD is open, take focus if a gamepad / keyboard is connected so D-pad and buttons work
    // Added in the UI redesign (part 2). Default-valued, so older config files still load.
    val railItems: List<String> = listOf("boost", "pill", "crosshair", "danmaku", "edge_guard", "shot"), // quick-toggle rail, top to bottom
    val hintMode: Int = 0,           // controller key hints strip: 0 = auto (only with a gamepad / keyboard), 1 = always, 2 = never
    val centerTab: Int = 0           // last centre tab: 0 = Dashboard, 1 = All tools
)

/** What the slide bar dock can hold, top to bottom. */
object SlideItemIds {
    const val APPS = "apps"
    const val CHAT = "chat"
    const val BROWSER = "browser"
    const val NOTES = "notes"
    const val CALC = "calc"
    val ALL = listOf(APPS, CHAT, BROWSER, NOTES, CALC)
}

/** HyperOS Game Turbo style slide bar (UI redesign part 3). Default-valued, so older config files still load. */
data class SlideBarConfig(
    val enabled: Boolean = true,
    val side: EdgeSide = EdgeSide.RIGHT,     // LEFT or RIGHT (TOP is treated as RIGHT)
    val offsetDp: Int = 120,                 // where the edge tab sits along the edge
    val items: List<String> = SlideItemIds.ALL,
    val showPinned: Boolean = true,          // pinned apps (long-press an app in the Apps page) sit under the dock buttons
    val pinnedCount: Int = 4,                // 0..6
    val closeOnLaunch: Boolean = true,       // close the slide bar once an app or a mini window is opened
    val flyoutWidthDp: Int = 320,            // 260..400
    val idleAlphaPct: Int = 45               // edge tab opacity when idle, 10..100
)

/** In-game incoming call banner. */
data class CallConfig(
    val bannerEnabled: Boolean = true,
    val speakerOnAnswer: Boolean = true,
    val bannerTopDp: Int = 6          // distance from the top edge, draggable
)

/** All-apps floating launcher. */
data class AppsConfig(
    val widthPct: Int = 45,           // floating window size as a percentage of the screen, landscape width
    val heightPct: Int = 85,
    val pinned: List<String> = emptyList(),
    val showSystem: Boolean = true
)

/** Hold Volume Up + Volume Down to open the HUD from anywhere (virtual hardware slider). */
data class ChordConfig(
    val enabled: Boolean = true,
    val holdMs: Int = 1200            // 600..3000
)

/** What the Quick Settings "Competitive Mode" tile does. */
data class CompetitiveConfig(
    val forceLandscape: Boolean = true,
    val wildBoost: Boolean = true,
    val diablo: Boolean = false,
    val openLobby: Boolean = true,
    val sound: Boolean = true,
    val haptic: Boolean = true
)

/** One keyboard key (negative codes are mouse buttons: -1 left, -2 right, -3 middle) mapped to a screen point. */
data class KbmKeyNode(
    val keyCode: Int = 0,
    val x: Float = 0.5f,              // fraction of the screen width
    val y: Float = 0.5f,              // fraction of the screen height
    val hold: Boolean = false,        // false = tap on press, true = finger stays down while the key is held
    val label: String = ""
)

/** Keyboard and mouse mapper for one game. WASD drives a virtual joystick, other keys press screen points. */
data class KbmConfig(
    val enabled: Boolean = false,
    val joystick: Boolean = true,
    val joyX: Float = 0.17f,
    val joyY: Float = 0.72f,
    val joyRadius: Float = 0.10f,     // fraction of the screen height
    val upKey: Int = 51,              // W
    val leftKey: Int = 29,            // A
    val downKey: Int = 47,            // S
    val rightKey: Int = 32,           // D
    val nodes: List<KbmKeyNode> = emptyList()
)

// ───────────────────────────── Game profile ─────────────────────────────

data class GameProfile(
    val packageName: String = "",
    val label: String = "",

    // FPS booster
    val gameMode: GameModeLevel = GameModeLevel.PERFORMANCE,
    val downscale: Float? = null,        // null = disabled, else 0.5..0.9
    val targetFps: Int = 0,              // 0 = disabled; 30/45/60/90/120/144
    val fpsCapViaDisplay: Boolean = true, // also lock the panel refresh rate so the cap holds in every game
    val refreshHz: Int = 0,              // 0 = untouched, -1 = max supported, else Hz
    val precompile: PrecompileMode = PrecompileMode.NONE,
    val trimCachesOnLaunch: Boolean = false,

    // Background control
    val freezeOnLaunch: Boolean = true,
    val blockBackgroundData: Boolean = true,
    val pauseSync: Boolean = true,

    // Network
    val dns: DnsPreset = DnsPreset.NO_CHANGE,
    val pingTargetIndex: Int = 0,

    // Compositor / input
    val zeroAnimation: Boolean = true,
    val pointerSpeed: Int? = null,       // -7..7, null = untouched (mouse / trackpad only)
    val longPressMs: Int? = null,        // touch long-press delay, null = untouched
    val touchSensitivity: Boolean = false, // OEM high touch sensitivity (Samsung key), only where it exists

    // HUD tools
    val crosshair: CrosshairConfig = CrosshairConfig(),
    val edgeGuard: EdgeGuardConfig = EdgeGuardConfig(),
    val filter: VisualFilterConfig = VisualFilterConfig(),
    val audio: AudioConfig = AudioConfig(),
    val macro: MacroConfig = MacroConfig(),
    val pill: PillConfig = PillConfig(),
    val cooldownSeconds: List<Int> = listOf(60, 120, 300, 600),
    val micro: MicroConfig = MicroConfig(),
    val turbo: TurboConfig = TurboConfig(),      // Phase 2
    val kbm: KbmConfig = KbmConfig(),            // Phase 3

    // Automation
    val autoRestoreDelaySec: Int? = null, // null = use GlobalSettings.restoreDelaySec
    val enabled: Boolean = true,
    val updatedAt: Long = 0L
)

// ───────────────────────────── Global settings ─────────────────────────────

data class PingTarget(val name: String = "", val host: String = "", val port: Int = 443)

val DEFAULT_PING_TARGETS = listOf(
    PingTarget("Asia / India (Mumbai)", "dynamodb.ap-south-1.amazonaws.com", 443),
    PingTarget("Europe (Frankfurt)", "dynamodb.eu-central-1.amazonaws.com", 443),
    PingTarget("North America (Virginia)", "dynamodb.us-east-1.amazonaws.com", 443)
)

data class SidebarConfig(
    val opacityPct: Int = 85,            // 20..100
    val cornerRadiusDp: Int = 20,        // 0..32
    val primaryHex: String = "#00E5FF",
    val secondaryHex: String = "#FF6D00",
    val toolOrder: List<String> = ToolIds.ALL,
    val hiddenTools: List<String> = emptyList(),
    val useCustomAccent: Boolean = false   // Phase 3: false = theme palette, true = primaryHex/secondaryHex
)

data class HandleConfig(
    val side: EdgeSide = EdgeSide.LEFT,
    val offsetDp: Int = 200,
    val widthDp: Int = 8,                // 4..16
    val heightDp: Int = 96,              // 40..160
    val colorHex: String = "#00E5FF",
    val autoHideAlphaPct: Int = 40
)

data class GlobalSettings(
    val theme: ThemeId = ThemeId.HYPEROS_WILD_BOOST,
    val sidebar: SidebarConfig = SidebarConfig(),
    val handle: HandleConfig = HandleConfig(),
    val freezeList: List<String> = emptyList(),
    val tempAlertC: Int = 42,
    val restoreDelaySec: Int = 15,
    val autoDetectGames: Boolean = true,
    val pingTargets: List<PingTarget> = DEFAULT_PING_TARGETS,
    val pingIntervalMs: Long = 1000L,
    val danmaku: DanmakuConfig = DanmakuConfig(),
    // Added in Phase 6 (default-valued, so older config files still load)
    val hubView: Int = 0,                         // Game Space layout: 0 = 3D carousel, 1 = grid
    val hubSort: Int = 0,                         // 0 = recently played, 1 = name, 2 = play time this week
    val hubHidden: List<String> = emptyList(),    // games the user removed from the Game Space list
    val watcherAutoStart: Boolean = true,         // start the game watcher whenever the hub opens
    // Added in Phase 2
    val wildBoostWhitelist: List<String> = emptyList(),  // apps the Wild Boost RAM cleaner must never stop
    // Added in Phase 3
    val hudLayout: HudLayoutConfig = HudLayoutConfig(),
    val calls: CallConfig = CallConfig(),
    val apps: AppsConfig = AppsConfig(),
    val chord: ChordConfig = ChordConfig(),
    val competitive: CompetitiveConfig = CompetitiveConfig(),
    // Added in the UI redesign (part 1)
    val edgeLight: EdgeLightConfig = EdgeLightConfig(),
    // Added in the UI redesign (part 3)
    val slideBar: SlideBarConfig = SlideBarConfig()
) {
    /**
     * Drops ids that no longer exist (tools that moved into the slide bar) from every saved list, so an old
     * config file never points at a missing tool. Nothing else changes.
     */
    fun migrated(): GlobalSettings {
        val gone = ToolIds.MOVED_TO_SLIDE_BAR.toSet()
        val valid = ToolIds.ALL.toSet()
        val order = sidebar.toolOrder.filter { it in valid }.distinct()
        val hidden = sidebar.hiddenTools.filter { it in valid }.distinct()
        val rail = hudLayout.railItems.filter { it !in gone }
        val items = slideBar.items.filter { it in SlideItemIds.ALL }.distinct()
        val side = if (slideBar.side == EdgeSide.TOP) EdgeSide.RIGHT else slideBar.side
        if (order == sidebar.toolOrder && hidden == sidebar.hiddenTools && rail == hudLayout.railItems &&
            items == slideBar.items && side == slideBar.side
        ) return this
        return copy(
            sidebar = sidebar.copy(toolOrder = order + ToolIds.ALL.filter { it !in order }, hiddenTools = hidden),
            hudLayout = hudLayout.copy(railItems = rail),
            slideBar = slideBar.copy(items = items, side = side)
        )
    }

    fun restoreDelayFor(p: GameProfile?): Int = (p?.autoRestoreDelaySec ?: restoreDelaySec).coerceIn(0, 600)
}

// ───────────────────────────── Restore snapshot ─────────────────────────────

/** One setting captured before we changed it. original == null means "was unset". */
data class SettingBackup(val ns: String = "", val key: String = "", val original: String? = null)

/**
 * Everything needed to put the phone back exactly as it was. Persisted to disk BEFORE any change is
 * applied, so restoration still works after the app process is killed or the phone reboots.
 */
data class SystemSnapshot(
    val gamePackage: String = "",
    val takenAt: Long = 0L,
    val settings: List<SettingBackup> = emptyList(),
    val restrictBackground: Boolean? = null,
    val masterSync: Boolean? = null,
    val frozenPackages: List<String> = emptyList(),   // RUN_ANY_IN_BACKGROUND set to ignore by us
    val gameConfigChanged: Boolean = false,
    val availMemBeforeMb: Long = 0L,
    // Added in Phase 2 (all default-valued, so Phase 1 snapshots still load)
    val gameConfigPackages: List<String> = emptyList(),          // packages given a downscale/fps override
    val gameModeOriginals: Map<String, String> = emptyMap(),     // pkg -> original game mode (battery/standard/performance)
    val restrictWhitelistUid: Int = -1,                          // uid we whitelisted while Data Saver was forced on
    val filterMatrixActive: Boolean = false                      // SurfaceFlinger colour matrix installed by Visual filter
)
