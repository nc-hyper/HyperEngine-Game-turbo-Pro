package com.hyperengine.gameturbo.core

import android.content.Context
import android.graphics.Point
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.hyperengine.gameturbo.data.AutoTouchScript
import com.hyperengine.gameturbo.data.HumanizerConfig
import com.hyperengine.gameturbo.data.LoopMode
import com.hyperengine.gameturbo.data.MacroEventType
import com.hyperengine.gameturbo.data.NodeKind
import com.hyperengine.gameturbo.data.TimingConfig
import com.hyperengine.gameturbo.data.TouchNode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.yield
import java.util.concurrent.ThreadLocalRandom
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** Live numbers for the dock and the HUD. Collect [AutoTouchEngine.state]. */
data class AutoTouchState(
    val continuousRunning: Boolean = false,
    val holding: Boolean = false,
    val macroPlaying: Boolean = false,
    val taps: Long = 0L,
    val cycles: Long = 0L,
    val elapsedMs: Long = 0L,
    val engine: TouchEngine = TouchEngine.NONE,
    val message: String = ""
) {
    val anyRunning: Boolean get() = continuousRunning || holding || macroPlaying
}

/** Random offset and interval jitter for the anti-detection humanizer. */
internal object Humanizer {

    /** A point chosen uniformly inside a circle of radius `offsetPx` around (x, y), kept on screen. */
    fun offset(x: Float, y: Float, h: HumanizerConfig, size: Point): Pair<Float, Float> {
        if (!h.enabled || h.offsetPx <= 0) return clampToScreen(x, y, size)
        val r = ThreadLocalRandom.current()
        val radius = h.offsetPx * sqrt(r.nextFloat())
        val angle = r.nextDouble() * 2.0 * Math.PI
        return clampToScreen(x + (radius * cos(angle)).toFloat(), y + (radius * sin(angle)).toFloat(), size)
    }

    /** Random milliseconds in [-ms, +ms]. */
    fun jitter(ms: Int): Long = if (ms <= 0) 0L else ThreadLocalRandom.current().nextInt(-ms, ms + 1).toLong()

    private fun clampToScreen(x: Float, y: Float, size: Point): Pair<Float, Float> =
        Pair(x.coerceIn(0f, (size.x - 1).toFloat()), y.coerceIn(0f, (size.y - 1).toFloat()))
}

/**
 * Runs an [AutoTouchScript] (Realme / OPPO Game Assistant style) through [MultiTouchInjector].
 *
 * THREE TRIGGER MODES (all share one script, so a layout can hold nodes AND recorded commands):
 *
 *  1. Continuous: [startContinuous] loops the enabled nodes in order (taps and swipes), each with its own
 *     speed when the node overrides it, until [stop], the loop count, or the countdown timer ends it.
 *  2. Hold-to-rapid-fire: [holdStart] hammers one node (normally point 1 over the Fire button) at the script's
 *     CPS or interval for exactly as long as the trigger is held; [holdStop] ends it on the same frame.
 *  3. One-tap combo: [playMacro] replays a recorded multi-touch command at its recorded timings, with each
 *     recorded finger on its own synthetic finger, so a Crouch + Scope + Fire combo is really simultaneous.
 *
 * TIMING: CPS 1..40 or a custom interval 20..10000 ms, hold 10..5000 ms, jitter on the interval and a random
 * point inside the target circle (humanizer). The script is read again on every cycle, so dragging a point or
 * changing a slider while it runs takes effect immediately.
 *
 * The humanizer only breaks up a perfectly regular pattern. It does not make automation invisible: many
 * online games forbid auto-tapping and ban for it. Use it where the game allows it.
 */
class AutoTouchEngine(context: Context, private val touch: MultiTouchInjector) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val main = Handler(Looper.getMainLooper())

    private val _state = MutableStateFlow(AutoTouchState())
    val state: StateFlow<AutoTouchState> = _state.asStateFlow()

    @Volatile
    private var script: AutoTouchScript = AutoTouchScript().sanitized()

    /** Called on the main thread when the continuous loop starts or stops (drives the Play / Pause icon). */
    @Volatile
    var onContinuousChanged: ((Boolean) -> Unit)? = null

    @Volatile
    private var loopJob: Job? = null

    @Volatile
    private var holdJob: Job? = null

    @Volatile
    private var macroJob: Job? = null

    private var lastEmit = 0L

    // ---------------------------------------------------------------------------------------------
    // Script
    // ---------------------------------------------------------------------------------------------

    /** Hands the engine the layout to run. Safe while running: the next cycle uses it. */
    fun load(s: AutoTouchScript) {
        script = s.sanitized()
    }

    fun currentScript(): AutoTouchScript = script

    val isContinuousRunning: Boolean get() = loopJob?.isActive == true
    val isHolding: Boolean get() = holdJob?.isActive == true
    val isMacroPlaying: Boolean get() = macroJob?.isActive == true

    // ---------------------------------------------------------------------------------------------
    // Mode 1: continuous
    // ---------------------------------------------------------------------------------------------

    /** Starts the loop. Returns an error message to show the user, or null when it started (or already runs). */
    @Synchronized
    fun startContinuous(): String? {
        if (script.nodes.none { it.enabled }) return "Add at least one tap point first"
        if (touch.activeEngine() == TouchEngine.NONE) return NO_ENGINE
        if (loopJob?.isActive == true) return null

        notifyContinuous(true)
        loopJob = scope.launch { runLoop() }
        return null
    }

    @Synchronized
    fun stopContinuous() {
        val j = loopJob ?: return
        loopJob = null
        j.cancel()
    }

    fun toggleContinuous(): String? =
        if (isContinuousRunning) {
            stopContinuous()
            null
        } else {
            startContinuous()
        }

    private suspend fun runLoop() {
        val me = currentCoroutineContext()[Job]
        val startedAt = SystemClock.elapsedRealtime()
        var cycles = 0L
        var taps = 0L
        var failures = 0
        var reason = "Stopped"
        _state.update { it.copy(continuousRunning = true, taps = 0L, cycles = 0L, elapsedMs = 0L, message = "Running") }
        try {
            loop@ while (me == null || me.isActive) {
                val s = script
                val nodes = s.nodes.filter { it.enabled }
                if (nodes.isEmpty()) {
                    reason = "No tap points"
                    break@loop
                }
                val size = touch.screenSize()
                for (n in nodes) {
                    if (me != null && !me.isActive) break@loop
                    val t = n.timing ?: s.timing
                    val t0 = SystemClock.uptimeMillis()
                    if (fireNode(n, t, size)) {
                        taps++
                        failures = 0
                    } else {
                        failures++
                        if (failures >= MAX_FAILURES) {
                            reason = "The system rejected the touch $MAX_FAILURES times in a row (is the screen on?)"
                            break@loop
                        }
                    }
                    val elapsed = SystemClock.elapsedRealtime() - startedAt
                    emit(taps, cycles, elapsed, true)
                    if (s.timing.loopMode == LoopMode.TIMER && elapsed >= s.timing.timerSeconds * 1000L) {
                        reason = "Finished: timer ended"
                        break@loop
                    }
                    pause(t, t0)
                }
                cycles++
                val s2 = script
                if (s2.timing.loopMode == LoopMode.COUNT && cycles >= s2.timing.loopCount) {
                    reason = "Finished: ${s2.timing.loopCount} cycles"
                    break@loop
                }
            }
        } finally {
            val elapsed = SystemClock.elapsedRealtime() - startedAt
            touch.releaseOwner(OWNER_AUTO)
            val current = loopJob
            if (current == null || current === me) {
                loopJob = null
                _state.update {
                    it.copy(
                        continuousRunning = false, taps = taps, cycles = cycles,
                        elapsedMs = elapsed, message = reason, engine = touch.activeEngine()
                    )
                }
                notifyContinuous(false)
            }
        }
    }

    // ---------------------------------------------------------------------------------------------
    // Mode 2: hold to rapid fire
    // ---------------------------------------------------------------------------------------------

    /**
     * Starts hammering node [nodeId] (default point 1) and keeps going until [holdStop]. Returns an error
     * message, or null. A watchdog ends a trigger that never reports its release after [MAX_HOLD_MS].
     */
    @Synchronized
    fun holdStart(nodeId: Int = 1): String? {
        val s = script
        val node = s.nodes.firstOrNull { it.id == nodeId && it.enabled }
            ?: return "Place tap point $nodeId over the button to fire first"
        if (touch.activeEngine() == TouchEngine.NONE) return NO_ENGINE
        if (holdJob?.isActive == true) return null

        val id = node.id
        holdJob = scope.launch { runHold(id) }
        return null
    }

    /** The trigger was released: stop on the spot. */
    @Synchronized
    fun holdStop() {
        val j = holdJob ?: return
        holdJob = null
        j.cancel()
    }

    private suspend fun runHold(nodeId: Int) {
        val me = currentCoroutineContext()[Job]
        val startedAt = SystemClock.elapsedRealtime()
        var taps = 0L
        var failures = 0
        var reason = "Released"
        _state.update { it.copy(holding = true, message = "Firing") }
        try {
            while (me == null || me.isActive) {
                val elapsed = SystemClock.elapsedRealtime() - startedAt
                if (elapsed >= MAX_HOLD_MS) {
                    reason = "Trigger held too long, stopped for safety"
                    break
                }
                val s = script
                val n = s.nodes.firstOrNull { it.id == nodeId && it.enabled }
                if (n == null) {
                    reason = "The fire point was removed"
                    break
                }
                val t0 = SystemClock.uptimeMillis()
                // rapid fire always taps, even when the node was drawn as a swipe
                if (fireNode(n.copy(kind = NodeKind.TAP), n.timing ?: s.timing, touch.screenSize())) {
                    taps++
                    failures = 0
                } else {
                    failures++
                    if (failures >= MAX_FAILURES) {
                        reason = "The system rejected the touch $MAX_FAILURES times in a row"
                        break
                    }
                }
                emit(taps, 0L, elapsed, false)
                pause(n.timing ?: s.timing, t0)
            }
        } finally {
            touch.releaseOwner(OWNER_AUTO)
            val current = holdJob
            if (current == null || current === me) {
                holdJob = null
                _state.update { it.copy(holding = false, message = reason) }
            }
        }
    }

    // ---------------------------------------------------------------------------------------------
    // Mode 3: one-tap combo macro
    // ---------------------------------------------------------------------------------------------

    /** Replays the recorded command [macroId] once. Re-triggering while it plays is ignored. */
    @Synchronized
    fun playMacro(macroId: String?): String? {
        val macro = script.macros.firstOrNull { it.id == macroId } ?: return "That command no longer exists"
        if (macro.events.isEmpty()) return "That command is empty, record it again"
        if (touch.activeEngine() == TouchEngine.NONE) return NO_ENGINE
        if (macroJob?.isActive == true) return null

        val events = macro.events.sortedBy { it.tMs }
        macroJob = scope.launch { runMacro(macro.name, events) }
        return null
    }

    @Synchronized
    fun stopMacro() {
        val j = macroJob ?: return
        macroJob = null
        j.cancel()
    }

    private suspend fun runMacro(name: String, events: List<com.hyperengine.gameturbo.data.MacroEvent>) {
        val me = currentCoroutineContext()[Job]
        val handles = arrayOfNulls<TouchHandle>(MACRO_FINGERS)
        val size = touch.screenSize()
        val t0 = SystemClock.uptimeMillis()
        var reason = "Command finished"
        _state.update { it.copy(macroPlaying = true, message = "Playing $name") }
        try {
            for (e in events) {
                val wait = e.tMs - (SystemClock.uptimeMillis() - t0)
                if (wait > 1L) delay(wait)
                if (me != null && !me.isActive) break
                val slot = e.slot.coerceIn(0, MACRO_FINGERS - 1)
                val x = e.x * size.x
                val y = e.y * size.y
                when (e.type) {
                    MacroEventType.DOWN -> {
                        handles[slot]?.let { touch.endHold(it) }
                        handles[slot] = touch.beginHold(x, y, OWNER_MACRO)
                        if (handles[slot] == null) reason = "No free finger for the command"
                    }
                    MacroEventType.MOVE -> handles[slot]?.let { touch.moveHold(it, x, y) }
                    MacroEventType.UP -> {
                        handles[slot]?.let { touch.endHold(it) }
                        handles[slot] = null
                    }
                }
            }
        } finally {
            // a cancelled or failed command must never leave a finger stuck on the screen
            for (h in handles) if (h != null) touch.endHold(h)
            val current = macroJob
            if (current == null || current === me) {
                macroJob = null
                _state.update { it.copy(macroPlaying = false, message = reason) }
            }
        }
    }

    // ---------------------------------------------------------------------------------------------
    // Stop everything
    // ---------------------------------------------------------------------------------------------

    /** Stops all three modes and lifts every finger this engine put down. */
    fun stopAll() {
        stopContinuous()
        holdStop()
        stopMacro()
        touch.releaseOwner(OWNER_AUTO)
        touch.releaseOwner(OWNER_MACRO)
    }

    fun refreshEngine() {
        _state.update { it.copy(engine = touch.refreshStatus().engine) }
    }

    // ---------------------------------------------------------------------------------------------
    // Shared helpers
    // ---------------------------------------------------------------------------------------------

    private suspend fun fireNode(n: TouchNode, t: TimingConfig, size: Point): Boolean {
        val h = t.humanizer
        val (px, py) = Humanizer.offset(n.x * size.x, n.y * size.y, h, size)
        return if (n.kind == NodeKind.SWIPE) {
            val (ex, ey) = Humanizer.offset(n.endX * size.x, n.endY * size.y, h, size)
            touch.swipe(px, py, ex, ey, n.swipeDurationMs.toLong(), OWNER_AUTO)
        } else {
            touch.tap(px, py, t.holdMs.toLong(), OWNER_AUTO)
        }
    }

    /** Waits out the rest of the interval (CPS or custom, plus jitter), measured from [startedAt]. */
    private suspend fun pause(t: TimingConfig, startedAt: Long) {
        var interval = t.effectiveIntervalMs().toLong()
        val h = t.humanizer
        if (h.enabled) interval += Humanizer.jitter(h.jitterMs)
        interval = interval.coerceAtLeast(TimingConfig.INTERVAL_MIN_MS.toLong())
        val wait = interval - (SystemClock.uptimeMillis() - startedAt)
        if (wait > 0L) delay(wait) else yield()
    }

    /** Publishes counters at most ~12 times per second so 40 CPS does not flood the UI. */
    private fun emit(taps: Long, cycles: Long, elapsed: Long, continuous: Boolean) {
        val now = SystemClock.uptimeMillis()
        if (now - lastEmit < EMIT_EVERY_MS) return
        lastEmit = now
        _state.update {
            if (continuous) it.copy(taps = taps, cycles = cycles, elapsedMs = elapsed, engine = touch.activeEngine())
            else it.copy(taps = taps, elapsedMs = elapsed, engine = touch.activeEngine())
        }
    }

    private fun notifyContinuous(on: Boolean) {
        main.post { runCatching { onContinuousChanged?.invoke(on) } }
    }

    companion object {
        /** Owner tags: they decide which fingers [stopAll] lifts. */
        const val OWNER_AUTO = "auto"
        const val OWNER_MACRO = "macro"

        const val NO_ENGINE = "No touch engine: start Shizuku or enable the accessibility service"

        private const val MAX_FAILURES = 5
        private const val MAX_HOLD_MS = 120_000L
        private const val MACRO_FINGERS = 4
        private const val EMIT_EVERY_MS = 80L
    }
}
