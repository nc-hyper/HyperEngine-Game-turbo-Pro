package com.hyperengine.gameturbo.ui

import android.content.Context
import android.view.WindowManager
import com.hyperengine.gameturbo.core.SystemBridgeExecutor
import com.hyperengine.gameturbo.core.TelemetrySample
import com.hyperengine.gameturbo.data.GameProfile
import com.hyperengine.gameturbo.data.GlobalSettings
import com.hyperengine.gameturbo.data.GameProfileRepository
import com.hyperengine.gameturbo.data.TimerSlot

/**
 * Groups the Phase 5 gamer tools and keeps them in step with the game:
 *  - 4 floating cooldown timers            ([CooldownTimers])
 *  - Danmaku notification ticker           ([DanmakuTicker])
 *  - AFK black-screen lock                 ([AfkLock])
 *  - mini browser, calculator, notes       ([MiniWindowHost], opened from the slide bar)
 *  - chat apps in a floating / split window ([ChatLauncher], from the slide bar)
 *
 * Everything is removed when the game leaves the foreground. Main thread only.
 */
class MicroToolsManager(
    context: Context,
    wm: WindowManager,
    private val repo: GameProfileRepository,
    bridge: SystemBridgeExecutor
) {

    private val themeProvider: () -> HudTheme = { HudThemes.resolve(repo.global.value) }

    val timers = CooldownTimers(context, wm, themeProvider)
    val danmaku = DanmakuTicker(context, wm, bridge)
    val afk = AfkLock(context, wm, themeProvider)
    val windows = MiniWindowHost(context, wm, themeProvider)

    private var game: String? = null

    var onAttached: (() -> Unit)? = null
        set(v) {
            field = v
            timers.onAttached = v
            danmaku.onAttached = v
            afk.onAttached = v
            windows.onAttached = v
        }

    init {
        timers.onPositionSaved = { slot, x, y ->
            game?.let { g ->
                repo.update(g) { p ->
                    val list = MutableList(TIMER_SLOTS) { p.micro.timers.getOrNull(it) ?: TimerSlot() }
                    list[slot] = list[slot].copy(x = x, y = y)
                    p.copy(micro = p.micro.copy(timers = list))
                }
            }
        }
    }

    /** Browser window for [g]: remembers the home page in the game's profile. Returns true when it is open afterwards. */
    fun toggleBrowser(g: String): Boolean = windows.toggleBrowser(
        g, repo.profile(g)?.label.orEmpty(), (repo.profile(g) ?: GameProfile()).micro
    ) { url -> repo.update(g) { it.copy(micro = it.micro.copy(browserHome = url)) } }

    fun toggleCalculator(): Boolean = windows.toggleCalculator()

    fun toggleNotes(g: String): Boolean = windows.toggleNotes(g)

    /** Registers the sidebar tiles. A tile only shows once its tool is registered here. */
    fun registerTools() {
        ToolRegistry.register(TimersTool(timers))
        ToolRegistry.register(DanmakuTool(danmaku))
        ToolRegistry.register(AfkTool(afk))
    }

    fun show(pkg: String, profile: GameProfile, global: GlobalSettings) {
        if (game != null && game != pkg) closeAll()
        game = pkg
        timers.show(profile)
        danmaku.show(global.danmaku)
        danmaku.applyEdge(global.edgeLight)
    }

    fun apply(profile: GameProfile) {
        timers.apply(profile)
    }

    fun applyGlobal(global: GlobalSettings) {
        if (game != null) {
            danmaku.apply(global.danmaku)
            danmaku.applyEdge(global.edgeLight)
        }
    }

    fun onSample(s: TelemetrySample) {
        afk.onSample(s)
    }

    fun relayout() {
        timers.relayout()
        danmaku.relayout()
        afk.relayout()
        windows.relayout()
    }

    /** Game left the foreground: everything goes, Do Not Disturb is put back. */
    fun hide() {
        closeAll()
        game = null
    }

    fun recoverPending() {
        danmaku.recoverPending()
    }

    fun destroy() {
        hide()
        danmaku.destroy()
    }

    private fun closeAll() {
        windows.closeAll()
        afk.exit()
        timers.hide()
        danmaku.hide()
    }
}
