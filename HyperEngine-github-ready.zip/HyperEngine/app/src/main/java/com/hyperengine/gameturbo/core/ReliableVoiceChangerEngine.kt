package com.hyperengine.gameturbo.core

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.SystemClock
import com.hyperengine.gameturbo.HyperApp
import com.hyperengine.gameturbo.data.VoicePreset
import com.hyperengine.gameturbo.service.VoiceForegroundService
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.concurrent.thread
import kotlin.math.max
import kotlin.math.min

data class VoiceState(
    val busy: Boolean = false,
    val monitoring: Boolean = false,
    val message: String = "",
    val hasRecording: Boolean = false,
    val progressMs: Int = 0,
    /** The hardware-matched rate in use right now, 0 when idle. */
    val sampleRate: Int = 0,
    /** How many times the capture pipeline was rebuilt during this session. */
    val recoveries: Int = 0,
    /** True while Android is handing back silence instead of the microphone. */
    val micSilenced: Boolean = false
)

/** Kept so existing code (`VoiceStudio(ctx)`) compiles unchanged: the studio IS the reliable engine now. */
typealias VoiceStudio = ReliableVoiceChangerEngine

/**
 * Voice changer: 5-second recorder with playback, and a live monitor. Hardened against the ways it used to die.
 *
 *  1. Sample rate: never hard-coded. The hardware output rate (AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE) is tried
 *     first, then 48000, 44100, 32000 and 16000, and each candidate is checked against both AudioRecord and
 *     AudioTrack. A candidate that "looks" supported but fails to initialise is skipped. Buffers are sized from
 *     PROPERTY_OUTPUT_FRAMES_PER_BUFFER so reads match the audio DSP's own period.
 *  2. Mic lock and focus: before capture (shell only, rate limited) it allows RECORD_AUDIO, PLAY_AUDIO and
 *     TAKE_AUDIO_FOCUS for this app and grants the runtime permission. Capture runs under a foreground service of
 *     type microphone ([VoiceForegroundService]), because Android 11+ silences the mic of an app that is not in the
 *     foreground and that, not a bug in the DSP, is what "works, then goes quiet when the game opens" usually is.
 *     The AudioRecord is built with AudioRecord.Builder (VOICE_COMMUNICATION first, then MIC, VOICE_RECOGNITION,
 *     UNPROCESSED, CAMCORDER), playback uses USAGE_ASSISTANCE_ACCESSIBILITY + CONTENT_TYPE_SPEECH (the usages Android
 *     fades and mutes least when a game takes audio focus; falls back to USAGE_MEDIA), and a game taking audio focus
 *     never stops the loop.
 *  3. Self-recovering loop: every read is checked. ERROR_DEAD_OBJECT, ERROR_INVALID_OPERATION, other negative codes,
 *     zero-byte reads, and 300 ms of exact digital silence make the pipeline release and rebuild itself in 50 ms
 *     (on silence it also rotates to the next capture source). The selected effect is a field the loop reads on
 *     every block, so it survives a rebuild, even one that lands on a different sample rate.
 *
 * What none of this can do, and the UI says so: Android gives an app no way to inject audio into ANOTHER app's
 * microphone stream. This engine keeps the mic open and processes it for you to hear (headphones) or record; it does
 * not change what teammates hear in a game's own voice chat. And if a ROM refuses background capture outright, the
 * state reports [VoiceState.micSilenced] instead of pretending.
 */
class ReliableVoiceChangerEngine(context: Context) {

    private val ctx: Context = context.applicationContext
    private val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val _state = MutableStateFlow(VoiceState())
    val state: StateFlow<VoiceState> = _state.asStateFlow()

    @Volatile private var token = 0
    @Volatile private var recording: ShortArray? = null
    @Volatile private var recordingRate = 0
    @Volatile private var livePreset = VoicePreset.ORIGINAL
    private var bypassAt = 0L

    /** Changes the effect of a running live monitor immediately (also used to pick the effect before it starts). */
    fun setLivePreset(preset: VoicePreset) {
        livePreset = preset
    }

    fun micGranted(): Boolean =
        ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    @Suppress("DEPRECATION")
    fun headphonesConnected(): Boolean {
        val ok = setOf(
            AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
            AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
            AudioDeviceInfo.TYPE_BLUETOOTH_SCO, 26 /* TYPE_BLE_HEADSET */
        )
        return am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any { it.type in ok }
    }

    // =========================================================================================
    // Hardware negotiation
    // =========================================================================================

    /** Rates this device can both record and play, best first: hardware rate, then 48000, 44100, 32000, 16000. */
    fun candidateRates(): List<Int> {
        val native = am.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE)?.toIntOrNull()
        val usable = (listOfNotNull(native) + FALLBACK_RATES).distinct().filter {
            AudioRecord.getMinBufferSize(it, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT) > 0 &&
                AudioTrack.getMinBufferSize(it, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT) > 0
        }
        return usable.ifEmpty { listOf(48000) }
    }

    private fun framesPerBuffer(): Int =
        am.getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER)?.toIntOrNull()?.takeIf { it > 0 } ?: 256

    private class Mic(val record: AudioRecord, val rate: Int, val source: Int)

    private fun buildMic(rate: Int, source: Int): Mic? {
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) return null
        val bytes = max(max(min * 2, framesPerBuffer() * 2 * 4), 4096)
        val rec = try {
            AudioRecord.Builder()
                .setAudioSource(source)
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(rate)
                        .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                        .build()
                )
                .setBufferSizeInBytes(bytes)
                .build()
        } catch (_: Throwable) {
            return null
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            runCatching { rec.release() }
            return null
        }
        try {
            rec.startRecording()
        } catch (_: Throwable) {
            runCatching { rec.release() }
            return null
        }
        if (rec.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
            runCatching { rec.stop() }
            runCatching { rec.release() }
            return null
        }
        return Mic(rec, rate, source)
    }

    private fun attrs(usage: Int): AudioAttributes =
        AudioAttributes.Builder().setUsage(usage).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()

    private fun buildTrack(rate: Int, live: Boolean): AudioTrack {
        val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val bytes = max(max(min, framesPerBuffer() * 2 * 4), 4096)
        var last: Throwable? = null
        for (usage in intArrayOf(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY, AudioAttributes.USAGE_MEDIA)) {
            try {
                val b = AudioTrack.Builder()
                    .setAudioAttributes(attrs(usage))
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(rate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(bytes)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                if (live) b.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                val t = b.build()
                if (t.state == AudioTrack.STATE_INITIALIZED) return t
                runCatching { t.release() }
            } catch (e: Throwable) {
                last = e
            }
        }
        throw IllegalStateException("AudioTrack could not be created at $rate Hz", last)
    }

    // =========================================================================================
    // Mic lock / permission bypass (shell only)
    // =========================================================================================

    /**
     * Allows RECORD_AUDIO, PLAY_AUDIO and TAKE_AUDIO_FOCUS for this app and grants the runtime permission. Needs
     * Shizuku or root; without them it does nothing. Runs at most once per 10 minutes. Called from worker threads.
     */
    private fun prepareBypass() {
        val now = SystemClock.elapsedRealtime()
        if (bypassAt != 0L && now - bypassAt < BYPASS_EVERY_MS) return
        val bridge = HyperApp.instance.bridge
        if (!bridge.hasShell()) return
        runBlocking {
            withTimeoutOrNull(6_000L) {
                if (!micGranted()) bridge.grantRuntimePermission(Manifest.permission.RECORD_AUDIO)
                for (op in listOf("RECORD_AUDIO", "PLAY_AUDIO", "TAKE_AUDIO_FOCUS")) {
                    bridge.setAppOp(ctx.packageName, op, "allow")
                }
            }
        }
        bypassAt = now
    }

    /** Short transient focus while a test clip plays. A game taking focus afterwards never stops us. */
    private inner class FocusGuard {
        private var request: AudioFocusRequest? = null

        fun take() {
            runCatching {
                val r = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                    .setAudioAttributes(attrs(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY))
                    .setAcceptsDelayedFocusGain(false)
                    .setWillPauseWhenDucked(false)
                    .setOnAudioFocusChangeListener { }
                    .build()
                am.requestAudioFocus(r)
                request = r
            }
        }

        fun drop() {
            request?.let { runCatching { am.abandonAudioFocusRequest(it) } }
            request = null
        }
    }

    // =========================================================================================
    // The self-recovering capture pipe
    // =========================================================================================

    /**
     * A microphone that rebuilds itself. [read] returns the number of samples (> 0), 0 when nothing usable arrived
     * this turn (a rebuild ran, or is about to), or -1 when the session was stopped or it gave up.
     */
    private inner class Pipe(private val my: Int) {
        private val rates = candidateRates()
        private var rateIdx = 0
        private var srcIdx = 0
        private var mic: Mic? = null
        private var failStreak = 0
        private var quietSince = 0L
        private var quietStrikes = 0
        var rate = 0
            private set
        var recoveries = 0
            private set

        fun open(): Boolean {
            closeMic()
            for (ri in rates.indices) {
                val r = rates[(rateIdx + ri) % rates.size]
                for (si in SOURCES.indices) {
                    val src = SOURCES[(srcIdx + si) % SOURCES.size]
                    val m = buildMic(r, src) ?: continue
                    mic = m
                    rate = r
                    rateIdx = rates.indexOf(r).coerceAtLeast(0)
                    srcIdx = SOURCES.indexOf(src).coerceAtLeast(0)
                    return true
                }
            }
            return false
        }

        fun read(buf: ShortArray, len: Int): Int {
            if (my != token) return -1
            val m = mic ?: return rebuild("microphone closed", 0L)
            val n = try {
                m.record.read(buf, 0, len)
            } catch (_: Throwable) {
                AudioRecord.ERROR_DEAD_OBJECT
            }
            val now = SystemClock.elapsedRealtime()
            when {
                n > 0 -> {
                    failStreak = 0
                    if (isSilent(buf, n)) {
                        if (quietSince == 0L) {
                            quietSince = now
                        } else if (now - quietSince >= SILENCE_MS) {
                            quietSince = 0L
                            return silenceRebuild()
                        }
                    } else {
                        quietSince = 0L
                        if (quietStrikes > 0) {
                            quietStrikes = 0
                            _state.update { it.copy(micSilenced = false) }
                        }
                    }
                    return n
                }
                n == 0 -> {
                    if (quietSince == 0L) {
                        quietSince = now
                    } else if (now - quietSince >= SILENCE_MS) {
                        quietSince = 0L
                        return silenceRebuild()
                    }
                    SystemClock.sleep(4L)
                    return 0
                }
                else -> return rebuild(errorName(n), 0L)
            }
        }

        private fun silenceRebuild(): Int {
            quietStrikes++
            val slow = quietStrikes >= 3
            if (slow) {
                _state.update {
                    it.copy(
                        micSilenced = true,
                        message = "No sound from the microphone. If you are talking, Android or the game is silencing it; retrying."
                    )
                }
            }
            srcIdx = (srcIdx + 1) % SOURCES.size          // try the next capture source
            return rebuild("silence", if (slow) 1_000L else 0L)
        }

        private fun rebuild(why: String, waitMs: Long): Int {
            closeMic()
            failStreak++
            if (failStreak > MAX_HARD_FAILS) {
                _state.update { it.copy(message = "The microphone kept failing ($why). Stopped.") }
                return -1
            }
            recoveries++
            val wait = if (waitMs > 0L) waitMs else if (failStreak <= FAST_RETRIES) RESTART_MS else 500L
            SystemClock.sleep(wait)
            if (my != token) return -1
            if (open()) {
                val r = recoveries
                val hz = rate
                _state.update { it.copy(recoveries = r, sampleRate = hz) }
            }
            return 0
        }

        fun close() {
            closeMic()
        }

        private fun closeMic() {
            val m = mic ?: return
            mic = null
            runCatching { m.record.stop() }
            runCatching { m.record.release() }
        }
    }

    private fun isSilent(buf: ShortArray, n: Int): Boolean {
        val zero: Short = 0
        for (i in 0 until n) if (buf[i] != zero) return false
        return true
    }

    private fun errorName(code: Int): String = when (code) {
        AudioRecord.ERROR_DEAD_OBJECT -> "dead object"
        AudioRecord.ERROR_INVALID_OPERATION -> "invalid operation"
        AudioRecord.ERROR_BAD_VALUE -> "bad value"
        else -> "error $code"
    }

    // =========================================================================================
    // Recorder
    // =========================================================================================

    /** Records [seconds] seconds, then plays the result through [preset]. */
    fun recordAndPlay(preset: VoicePreset, seconds: Int = 5) {
        if (!micGranted()) {
            post(VoiceState(message = "Microphone permission is missing"))
            return
        }
        stop()
        val my = ++token
        thread(name = "hyper-voice-rec", isDaemon = true) {
            val hold = VoiceForegroundService.hold(ctx)
            val pipe = Pipe(my)
            var raw = ShortArray(0)
            var read = 0
            var rate = 0
            try {
                prepareBypass()
                if (!pipe.open()) {
                    post(VoiceState(message = "The microphone could not be opened (is another app using it?)"))
                    return@thread
                }
                rate = pipe.rate
                var total = rate * seconds
                raw = ShortArray(total)
                val block = ShortArray(2048)
                var lastUi = 0L
                while (read < total && token == my) {
                    val n = pipe.read(block, min(block.size, total - read))
                    if (n < 0) break
                    if (n == 0) continue
                    if (pipe.rate != rate) {            // the pipe rebuilt on another rate: start this take again
                        rate = pipe.rate
                        total = rate * seconds
                        raw = ShortArray(total)
                        read = 0
                        continue
                    }
                    System.arraycopy(block, 0, raw, read, n)
                    read += n
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastUi > 200L) {
                        lastUi = now
                        _state.update {
                            it.copy(busy = true, message = "Recording... speak now", progressMs = read * 1000 / rate, sampleRate = rate)
                        }
                    }
                }
            } catch (t: Throwable) {
                post(VoiceState(message = "Recording failed: " + (t.message ?: t.javaClass.simpleName)))
                return@thread
            } finally {
                pipe.close()
                hold.release()
            }
            if (token != my) return@thread
            if (read == 0) {
                post(VoiceState(message = "Nothing was recorded"))
                return@thread
            }
            recording = raw.copyOf(read)
            recordingRate = rate
            if (isSilent(raw, read)) {
                post(
                    VoiceState(
                        hasRecording = true, micSilenced = true, sampleRate = rate, recoveries = pipe.recoveries,
                        message = "The recording is silent. Android is probably silencing the microphone while another app is in front."
                    )
                )
                return@thread
            }
            playInternal(my, preset)
        }
    }

    /** Plays the last recording through [preset] (ORIGINAL = unprocessed). */
    fun play(preset: VoicePreset) {
        if (recording == null) {
            post(VoiceState(message = "Record something first"))
            return
        }
        stop()
        val my = ++token
        thread(name = "hyper-voice-play", isDaemon = true) { playInternal(my, preset) }
    }

    // =========================================================================================
    // Live monitor
    // =========================================================================================

    /** Live monitor through headphones. Returns null when started, otherwise the reason it could not. */
    fun startMonitor(preset: VoicePreset): String? {
        if (!micGranted()) return "Microphone permission is missing"
        if (!headphonesConnected()) {
            return "Connect headphones first. Through the speaker the microphone would pick up its own sound and howl."
        }
        stop()
        livePreset = preset
        val my = ++token
        thread(name = "hyper-voice-live", isDaemon = true) { monitorLoop(my) }
        return null
    }

    private fun monitorLoop(my: Int) {
        val hold = VoiceForegroundService.hold(ctx)
        val pipe = Pipe(my)
        var track: AudioTrack? = null
        try {
            prepareBypass()
            if (!pipe.open()) {
                post(VoiceState(message = "The microphone could not be opened (another app may be holding it)"))
                return
            }
            val block = ShortArray(max(512, framesPerBuffer() * 2))
            var dsp: VoiceDsp? = null
            var dspPreset: VoicePreset? = null
            var dspRate = 0
            var trackRate = 0
            post(
                VoiceState(
                    monitoring = true, sampleRate = pipe.rate,
                    message = "Live monitor on: " + livePreset.name.lowercase().replace('_', ' ') + " at " + pipe.rate + " Hz"
                )
            )
            while (token == my) {
                val n = pipe.read(block, block.size)
                if (n < 0) break
                if (n == 0) continue
                val rate = pipe.rate
                val cur: AudioTrack = track.takeIf { trackRate == rate } ?: run {
                    track?.let { old ->
                        runCatching { old.stop() }
                        runCatching { old.release() }
                    }
                    val fresh = buildTrack(rate, live = true)
                    fresh.play()
                    track = fresh
                    trackRate = rate
                    fresh
                }
                val p = livePreset
                val d: VoiceDsp = dsp.takeIf { dspPreset == p && dspRate == rate } ?: VoiceDsp(p, rate).also {
                    dsp = it
                    dspPreset = p
                    dspRate = rate
                }
                d.process(block, n)
                if (cur.write(block, 0, n) < 0) {       // output died (audio server restart): rebuild on the next block
                    runCatching { cur.stop() }
                    runCatching { cur.release() }
                    track = null
                }
            }
        } catch (t: Throwable) {
            post(VoiceState(message = "Live monitor failed: " + (t.message ?: t.javaClass.simpleName)))
            return
        } finally {
            pipe.close()
            track?.let {
                runCatching { it.stop() }
                runCatching { it.release() }
            }
            hold.release()
        }
        if (token == my) post(VoiceState(hasRecording = recording != null, message = "Stopped"))
    }

    fun stop() {
        token++
        _state.value = VoiceState(hasRecording = recording != null, message = "")
    }

    fun release() {
        stop()
        recording = null
        _state.value = VoiceState()
    }

    // =========================================================================================
    // Playback
    // =========================================================================================

    private fun playInternal(my: Int, preset: VoicePreset) {
        val raw = recording ?: return
        val rate = recordingRate.takeIf { it > 0 } ?: candidateRates().first()
        val focus = FocusGuard()
        var track: AudioTrack? = null
        try {
            val out = VoiceDsp(preset, rate).processAll(raw)
            focus.take()
            track = buildTrack(rate, live = false)
            track.play()
            post(
                VoiceState(
                    busy = true, hasRecording = true, sampleRate = rate,
                    message = "Playing: " + preset.name.lowercase().replace('_', ' ')
                )
            )
            var off = 0
            while (off < out.size && token == my) {
                val n = min(2048, out.size - off)
                val w = track.write(out, off, n)
                if (w <= 0) break
                off += w
            }
            if (token == my) Thread.sleep(150L)      // let the tail finish when it was not interrupted
        } catch (t: Throwable) {
            post(VoiceState(hasRecording = true, message = "Playback failed: " + (t.message ?: t.javaClass.simpleName)))
            return
        } finally {
            runCatching { track?.stop() }
            runCatching { track?.release() }
            focus.drop()
        }
        if (token == my) post(VoiceState(hasRecording = true, sampleRate = rate, message = "Done"))
    }

    private fun post(s: VoiceState) {
        _state.value = s.copy(hasRecording = s.hasRecording || recording != null)
    }

    companion object {
        /** Kept for older callers; the real rate is negotiated at runtime. */
        const val SAMPLE_RATE = 44100

        private val FALLBACK_RATES = listOf(48000, 44100, 32000, 16000)
        private val SOURCES = intArrayOf(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            MediaRecorder.AudioSource.MIC,
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            MediaRecorder.AudioSource.UNPROCESSED,
            MediaRecorder.AudioSource.CAMCORDER
        )

        private const val SILENCE_MS = 300L
        private const val RESTART_MS = 50L
        private const val FAST_RETRIES = 6
        private const val MAX_HARD_FAILS = 14
        private const val BYPASS_EVERY_MS = 10 * 60_000L
    }
}
