package com.hyperengine.gameturbo.core

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import com.hyperengine.gameturbo.service.SelfHealReceiver
import com.hyperengine.gameturbo.service.TouchMacroService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/** What the self-healer last saw and did. [summary] is one readable line for the Setup screen. */
data class HealState(
    val running: Boolean = false,
    val enabled: Boolean = false,       // our component is in enabled_accessibility_services
    val connected: Boolean = false,     // Android has bound it
    val autoHeal: Boolean = false,
    val lastTrigger: String = "",
    val lastRunAt: Long = 0L,
    val lastOk: Boolean = true,
    val summary: String = ""
)

/**
 * Keeps the auto-tapper accessibility service alive.
 *
 * Why it drops: HyperOS / ColorOS battery managers kill the app process or unbind the service under memory
 * pressure, and some ROMs also clear it from the enabled list when the app is force-stopped.
 *
 * What this does, each time it runs (app start, game launch, Wild Boost tile tap, a 15 minute watchdog alarm, a
 * boot / app-update broadcast, or the service itself noticing it was unbound):
 *  1. Shell only, at most once per 6 hours: whitelists the app from Doze and background restrictions
 *     (`cmd deviceidle whitelist +pkg`, `RUN_ANY_IN_BACKGROUND`, `RUN_IN_BACKGROUND`, `SYSTEM_ALERT_WINDOW`,
 *     `START_FOREGROUND`, standby bucket active).
 *  2. Reads `enabled_accessibility_services`; if our component is missing (or `accessibility_enabled` is 0) it is
 *     appended and the master switch is set to 1, through Shizuku / root or, without a shell, through the
 *     WRITE_SECURE_SETTINGS grant.
 *  3. If it is listed but Android has not bound it, the entry is removed and added again, which makes
 *     AccessibilityManagerService rebind it. Waits for the real "connected" signal and reports it.
 *  4. Arms an AlarmManager watchdog (setAndAllowWhileIdle) so a dead process is revived later.
 *
 * Consent and limits, said plainly:
 *  - It only re-enables a service the user switched on at least once (or enabled from this app's own buttons),
 *    and only while "Keep it connected" is on. Turn that off to stop all of it.
 *  - If you switch the service off in Android Settings, it stays off until the next app start, game launch or tile
 *    tap; an immediate re-enable loop would fight you.
 *  - Without Shizuku, root or the WRITE_SECURE_SETTINGS grant nothing can be changed; it says so instead of
 *    pretending, and the Setup screen opens Accessibility settings.
 *  - On some ROMs the OS refuses to bind a service from a "restricted" app no matter what is written; that shows up
 *    as "enabled but not bound".
 */
class AccessibilitySelfHealer(
    context: Context,
    private val bridge: SystemBridgeExecutor
) {
    private val ctx = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val prefs = ctx.getSharedPreferences("hyper_selfheal", Context.MODE_PRIVATE)
    private val running = Mutex()
    private val component = ComponentName(ctx, TouchMacroService::class.java)

    private val _state = MutableStateFlow(
        HealState(autoHeal = prefs.getBoolean(KEY_AUTO, false), connected = TouchMacroService.connected.value)
    )
    val state: StateFlow<HealState> = _state.asStateFlow()

    val autoHeal: Boolean get() = prefs.getBoolean(KEY_AUTO, false)
    private val optedIn: Boolean get() = prefs.getBoolean(KEY_OPTED_IN, false)

    // =========================================================================================
    // Public API
    // =========================================================================================

    /** Fire and forget. Safe to call from any thread, as often as you like: runs never overlap. */
    fun heal(trigger: String, force: Boolean = false) {
        scope.launch { healNow(trigger, force) }
    }

    /** Same, for a BroadcastReceiver: [onDone] runs when the run ends or after 9 seconds, whichever is first. */
    fun healThen(trigger: String, onDone: () -> Unit) {
        scope.launch {
            try {
                withTimeoutOrNull(9_000L) { healNow(trigger, false) }
            } finally {
                onDone()
            }
        }
    }

    /** The user pressed an "Enable" button in this app: counts as consent, and always runs. */
    suspend fun enableNow(trigger: String = "enable button"): List<StepResult> {
        optIn()
        return healNow(trigger, force = true)
    }

    fun setAutoHeal(on: Boolean) {
        prefs.edit().putBoolean(KEY_AUTO, on).apply()
        _state.update { it.copy(autoHeal = on) }
        if (on) {
            armWatchdog()
        } else {
            cancelAlarm(REQ_WATCHDOG)
            cancelAlarm(REQ_RESTART)
        }
    }

    /** Called by [TouchMacroService.onServiceConnected]. Being connected at all means the user enabled it once. */
    fun onServiceConnected() {
        optIn()
        _state.update {
            it.copy(enabled = true, connected = true, lastOk = true, summary = "Connected")
        }
        cancelAlarm(REQ_RESTART)
        armWatchdog()
    }

    /**
     * Called by the service from onUnbind / onTaskRemoved / onDestroy. If Android still lists the service as
     * enabled this was a kill or an unbind (battery manager, memory pressure), so it is restored right away; if the
     * list no longer has it, the user (or a force-stop) switched it off and only the normal triggers bring it back.
     */
    fun onServiceLost(reason: String) {
        _state.update { it.copy(connected = false, summary = "Disconnected: $reason") }
        if (!autoHeal || !optedIn) return
        if (bridge.isAccessibilityEnabled()) {
            scheduleRestart(RESTART_DELAY_MS, reason)         // survives the process dying
            scope.launch {
                delay(1_500L)
                healNow("service lost: $reason", force = false)
            }
        }
    }

    // =========================================================================================
    // The run
    // =========================================================================================

    suspend fun healNow(trigger: String, force: Boolean): List<StepResult> {
        if (!running.tryLock()) return emptyList()
        val steps = ArrayList<StepResult>()
        try {
            _state.update { it.copy(running = true, lastTrigger = trigger) }
            withContext(Dispatchers.IO) { runCatching { bridge.refreshNow() } }

            // Doze whitelist, standby bucket and background-allow are only touched when the user turned
            // "Keep running after closing" on. They used to run on every app start.
            if (bridge.hasShell() && autoHeal) steps += keepAlive(force)
            steps += healService(force)

            val bad = steps.filter { !it.ok }
            val connected = TouchMacroService.connected.value
            _state.update {
                it.copy(
                    running = false,
                    enabled = bridge.isAccessibilityEnabled(),
                    connected = connected,
                    autoHeal = autoHeal,
                    lastRunAt = System.currentTimeMillis(),
                    lastOk = bad.isEmpty(),
                    summary = summarize(steps, connected)
                )
            }
            if (autoHeal && optedIn) {
                armWatchdog()
            } else {
                cancelAlarm(REQ_WATCHDOG)
                cancelAlarm(REQ_RESTART)
            }
        } finally {
            _state.update { it.copy(running = false) }
            running.unlock()
        }
        return steps
    }

    private fun summarize(steps: List<StepResult>, connected: Boolean): String {
        val bad = steps.firstOrNull { !it.ok }
        return when {
            bad != null -> bad.step + ": " + bad.detail
            connected -> "Connected"
            steps.any { it.detail.startsWith("idle") } -> steps.first { it.detail.startsWith("idle") }.detail
            else -> "Waiting for Android to connect it"
        }
    }

    // ---- 1. keep the app alive (shell) -------------------------------------------------------

    private suspend fun keepAlive(force: Boolean): List<StepResult> {
        val last = prefs.getLong(KEY_WL_AT, 0L)
        if (!force && System.currentTimeMillis() - last < WHITELIST_EVERY_MS) return emptyList()
        val pkg = ctx.packageName
        val out = ArrayList<StepResult>()

        val idle = bridge.shell("cmd deviceidle whitelist +$pkg", 8_000L)
        val bucket = bridge.shell("am set-standby-bucket $pkg active", 8_000L)
        out += StepResult(
            "Battery optimisation whitelist", idle.ok,
            if (idle.ok) "Doze whitelist added" + (if (bucket.ok) ", standby bucket active" else "")
            else idle.message.ifBlank { "cmd deviceidle failed" }
        )

        val bg1 = bridge.setAppOp(pkg, "RUN_ANY_IN_BACKGROUND", "allow")
        val bg2 = bridge.setAppOp(pkg, "RUN_IN_BACKGROUND", "allow")
        out += StepResult(
            "Background run allowed", bg1.ok || bg2.ok,
            if (bg1.ok || bg2.ok) "RUN_ANY_IN_BACKGROUND allow" else bg1.message.ifBlank { "refused" }
        )

        val overlay = bridge.setAppOp(pkg, "SYSTEM_ALERT_WINDOW", "allow")
        bridge.setAppOp(pkg, "START_FOREGROUND", "allow")       // not on every Android version: result ignored
        out += StepResult("Overlay permission op", overlay.ok, if (overlay.ok) "SYSTEM_ALERT_WINDOW allow" else overlay.message.ifBlank { "refused" })

        if (out.none { !it.ok }) prefs.edit().putLong(KEY_WL_AT, System.currentTimeMillis()).apply()
        return out
    }

    // ---- 2 + 3. enable and bind ----------------------------------------------------------------

    private suspend fun healService(force: Boolean): StepResult {
        val listed = bridge.isAccessibilityEnabled()
        val masterOn = bridge.getSetting(Ns.SECURE, "accessibility_enabled") == "1"
        if (listed && masterOn && TouchMacroService.connected.value) {
            return StepResult("Accessibility service", true, "connected")
        }
        if (!force && (!autoHeal || !optedIn)) {
            return StepResult(
                "Accessibility service", true,
                if (!autoHeal) "idle: Keep it connected is off" else "idle: not enabled yet, turn the auto tapper on once"
            )
        }
        val canEdit = bridge.hasShell() || bridge.state.value.writeSecureSettings
        if (!canEdit) {
            return StepResult(
                "Accessibility service", false,
                if (listed) "listed but not bound, and no Shizuku / root / secure-settings grant to rebind it"
                else "off, and no Shizuku / root / secure-settings grant to switch it on by itself"
            )
        }

        if (!listed || !masterOn) {
            val r = bridge.enableAccessibilityService(component)
            if (!r.ok) return StepResult("Accessibility service", false, "could not switch it on: " + r.message.ifBlank { r.via })
        }
        if (waitConnected(2_500L)) {
            return StepResult("Accessibility service", true, if (listed && masterOn) "connected" else "switched on and connected")
        }

        // Listed but Android did not bind it: remove and re-add the entry so the manager rebinds.
        val toggled = toggleRebind()
        if (toggled != null) return StepResult("Accessibility service", false, toggled)
        return if (waitConnected(4_000L)) {
            StepResult("Accessibility service", true, "rebound")
        } else {
            StepResult("Accessibility service", false, "enabled but Android has not bound it (this ROM may block background accessibility)")
        }
    }

    /** Returns null when the entry was removed and added back, otherwise the reason it was not. */
    private suspend fun toggleRebind(): String? {
        val raw = bridge.getSetting(Ns.SECURE, KEY_A11Y).orEmpty()
        val rest = raw.split(':').filter { it.isNotBlank() && !isOurs(it) }
        val removed = if (rest.isEmpty()) bridge.deleteSetting(Ns.SECURE, KEY_A11Y)
        else bridge.putSetting(Ns.SECURE, KEY_A11Y, rest.joinToString(":"))
        if (!removed.ok) return "rebind failed: " + removed.message.ifBlank { removed.via }
        delay(450L)
        val added = bridge.enableAccessibilityService(component)
        return if (added.ok) null else "rebind failed on re-adding: " + added.message.ifBlank { added.via }
    }

    private fun isOurs(item: String): Boolean =
        item.equals(component.flattenToString(), true) || item.equals(component.flattenToShortString(), true)

    private suspend fun waitConnected(timeoutMs: Long): Boolean {
        if (TouchMacroService.connected.value) return true
        var waited = 0L
        while (waited < timeoutMs) {
            delay(150L)
            waited += 150L
            if (TouchMacroService.connected.value) return true
        }
        return false
    }

    // =========================================================================================
    // Restart alarms
    // =========================================================================================

    private fun optIn() {
        if (!prefs.getBoolean(KEY_OPTED_IN, false)) prefs.edit().putBoolean(KEY_OPTED_IN, true).apply()
    }

    /** One-shot alarm that runs a heal even if the process is dead by then. */
    fun scheduleRestart(delayMs: Long, reason: String) {
        setAlarm(REQ_RESTART, delayMs, reason)
    }

    /** The 15 minute safety net. Each run re-arms the next one. */
    fun armWatchdog() {
        if (!autoHeal || !optedIn) return
        setAlarm(REQ_WATCHDOG, WATCHDOG_MS, "watchdog")
    }

    private fun setAlarm(request: Int, delayMs: Long, reason: String) {
        runCatching {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            // Inexact on purpose: no exact-alarm permission needed, and the OS may batch it a little.
            am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + delayMs, pending(request, reason))
        }
    }

    private fun cancelAlarm(request: Int) {
        runCatching {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.cancel(pending(request, ""))
        }
    }

    private fun pending(request: Int, reason: String): PendingIntent {
        val i = Intent(ctx, SelfHealReceiver::class.java)
            .setAction(SelfHealReceiver.ACTION_HEAL)
            .putExtra(SelfHealReceiver.EXTRA_REASON, reason.ifBlank { "alarm" })
        return PendingIntent.getBroadcast(ctx, request, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private companion object {
        // "auto2": the old key defaulted to ON, which kept the app running after it was closed. Now it is opt-in.
        const val KEY_AUTO = "auto2"
        const val KEY_OPTED_IN = "optedIn"
        const val KEY_WL_AT = "whitelistAt"
        const val KEY_A11Y = "enabled_accessibility_services"
        const val REQ_RESTART = 6101
        const val REQ_WATCHDOG = 6102
        const val RESTART_DELAY_MS = 4_000L
        const val WATCHDOG_MS = 15 * 60_000L
        const val WHITELIST_EVERY_MS = 6 * 3_600_000L
    }
}
