package com.hyperengine.gameturbo.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import com.hyperengine.gameturbo.core.FpsSource
import com.hyperengine.gameturbo.core.TelemetrySample
import com.hyperengine.gameturbo.data.MicroConfig
import java.text.DateFormat
import java.util.Date
import java.util.Locale
import java.util.Random
import kotlin.math.max

// =============================================================================================
// Black screen with a drifting clock
// =============================================================================================

/**
 * Pure black (OLED pixels off) with a small neon readout that jumps to a new spot every 20 s, so
 * nothing stays lit in one place long enough to burn in. Hold the screen for 1.2 s to wake it.
 */
class AfkView(context: Context) : View(context) {

    var accent = 0xFF00E5FF.toInt()
    var showStats = true
    var blockTouch = true
    var statsLine: () -> String = { "" }
    var onWake: () -> Unit = {}

    private val rnd = Random()
    private val big = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD) }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.MONOSPACE }
    private var tx = 0f
    private var ty = 0f
    private var movedAt = 0L
    private val timeFmt = DateFormat.getTimeInstance(DateFormat.MEDIUM)
    private val wake = Runnable { onWake() }
    private val startedAt = SystemClock.elapsedRealtime()

    init {
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    private fun dp(v: Float) = v * resources.displayMetrics.density

    override fun onDraw(c: Canvas) {
        // 99 % black when this window takes touches; a pass-through window is capped by Android at 79 %
        // (its brightness override covers the rest).
        c.drawColor(if (blockTouch) Color.argb(252, 0, 0, 0) else Color.BLACK)
        val time = timeFmt.format(Date())
        val up = (SystemClock.elapsedRealtime() - startedAt) / 1000
        val l2 = if (showStats) statsLine() else ""
        val l3 = "AFK " + formatDuration(up) + (if (blockTouch) "  -  hold to wake" else "")
        big.textSize = dp(22f)
        small.textSize = dp(11f)
        val col = HudThemes.withAlpha(accent, 0x99)
        big.color = col
        small.color = HudThemes.withAlpha(accent, 0x66)
        val w = max(big.measureText(time), max(small.measureText(l2), small.measureText(l3)))
        val boxH = dp(70f)
        val now = SystemClock.elapsedRealtime()
        if (movedAt == 0L || now - movedAt > 20_000L) {
            movedAt = now
            tx = dp(12f) + rnd.nextFloat() * max(1f, width - w - dp(24f))
            ty = dp(40f) + rnd.nextFloat() * max(1f, height - boxH - dp(80f))
        }
        c.drawText(time, tx, ty, big)
        c.drawText(l3, tx, ty + dp(18f), small)
        if (l2.isNotEmpty()) c.drawText(l2, tx, ty + dp(34f), small)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!blockTouch) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> postDelayed(wake, 1200L)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> removeCallbacks(wake)
        }
        return true
    }
}

// =============================================================================================
// Manager
// =============================================================================================

/**
 * Keeps the game running while the screen shows almost nothing. The window carries
 * FLAG_KEEP_SCREEN_ON, so the display never times out, and asks for the lowest brightness.
 *
 * It swallows touches so a pocket or a cat cannot play for you. When the auto tapper is running it
 * lets touches through instead (otherwise the injected taps would hit this window, not the game); you
 * then leave AFK from the sidebar. Main thread only.
 */
class AfkLock(context: Context, private val wm: WindowManager, private val themeProvider: () -> HudTheme) {

    private val ctx: Context = context.applicationContext
    private val handler = Handler(Looper.getMainLooper())

    var onAttached: (() -> Unit)? = null
    var onChanged: ((Boolean) -> Unit)? = null

    private var view: AfkView? = null
    private var params: WindowManager.LayoutParams? = null
    private var attached = false
    private var passThrough = false
    private var wantTouch = true
    private var sample = TelemetrySample()

    val isActive: Boolean get() = attached

    private val tick = object : Runnable {
        override fun run() {
            view?.invalidate()
            if (attached) handler.postDelayed(this, 1000L)
        }
    }

    fun enter(micro: MicroConfig) {
        if (attached) {
            wantTouch = micro.afkBlockTouch
            applyState(micro.afkShowStats)
            return
        }
        wantTouch = micro.afkBlockTouch
        val v = AfkView(ctx)
        v.accent = themeProvider().accent
        v.statsLine = { statsText() }
        v.onWake = { exit() }
        val scr = OverlayKit.realSize(wm)
        val touchable = wantTouch && !passThrough
        val p = OverlayKit.params(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            "HyperEngineAfk", touchable = touchable
        )
        p.width = scr.x
        p.height = scr.y
        OverlayKit.setFlag(p, WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, true)
        p.screenBrightness = 0.01f
        view = v
        params = p
        applyViewFlags(micro.afkShowStats)
        try {
            wm.addView(v, p)
            attached = true
            onAttached?.invoke()
            handler.postDelayed(tick, 1000L)
            onChanged?.invoke(true)
        } catch (_: Throwable) {
            view = null
            params = null
            attached = false
        }
    }

    fun exit() {
        handler.removeCallbacks(tick)
        val v = view
        if (attached && v != null) runCatching { wm.removeViewImmediate(v) }
        val was = attached
        attached = false
        view = null
        params = null
        if (was) onChanged?.invoke(false)
    }

    /** The auto tapper calls this: true = let touches through while it runs. */
    fun setPassThrough(on: Boolean) {
        passThrough = on
        if (attached) applyState(null)
    }

    fun onSample(s: TelemetrySample) {
        sample = s
    }

    fun relayout() {
        val v = view ?: return
        val p = params ?: return
        if (!attached) return
        val scr = OverlayKit.realSize(wm)
        p.width = scr.x
        p.height = scr.y
        runCatching { wm.updateViewLayout(v, p) }
    }

    // ---- internals ----

    private fun applyViewFlags(showStats: Boolean?) {
        val v = view ?: return
        if (showStats != null) v.showStats = showStats
        v.blockTouch = wantTouch && !passThrough
    }

    private fun applyState(showStats: Boolean?) {
        val v = view ?: return
        val p = params ?: return
        applyViewFlags(showStats)
        val touchable = wantTouch && !passThrough
        OverlayKit.setFlag(p, WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, !touchable)
        p.alpha = if (touchable) 1f else 0.79f
        runCatching { wm.updateViewLayout(v, p) }
        v.invalidate()
    }

    private fun statsText(): String {
        val s = sample
        val fps = if (s.fpsSource == FpsSource.SURFACE_FLINGER) String.format(Locale.US, "%.0f fps", s.fps) else "-- fps"
        val bat = if (s.batteryPct >= 0) "  " + s.batteryPct + "%" else ""
        return fps + String.format(Locale.US, "  %.1f\u00B0C", s.batteryTempC) + bat
    }
}

// =============================================================================================
// Sidebar tool page
// =============================================================================================

class AfkTool(private val afk: AfkLock) : HudTool("afk") {

    override fun isActive(host: ToolHost): Boolean = afk.isActive

    override fun onTap(host: ToolHost) {
        val ctx = host.hostContext
        val theme = host.theme
        val repo = host.deps.repo
        val col = Ui.vbox(ctx)
        var micro = GameActions.profileFor(host.deps, host.game).micro

        col.addView(ToolUi.note(host,
            "For auto-farming: the screen goes almost black (OLED pixels off) and stays awake while the game keeps " +
                "running. A small neon clock hops to a new spot every 20 seconds so nothing burns in. Hold the " +
                "screen for 1.2 seconds to wake it, or use the sidebar handle."))

        fun save(next: MicroConfig) {
            micro = next
            repo.update(host.game) { it.copy(micro = next) }
        }

        col.addView(Ui.section(ctx, theme, "Options"))
        col.addView(ToolUi.check(ctx, theme, "Block touches while dark (stops accidental taps)", micro.afkBlockTouch) { save(micro.copy(afkBlockTouch = it)) })
        col.addView(ToolUi.check(ctx, theme, "Show FPS, temperature and battery", micro.afkShowStats) { save(micro.copy(afkShowStats = it)) })
        col.addView(ToolUi.note(host,
            "While the auto tapper runs, touches always pass through so its taps reach the game."))

        col.addView(Ui.section(ctx, theme, "Screen"))
        val btn = Ui.button(ctx, theme, if (afk.isActive) "Wake the screen" else "Go dark now", true) {}
        btn.setOnClickListener {
            if (afk.isActive) afk.exit() else afk.enter(micro)
            host.toast(if (afk.isActive) "AFK lock on" else "AFK lock off")
            host.refreshTiles()
            onTap(host)
        }
        col.addView(btn, Ui.lp(Ui.MATCH, Ui.WRAP))
        host.openDetail("AFK lock", col)
    }
}
