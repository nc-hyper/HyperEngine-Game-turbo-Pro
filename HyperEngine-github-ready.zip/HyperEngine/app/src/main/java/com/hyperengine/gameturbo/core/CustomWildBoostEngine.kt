package com.hyperengine.gameturbo.core

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.session.MediaSessionManager
import android.os.BatteryManager
import android.os.PowerManager
import android.provider.Settings
import android.provider.Telephony
import android.telecom.TelecomManager
import androidx.core.content.ContextCompat
import com.hyperengine.gameturbo.data.DnsPreset
import com.hyperengine.gameturbo.data.FanMode
import com.hyperengine.gameturbo.data.GameProfile
import com.hyperengine.gameturbo.data.GameProfileRepository
import com.hyperengine.gameturbo.service.DanmakuNotificationService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Locale
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

// ---------------------------------------------------------------------------------------------
// Public types
// ---------------------------------------------------------------------------------------------

/** The three tiers of the Performance Engine: Green / Blue / Red in the UI. */
enum class PerfTier(val label: String, val level: GameModeLevel) {
    ECO("Battery saver", GameModeLevel.BATTERY),
    BALANCED("Balanced", GameModeLevel.STANDARD),
    WILDBOOST("Wild Boost", GameModeLevel.PERFORMANCE)
}

data class CleanReport(
    val candidates: Int,            // user apps that were eligible (not protected)
    val running: Int,               // of those, how many had a live process (-1 = unknown without a shell)
    val stopped: Int,               // force-stops the shell confirmed (-1 = unknown without a shell)
    val protectedSkipped: Int,
    val availBeforeMb: Long,
    val availAfterMb: Long,
    val usedShell: Boolean
) {
    /** Measured with ActivityManager.MemoryInfo before and after. Can be negative. */
    val reclaimedMb: Long get() = availAfterMb - availBeforeMb
}

data class ChargeSepStatus(
    val on: Boolean = false,        // charging is suspended right now
    val wanted: Boolean = false,    // the user asked for it (it engages whenever a charger is connected)
    val hardware: Boolean = false,  // true = a real charge-control node was written; false = software-only unplug
    val method: String = "",
    val detail: String = ""
)

data class WildBoostState(
    val tier: PerfTier = PerfTier.BALANCED,
    val active: Boolean = false,    // Wild Boost steps are applied
    val diablo: Boolean = false,
    val game: String? = null,
    val busy: String? = null,
    val fanMode: FanMode = FanMode.OFF,
    val fanActive: Boolean = false,
    val fanRpm: Int = 0,            // virtual rotor speed shown by the HUD turbine
    val batteryTempC: Float = 0f,
    val thermalTripped: Boolean = false,
    val thermalNote: String = "",
    val chargeSeparation: ChargeSepStatus = ChargeSepStatus(),
    val batterySaverOn: Boolean = false,    // the phone's REAL Battery Saver state, kept in sync by a broadcast
    val lastClean: CleanReport? = null,
    val log: List<EngineLogLine> = emptyList()
)

// ---------------------------------------------------------------------------------------------
// The engine
// ---------------------------------------------------------------------------------------------

/**
 * Self-contained Wild Boost / Diablo engine. It works on a phone that has no native performance mode,
 * because every step is a real shell command or Android API:
 *
 *  1  fixed-performance mode (`cmd power set-fixed-performance-mode-enabled true`)
 *  2  OEM speed flags (`speed_mode`, `power_mode`)
 *  3  OEM throttlers suspended (shared [ThrottlerGuard])
 *  4  animation scales to 0
 *  5  background app cleaner + `pm trim-caches 999G`
 *  6  ART compile (`cmd package compile -m speed-profile -f`) before launch
 *  7  background data restricted
 *
 * plus the virtual turbo fan with real cooling actions, Charge Separation with a safety watchdog,
 * Battery Saver sync, and the gaming DNS switcher. Settings keys go through
 * [OptimizationEngine.putTracked] so Restore undoes them; everything else is saved in [Phase2Store]
 * before it changes.
 *
 * What the fan and charge features can and cannot do, in plain terms:
 *  - There is no fan in a normal phone. The turbine is a display of a thermal controller; the cooling is
 *    real but modest: fewer background processes, a dimmer backlight, no background sync.
 *  - Charge Separation really stops charging only when a charge-control node under /sys is writable
 *    (usually root, some Shizuku setups). Without one, `cmd battery unplug` only changes what Android
 *    REPORTS (the charger keeps charging in hardware). That mode is labelled "software only".
 *  - Nothing can drive a Bluetooth/USB cooler without that vendor's protocol, so none is attempted.
 */
class CustomWildBoostEngine(
    context: Context,
    private val bridge: SystemBridgeExecutor,
    private val engine: OptimizationEngine,
    private val fps: FpsRefreshRateEnforcer,
    private val repo: GameProfileRepository,
    private val store: Phase2Store
) {

    private val ctx: Context = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val wbMutex = Mutex()
    private val chargeMutex = Mutex()
    private val prefs = ctx.getSharedPreferences("hyper_wildboost", Context.MODE_PRIVATE)
    private val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager

    private val _state = MutableStateFlow(WildBoostState())
    val state: StateFlow<WildBoostState> = _state.asStateFlow()

    @Volatile private var activeGame: String? = null
    private var releaseJob: Job? = null
    private var guardJob: Job? = null
    private val guardLock = Any()
    private var started = false

    // fan / thermal bookkeeping
    @Volatile private var dimmed = false
    @Volatile private var coolApplied = false
    @Volatile private var syncPausedByUs = false

    // charge separation bookkeeping
    @Volatile private var chargeWanted = false
    @Volatile private var chargeAuto = false          // engaged by the thermal guard, not by the user
    @Volatile private var chargeFloor = 20
    @Volatile private var chargeAllowSoftware = true
    @Volatile private var chargeResumeAbove = 0       // after hitting the floor, wait until the level is back above this

    private val powerSaveReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            _state.update { it.copy(batterySaverOn = pm.isPowerSaveMode) }
        }
    }

    // =========================================================================================
    // Lifecycle
    // =========================================================================================

    /** Call once from Application.onCreate. */
    fun start() {
        if (started) return
        started = true
        _state.update { it.copy(batterySaverOn = pm.isPowerSaveMode) }
        // The HUD's Battery Saver tile always shows the phone's real state, whoever switched it.
        runCatching {
            ContextCompat.registerReceiver(
                ctx, powerSaveReceiver, IntentFilter(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED),
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
        }
    }

    /** Game came forward: applies whatever its profile asks for, after the engine finished the profile. */
    fun onGameForeground(pkg: String) {
        cancelRelease()
        activeGame = pkg
        _state.update { it.copy(game = pkg) }
        scope.launch {
            val p = repo.profile(pkg) ?: return@launch
            if (!p.enabled) return@launch
            val t = p.turbo
            withTimeoutOrNull(8_000L) { engine.status.first { it.activeGame == pkg && it.busy == null } }
            if (activeGame != pkg) return@launch

            if (t.nativeBatterySaver) {
                if (!_state.value.batterySaverOn || store.snapshot.batterySaverOriginal == null) setBatterySaver(true, pkg)
            } else if (t.wildBoost && !_state.value.active) {
                activate(pkg, t.diablo)
            }
            if (t.fan != FanMode.OFF && _state.value.fanMode != t.fan) startFan(t.fan, pkg)
            if (t.chargeSeparation) {
                setChargeSeparation(true, t.chargeFloorPct, t.softwareUnplugFallback, null)
            }
            ensureGuard()
        }
    }

    /** Game left. Charging resumes at once; everything else is released shortly before the engine restores. */
    fun onGameBackground() {
        val pkg = activeGame ?: return
        val delaySec = repo.global.value.restoreDelayFor(repo.profile(pkg))
        cancelRelease()
        scope.launch { stopChargeSeparation("game exited") }
        releaseJob = scope.launch {
            delay((delaySec * 1000L - 1_500L).coerceAtLeast(0L))
            releaseSoft("game in background for more than ${delaySec}s")
        }
    }

    private fun cancelRelease() {
        releaseJob?.cancel()
        releaseJob = null
    }

    /** Undoes whatever a killed process left behind. Needs the shell, so call it once the bridge is up. */
    suspend fun recoverPending(): List<StepResult> {
        val out = ArrayList<StepResult>()
        val s = store.snapshot
        if (s.charge != null) out += disengageCharge("recovery after restart")
        if (s.fixedPerformance) out += fixedPerformance(false)
        if (s.thermalOverride) out += thermalOverride(false)
        if (s.batterySaverOriginal != null) out += restoreBatterySaverIfOurs()
        return out.logAll()
    }

    /**
     * Releases everything of ours that the engine's snapshot does not cover. Settings keys written through
     * putTracked come back with OptimizationEngine.restoreAll().
     */
    suspend fun releaseSoft(reason: String): List<StepResult> = wbMutex.withLock {
        val out = ArrayList<StepResult>()
        out += fixedPerformance(false)
        out += fps.throttlers.release(OWNER_WB)
        out += thermalOverride(false)
        out += stopFanLocked()
        out += restoreBatterySaverIfOurs()
        out += stopChargeSeparationLocked(reason)
        activeGame = null
        _state.update {
            WildBoostState(log = it.log, batterySaverOn = pm.isPowerSaveMode, batteryTempC = it.batteryTempC)
        }
        out.logAll()
    }

    // =========================================================================================
    // Tiers
    // =========================================================================================

    /** Green / Blue / Red. [pkg] is the running game (null = only the global parts). */
    suspend fun setTier(pkg: String?, tier: PerfTier): List<StepResult> {
        val out = ArrayList<StepResult>()
        val saverIsOurs = store.snapshot.batterySaverOriginal != null
        when (tier) {
            PerfTier.ECO -> out += setBatterySaver(true, pkg)
            PerfTier.BALANCED -> {
                if (saverIsOurs) out += setBatterySaver(false, pkg)
                if (_state.value.active) out += deactivate(pkg)
                if (pkg != null) {
                    repo.update(pkg) { it.copy(gameMode = GameModeLevel.STANDARD) }
                    out += engine.setGameMode(pkg, GameModeLevel.STANDARD, null, 0)
                }
            }
            PerfTier.WILDBOOST -> {
                if (saverIsOurs) out += setBatterySaver(false, pkg)
                if (pkg != null) {
                    repo.update(pkg) { it.copy(gameMode = GameModeLevel.PERFORMANCE) }
                    out += activate(pkg, _state.value.diablo)
                }
            }
        }
        _state.update { it.copy(tier = tier) }
        return out
    }

    // =========================================================================================
    // Wild Boost / Diablo
    // =========================================================================================

    suspend fun activate(pkg: String, diablo: Boolean = false): List<StepResult> = wbMutex.withLock {
        if (!Validators.PACKAGE.matches(pkg)) {
            return@withLock listOf(StepResult("Wild Boost", false, "invalid package name")).logAll()
        }
        setBusy(if (diablo) "Diablo mode" else "Wild Boost")
        val steps = ArrayList<StepResult>()
        try {
            activeGame = pkg
            val profile = repo.profile(pkg) ?: repo.getOrCreate(pkg, pkg)

            // 1  fixed performance mode: clocks stay up instead of following the governor
            steps += fixedPerformance(true)

            // 2  OEM speed flags (key names are vendor specific; they do nothing on ROMs that never read them)
            steps += engine.putTracked(Ns.SYSTEM, "speed_mode", "1").let { it.copy(step = "OEM speed_mode flag") }
            steps += engine.putTracked(Ns.SYSTEM, "power_mode", "high").let { it.copy(step = "OEM power_mode flag") }

            // 3  OEM throttlers
            steps += fps.throttlers.acquire(OWNER_WB)

            // 4  compositor animations off
            steps += engine.setZeroAnimation(true)

            // 5  RAM: stop heavy background apps now, trim caches in the background (it can take a while)
            val clean = cleanRam(pkg)
            steps += StepResult("Background app cleaner", true, describe(clean))
            scope.launch { record(engine.trimShaderCaches(false)) }

            // 7  background network
            steps += engine.setBackgroundDataBlock(true)

            // game mode: keep the FPS cap and downscale the profile or the FPS unlocker already set
            val cap = max(profile.targetFps, profile.turbo.unlockFps)
            steps += engine.setGameMode(pkg, GameModeLevel.PERFORMANCE, profile.downscale, cap)

            if (diablo) steps += thermalOverride(true)

            _state.update { it.copy(active = true, diablo = diablo, tier = PerfTier.WILDBOOST, game = pkg) }
            ensureGuard()
        } finally {
            setBusy(null)
        }
        steps.logAll()
    }

    /** Turns Wild Boost off from the HUD. Items the profile itself asks for (animations, data block) stay on. */
    suspend fun deactivate(pkg: String?): List<StepResult> = wbMutex.withLock { deactivateLocked(pkg) }

    private suspend fun deactivateLocked(pkg: String?): List<StepResult> {
        val steps = ArrayList<StepResult>()
        steps += fixedPerformance(false)
        steps += engine.releaseTracked(listOf(Ns.SYSTEM to "speed_mode", Ns.SYSTEM to "power_mode"))
        steps += fps.throttlers.release(OWNER_WB)
        steps += thermalOverride(false)
        val p = pkg?.let { repo.profile(it) }
        if (p == null || !p.zeroAnimation) steps += engine.setZeroAnimation(false)
        if (p == null || !p.blockBackgroundData) steps += engine.setBackgroundDataBlock(false)
        _state.update { it.copy(active = false, diablo = false, tier = PerfTier.BALANCED) }
        return steps.logAll()
    }

    /** Before launch: ART compile (skipped when done in the last 24 h) and a RAM clean. Never run this while playing. */
    suspend fun prepareForLaunch(profile: GameProfile): List<StepResult> {
        if (!profile.turbo.wildBoost && !profile.turbo.diablo) return emptyList()
        val out = ArrayList<StepResult>()
        out += compileDex(profile.packageName, force = false)
        val clean = cleanRam(profile.packageName)
        out += StepResult("Background app cleaner", true, describe(clean))
        return out.logAll()
    }

    /** `cmd package compile -m speed-profile -f <pkg>`. [force] ignores the 24 hour memory of the last run. */
    suspend fun compileDex(pkg: String, force: Boolean): StepResult {
        if (!Validators.PACKAGE.matches(pkg)) return StepResult("DEX compile", false, "invalid package name")
        val key = "compiled.$pkg"
        val last = prefs.getLong(key, 0L)
        if (!force && System.currentTimeMillis() - last < DAY_MS) {
            return StepResult("DEX compile", true, "compiled in the last 24 hours, skipped")
        }
        val r = engine.compileGame(pkg, CompileMode.FAST)
        if (r.ok) prefs.edit().putLong(key, System.currentTimeMillis()).apply()
        return r
    }

    private fun describe(c: CleanReport): String {
        val freed = "RAM ${c.availBeforeMb} -> ${c.availAfterMb} MB free (${if (c.reclaimedMb >= 0) "+" else ""}${c.reclaimedMb} MB)"
        return if (c.usedShell) "${c.stopped} of ${c.running} running apps stopped, ${c.protectedSkipped} protected. $freed"
        else "background processes of ${c.candidates} apps trimmed (no shell, so force-stop is unavailable). $freed"
    }

    // ---- individual shell steps ----

    private suspend fun fixedPerformance(on: Boolean): StepResult {
        if (!on && !store.snapshot.fixedPerformance) return StepResult("Fixed performance mode", true, "not set by Wild Boost")
        if (on) store.update { it.copy(fixedPerformance = true) }
        val r = priv(
            "cmd power set-fixed-performance-mode-enabled $on",
            "Fixed performance mode",
            if (on) "clocks held up" else "released"
        )
        if (on && !r.ok) store.update { it.copy(fixedPerformance = false) }
        if (!on && r.ok) store.update { it.copy(fixedPerformance = false) }
        return r
    }

    /** Diablo extra: tells apps the device is not throttled. The hardware's own thermal protection is untouched. */
    private suspend fun thermalOverride(on: Boolean): StepResult {
        if (!on && !store.snapshot.thermalOverride) return StepResult("Thermal API override", true, "not active")
        if (on) store.update { it.copy(thermalOverride = true) }
        val r = if (on) priv(
            "cmd thermalservice override-status 0", "Thermal API override",
            "apps now see no throttling; hardware thermal protection stays on"
        ) else priv("cmd thermalservice reset", "Thermal API override", "reset")
        if (on && !r.ok) store.update { it.copy(thermalOverride = false) }
        if (!on && r.ok) store.update { it.copy(thermalOverride = false) }
        return r
    }

    /** Shell command with honest results: ROMs that reject a `cmd` often still exit 0, so the output is checked too. */
    private suspend fun priv(command: String, name: String, okText: String, timeoutMs: Long = 20_000L): StepResult {
        if (!bridge.hasShell()) return StepResult(name, false, "needs Shizuku or root")
        val r = bridge.shell(command, timeoutMs)
        val text = r.stdout + " " + r.stderr
        val soft = r.ok && (
            text.contains("Unknown command", true) || text.contains("Exception", true) ||
                text.trimStart().startsWith("Error") || text.contains("Bad argument", true) ||
                text.contains("Usage:", true) || text.contains("not found", true)
            )
        val ok = r.ok && !soft
        return StepResult(name, ok, if (ok) okText else r.stderr.ifBlank { r.stdout }.ifBlank { "exit ${r.exitCode}" }.take(160))
    }

    // =========================================================================================
    // RAM cleaner
    // =========================================================================================

    /**
     * Stops running user apps that are not protected. Protected: this app, the game, launcher, keyboard,
     * dialer, SMS, system services, apps with an active media session (music keeps playing), and the
     * user's whitelist. The freed memory is MEASURED with MemoryInfo, not estimated.
     */
    suspend fun cleanRam(game: String?): CleanReport = withContext(Dispatchers.IO) {
        val protectedSet = protectedPackages(game) + repo.global.value.wildBoostWhitelist + mediaPackages()
        val all = userPackages()
        val candidates = all.filter { it !in protectedSet && Validators.PACKAGE.matches(it) }
        val before = MemoryReader.availBytes(ctx)
        val useShell = bridge.hasShell()
        var running = -1
        var stopped = -1

        if (useShell) {
            val ps = bridge.shell("ps -A -o NAME 2>/dev/null", 8_000L)
            val live = ps.stdout.lineSequence().map { it.trim().substringBefore(':') }.filter { it.isNotEmpty() }.toHashSet()
            val targets = candidates.filter { it in live }
            running = targets.size
            stopped = 0
            for (chunk in targets.chunked(20)) {
                val script = "for p in ${chunk.joinToString(" ")}; do am force-stop \$p >/dev/null 2>&1; echo \"\$p \$?\"; done"
                val r = bridge.shell(script, 60_000L)
                for (line in r.stdout.lineSequence()) {
                    val t = line.trim().split(' ')
                    if (t.size == 2 && t[1] == "0" && t[0] in chunk) stopped++
                }
            }
            bridge.killAllBackground()
        }
        // ActivityManager route: the only one without a shell, and a harmless second pass with one
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        for (p in candidates) runCatching { am.killBackgroundProcesses(p) }

        delay(800L) // let the kernel return the pages before measuring
        val after = MemoryReader.availBytes(ctx)
        val mb = 1024L * 1024L
        val report = CleanReport(
            candidates = candidates.size,
            running = running,
            stopped = stopped,
            protectedSkipped = all.count { it in protectedSet },
            availBeforeMb = before / mb,
            availAfterMb = after / mb,
            usedShell = useShell
        )
        _state.update { it.copy(lastClean = report) }
        report
    }

    @Suppress("DEPRECATION")
    private fun userPackages(): List<String> = try {
        ctx.packageManager.getInstalledApplications(0)
            .filter { ai ->
                val system = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                !system || ai.packageName in HEAVY_SYSTEM_APPS
            }
            .map { it.packageName }
    } catch (_: Throwable) {
        emptyList()
    }

    private fun mediaPackages(): Set<String> = runCatching {
        val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        msm.getActiveSessions(ComponentName(ctx, DanmakuNotificationService::class.java)).map { it.packageName }.toSet()
    }.getOrDefault(emptySet())

    private fun protectedPackages(game: String?): Set<String> {
        val set = hashSetOf(
            ctx.packageName, "android", "com.android.systemui", "com.android.phone",
            "com.android.server.telecom", "com.android.providers.telephony",
            "com.android.providers.settings", "moe.shizuku.privileged.api",
            "com.google.android.gms", "com.google.android.gsf", "com.android.vending",
            "com.android.bluetooth", "com.android.nfc"
        )
        if (!game.isNullOrEmpty()) set += game
        runCatching {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            ctx.packageManager.resolveActivity(home, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY)
                ?.activityInfo?.packageName?.let { set += it }
        }
        runCatching {
            Settings.Secure.getString(ctx.contentResolver, "default_input_method")
                ?.substringBefore('/')?.takeIf { it.isNotBlank() }?.let { set += it }
        }
        runCatching { (ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).defaultDialerPackage?.let { set += it } }
        runCatching { Telephony.Sms.getDefaultSmsPackage(ctx)?.let { set += it } }
        return set
    }

    // =========================================================================================
    // Virtual turbo fan + thermal controller
    // =========================================================================================

    /** Saves the mode in the game's profile, then runs it. */
    suspend fun setFan(pkg: String?, mode: FanMode): List<StepResult> {
        if (pkg != null) repo.update(pkg) { it.copy(turbo = it.turbo.copy(fan = mode)) }
        return startFan(mode, pkg)
    }

    suspend fun startFan(mode: FanMode, pkg: String?): List<StepResult> {
        if (mode == FanMode.OFF) return wbMutex.withLock { stopFanLocked() }
        val steps = ArrayList<StepResult>()
        _state.update { it.copy(fanMode = mode, fanActive = true) }
        val temp = readBatt().tempC
        // Auto thermal waits until the battery is warm; the other two act immediately.
        if (mode != FanMode.AUTO_THERMAL || temp >= AUTO_COOL_C) {
            steps += coolActions(pkg ?: activeGame)
            coolApplied = true
        }
        ensureGuard()
        return steps.logAll()
    }

    suspend fun stopFan(): List<StepResult> = wbMutex.withLock { stopFanLocked() }

    private suspend fun stopFanLocked(): List<StepResult> {
        val out = ArrayList<StepResult>()
        val was = _state.value.fanMode != FanMode.OFF || dimmed || syncPausedByUs
        _state.update { it.copy(fanMode = FanMode.OFF, fanActive = false, fanRpm = 0) }
        coolApplied = false
        val p = activeGame?.let { repo.profile(it) }
        if (dimmed && p?.filter?.brightnessLock != true) {
            out += engine.releaseTracked(listOf(Ns.SYSTEM to "screen_brightness_mode", Ns.SYSTEM to "screen_brightness"))
        }
        dimmed = false
        if (syncPausedByUs && p?.pauseSync != true) out += engine.setBackgroundSyncPaused(false)
        syncPausedByUs = false
        if (was && out.isEmpty()) out += StepResult("Turbo fan", true, "stopped")
        return out
    }

    /** The real cooling work: fewer background processes, a 10% dimmer backlight, no background sync. */
    private suspend fun coolActions(game: String?): List<StepResult> {
        val out = ArrayList<StepResult>()
        val clean = cleanRam(game)
        out += StepResult("Cooling: background apps", true, describe(clean))
        out += dimBrightness(10)
        if (bridge.isMasterSyncOn()) {
            val r = engine.setBackgroundSyncPaused(true)
            if (r.ok) syncPausedByUs = true
            out += r.copy(step = "Cooling: background sync")
        }
        return out
    }

    /** Lowers the backlight by [percent] of its current value, once. The original (and auto mode) is restored on stop. */
    private suspend fun dimBrightness(percent: Int): StepResult {
        if (dimmed) return StepResult("Cooling: backlight", true, "already lowered")
        val cur = bridge.getSetting(Ns.SYSTEM, "screen_brightness")?.toIntOrNull()
            ?: return StepResult("Cooling: backlight", false, "current brightness could not be read")
        val maxB = bridge.brightnessMax()
        val floor = max(1, (maxB * 0.05f).roundToInt())
        val target = max(floor, (cur * (100 - percent) / 100f).roundToInt())
        if (target >= cur) return StepResult("Cooling: backlight", true, "already at the minimum")
        val mode = engine.putTracked(Ns.SYSTEM, "screen_brightness_mode", "0")
        val level = engine.putTracked(Ns.SYSTEM, "screen_brightness", target.toString())
        val ok = mode.ok && level.ok
        dimmed = ok
        return StepResult("Cooling: backlight -$percent%", ok, if (ok) "$cur -> $target of $maxB" else (if (!mode.ok) mode.detail else level.detail))
    }

    private fun rpmTarget(mode: FanMode, tempC: Float): Float = when (mode) {
        FanMode.OFF -> 0f
        FanMode.MAX_CYCLONE -> 20_000f
        FanMode.AUTO_THERMAL ->
            if (tempC < 36f) 0f else 3_000f + (min(tempC, 44f) - 36f) / 8f * (FanMode.AUTO_THERMAL.maxRpm - 3_000f)
        FanMode.SMART_COOL ->
            if (tempC < 33f) 4_000f else 6_000f + (min(tempC, 42f) - 33f) / 9f * (FanMode.SMART_COOL.maxRpm - 6_000f)
    }

    // ---- turbine sound and the speaker pulse ----

    /** Rising rotor whoosh. Synthesised: a sweep from 70 to 700 Hz with its second harmonic plus air noise. */
    suspend fun playTurbineSpinUp(durationMs: Int = 1_400): StepResult {
        val rate = 44_100
        val frames = durationMs.coerceIn(500, 4_000) * rate / 1000
        val pcm = ShortArray(frames)
        var phase = 0.0
        for (i in 0 until frames) {
            val x = i.toDouble() / frames
            val f = 70.0 + (700.0 - 70.0) * x * x
            phase += 2.0 * PI * f / rate
            val env = min(1.0, min(x / 0.08, (1.0 - x) / 0.2))
            val s = (0.55 * sin(phase) + 0.25 * sin(2.0 * phase) + 0.20 * (Random.nextDouble() * 2.0 - 1.0) * x) * env
            pcm[i] = (s * 0.8 * Short.MAX_VALUE).toInt().toShort()
        }
        return playPcm(pcm, rate, "Turbine spin-up sound")
    }

    /**
     * 165 Hz pulses through the speaker, the frequency phones use to push dust and moisture out of the grille.
     * Plays at the CURRENT media volume (raise it first); the system volume is never changed.
     */
    suspend fun playSonicEject(durationMs: Int = 3_000): StepResult {
        val rate = 48_000
        val frames = durationMs.coerceIn(1_000, 8_000) * rate / 1000
        val burst = 700 * rate / 1000
        val period = 950 * rate / 1000
        val fade = rate / 50 // 20 ms ramps, so the pulses do not click
        val pcm = ShortArray(frames)
        for (i in 0 until frames) {
            val pos = i % period
            if (pos >= burst) continue
            val env = min(1.0, min(pos, burst - pos).toDouble() / fade)
            pcm[i] = (sin(2.0 * PI * 165.0 * i / rate) * env * 0.95 * Short.MAX_VALUE).toInt().toShort()
        }
        return playPcm(pcm, rate, "Speaker eject pulse")
    }

    private suspend fun playPcm(pcm: ShortArray, rate: Int, name: String): StepResult = withContext(Dispatchers.IO) {
        var track: AudioTrack? = null
        try {
            track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(rate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(pcm.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            track.write(pcm, 0, pcm.size)
            track.play()
            delay(pcm.size * 1000L / rate + 150L)
            StepResult(name, true, "played at the current media volume").also { record(it) }
        } catch (t: Throwable) {
            StepResult(name, false, t.message ?: t.javaClass.simpleName).also { record(it) }
        } finally {
            runCatching { track?.stop() }
            runCatching { track?.release() }
        }
    }

    // =========================================================================================
    // Charge Separation + thermal cutoff
    // =========================================================================================

    /**
     * Arms Charge Separation. It engages whenever a charger is connected and the battery is above [floorPct],
     * and the safety watchdog resumes charging when the game exits, the charger is unplugged, or the level
     * drops to the floor. [pkg] (when given) saves the choice in that game's profile.
     */
    suspend fun setChargeSeparation(on: Boolean, floorPct: Int, allowSoftware: Boolean, pkg: String?): ChargeSepStatus {
        if (!on) return stopChargeSeparation("turned off")
        val floor = floorPct.coerceIn(5, 90)
        chargeWanted = true
        chargeAuto = false
        chargeFloor = floor
        chargeAllowSoftware = allowSoftware
        chargeResumeAbove = 0
        if (pkg != null) {
            repo.update(pkg) {
                it.copy(turbo = it.turbo.copy(chargeSeparation = true, chargeFloorPct = floor, softwareUnplugFallback = allowSoftware))
            }
        }
        publishCharge(_state.value.chargeSeparation.copy(wanted = true))
        val b = readBatt()
        val result = when {
            _state.value.chargeSeparation.on -> _state.value.chargeSeparation
            !b.plugged -> publishCharge(
                ChargeSepStatus(wanted = true, detail = "armed: charging stops as soon as a charger is connected")
            )
            b.pct in 0..floor -> publishCharge(
                ChargeSepStatus(wanted = true, detail = "battery is at ${b.pct}%, at or below the $floor% floor, so it keeps charging")
            )
            else -> engageCharge(allowSoftware, auto = false)
        }
        ensureGuard()
        return result
    }

    /** Saves "off" in the profile when [pkg] is given; always resumes charging. */
    suspend fun disableChargeSeparation(pkg: String?): ChargeSepStatus {
        if (pkg != null) repo.update(pkg) { it.copy(turbo = it.turbo.copy(chargeSeparation = false)) }
        return stopChargeSeparation("turned off")
    }

    suspend fun stopChargeSeparation(reason: String): ChargeSepStatus {
        chargeWanted = false
        chargeAuto = false
        chargeResumeAbove = 0
        return disengageCharge(reason).let { _state.value.chargeSeparation }
    }

    private suspend fun stopChargeSeparationLocked(reason: String): List<StepResult> {
        chargeWanted = false
        chargeAuto = false
        chargeResumeAbove = 0
        if (store.snapshot.charge == null && !_state.value.chargeSeparation.on) return emptyList()
        return listOf(disengageCharge(reason))
    }

    private class ChargeNode(val path: String, val off: String)

    private suspend fun engageCharge(allowSoftware: Boolean, auto: Boolean): ChargeSepStatus = chargeMutex.withLock {
        if (_state.value.chargeSeparation.on) return@withLock _state.value.chargeSeparation
        val b = readBatt()
        if (!b.plugged) {
            return@withLock publishCharge(ChargeSepStatus(wanted = chargeWanted, detail = "no charger connected"))
        }
        if (!bridge.hasShell()) {
            return@withLock publishCharge(
                ChargeSepStatus(wanted = chargeWanted, detail = "needs Shizuku or root to control charging")
            )
        }

        // 1. real charge control: a writable node under /sys. Verified by watching the battery status change.
        val probe = bridge.shell(
            "for p in ${CHARGE_NODES.joinToString(" ") { it.path }}; do [ -w \$p ] && echo \$p; done", 8_000L
        )
        val writable = probe.stdout.lineSequence().map { it.trim() }.filter { l -> CHARGE_NODES.any { it.path == l } }.toList()
        for (path in writable) {
            val node = CHARGE_NODES.first { it.path == path }
            val cur = bridge.shell("cat ${node.path}", 4_000L).stdout.trim()
            if (!Regex("^[0-9]+$").matches(cur)) continue
            store.update { it.copy(charge = ChargeBackup(node.path, cur, false)) } // BEFORE writing
            val w = bridge.shell("echo ${node.off} > ${node.path}", 4_000L)
            if (w.ok && awaitNotCharging(4_000L)) {
                return@withLock publishCharge(
                    ChargeSepStatus(
                        on = true, wanted = chargeWanted, hardware = true, method = node.path.substringAfterLast('/'),
                        detail = "charging suspended in hardware through ${node.path.substringAfterLast('/')}"
                    )
                )
            }
            bridge.shell("echo $cur > ${node.path}", 4_000L) // this node did not stop charging: put it back
            store.update { it.copy(charge = null) }
        }

        // 2. software unplug: Android is TOLD the charger is gone. The charger itself keeps charging.
        if (allowSoftware && !auto) {
            store.update { it.copy(charge = ChargeBackup("", "", true)) }
            val r = priv("cmd battery unplug", "Charge separation", "unplugged in software")
            if (r.ok) {
                return@withLock publishCharge(
                    ChargeSepStatus(
                        on = true, wanted = chargeWanted, hardware = false, method = "software unplug",
                        detail = "software only: Android reports the charger as unplugged, but no charge-control node " +
                            "was writable, so the charger still charges in hardware"
                    )
                )
            }
            store.update { it.copy(charge = null) }
            return@withLock publishCharge(ChargeSepStatus(wanted = chargeWanted, detail = r.detail))
        }
        publishCharge(
            ChargeSepStatus(
                wanted = chargeWanted,
                detail = if (writable.isEmpty()) "no writable charge-control node on this phone (usually needs root)"
                else "charge-control nodes were found but none stopped charging"
            )
        )
    }

    /** Restores charging and, for the software mode, `cmd battery reset`. Safe to call when nothing is engaged. */
    private suspend fun disengageCharge(reason: String): StepResult = chargeMutex.withLock {
        val c = store.snapshot.charge
        if (c == null && !_state.value.chargeSeparation.on) {
            publishCharge(_state.value.chargeSeparation.copy(wanted = chargeWanted, detail = reason))
            return@withLock StepResult("Charge separation", true, "not engaged")
        }
        var ok = true
        var msg = reason
        if (c != null && c.node.isNotEmpty()) {
            val known = CHARGE_NODES.any { it.path == c.node }
            if (known && Regex("^[0-9]+$").matches(c.restoreValue)) {
                val r = bridge.shell("echo ${c.restoreValue} > ${c.node}", 4_000L)
                if (!r.ok) {
                    ok = false
                    msg = "could not restore ${c.node}: ${r.message}"
                }
            }
        }
        if (c != null && c.software) {
            val r = priv("cmd battery reset", "Charge separation", "reset")
            if (!r.ok) {
                ok = false
                msg = "cmd battery reset failed: ${r.detail}"
            }
        }
        if (ok) store.update { it.copy(charge = null) }
        publishCharge(
            ChargeSepStatus(
                on = !ok && _state.value.chargeSeparation.on,
                wanted = chargeWanted,
                detail = if (ok) "charging restored ($reason)" else msg
            )
        )
        StepResult("Charge separation off", ok, msg).also { record(it) }
    }

    private fun publishCharge(s: ChargeSepStatus): ChargeSepStatus {
        _state.update { it.copy(chargeSeparation = s) }
        return s
    }

    private suspend fun awaitNotCharging(timeoutMs: Long): Boolean {
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            delay(500L)
            if (readBatt().status != BatteryManager.BATTERY_STATUS_CHARGING) return true
        }
        return false
    }

    private suspend fun chargeGuardTick(b: Batt) {
        val st = _state.value.chargeSeparation
        if (st.on) {
            val software = store.snapshot.charge?.software == true
            when {
                // in software mode Android already reports "unplugged", so that signal means nothing there
                !software && !b.plugged -> disengageCharge("charger unplugged")
                b.pct in 0..chargeFloor -> {
                    chargeResumeAbove = chargeFloor + 8
                    disengageCharge("battery at ${b.pct}%, at the $chargeFloor% floor")
                }
            }
        } else if ((chargeWanted || chargeAuto) && b.plugged && b.pct > max(chargeFloor, chargeResumeAbove)) {
            chargeResumeAbove = 0
            engageCharge(chargeAllowSoftware, chargeAuto && !chargeWanted)
        }
    }

    // ---- thermal cutoff (works with or without a charge-control node) ----

    private suspend fun thermalTick(b: Batt) {
        val s = _state.value
        val cutoff = (activeGame?.let { repo.profile(it)?.turbo?.thermalCutoffC } ?: 41).coerceIn(35, 55)
        if (!s.thermalTripped && b.tempC >= cutoff) {
            val note = String.format(Locale.US, "Battery %.1f C reached the %d C cutoff: cooling and charge protection engaged", b.tempC, cutoff)
            _state.update { it.copy(thermalTripped = true, thermalNote = note) }
            record(StepResult("Thermal cutoff", true, note))
            if (b.plugged && !_state.value.chargeSeparation.on) {
                chargeAuto = true // hardware nodes only: a software unplug would not cool anything
                engageCharge(false, auto = true)
            }
            if (!coolApplied) {
                coolApplied = true
                coolActions(activeGame).logAll()
            }
        } else if (s.thermalTripped && b.tempC <= cutoff - 3) {
            _state.update { it.copy(thermalTripped = false, thermalNote = "Battery cooled down to ${String.format(Locale.US, "%.1f", b.tempC)} C") }
            if (chargeAuto && !chargeWanted) {
                chargeAuto = false
                disengageCharge("battery cooled down")
            }
        }
    }

    // =========================================================================================
    // Native Battery Saver
    // =========================================================================================

    /**
     * ON: `cmd power set-mode 1`, `low_power=1`, `POWER_SAVE_MODE_OPEN=1` (Xiaomi), the game's Battery game
     * mode, and a 60 Hz lock. Without a shell it tries the settings key and then opens Android's own
     * Battery Saver screen. OFF puts everything back; if Battery Saver was already on before we touched
     * it, it is left on. The tile always follows the real state through ACTION_POWER_SAVE_MODE_CHANGED.
     */
    suspend fun setBatterySaver(on: Boolean, pkg: String?): List<StepResult> = wbMutex.withLock {
        val steps = ArrayList<StepResult>()
        setBusy("Battery Saver")
        try {
            if (on) {
                if (_state.value.active) steps += deactivateLocked(pkg)
                if (store.snapshot.batterySaverOriginal == null) {
                    val was = pm.isPowerSaveMode
                    store.update { it.copy(batterySaverOriginal = was) }
                }
                if (bridge.hasShell()) {
                    steps += priv("cmd power set-mode 1", "Native Battery Saver", "cmd power set-mode 1")
                    steps += engine.putTracked(Ns.GLOBAL, "low_power", "1")
                    steps += engine.putTracked(Ns.SYSTEM, "POWER_SAVE_MODE_OPEN", "1")
                } else {
                    val r = engine.putTracked(Ns.GLOBAL, "low_power", "1")
                    delay(700L)
                    if (pm.isPowerSaveMode) {
                        steps += r
                    } else {
                        steps += openBatterySaverSettings()
                    }
                }
                if (pkg != null) steps += engine.setGameMode(pkg, GameModeLevel.BATTERY, null, 0)
                steps += engine.lockRefreshRate(60)
                fps.holdRate(60)
                _state.update { it.copy(tier = PerfTier.ECO) }
            } else {
                steps += restoreBatterySaverIfOurs()
                steps += engine.releaseTracked(listOf(Ns.GLOBAL to "low_power", Ns.SYSTEM to "POWER_SAVE_MODE_OPEN"))
                steps += fps.releaseSoft("Battery Saver turned off")
                if (pkg != null) {
                    val p = repo.profile(pkg)
                    if (p != null) {
                        steps += engine.setGameTuning(pkg, p.gameMode, p.downscale, p.targetFps, p.fpsCapViaDisplay, p.refreshHz)
                        if (p.refreshHz == 0 && !(p.targetFps > 0 && p.fpsCapViaDisplay)) steps += engine.unlockRefreshRate()
                        if (p.turbo.unlockFps > 0) fps.enforce(pkg, p.turbo.unlockFps)
                    }
                }
                _state.update { it.copy(tier = PerfTier.BALANCED) }
            }
            delay(400L)
            _state.update { it.copy(batterySaverOn = pm.isPowerSaveMode) }
        } finally {
            setBusy(null)
        }
        steps.logAll()
    }

    /** Switches Battery Saver off only when WE turned it on. */
    private suspend fun restoreBatterySaverIfOurs(): List<StepResult> {
        val original = store.snapshot.batterySaverOriginal ?: return emptyList()
        val out = ArrayList<StepResult>()
        if (!original) {
            out += if (bridge.hasShell()) priv("cmd power set-mode 0", "Native Battery Saver off", "cmd power set-mode 0")
            else openBatterySaverSettings()
        }
        store.update { it.copy(batterySaverOriginal = null) }
        return out
    }

    private fun openBatterySaverSettings(): StepResult = try {
        ctx.startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        StepResult("Battery Saver", true, "opened Android's Battery Saver settings: switch it there (no Shizuku or root)")
    } catch (t: Throwable) {
        StepResult("Battery Saver", false, t.message ?: "could not open the Battery Saver settings")
    }

    // =========================================================================================
    // Gaming DNS switcher (Cloudflare 1.1.1.1, Google, AdGuard ...)
    // =========================================================================================

    suspend fun setGamingDns(preset: DnsPreset): StepResult = engine.setDns(preset)

    suspend fun restoreDns(): StepResult = engine.restoreDns()

    // =========================================================================================
    // Guard loop (fan speed, charge watchdog, thermal cutoff)
    // =========================================================================================

    private data class Batt(val tempC: Float, val pct: Int, val plugged: Boolean, val status: Int)

    private fun readBatt(): Batt {
        val i: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val pct = if (level >= 0 && scale > 0) (level * 100f / scale).roundToInt() else -1
        val plugged = (i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        return Batt(temp, pct, plugged, status)
    }

    private fun guardNeeded(): Boolean {
        val s = _state.value
        return s.fanMode != FanMode.OFF || chargeWanted || chargeAuto || s.chargeSeparation.on || s.active || activeGame != null
    }

    private fun ensureGuard() {
        synchronized(guardLock) {
            if (guardJob?.isActive == true) return
            guardJob = scope.launch { guardLoop() }
        }
    }

    private suspend fun guardLoop() {
        var rpm = 0f
        while (currentCoroutineContext().isActive) {
            val b = readBatt()
            val mode = _state.value.fanMode

            // rotor speed: ramps like a real rotor (spins up faster than it spins down)
            val target = rpmTarget(mode, b.tempC)
            rpm += (target - rpm).coerceIn(-3_000f, 2_500f)
            if (mode == FanMode.AUTO_THERMAL && !coolApplied && b.tempC >= AUTO_COOL_C) {
                coolApplied = true
                scope.launch { coolActions(activeGame).logAll() }
            }
            _state.update { it.copy(fanRpm = rpm.roundToInt(), fanActive = mode != FanMode.OFF, batteryTempC = b.tempC) }

            runCatching { chargeGuardTick(b) }
            runCatching { thermalTick(b) }

            if (!guardNeeded()) break
            delay(1_000L)
        }
    }

    // =========================================================================================
    // Helpers
    // =========================================================================================

    private fun setBusy(text: String?) {
        _state.update { it.copy(busy = text) }
    }

    private fun record(r: StepResult) {
        _state.update {
            it.copy(log = (it.log + EngineLogLine(System.currentTimeMillis(), r.step, r.ok, r.detail)).takeLast(100))
        }
    }

    private fun List<StepResult>.logAll(): List<StepResult> = also { list -> list.forEach { record(it) } }

    private companion object {
        const val OWNER_WB = "wildboost"
        const val DAY_MS = 24L * 3_600_000L
        const val AUTO_COOL_C = 38f

        /** Updated system apps that are big RAM users and safe to stop. Everything else that is a system app is left alone. */
        val HEAVY_SYSTEM_APPS = setOf(
            "com.android.chrome", "com.google.android.youtube", "com.google.android.apps.photos",
            "com.google.android.apps.docs"
        )

        /** Charge-control nodes seen on Qualcomm, MediaTek, Samsung, OnePlus, Motorola, Xiaomi and Pixel kernels. */
        val CHARGE_NODES = listOf(
            ChargeNode("/sys/class/power_supply/battery/input_suspend", "1"),
            ChargeNode("/sys/class/power_supply/battery/charging_enabled", "0"),
            ChargeNode("/sys/class/power_supply/battery/battery_charging_enabled", "0"),
            ChargeNode("/sys/class/power_supply/battery/mmi_charging_enable", "0"),
            ChargeNode("/sys/class/power_supply/battery/batt_slate_mode", "1"),
            ChargeNode("/sys/class/power_supply/battery/store_mode", "1"),
            ChargeNode("/sys/class/power_supply/battery/op_disable_charge", "1"),
            ChargeNode("/sys/class/power_supply/battery/charge_disable", "1"),
            ChargeNode("/sys/class/power_supply/usb/input_suspend", "1"),
            ChargeNode("/sys/class/qcom-battery/input_suspend", "1"),
            ChargeNode("/sys/devices/platform/soc/soc:google,charger/charge_disable", "1"),
            ChargeNode("/sys/kernel/debug/google_charger/input_suspend", "1")
        )
    }
}
