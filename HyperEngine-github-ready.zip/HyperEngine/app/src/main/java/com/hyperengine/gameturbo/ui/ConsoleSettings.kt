package com.hyperengine.gameturbo.ui

import android.view.View
import com.hyperengine.gameturbo.data.EdgeSide
import com.hyperengine.gameturbo.data.SlideItemIds
import com.hyperengine.gameturbo.data.ThemeId
import com.hyperengine.gameturbo.service.CompetitiveMode
import com.hyperengine.gameturbo.service.SliderFeedback
import kotlinx.coroutines.launch

/**
 * One page for everything console-like: theme, HUD layout, the Volume-key hardware switch and what the
 * Competitive Mode tile does. Opened from the landscape HUD's gear button and from the "Console" tool tile.
 */
object ConsoleSettings {

    fun build(host: ToolHost): View {
        val ctx = host.hostContext
        val theme = host.theme
        val repo = host.deps.repo
        val g = repo.global.value
        val col = Ui.vbox(ctx)
        val result = Ui.label(ctx, "", 11f, theme.textSecondary)

        // ---- theme ----
        col.addView(Ui.section(ctx, theme, "Theme"))
        col.addView(ChipGroup(ctx, theme, HudThemes.LABELS, g.theme.ordinal, 2) { i ->
            repo.updateGlobal { it.copy(theme = ThemeId.values()[i]) }
        })

        // ---- layout ----
        col.addView(Ui.section(ctx, theme, "HUD layout"))
        col.addView(
            ToolUi.note(host, "Automatic opens the dual-wing console HUD when the screen is landscape and the one-column sidebar in portrait.")
        )
        col.addView(ChipGroup(ctx, theme, listOf("Automatic", "Wings", "Sidebar"), g.hudLayout.mode.coerceIn(0, 2), 3) { i ->
            repo.updateGlobal { it.copy(hudLayout = it.hudLayout.copy(mode = i)) }
        })
        col.addView(Ui.labeledSlider(ctx, theme, "Background dim", "%", 0, 80, g.hudLayout.scrimPct) { v ->
            repo.updateGlobal { it.copy(hudLayout = it.hudLayout.copy(scrimPct = v)) }
        }, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 8), 0, 0))
        col.addView(Ui.labeledSlider(ctx, theme, "Control wing width", " dp", 240, 380, g.hudLayout.wingWidthDp.coerceIn(240, 380)) { v ->
            repo.updateGlobal { it.copy(hudLayout = it.hudLayout.copy(wingWidthDp = v)) }
        }, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 6), 0, 0))
        col.addView(ToolUi.check(ctx, theme, "Gamepad / keyboard navigation while the HUD is open", g.hudLayout.controllerNav) { on ->
            repo.updateGlobal { it.copy(hudLayout = it.hudLayout.copy(controllerNav = on)) }
        })

        // ---- controller key hints (redesign part 2) ----
        col.addView(Ui.section(ctx, theme, "Controller key hints"))
        col.addView(
            ToolUi.note(host, "The strip along the bottom of the landscape HUD: B Back, Y Console settings, X Dashboard / All tools, L1 / R1 Cube face. Auto shows it only while a gamepad or keyboard is connected.")
        )
        col.addView(ChipGroup(ctx, theme, listOf("Auto", "Always", "Never"), g.hudLayout.hintMode.coerceIn(0, 2), 3) { i ->
            repo.updateGlobal { it.copy(hudLayout = it.hudLayout.copy(hintMode = i)) }
        })

        // ---- quick toggle rail (redesign part 2) ----
        col.addView(Ui.section(ctx, theme, "Quick toggle rail"))
        col.addView(
            ToolUi.note(host, "The round buttons on the left of the landscape HUD. Tap flips the feature (or opens its page), long-press opens its page. The All tools button is always there.")
        )
        val railCard = Hyper.card(ctx, theme)
        val onRail = g.hudLayout.railItems.toSet()
        QuickCatalog.IDS.filter { ToolRegistry.has(it) }.forEachIndexed { i, id ->
            if (i > 0) Hyper.addDivider(ctx, theme, railCard)
            railCard.addView(Hyper.switchRow(ctx, theme, ToolCatalog.info(id).title, null, id in onRail) { checked ->
                repo.updateGlobal { cur ->
                    val set = cur.hudLayout.railItems.toMutableSet()
                    if (checked) set.add(id) else set.remove(id)
                    cur.copy(hudLayout = cur.hudLayout.copy(railItems = QuickCatalog.IDS.filter { it in set }))
                }
            })
        }
        col.addView(railCard, Ui.lp(Ui.MATCH, Ui.WRAP))

        // ---- slide bar (redesign part 3) ----
        col.addView(Ui.section(ctx, theme, "Slide bar"))
        col.addView(
            ToolUi.note(host, "The edge tab that opens the dock: Apps, Chat apps, Browser, Notes and Calculator, plus your pinned apps. Tap the tab or drag it inward. Long-press the tab and drag to move it along the edge. Opening the slide bar closes the HUD and the other way round.")
        )
        val sb = g.slideBar
        fun updSlide(t: (com.hyperengine.gameturbo.data.SlideBarConfig) -> com.hyperengine.gameturbo.data.SlideBarConfig) =
            repo.updateGlobal { it.copy(slideBar = t(it.slideBar)) }
        col.addView(ToolUi.check(ctx, theme, "Show the edge tab in games", sb.enabled) { on -> updSlide { it.copy(enabled = on) } })
        col.addView(Ui.section(ctx, theme, "Slide bar edge"))
        col.addView(ChipGroup(ctx, theme, listOf("Left", "Right"), if (sb.side == EdgeSide.LEFT) 0 else 1, 2) { i ->
            updSlide { it.copy(side = if (i == 0) EdgeSide.LEFT else EdgeSide.RIGHT) }
        })
        col.addView(Ui.section(ctx, theme, "Dock buttons"))
        val slideCard = Hyper.card(ctx, theme)
        val slideNames = mapOf(
            SlideItemIds.APPS to "All apps (floating windows)",
            SlideItemIds.CHAT to "Chat apps",
            SlideItemIds.BROWSER to "Mini browser",
            SlideItemIds.NOTES to "Quick notes",
            SlideItemIds.CALC to "Calculator"
        )
        SlideItemIds.ALL.forEachIndexed { i, id ->
            if (i > 0) Hyper.addDivider(ctx, theme, slideCard)
            slideCard.addView(Hyper.switchRow(ctx, theme, slideNames[id].orEmpty(), null, id in sb.items) { checked ->
                updSlide { cur ->
                    val set = cur.items.toMutableSet()
                    if (checked) set.add(id) else set.remove(id)
                    cur.copy(items = SlideItemIds.ALL.filter { it in set })
                }
            })
        }
        col.addView(slideCard, Ui.lp(Ui.MATCH, Ui.WRAP))
        col.addView(ToolUi.check(ctx, theme, "Show pinned apps under the buttons", sb.showPinned) { on -> updSlide { it.copy(showPinned = on) } })
        col.addView(Ui.labeledSlider(ctx, theme, "Pinned apps shown", "", 0, 6, sb.pinnedCount.coerceIn(0, 6)) { v ->
            updSlide { it.copy(pinnedCount = v) }
        }, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 6), 0, 0))
        col.addView(
            ToolUi.note(host, "Pin an app by long-pressing it in the Apps page. Long-press a pinned app in the dock to unpin it."),
            Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 4), 0, 0)
        )
        col.addView(ToolUi.check(ctx, theme, "Close the slide bar after opening an app or window", sb.closeOnLaunch) { on -> updSlide { it.copy(closeOnLaunch = on) } })
        col.addView(Ui.labeledSlider(ctx, theme, "Page width (Apps, Chat)", " dp", 260, 400, sb.flyoutWidthDp.coerceIn(260, 400)) { v ->
            updSlide { it.copy(flyoutWidthDp = v) }
        }, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 6), 0, 0))
        col.addView(Ui.labeledSlider(ctx, theme, "Edge tab idle opacity", "%", 10, 100, sb.idleAlphaPct.coerceIn(10, 100)) { v ->
            updSlide { it.copy(idleAlphaPct = v) }
        }, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 6), 0, 0))
        col.addView(Ui.button(ctx, theme, "Open the slide bar now", true) {
            HudBus.openSlideBar?.invoke()
        }, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 10), 0, 0))

        // ---- hardware switch ----
        col.addView(Ui.section(ctx, theme, "Hardware switch (Volume Up + Volume Down)"))
        col.addView(
            ToolUi.note(
                host,
                "Hold both volume keys to flip Competitive Mode from anywhere, like the RedMagic slider. " +
                    "Needs the HyperEngine accessibility service to be on."
            )
        )
        col.addView(ToolUi.check(ctx, theme, "Enable the key chord", g.chord.enabled) { on ->
            repo.updateGlobal { it.copy(chord = it.chord.copy(enabled = on)) }
        })
        col.addView(Ui.labeledSlider(ctx, theme, "Hold time", " ms", 600, 3000, g.chord.holdMs.coerceIn(600, 3000)) { v ->
            repo.updateGlobal { it.copy(chord = it.chord.copy(holdMs = v)) }
        })

        // ---- competitive mode ----
        col.addView(Ui.section(ctx, theme, "Competitive Mode (tile and key chord)"))
        val c = g.competitive
        fun upd(t: (com.hyperengine.gameturbo.data.CompetitiveConfig) -> com.hyperengine.gameturbo.data.CompetitiveConfig) =
            repo.updateGlobal { it.copy(competitive = t(it.competitive)) }
        col.addView(ToolUi.check(ctx, theme, "Lock the screen to landscape", c.forceLandscape) { on -> upd { it.copy(forceLandscape = on) } })
        col.addView(ToolUi.check(ctx, theme, "Start Wild Boost", c.wildBoost) { on -> upd { it.copy(wildBoost = on) } })
        col.addView(ToolUi.check(ctx, theme, "Use Diablo mode instead of plain Wild Boost", c.diablo) { on -> upd { it.copy(diablo = on) } })
        col.addView(ToolUi.check(ctx, theme, "Open the Game Space lobby", c.openLobby) { on -> upd { it.copy(openLobby = on) } })
        col.addView(ToolUi.check(ctx, theme, "Slider sound", c.sound) { on -> upd { it.copy(sound = on) } })
        col.addView(ToolUi.check(ctx, theme, "Heavy haptic thud", c.haptic) { on -> upd { it.copy(haptic = on) } })

        val row = Ui.hbox(ctx)
        row.addView(Ui.button(ctx, theme, "Test sound and thud") {
            val cur = repo.global.value.competitive
            SliderFeedback.play(ctx, cur.sound, cur.haptic)
        }, Ui.lp(0, Ui.WRAP, 1f, 0, 0, Ui.dp(ctx, 4), 0))
        row.addView(Ui.button(ctx, theme, "Flip mode now", true) {
            host.scope.launch {
                val text = CompetitiveMode.toggle(ctx)
                result.setTextColor(theme.good)
                result.text = text
                host.refreshTiles()
            }
        }, Ui.lp(0, Ui.WRAP, 1f, Ui.dp(ctx, 4), 0, 0, 0))
        col.addView(row, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 10), 0, 0))
        col.addView(result, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 6), 0, 0))
        col.addView(
            ToolUi.note(host, "Add the tile: pull down Quick Settings, tap the pencil, drag Competitive Mode into your tiles."),
        )
        return col
    }
}

class ConsoleTool : HudTool("console") {
    override fun isActive(host: ToolHost): Boolean = CompetitiveMode.isActive(host.hostContext)
    override fun onTap(host: ToolHost) {
        host.openDetail("Console settings", ConsoleSettings.build(host))
    }
}
