package com.hyperengine.gameturbo.service

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.os.Handler
import android.os.Looper
import com.hyperengine.gameturbo.R
import com.hyperengine.gameturbo.core.CustomWildBoostEngine
import com.hyperengine.gameturbo.core.FpsRefreshRateEnforcer
import com.hyperengine.gameturbo.core.OptimizationEngine
import com.hyperengine.gameturbo.core.PerfTier
import com.hyperengine.gameturbo.core.StepResult
import com.hyperengine.gameturbo.core.SystemBridgeExecutor
import com.hyperengine.gameturbo.data.GameProfileRepository
import com.hyperengine.gameturbo.ui.WildBoostAuraOverlay
import com.hyperengine.gameturbo.ui.WildBoostIgnitionOverlay
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.max
import kotlin.math.min

/**
 * One definition of "Wild Boost ON" for every entry point: the Quick Settings tile and the sidebar's
 * Performance tier chip. Lives in HyperApp, so it works with or without the HUD on screen.
 *
 * Full boost for a game =
 *   1  CustomWildBoostEngine: fixed performance mode, OEM throttlers frozen (powerkeeper), animations off,
 *      RAM clean, background data block, game mode PERFORMANCE
 *   2  FpsRefreshRateEnforcer: the 5-layer lock at max(profile unlock, 144), rounded down to what the panel offers
 *   3  every registered [Booster] (HyperBoost scaling and low-latency mode register here)
 *   4  `cmd package compile` in the background (the engine skips it when it ran in the last 24 hours)
 *
 * Without a game in front (tile tapped on the home screen) there is nothing to boost, so Wild Boost is armed
 * for the next game instead and starts the moment the detector sees one. Tapping again cancels it.
 *
 * Ignition only plays when privileged commands can actually run, so the animation never celebrates a boost
 * that did nothing. Ignition does not replay when a profile auto-starts Wild Boost at game launch.
 *
 * Threading: [toggle], [ignite] and the state flow are main-thread friendly; [boostOn] / [boostOff] are
 * suspend and may be called from any dispatcher.
 */
class WildBoostController(
    context: Context,
    private val bridge: SystemBridgeExecutor,
    private val engine: OptimizationEngine,
    private val fps: FpsRefreshRateEnforcer,
    private val wild: CustomWildBoostEngine,
    private val repo: GameProfileRepository
) {

    enum class Source { TILE, HUD }

    /**
     * An extra that rides along with Wild Boost (HyperBoost scaling, low-latency mode). [apply] must be safe to call
     * twice with the same value and must return an honest result.
     */
    class Booster(val id: String, val apply: suspend (game: String, on: Boolean) -> StepResult)

    /**
     * [on]      tile shows active (boost applied, being applied, or armed for the next game)
     * [pending] armed for the next game, nothing applied yet
     * [hz]      refresh rate the boost is aiming for (panel limited)
     * [note]    short problem text for the tile subtitle ("PARTIAL BOOST", "Needs Shizuku"); null when fine
     */
    data class UiState(
        val on: Boolean = false,
        val pending: Boolean = false,
        val busy: Boolean = false,
        val hz: Int = TARGET_FPS,
        val note: String? = null
    )

    private val ctx: Context = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val prefs = ctx.getSharedPreferences("hyper_wildboost_tile", Context.MODE_PRIVATE)
    private val ignition = WildBoostIgnitionOverlay(ctx)
    private val aura = WildBoostAuraOverlay(ctx)
    private val boosters = CopyOnWriteArrayList<Booster>()

    private val pending = MutableStateFlow(prefs.getBoolean(KEY_PENDING, false))
    private val transition = MutableStateFlow<Boolean?>(null)   // true = switching on, false = switching off
    private val note = MutableStateFlow<String?>(null)

    @Volatile private var extrasGame: String? = null
    private var releaseJob: Job? = null
    private var opJob: Job? = null                 // the running on/off; a newer tap cancels it and takes over
    private val opGen = AtomicInteger()

    /** Called on the main thread when the turbine lands in the edge pill. HudController uses it to flash the handle. */
    @Volatile var onIgnitionDocked: (() -> Unit)? = null

    // Declared before [state]: its eagerly started collector reads this on the first emission.
    private val panelCapHz: Int by lazy {
        runCatching { engine.supportedRefreshRates().maxOrNull() }.getOrNull()
            ?.takeIf { it > 0 }?.let { min(it, TARGET_FPS) } ?: TARGET_FPS
    }

    val state: StateFlow<UiState> = combine(wild.state, pending, transition, note) { w, armed, t, n ->
        UiState(
            on = t ?: (w.active || armed),
            pending = armed && !w.active,
            busy = t != null || w.busy != null,
            hz = targetHz(),
            note = n
        )
    }.stateIn(scope, SharingStarted.Eagerly, UiState())

    init {
        // Builds the turbine sound off the main thread, so a cold tile tap starts the audio on frame one.
        WildBoostIgnitionOverlay.prewarmSound()
    }

    // =========================================================================================
    // Boosters (Step 2 modules register here)
    // =========================================================================================

    fun registerBooster(b: Booster) {
        boosters.removeAll { it.id == b.id }
        boosters.add(b)
    }

    fun unregisterBooster(id: String) {
        boosters.removeAll { it.id == id }
    }

    // =========================================================================================
    // Entry points
    // =========================================================================================

    /** Tile tap. Switches Wild Boost on or off; ignores taps while a switch is still running. */
    fun toggle(source: Source) {
        if (isOn()) turnOff(source) else turnOn(source)
    }

    /**
     * Runs one on/off at a time, in tap order. A newer tap cancels the one still running (even a boost that is half
     * way through switching on) and waits for its clean-up before starting, so "off" is never ignored.
     */
    private fun launchOp(wantOn: Boolean, block: suspend () -> Unit) {
        val prev = opJob
        prev?.cancel()
        val gen = opGen.incrementAndGet()
        transition.value = wantOn
        opJob = scope.launch(Dispatchers.Default) {
            try {
                prev?.join()
                block()
            } finally {
                if (opGen.get() == gen) transition.value = null
            }
        }
    }

    private fun isOn(): Boolean = transition.value ?: (wild.state.value.active || pending.value)

    private fun turnOn(source: Source) {
        if (!bridge.hasShell()) {
            note.value = ctx.getString(R.string.wild_boost_needs_shizuku)
            return
        }
        note.value = null
        val game = currentGame()
        if (game != null) {
            launchOp(true) { applyOn(game, persistMode = false) }
        } else {
            setPending(true)
            // The watcher is what notices the game; start it if the user has not.
            runCatching {
                if (!GameDetectorService.state.value.running) GameDetectorService.start(ctx)
            }
        }
        scope.launch {
            if (source == Source.TILE) {
                collapseShade()
                delay(SHADE_SETTLE_MS)     // the shade sits above overlay windows until its animation ends
                aura(on = true)            // the tile gets the modern aura; the HUD keeps the full turbine
            } else {
                ignite()
            }
        }
    }

    private fun turnOff(source: Source) {
        note.value = null
        setPending(false)
        if (source == Source.TILE) {
            scope.launch {
                collapseShade()
                delay(SHADE_SETTLE_MS)
                aura(on = false)           // a tap on "off" shows that it happened
            }
        }
        // Only the armed one-shot was cancelled: nothing was applied, so nothing to undo.
        if (!wild.state.value.active && transition.value == null && extrasGame == null) return
        val game = wild.state.value.game ?: currentGame() ?: fps.state.value.game
        launchOp(false) { applyOff(game, persistMode = false) }
    }

    /**
     * The full boost for [game]. [persistMode] true = the HUD route: the profile's game mode is saved as
     * Performance (same as the tier chip always did). false = the tile route: nothing in the profile changes.
     * [activateWild] false = the engine already activated Wild Boost (a profile auto-started it).
     * Returns every step, so the HUD can print them.
     */
    suspend fun boostOn(game: String, persistMode: Boolean, activateWild: Boolean = true): List<StepResult> {
        transition.value = true
        try {
            return applyOn(game, persistMode, activateWild)
        } finally {
            transition.value = null
        }
    }

    private suspend fun applyOn(game: String, persistMode: Boolean, activateWild: Boolean = true): List<StepResult> {
        val steps = ArrayList<StepResult>()
        run {
            val profile = repo.profile(game) ?: repo.getOrCreate(game, game)

            if (activateWild) {
                steps += if (persistMode) wild.setTier(game, PerfTier.WILDBOOST)
                else wild.activate(game, profile.turbo.diablo || wild.state.value.diablo)
            }

            // 5-layer lock. Never lowers a rate the profile already asked for. Skipped if already holding it.
            val want = max(profile.turbo.unlockFps, TARGET_FPS)
            val f = fps.state.value
            if (!f.active || f.game != game || f.targetFps < want) {
                steps += withContext(Dispatchers.Default) { fps.enforce(game, want).layers }
            }
            extrasGame = game

            for (b in boosters) steps += runBooster(b, game, true)

            // Heavy, so it never blocks the boost itself. The engine skips it if done in the last 24 hours.
            scope.launch(Dispatchers.Default) { runCatching { wild.compileDex(game, force = false) } }

            val failed = steps.count { !it.ok }
            note.value = when {
                persistMode || steps.isEmpty() -> null          // the HUD shows each step itself
                failed == steps.size -> {
                    runCatching { wild.deactivate(game) }
                    releaseExtras(game)
                    ctx.getString(R.string.wild_boost_failed)
                }
                failed > 0 -> ctx.getString(R.string.wild_boost_partial)
                else -> null
            }
        }
        return steps
    }

    /** Wild Boost and everything [boostOn] added, off. */
    suspend fun boostOff(game: String?, persistMode: Boolean): List<StepResult> {
        transition.value = false
        try {
            return applyOff(game, persistMode)
        } finally {
            transition.value = null
        }
    }

    private suspend fun applyOff(game: String?, persistMode: Boolean): List<StepResult> {
        val g = game ?: extrasGame ?: fps.state.value.game
        val steps = ArrayList<StepResult>()
        steps += releaseExtras(g, force = true)
        steps += if (persistMode && g != null) wild.setTier(g, PerfTier.BALANCED) else wild.deactivate(g)
        // A profile that starts Wild Boost with its game would switch it straight back on the moment the game
        // regains focus (closing the shade does exactly that). A deliberate off clears it, like the HUD chip does.
        if (g != null && repo.profile(g)?.turbo?.wildBoost == true) {
            repo.update(g) { it.copy(turbo = it.turbo.copy(wildBoost = false)) }
        }
        return steps
    }

    /**
     * Takes back the 5-layer lock and the boosters that [boostOn] added. If the profile has its own FPS
     * unlock, that level is put back instead of switching the lock off. Safe to call when nothing was added.
     */
    suspend fun releaseExtras(game: String?, force: Boolean = false): List<StepResult> {
        // [force] (a deliberate off) also lets go of a lock this controller did not remember adding, e.g. after the
        // process was restarted while Wild Boost was on.
        val g = extrasGame ?: (if (force) game ?: fps.state.value.game else null) ?: return emptyList()
        extrasGame = null
        val out = ArrayList<StepResult>()
        for (b in boosters) out += runBooster(b, g, false)
        if (fps.state.value.active) {
            val keep = repo.profile(g)?.turbo?.unlockFps ?: 0
            out += withContext(Dispatchers.Default) {
                if (keep > 0) {
                    if (fps.state.value.targetFps != keep) fps.enforce(g, keep).layers else emptyList()
                } else {
                    fps.deactivate(g)
                }
            }
        }
        return out
    }

    private suspend fun runBooster(b: Booster, game: String, on: Boolean): StepResult =
        try {
            b.apply(game, on)
        } catch (t: Throwable) {
            StepResult(b.id, false, t.message ?: "failed")
        }

    // =========================================================================================
    // Game lifecycle (called by GameDetectorService, right after the engines)
    // =========================================================================================

    fun onGameForeground(game: String) {
        releaseJob?.cancel()
        releaseJob = null
        if (extrasGame != null && extrasGame != game) extrasGame = null
        if (!pending.value) return
        setPending(false)
        scope.launch {
            // The engine applies the game's profile first; our boost must not be overwritten by it.
            withTimeoutOrNull(8_000L) { engine.status.first { it.activeGame == game && it.busy == null } }
            boostOn(game, persistMode = false, activateWild = !wild.state.value.active)
        }
    }

    /** The engines release after the restore delay; the boosters follow on the same schedule. */
    fun onGameBackground() {
        val g = extrasGame ?: return
        val delaySec = repo.global.value.restoreDelayFor(repo.profile(g))
        releaseJob?.cancel()
        releaseJob = scope.launch {
            delay((delaySec * 1000L - 1_500L).coerceAtLeast(0L))
            if (extrasGame == g) {
                extrasGame = null
                for (b in boosters) runBooster(b, g, false)
            }
        }
    }

    /** The game watcher was stopped: nothing will restore later, so let the boosters go now. */
    fun onWatcherStopped() {
        releaseJob?.cancel()
        releaseJob = null
        val g = extrasGame ?: return
        extrasGame = null
        scope.launch { for (b in boosters) runBooster(b, g, false) }
    }

    // =========================================================================================
    // Ignition
    // =========================================================================================

    /** Plays the 2.2 s ignition, docking into the edge pill. No-op without privileged access. Any thread. */
    fun ignite(force: Boolean = false) {
        if (!bridge.hasShell()) return
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post { ignite(force) }
            return
        }
        val spec = WildBoostIgnitionOverlay.specFromSettings(ctx, force)
            .copy(fpsTarget = targetHz(), scaleLabel = scaleLabel())
        ignition.onDocked = { onIgnitionDocked?.invoke() }
        ignition.play(spec)
    }

    /** The tile's animation. Main thread only (callers are on it). */
    private fun aura(on: Boolean) {
        if (on) {
            aura.play(true, ctx.getString(R.string.wild_boost_tile_label).uppercase(),
                ctx.getString(R.string.wild_boost_tile_sub_on, targetHz()))
        } else {
            aura.play(false, ctx.getString(R.string.wild_boost_tile_sub_off).uppercase(),
                ctx.getString(R.string.wild_boost_aura_off_sub))
        }
    }

    /** Honest label for the scaling row: ACTIVE only when a HyperBoost booster is registered to apply it. */
    private fun scaleLabel(): String =
        if (boosters.any { it.id == ID_HYPERBOOST }) "ACTIVE" else "STANDBY"

    // =========================================================================================
    // Helpers
    // =========================================================================================

    /** The rate the lock is holding, or what it will aim for: 144 capped to the panel's best mode. */
    private fun targetHz(): Int {
        val locked = fps.lockedHz.value
        return if (locked > 0) locked else panelCapHz
    }

    private fun currentGame(): String? =
        GameDetectorService.state.value.let { it.game ?: it.demo }

    private fun setPending(on: Boolean) {
        pending.value = on
        prefs.edit().putBoolean(KEY_PENDING, on).apply()
    }

    /**
     * Closes the notification shade so the player lands back in the game: `cmd statusbar collapse` through
     * Shizuku, or Back through the accessibility service when no shell answers.
     */
    private suspend fun collapseShade() {
        val ok = withContext(Dispatchers.IO) {
            runCatching { bridge.shell("cmd statusbar collapse", 3_000L).ok }.getOrDefault(false)
        }
        if (!ok) {
            TouchMacroService.instance?.let {
                runCatching { it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK) }
            }
        }
    }

    companion object {
        const val TARGET_FPS = 144
        const val ID_HYPERBOOST = "hyperboost"
        const val ID_LOW_LATENCY = "lowLatency"
        private const val KEY_PENDING = "pending"
        private const val SHADE_SETTLE_MS = 160L
    }
}
