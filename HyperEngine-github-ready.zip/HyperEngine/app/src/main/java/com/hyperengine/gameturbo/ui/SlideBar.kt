package com.hyperengine.gameturbo.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Rect
import android.graphics.RectF
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.hyperengine.gameturbo.core.AppEntry
import com.hyperengine.gameturbo.core.DisplayModeLock
import com.hyperengine.gameturbo.core.FreeformAppLauncher
import com.hyperengine.gameturbo.data.EdgeSide
import com.hyperengine.gameturbo.data.HandleConfig
import com.hyperengine.gameturbo.data.SlideBarConfig
import com.hyperengine.gameturbo.data.SlideItemIds
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Slide bar (UI redesign, part 3), modelled on the HyperOS Game Turbo toolbox.
 *
 * Apps, Chat apps, Browser, Notes and Calculator used to be tiles inside the HUD. They now live here:
 *
 *  - [SlideBarTab]        a slim edge tab (opposite edge to the HUD handle by default). Tap or drag inward to open.
 *  - dock                 a vertical strip of round buttons: Apps, Chat, Browser, Notes, Calc, then the pinned apps.
 *  - flyout               opens beside the dock for the two buttons that need a page: Apps (searchable grid of every
 *                         launcher app, floating windows) and Chat apps (floating or split).
 *  - Browser / Notes / Calc toggle their floating mini window straight away and, by default, close the bar.
 *
 * The slide bar and the HUD never show at the same time: opening one closes the other. Every window it adds is
 * sized to what is on screen, so touches outside the dock and flyout always reach the game (a tap there closes it).
 */

/** The "Slide bar" tile in the All tools grid and the optional rail button: opens the slide bar. */
class SlideBarTool : HudTool("slidebar") {
    override fun isActive(host: ToolHost): Boolean = HudBus.slideBarOpen?.invoke() == true
    override fun onTap(host: ToolHost) {
        val open = HudBus.openSlideBar
        if (open == null) host.toast("The slide bar is only available while a game is on screen") else open()
    }
}

// ---------------------------------------------------------------------------------------------
// Edge tab
// ---------------------------------------------------------------------------------------------

class SlideBarTab(context: Context, private val onOpen: () -> Unit) : View(context) {

    /** The tab was long-pressed and dragged along its edge. [finished] is true on release. */
    var onReposition: ((rawX: Float, rawY: Float, finished: Boolean) -> Unit)? = null

    private var cfg = SlideBarConfig()
    private var color = 0xFFFF8A3D.toInt()
    private var animations = true

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val bar = RectF()
    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var fired = false
    private var moving = false
    private val idleRunnable = Runnable { fadeToIdle() }
    private val longPress = Runnable {
        moving = true
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        invalidate()
    }

    fun apply(config: SlideBarConfig, accent: Int, animationsEnabled: Boolean) {
        cfg = config
        color = accent
        animations = animationsEnabled
        invalidate()
        wake()
    }

    /** Full opacity now, back to the configured idle opacity after 2.5 seconds. */
    fun wake() {
        removeCallbacks(idleRunnable)
        animate().cancel()
        alpha = 1f
        postDelayed(idleRunnable, 2500L)
    }

    private fun fadeToIdle() {
        if (moving) return
        val target = cfg.idleAlphaPct.coerceIn(10, 100) / 100f
        if (animations) animate().alpha(target).setDuration(300L).start() else alpha = target
    }

    private fun left(): Boolean = cfg.side == EdgeSide.LEFT

    override fun onDraw(c: Canvas) {
        val d = resources.displayMetrics.density
        val thick = 8f * d
        val w = width.toFloat()
        val h = height.toFloat()
        val barH = min(h, 52f * d)
        val top = (h - barH) / 2f
        if (left()) bar.set(0f, top, thick, top + barH) else bar.set(w - thick, top, w, top + barH)
        paint.color = if (moving) HudThemes.withAlpha(color, 255) else color
        c.drawRoundRect(bar, thick / 2f, thick / 2f, paint)
        // three grip dots so the tab reads differently from the HUD handle
        paint.color = HudThemes.withAlpha(HudThemes.onAccent(color), 200)
        val cx = bar.centerX()
        val gap = 7f * d
        val cy = bar.centerY()
        for (i in -1..1) c.drawCircle(cx, cy + i * gap, 1.3f * d, paint)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        super.onLayout(changed, l, t, r, b)
        if (Build.VERSION.SDK_INT >= 29) {
            runCatching { systemGestureExclusionRects = listOf(Rect(0, 0, r - l, b - t)) }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX
                downY = e.rawY
                fired = false
                moving = false
                wake()
                postDelayed(longPress, ViewConfiguration.getLongPressTimeout().toLong())
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (moving) {
                    onReposition?.invoke(e.rawX, e.rawY, false)
                    return true
                }
                val inward = if (left()) e.rawX - downX else downX - e.rawX
                if (abs(e.rawX - downX) + abs(e.rawY - downY) > slop) removeCallbacks(longPress)
                if (!fired && inward > slop * 3) {
                    removeCallbacks(longPress)
                    fired = true
                    performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    onOpen()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longPress)
                if (moving) {
                    moving = false
                    onReposition?.invoke(e.rawX, e.rawY, true)
                    invalidate()
                    wake()
                    return true
                }
                val moved = abs(e.rawX - downX) + abs(e.rawY - downY)
                if (!fired && moved < slop * 2) {
                    fired = true
                    performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    onOpen()
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longPress)
                moving = false
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(idleRunnable)
        removeCallbacks(longPress)
        animate().cancel()
        super.onDetachedFromWindow()
    }
}

// ---------------------------------------------------------------------------------------------
// Panel root and dock widgets
// ---------------------------------------------------------------------------------------------

/**
 * Root of the slide bar window. A touch outside the window (ACTION_OUTSIDE) or on the transparent part of the
 * window that is not the dock or the flyout closes the bar.
 */
private class SlideBarRoot(context: Context, private val onOutside: () -> Unit) : FrameLayout(context) {

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_OUTSIDE) {
            onOutside()
            return true
        }
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            val row = getChildAt(0) as? ViewGroup
            var hit = false
            if (row != null) {
                for (i in 0 until row.childCount) {
                    val ch = row.getChildAt(i)
                    if (ch.visibility == View.VISIBLE &&
                        ev.x >= ch.left && ev.x <= ch.right && ev.y >= ch.top && ev.y <= ch.bottom
                    ) hit = true
                }
            }
            if (!hit) {
                onOutside()
                return true
            }
        }
        return super.dispatchTouchEvent(ev)
    }
}

/** A pinned app in the dock: its own icon on a tile, name underneath. Tap opens it, long-press unpins it. */
private class PinnedAppButton(
    ctx: Context,
    theme: HudTheme,
    label: String,
    val icon: ImageView,
    onTap: () -> Unit,
    onLong: () -> Unit
) : LinearLayout(ctx) {

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(0, Ui.dp(ctx, 3), 0, Ui.dp(ctx, 3))
        val tile = FrameLayout(ctx)
        tile.background = Ui.rounded(theme.tile, ConsoleKit.radius(ctx, theme).coerceAtMost(Ui.dpf(ctx, 14f)))
        icon.scaleType = ImageView.ScaleType.FIT_CENTER
        tile.addView(icon, FrameLayout.LayoutParams(Ui.dp(ctx, 32), Ui.dp(ctx, 32), Gravity.CENTER))
        addView(tile, Ui.lp(Ui.dp(ctx, 44), Ui.dp(ctx, 44)))
        addView(
            Ui.label(ctx, label, 8f, theme.textSecondary).apply {
                gravity = Gravity.CENTER
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
            },
            Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 3), 0, 0)
        )
        isClickable = true
        setOnClickListener { onTap() }
        setOnLongClickListener {
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            onLong()
            true
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Controller
// ---------------------------------------------------------------------------------------------

/**
 * Owns the slide bar's two overlay windows (edge tab, dock + flyout). Main thread only. [HudController] creates it,
 * feeds it the game, the settings and the display-mode lock, and closes the HUD when it opens.
 */
class SlideBarController(
    context: Context,
    private val wm: WindowManager,
    private val deps: SidebarDeps,
    private val micro: MicroToolsManager,
    private val scope: CoroutineScope,
    private val handleProvider: () -> HandleConfig
) {

    private val ctx: Context = context.applicationContext
    private val repo get() = deps.repo

    /** Called just before the bar opens, so the owner can close the HUD. */
    var onOpening: (() -> Unit)? = null

    private var game: String? = null
    private var tab: SlideBarTab? = null
    private var root: SlideBarRoot? = null
    private var dockCol: LinearLayout? = null
    private var flyout: FrameLayout? = null
    private var footer: TextView? = null
    private var params: WindowManager.LayoutParams? = null
    private var flyoutKey: String? = null
    private var closing = false
    private var captureHidden = false
    private var focusable = false
    private var lastPinned: List<String> = emptyList()
    private val dockButtons = ArrayList<RailButton>()
    private var launcher: FreeformAppLauncher? = null
    private val footerReset = Runnable { footer?.text = "" }

    val isOpen: Boolean get() = root != null

    private fun global() = repo.global.value
    private fun theme() = HudThemes.resolve(global())
    private fun cfg(): SlideBarConfig = global().slideBar
    private fun left(): Boolean = cfg().side == EdgeSide.LEFT
    private fun dp(v: Int): Int = Ui.dp(ctx, v)

    @Suppress("DEPRECATION")
    private fun screen(): Point = Point().also { wm.defaultDisplay.getRealSize(it) }

    private fun launcher(): FreeformAppLauncher =
        launcher ?: FreeformAppLauncher(ctx, deps.bridge).also { launcher = it }

    // =========================================================================================
    // Public API
    // =========================================================================================

    /** A game came to the foreground: shows the edge tab (when the slide bar is enabled). */
    fun show(pkg: String) {
        if (game != null && game != pkg) removePanel()
        game = pkg
        lastPinned = global().apps.pinned
        ensureTab()
    }

    /** The game left: everything goes. */
    fun hide() {
        removePanel()
        removeTab()
        game = null
    }

    /** Opens the dock. Works even when the edge tab is switched off in settings. Returns false with no game or permission. */
    fun open(): Boolean {
        if (game == null || !Settings.canDrawOverlays(ctx)) return false
        if (root != null) return true
        onOpening?.invoke()
        val theme = theme()
        val built = buildPanel(theme)
        val p = panelParams(theme)
        try {
            wm.addView(built, p)
        } catch (_: Throwable) {
            return false
        }
        root = built
        params = p
        closing = false
        syncTabVisibility()
        if (theme.animations) {
            val w = p.width + dp(16)
            built.translationX = if (left()) -w.toFloat() else w.toFloat()
            built.animate().translationX(0f).setDuration(180L).start()
        }
        return true
    }

    fun close(animated: Boolean = true) {
        val r = root ?: return
        if (!animated || !theme().animations) {
            removePanel()
            return
        }
        if (closing) return
        closing = true
        val w = (params?.width ?: r.width) + dp(16)
        r.animate()
            .translationX(if (left()) -w.toFloat() else w.toFloat())
            .setDuration(150L)
            .withEndAction { removePanel() }
            .start()
    }

    /** Settings that change the look or the position of the slide bar changed. */
    fun restyle() {
        removePanel()
        ensureTab()
    }

    /** The saved global settings changed: a pin or unpin while the dock is open refreshes the pinned apps. */
    fun onGlobal() {
        val pinned = global().apps.pinned
        if (pinned == lastPinned) return
        lastPinned = pinned
        if (root != null) rebuildDock()
    }

    /** A mini window opened or closed: relight the Browser / Notes / Calc buttons. */
    fun onWindowsChanged() {
        for (b in dockButtons) b.refresh()
    }

    fun relayout() {
        tab?.let { updateSafe(it, tabParams()) }
        val r = root
        if (r != null) {
            val p = panelParams(theme())
            params = p
            updateSafe(r, p)
        }
    }

    /** Re-adds the windows so they sit above an overlay that was just added. */
    fun raise() {
        if (game == null) return
        tab?.let { t ->
            runCatching {
                wm.removeViewImmediate(t)
                wm.addView(t, tabParams())
            }
        }
        val r = root
        val p = params
        if (r != null && p != null) {
            runCatching {
                wm.removeViewImmediate(r)
                wm.addView(r, p)
            }
        }
    }

    /** The FPS enforcer changed the display mode: both windows carry the same lock as the other overlays. */
    fun refreshDisplayMode() {
        tab?.let { updateSafe(it, tabParams()) }
        val r = root
        val p = params
        if (r != null && p != null) {
            DisplayModeLock.applyCurrent(ctx, p)
            updateSafe(r, p)
        }
    }

    /** Hides both windows for the instant a screenshot is taken. */
    fun setCaptureHidden(hidden: Boolean) {
        captureHidden = hidden
        root?.visibility = if (hidden) View.INVISIBLE else View.VISIBLE
        syncTabVisibility()
    }

    // =========================================================================================
    // Edge tab
    // =========================================================================================

    private fun ensureTab() {
        val c = cfg()
        if (!c.enabled || game == null) {
            removeTab()
            return
        }
        val theme = theme()
        val existing = tab
        if (existing != null) {
            existing.apply(c, theme.accent2, theme.animations)
            updateSafe(existing, tabParams())
            syncTabVisibility()
            return
        }
        val v = SlideBarTab(ctx) { open() }
        v.onReposition = { rawX, rawY, finished -> moveTab(rawX, rawY, finished) }
        v.apply(c, theme.accent2, theme.animations)
        try {
            wm.addView(v, tabParams())
            tab = v
        } catch (_: Throwable) {
            tab = null
        }
        syncTabVisibility()
    }

    private fun removeTab() {
        tab?.let { runCatching { wm.removeViewImmediate(it) } }
        tab = null
    }

    private fun syncTabVisibility() {
        tab?.visibility = if (captureHidden || root != null) View.INVISIBLE else View.VISIBLE
        if (root == null) tab?.wake()
    }

    private fun tabLen(): Int = dp(72)

    private fun tabY(): Int {
        val scr = screen()
        val len = tabLen()
        var y = dp(cfg().offsetDp).coerceIn(0, max(0, scr.y - len))
        // Keep clear of the HUD handle when both sit on the same edge.
        val h = handleProvider()
        val sameEdge = (h.side == EdgeSide.LEFT && left()) || (h.side == EdgeSide.RIGHT && !left())
        if (sameEdge) {
            val hLen = dp(h.heightDp.coerceIn(40, 160))
            val hy = dp(h.offsetDp)
            if (y < hy + hLen && y + len > hy) {
                y = hy + hLen + dp(6)
                if (y + len > scr.y) y = max(0, hy - len - dp(6))
            }
        }
        return y
    }

    private fun tabParams(): WindowManager.LayoutParams {
        val p = WindowManager.LayoutParams(
            dp(26), tabLen(), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, baseFlags(), PixelFormat.TRANSLUCENT
        )
        p.gravity = (if (left()) Gravity.LEFT else Gravity.RIGHT) or Gravity.TOP
        p.x = 0
        p.y = tabY()
        p.title = "HyperEngineSlideTab"
        if (Build.VERSION.SDK_INT >= 28) {
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        DisplayModeLock.applyCurrent(ctx, p)
        return p
    }

    private fun moveTab(@Suppress("UNUSED_PARAMETER") rawX: Float, rawY: Float, finished: Boolean) {
        val v = tab ?: return
        val scr = screen()
        val len = tabLen()
        val y = (rawY - len / 2f).toInt().coerceIn(0, max(0, scr.y - len))
        if (finished) {
            val dpv = (y / ctx.resources.displayMetrics.density).toInt()
            repo.updateGlobal { it.copy(slideBar = it.slideBar.copy(offsetDp = dpv)) }
        } else {
            val p = tabParams()
            p.y = y
            updateSafe(v, p)
        }
    }

    // =========================================================================================
    // Dock and flyout
    // =========================================================================================

    private val host = object : ToolHost {
        override val hostContext: Context get() = ctx
        override val game: String get() = this@SlideBarController.game.orEmpty()
        override val theme: HudTheme get() = this@SlideBarController.theme()
        override val deps: SidebarDeps get() = this@SlideBarController.deps
        override val scope: CoroutineScope get() = this@SlideBarController.scope
        override fun toast(msg: String) = say(msg)
        override fun openDetail(title: String, content: View) = showFlyout(null, title, content)
        override fun refreshTiles() = onWindowsChanged()
    }

    /** One short message: in the flyout footer while a page is open, otherwise a system toast. */
    private fun say(msg: String) {
        val f = footer
        if (f != null && flyoutKey != null) {
            f.setTextColor(theme().accent)
            f.text = msg
            f.removeCallbacks(footerReset)
            f.postDelayed(footerReset, 3500L)
        } else {
            runCatching { Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show() }
        }
    }

    private fun buildPanel(theme: HudTheme): SlideBarRoot {
        val r = SlideBarRoot(ctx) { close() }
        val row = Ui.hbox(ctx).apply { gravity = Gravity.CENTER_VERTICAL }

        // ---- dock ----
        val dock = ConsolePanel(ctx, theme, dp(6))
        val scroll = ScrollView(ctx).apply { isVerticalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER }
        val col = Ui.vbox(ctx).apply { gravity = Gravity.CENTER_HORIZONTAL }
        scroll.addView(col, FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        dock.addView(scroll, FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        dockCol = col

        // ---- flyout (hidden until a page is opened) ----
        val fly = ConsolePanel(ctx, theme, dp(10))
        fly.visibility = View.GONE
        flyout = fly

        val dockLp = Ui.lp(dp(DOCK_DP), Ui.WRAP)
        val gap = dp(8)
        val flyLp = Ui.lp(flyoutWidthPx(), Ui.MATCH, 0f, if (left()) gap else 0, 0, if (left()) 0 else gap, 0)
        if (left()) {
            row.addView(dock, dockLp)
            row.addView(fly, flyLp)
        } else {
            row.addView(fly, flyLp)
            row.addView(dock, dockLp)
        }
        r.addView(row, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        flyoutKey = null
        rebuildDock(theme)
        return r
    }

    private fun rebuildDock(theme: HudTheme = theme()) {
        val col = dockCol ?: return
        col.removeAllViews()
        dockButtons.clear()
        val c = cfg()

        for (id in c.items.filter { it in SlideItemIds.ALL }) {
            val item = itemFor(id) ?: continue
            val b = RailButton(ctx, theme, item)
            dockButtons += b
            col.addView(b, Ui.lp(Ui.MATCH, Ui.WRAP))
        }

        val pm = ctx.packageManager
        val pins = if (c.showPinned && c.pinnedCount > 0) {
            global().apps.pinned.filter { pm.getLaunchIntentForPackage(it) != null }.take(c.pinnedCount.coerceIn(0, 6))
        } else emptyList()
        if (pins.isNotEmpty()) {
            col.addView(
                View(ctx).apply { setBackgroundColor(theme.divider) },
                Ui.lp(Ui.dp(ctx, 28), Ui.dp(ctx, 1), 0f, 0, Ui.dp(ctx, 4), 0, Ui.dp(ctx, 4))
            )
            for (pkg in pins) col.addView(pinnedButton(theme, pkg), Ui.lp(Ui.MATCH, Ui.WRAP))
        }
        for (b in dockButtons) b.refresh()
    }

    private fun itemFor(id: String): QuickItem? = when (id) {
        SlideItemIds.APPS -> QuickItem(id, "Apps", IconKind.GRID, { flyoutKey == SlideItemIds.APPS }, { togglePage(SlideItemIds.APPS) })
        SlideItemIds.CHAT -> QuickItem(id, "Chat", IconKind.CHAT, { flyoutKey == SlideItemIds.CHAT }, { togglePage(SlideItemIds.CHAT) })
        SlideItemIds.BROWSER -> QuickItem(id, "Browser", IconKind.BROWSER, { micro.windows.isOpen("browser") }, {
            val g = game
            if (g != null) afterWindow(micro.toggleBrowser(g))
        })
        SlideItemIds.NOTES -> QuickItem(id, "Notes", IconKind.NOTE, { micro.windows.isOpen("notes") }, {
            val g = game
            if (g != null) afterWindow(micro.toggleNotes(g))
        })
        SlideItemIds.CALC -> QuickItem(id, "Calc", IconKind.CALC, { micro.windows.isOpen("calculator") }, {
            afterWindow(micro.toggleCalculator())
        })
        else -> null
    }

    /** A mini window was toggled. When it is now open the bar steps aside so the window is not under it. */
    private fun afterWindow(openNow: Boolean) {
        if (openNow && cfg().closeOnLaunch) close() else onWindowsChanged()
    }

    private fun afterLaunch() {
        if (cfg().closeOnLaunch) close() else onWindowsChanged()
    }

    private fun pinnedButton(theme: HudTheme, pkg: String): View {
        val pm = ctx.packageManager
        val label = runCatching { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() }.getOrDefault(pkg)
        val img = ImageView(ctx)
        scope.launch {
            val d = withContext(Dispatchers.Default) { runCatching { pm.getApplicationIcon(pkg) }.getOrNull() }
            if (d != null) img.setImageDrawable(d)
        }
        return PinnedAppButton(ctx, theme, label, img, {
            val comp = pm.getLaunchIntentForPackage(pkg)?.component
            val entry = AppEntry(label, pkg, comp?.className.orEmpty(), false)
            scope.launch {
                val rep = launcher().launch(entry, global().apps)
                if (rep.ok) afterLaunch() else say(rep.message)
            }
        }, {
            repo.updateGlobal { it.copy(apps = it.apps.copy(pinned = it.apps.pinned - pkg)) }
            say("$label unpinned")
        })
    }

    // ---- flyout pages ----

    private fun togglePage(key: String) {
        if (flyoutKey == key) {
            closeFlyout()
            return
        }
        val h = host
        when (key) {
            SlideItemIds.APPS -> showFlyout(
                key, "All apps",
                AppsPanel.build(h, launcher(), focus = { setFocusable(it) }, onLaunched = { afterLaunch() })
            )
            SlideItemIds.CHAT -> showFlyout(key, "Chat apps", ChatPanel.build(h) { afterLaunch() })
        }
    }

    private fun flyoutWidthPx(): Int {
        val scr = screen()
        val room = scr.x - dp(DOCK_DP) - dp(8) - dp(16)
        return max(min(dp(cfg().flyoutWidthDp.coerceIn(260, 400)), room), min(dp(200), max(room, dp(120))))
    }

    private fun showFlyout(key: String?, title: String, content: View) {
        val fly = flyout ?: return
        val theme = theme()
        fly.removeAllViews()
        val column = Ui.vbox(ctx)
        val header = Ui.hbox(ctx).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(Ui.label(ctx, title, 15f, theme.textPrimary, true), Ui.lp(0, Ui.WRAP, 1f))
        header.addView(ConsoleKit.iconButton(ctx, theme, IconKind.CLOSE, false) { closeFlyout() }, Ui.lp(Ui.dp(ctx, 34), Ui.dp(ctx, 34)))
        column.addView(header, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, 0, 0, Ui.dp(ctx, 6)))
        val sv = ScrollView(ctx).apply { isVerticalScrollBarEnabled = false }
        (content.parent as? ViewGroup)?.removeView(content)
        sv.addView(content, FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        column.addView(sv, Ui.lp(Ui.MATCH, 0, 1f))
        val f = Ui.label(ctx, "", 11f, theme.accent)
        footer = f
        column.addView(f, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 4), 0, 0))
        fly.addView(column, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        fly.visibility = View.VISIBLE
        flyoutKey = key ?: "detail"
        resizeWindow()
        onWindowsChanged()
    }

    private fun closeFlyout() {
        setFocusable(false)
        flyout?.let {
            it.removeAllViews()
            it.visibility = View.GONE
        }
        footer?.removeCallbacks(footerReset)
        footer = null
        flyoutKey = null
        resizeWindow()
        onWindowsChanged()
    }

    private fun resizeWindow() {
        val r = root ?: return
        val p = params ?: return
        p.width = panelWidth()
        updateSafe(r, p)
    }

    /** The keyboard needs a focusable window; the Apps search box asks for it and gives it back. */
    private fun setFocusable(on: Boolean) {
        val r = root ?: return
        val p = params ?: return
        if (focusable == on) return
        focusable = on
        if (on) {
            p.flags = p.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
            p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        } else {
            p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        }
        updateSafe(r, p)
    }

    // =========================================================================================
    // Window plumbing
    // =========================================================================================

    private fun panelWidth(): Int {
        val dock = dp(DOCK_DP)
        return if (flyoutKey == null) dock else dock + dp(8) + flyoutWidthPx()
    }

    private fun panelParams(theme: HudTheme): WindowManager.LayoutParams {
        val scr = screen()
        val margin = dp(8)
        val p = WindowManager.LayoutParams(
            panelWidth(), scr.y - margin * 2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            baseFlags() or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH, PixelFormat.TRANSLUCENT
        )
        p.gravity = (if (left()) Gravity.LEFT else Gravity.RIGHT) or Gravity.TOP
        p.x = margin
        p.y = margin
        p.title = "HyperEngineSlideBar"
        if (Build.VERSION.SDK_INT >= 28) {
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        DisplayModeLock.applyCurrent(ctx, p)
        if (focusable) p.flags = p.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        return p
    }

    private fun removePanel() {
        val r = root ?: return
        root = null
        params = null
        closing = false
        focusable = false
        flyoutKey = null
        footer?.removeCallbacks(footerReset)
        footer = null
        flyout = null
        dockCol = null
        dockButtons.clear()
        runCatching { r.animate().cancel() }
        runCatching { wm.removeViewImmediate(r) }
        syncTabVisibility()
    }

    private fun baseFlags(): Int =
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

    private fun updateSafe(v: View, p: WindowManager.LayoutParams) {
        runCatching { if (v.isAttachedToWindow) wm.updateViewLayout(v, p) }
    }

    companion object {
        /** Dock window width: 44 dp round buttons plus the panel padding. */
        private const val DOCK_DP = 72
    }
}
