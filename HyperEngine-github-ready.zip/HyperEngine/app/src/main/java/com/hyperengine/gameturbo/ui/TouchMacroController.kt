package com.hyperengine.gameturbo.ui

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Point
import android.graphics.RectF
import android.graphics.Typeface
import android.os.SystemClock
import android.provider.Settings
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import com.hyperengine.gameturbo.data.MacroConfig
import com.hyperengine.gameturbo.data.MacroPoint
import com.hyperengine.gameturbo.service.TouchMacroService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.yield
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

private fun MacroConfig.clean(): MacroConfig {
    val pts = if (points.size >= 3) points.take(3) else points.take(1).ifEmpty { listOf(MacroPoint()) }
    return copy(
        points = pts.map { MacroPoint(it.x.coerceIn(0f, 1f), it.y.coerceIn(0f, 1f)) },
        intervalMs = intervalMs.coerceIn(50, 5000),
        tapDurationMs = tapDurationMs.coerceIn(10, 500),
        maxTaps = maxTaps.coerceIn(0, 100000)
    )
}

// =============================================================================================
// Views
// =============================================================================================

/** The draggable target. Its centre is the exact point that gets tapped. */
class MacroNodeView(context: Context, private val number: Int) : View(context) {

    var accent: Int = 0xFF00E5FF.toInt()
        set(v) { field = v; invalidate() }
    var running: Boolean = false
        set(v) { field = v; invalidate() }

    var positionProvider: () -> Point = { Point(0, 0) }
    var onMove: (Int, Int) -> Unit = { _, _ -> }
    var onDragEnd: () -> Unit = {}

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0
    private var moved = false

    init {
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    private fun dp(v: Float) = v * resources.displayMetrics.density

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f - dp(3f)
        fill.color = HudThemes.withAlpha(accent, if (running) 0x30 else 0x66)
        c.drawCircle(cx, cy, r, fill)
        ring.strokeWidth = dp(2f)
        ring.color = if (running) 0xFFFF5252.toInt() else accent
        c.drawCircle(cx, cy, r, ring)
        ring.strokeWidth = dp(1.5f)
        ring.color = 0xFFFFFFFF.toInt()
        val a = r * 0.18f
        val b = r * 0.62f
        c.drawLine(cx - b, cy, cx - a, cy, ring)
        c.drawLine(cx + a, cy, cx + b, cy, ring)
        c.drawLine(cx, cy - b, cx, cy - a, ring)
        c.drawLine(cx, cy + a, cx, cy + b, ring)
        fill.color = 0xFFFFFFFF.toInt()
        c.drawCircle(cx, cy, dp(1.6f), fill)
        text.color = 0xFFFFFFFF.toInt()
        text.textSize = dp(11f)
        text.setShadowLayer(dp(2f), 0f, 0f, 0xFF000000.toInt())
        c.drawText(number.toString(), cx + r * 0.62f, cy - r * 0.42f, text)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX
                downY = e.rawY
                val p = positionProvider()
                startX = p.x
                startY = p.y
                moved = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downX
                val dy = e.rawY - downY
                if (!moved && hypot(dx, dy) > slop) moved = true
                if (moved) onMove((startX + dx).toInt(), (startY + dy).toInt())
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (moved) onDragEnd()
                return true
            }
        }
        return super.onTouchEvent(e)
    }
}

/** Play/Pause + 1-or-3-points toggle + drag grip, in one small floating pill. */
class MacroControlView(context: Context) : View(context) {

    var accent: Int = 0xFF00E5FF.toInt()
        set(v) { field = v; invalidate() }
    var running: Boolean = false
        set(v) { field = v; invalidate() }
    var pointCount: Int = 1
        set(v) { field = v; invalidate() }
    var taps: Int = 0
        set(v) { field = v; invalidate() }

    var onPlayPause: () -> Unit = {}
    var onTogglePoints: () -> Unit = {}
    var positionProvider: () -> Point = { Point(0, 0) }
    var onMove: (Int, Int) -> Unit = { _, _ -> }
    var onDragEnd: () -> Unit = {}

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val icon = Paint(Paint.ANTI_ALIAS_FLAG)
    private val big = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG)
    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var localDownX = 0f
    private var startX = 0
    private var startY = 0
    private var moved = false

    init {
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    private fun dp(v: Float) = v * resources.displayMetrics.density

    private val rect = RectF()
    private val tri = Path()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        bg.color = 0xCC000000.toInt()
        rect.set(0f, 0f, w, h)
        c.drawRoundRect(rect, h / 2f, h / 2f, bg)
        stroke.strokeWidth = dp(1.5f)
        stroke.color = if (running) 0xFFFF5252.toInt() else accent
        rect.set(dp(0.75f), dp(0.75f), w - dp(0.75f), h - dp(0.75f))
        c.drawRoundRect(rect, h / 2f, h / 2f, stroke)

        // play / pause
        val pcx = dp(26f)
        val pcy = h / 2f
        icon.color = if (running) 0xFFFF5252.toInt() else accent
        c.drawCircle(pcx, pcy, dp(18f), icon)
        icon.color = HudThemes.onAccent(if (running) 0xFFFF5252.toInt() else accent)
        if (running) {
            c.drawRect(pcx - dp(6f), pcy - dp(7f), pcx - dp(2f), pcy + dp(7f), icon)
            c.drawRect(pcx + dp(2f), pcy - dp(7f), pcx + dp(6f), pcy + dp(7f), icon)
        } else {
            tri.reset()
            tri.moveTo(pcx - dp(4f), pcy - dp(8f))
            tri.lineTo(pcx + dp(8f), pcy)
            tri.lineTo(pcx - dp(4f), pcy + dp(8f))
            tri.close()
            c.drawPath(tri, icon)
        }

        // middle: point count + status
        big.color = 0xFFFFFFFF.toInt()
        big.textSize = dp(13f)
        small.color = 0xFFB0B8C0.toInt()
        small.textSize = dp(9.5f)
        val mx = dp(52f)
        c.drawText(if (pointCount >= 3) "3 points" else "1 point", mx, h / 2f - dp(1f), big)
        c.drawText(if (running) "$taps taps" else "tap to switch", mx, h / 2f + dp(11f), small)

        // grip
        icon.color = 0xFF7D8791.toInt()
        val gx = w - dp(16f)
        for (i in -1..1) c.drawCircle(gx, h / 2f + i * dp(7f), dp(2f), icon)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX
                downY = e.rawY
                localDownX = e.x
                val p = positionProvider()
                startX = p.x
                startY = p.y
                moved = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downX
                val dy = e.rawY - downY
                if (!moved && hypot(dx, dy) > slop) moved = true
                if (moved) onMove((startX + dx).toInt(), (startY + dy).toInt())
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (moved) {
                    onDragEnd()
                } else if (localDownX < dp(48f)) {
                    onPlayPause()
                } else if (localDownX < width - dp(32f)) {
                    onTogglePoints()
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                if (moved) onDragEnd()
                return true
            }
        }
        return super.onTouchEvent(e)
    }
}

// =============================================================================================
// Controller
// =============================================================================================

data class MacroState(val running: Boolean = false, val taps: Int = 0, val message: String = "")

/**
 * Floating auto tapper. Place 1 or 3 numbered nodes on the in-game buttons, press Play and the
 * accessibility service taps them one after another at the chosen interval.
 *
 * While it runs the nodes become click-through, otherwise the injected tap would land on our own node
 * instead of the game. Drag them while it is paused. The Play/Pause pill stays touchable.
 * Everything here runs on the main thread.
 */
class TouchMacroController(context: Context, private val wm: WindowManager) {

    private val ctx: Context = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    var onAttached: (() -> Unit)? = null
    var onConfigChanged: ((MacroConfig) -> Unit)? = null
    var onRunningChanged: ((Boolean) -> Unit)? = null
    var accentProvider: () -> Int = { 0xFF00E5FF.toInt() }

    private class NodeWin(val view: MacroNodeView, val params: WindowManager.LayoutParams) {
        var attached = false
    }

    private var active = false
    private var cfg = MacroConfig()
    private val nodes = ArrayList<NodeWin>()
    private var controlView: MacroControlView? = null
    private var controlParams: WindowManager.LayoutParams? = null
    private var controlAttached = false
    private var job: Job? = null
    private var taps = 0

    private val _state = MutableStateFlow(MacroState())
    val state: StateFlow<MacroState> = _state.asStateFlow()

    val isRunning: Boolean get() = job?.isActive == true

    fun show(c: MacroConfig) {
        active = true
        apply(c)
    }

    fun apply(c: MacroConfig) {
        val next = c.clean()
        val pointsChanged = next.points.size != cfg.points.size
        cfg = next
        if (!active || !cfg.enabled) {
            stop()
            detach()
            return
        }
        if (pointsChanged && isRunning) stop()
        syncNodes()
        syncControl()
    }

    fun hide() {
        active = false
        stop()
        detach()
    }

    fun relayout() {
        if (!active || !cfg.enabled) return
        syncNodes()
        syncControl()
    }

    fun destroy() {
        hide()
        scope.cancel()
    }

    // ---- running ----

    /** Returns null when started, otherwise the reason it could not start. */
    fun start(): String? {
        if (!active || !cfg.enabled) return "Turn the auto tapper on first"
        if (isRunning) return null
        if (TouchMacroService.instance == null) return "The accessibility service is not running"
        val pts = nodes.map { n ->
            Point(n.params.x + n.params.width / 2, n.params.y + n.params.height / 2)
        }
        if (pts.isEmpty()) return "No tap points"

        taps = 0
        setRunningUi(true)
        _state.value = MacroState(running = true, taps = 0, message = "Running")
        onRunningChanged?.invoke(true)

        job = scope.launch {
            val me = currentCoroutineContext()[Job]
            var i = 0
            var failures = 0
            var reason = "Stopped"
            try {
                while (isActive) {
                    val svc = TouchMacroService.instance
                    if (svc == null) {
                        reason = "The accessibility service stopped"
                        break
                    }
                    val p = pts[i % pts.size]
                    val t0 = SystemClock.uptimeMillis()
                    val ok = svc.tap(p.x.toFloat(), p.y.toFloat(), cfg.tapDurationMs.toLong())
                    if (ok) {
                        taps++
                        failures = 0
                        controlView?.taps = taps
                        _state.value = MacroState(running = true, taps = taps, message = "Running")
                    } else {
                        failures++
                        if (failures >= 5) {
                            reason = "Android rejected the tap 5 times in a row (is the screen on?)"
                            break
                        }
                    }
                    if (cfg.maxTaps > 0 && taps >= cfg.maxTaps) {
                        reason = "Finished: ${cfg.maxTaps} taps"
                        break
                    }
                    i++
                    val wait = cfg.intervalMs - (SystemClock.uptimeMillis() - t0)
                    if (wait > 0L) delay(wait) else yield()
                }
            } finally {
                // A stop() followed quickly by start() must not let the old loop reset the new one's UI.
                if (job == null || job === me) {
                    setRunningUi(false)
                    _state.value = MacroState(running = false, taps = taps, message = reason)
                    onRunningChanged?.invoke(false)
                }
            }
        }
        return null
    }

    fun stop() {
        val j = job ?: return
        job = null
        j.cancel()
        // the finally block of the loop resets the UI and the state
    }

    fun toggle(): String? = if (isRunning) { stop(); null } else start()

    private fun setRunningUi(on: Boolean) {
        nodes.forEach { n ->
            n.view.running = on
            if (n.attached) {
                OverlayKit.setFlag(n.params, WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, on)
                runCatching { wm.updateViewLayout(n.view, n.params) }
            }
        }
        controlView?.running = on
        if (!on) controlView?.taps = taps
    }

    // ---- windows ----

    private fun nodeSizePx() = Ui.dp(ctx, 56)

    private fun syncNodes() {
        val scr = OverlayKit.realSize(wm)
        val want = cfg.points.size
        while (nodes.size > want) removeNode(nodes.removeAt(nodes.size - 1))
        for (i in 0 until want) {
            val nw = nodes.getOrNull(i) ?: createNode(i).also { nodes += it }
            val size = nodeSizePx()
            val pt = cfg.points[i]
            nw.params.x = (pt.x * scr.x - size / 2f).toInt().coerceIn(0, max(0, scr.x - size))
            nw.params.y = (pt.y * scr.y - size / 2f).toInt().coerceIn(0, max(0, scr.y - size))
            nw.view.accent = accentProvider()
            addOrUpdate(nw)
        }
    }

    private fun createNode(index: Int): NodeWin {
        val size = nodeSizePx()
        val v = MacroNodeView(ctx, index + 1)
        val p = OverlayKit.params(size, size, "HyperEngineMacroNode${index + 1}", touchable = true)
        // pinned at 0.79 from the start so switching to click-through never needs an alpha change
        p.alpha = 0.79f
        val nw = NodeWin(v, p)
        v.positionProvider = { Point(p.x, p.y) }
        v.onMove = { x, y -> moveNode(index, nw, x, y) }
        v.onDragEnd = { onConfigChanged?.invoke(cfg) }
        return nw
    }

    private fun moveNode(index: Int, nw: NodeWin, x: Int, y: Int) {
        if (isRunning || !nw.attached) return
        val scr = OverlayKit.realSize(wm)
        val size = nodeSizePx()
        nw.params.x = x.coerceIn(0, max(0, scr.x - size))
        nw.params.y = y.coerceIn(0, max(0, scr.y - size))
        runCatching { wm.updateViewLayout(nw.view, nw.params) }
        val list = cfg.points.toMutableList()
        if (index < list.size) {
            list[index] = MacroPoint(
                ((nw.params.x + size / 2f) / scr.x).coerceIn(0f, 1f),
                ((nw.params.y + size / 2f) / scr.y).coerceIn(0f, 1f)
            )
            cfg = cfg.copy(points = list)
        }
    }

    private fun addOrUpdate(nw: NodeWin) {
        try {
            if (nw.attached) {
                wm.updateViewLayout(nw.view, nw.params)
            } else {
                wm.addView(nw.view, nw.params)
                nw.attached = true
                onAttached?.invoke()
            }
        } catch (_: Throwable) {
            nw.attached = false
        }
    }

    private fun removeNode(nw: NodeWin) {
        if (nw.attached) runCatching { wm.removeViewImmediate(nw.view) }
        nw.attached = false
    }

    private fun syncControl() {
        val scr = OverlayKit.realSize(wm)
        val w = Ui.dp(ctx, 160)
        val h = Ui.dp(ctx, 48)
        val v = controlView ?: MacroControlView(ctx).also { wireControl(it); controlView = it }
        val p = controlParams ?: OverlayKit.params(w, h, "HyperEngineMacroControl", touchable = true)
            .also { controlParams = it }
        v.accent = accentProvider()
        v.pointCount = cfg.points.size
        v.running = isRunning
        v.taps = taps
        val x = if (cfg.controlX >= 0) cfg.controlX else (scr.x - w) / 2
        val y = if (cfg.controlY >= 0) cfg.controlY else Ui.dp(ctx, 72)
        p.x = x.coerceIn(0, max(0, scr.x - w))
        p.y = y.coerceIn(0, max(0, scr.y - h))
        try {
            if (controlAttached) {
                wm.updateViewLayout(v, p)
            } else {
                wm.addView(v, p)
                controlAttached = true
                onAttached?.invoke()
            }
        } catch (_: Throwable) {
            controlAttached = false
        }
    }

    private fun wireControl(v: MacroControlView) {
        v.positionProvider = { Point(controlParams?.x ?: 0, controlParams?.y ?: 0) }
        v.onMove = { x, y ->
            val p = controlParams
            if (p != null && controlAttached) {
                val scr = OverlayKit.realSize(wm)
                p.x = x.coerceIn(0, max(0, scr.x - p.width))
                p.y = y.coerceIn(0, max(0, scr.y - p.height))
                runCatching { wm.updateViewLayout(v, p) }
            }
        }
        v.onDragEnd = {
            val p = controlParams
            if (p != null) {
                cfg = cfg.copy(controlX = p.x, controlY = p.y)
                onConfigChanged?.invoke(cfg)
            }
        }
        v.onPlayPause = {
            val err = toggle()
            if (err != null) {
                _state.value = MacroState(running = false, taps = taps, message = err)
                android.widget.Toast.makeText(ctx, err, android.widget.Toast.LENGTH_SHORT).show()
            }
        }
        v.onTogglePoints = { setPointCount(if (cfg.points.size >= 3) 1 else 3) }
    }

    /** 1 point, or 3 sequential points. Extra points start next to the first one. */
    fun setPointCount(n: Int) {
        if (isRunning) stop()
        val first = cfg.points.firstOrNull() ?: MacroPoint()
        val pts = if (n >= 3) {
            val a = cfg.points.getOrNull(1) ?: MacroPoint((first.x + 0.12f).coerceAtMost(0.95f), first.y)
            val b = cfg.points.getOrNull(2) ?: MacroPoint(first.x, (first.y + 0.15f).coerceAtMost(0.95f))
            listOf(first, a, b)
        } else {
            listOf(first)
        }
        cfg = cfg.copy(points = pts)
        syncNodes()
        syncControl()
        onConfigChanged?.invoke(cfg)
    }

    private fun detach() {
        nodes.forEach { removeNode(it) }
        nodes.clear()
        val v = controlView
        if (controlAttached && v != null) runCatching { wm.removeViewImmediate(v) }
        controlAttached = false
        controlView = null
        controlParams = null
    }
}

// =============================================================================================
// Sidebar tool page
// =============================================================================================

class MacroTool(private val controller: TouchMacroController) : HudTool("macro") {

    override fun isActive(host: ToolHost): Boolean = controller.isRunning

    override fun onTap(host: ToolHost) {
        val ctx = host.hostContext
        val theme = host.theme
        val repo = host.deps.repo
        var cfg = GameActions.profileFor(host.deps, host.game).macro
        val col = Ui.vbox(ctx)

        col.addView(ToolUi.note(host,
            "Taps the screen for you through an accessibility service. Switch it on, drag the numbered target " +
                "onto an in-game button, then press the round play button. Use 3 points to tap three buttons in " +
                "turn. While it runs the targets let touches through; pause it to move them."))

        val status = Ui.label(ctx, "", 11f, theme.textSecondary)
        status.setPadding(0, Ui.dp(ctx, 4), 0, Ui.dp(ctx, 6))

        // ---- accessibility service state ----
        val svcNote = Ui.label(ctx, "", 11f, theme.textSecondary)
        col.addView(svcNote)
        val enableBtn = Ui.button(ctx, theme, "Enable the accessibility service", true) {
            host.scope.launch {
                val cn = ComponentName(ctx, TouchMacroService::class.java)
                val r = host.deps.bridge.enableAccessibilityService(cn)
                if (r.ok) {
                    host.toast("Accessibility service enabled")
                } else {
                    host.toast("Could not enable it automatically: " + r.message)
                    runCatching {
                        ctx.startActivity(
                            Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                }
            }
        }
        col.addView(enableBtn, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 4), 0, Ui.dp(ctx, 4)))
        host.scope.launch {
            TouchMacroService.connected.collect { on ->
                svcNote.text = if (on) "Accessibility service: running"
                else "Accessibility service: off. Taps cannot be sent until it is enabled. On Android 13+ a " +
                    "sideloaded app may first need 'Allow restricted settings' in its App info page."
                svcNote.setTextColor(if (on) theme.good else theme.warn)
                enableBtn.visibility = if (on) View.GONE else View.VISIBLE
            }
        }

        fun commit(next: MacroConfig, rebuild: Boolean = false) {
            cfg = next
            controller.apply(cfg)
            repo.update(host.game) { it.copy(macro = cfg) }
            host.refreshTiles()
            if (rebuild) onTap(host)
        }

        col.addView(ChipGroup(ctx, theme, listOf("Off", "On"), if (cfg.enabled) 1 else 0, 2) { i ->
            commit(cfg.copy(enabled = i == 1), rebuild = true)
        })

        if (cfg.enabled) {
            col.addView(Ui.section(ctx, theme, "Targets"))
            col.addView(ChipGroup(
                ctx, theme, listOf("1 point", "3 points in turn"), if (cfg.points.size >= 3) 1 else 0, 2
            ) { i ->
                controller.setPointCount(if (i == 1) 3 else 1)
                host.refreshTiles()
            })

            col.addView(Ui.section(ctx, theme, "Timing"))
            col.addView(ToolUi.liveSlider(ctx, theme, "Tap interval", " ms", 50, 5000, cfg.intervalMs,
                { cfg = cfg.copy(intervalMs = it); controller.apply(cfg) },
                { commit(cfg.copy(intervalMs = it)) }))
            col.addView(ToolUi.liveSlider(ctx, theme, "Tap duration", " ms", 10, 500, cfg.tapDurationMs,
                { cfg = cfg.copy(tapDurationMs = it); controller.apply(cfg) },
                { commit(cfg.copy(tapDurationMs = it)) }))
            col.addView(ToolUi.liveSlider(ctx, theme, "Stop after (0 = never)", " taps", 0, 1000, cfg.maxTaps.coerceAtMost(1000),
                { cfg = cfg.copy(maxTaps = it) },
                { commit(cfg.copy(maxTaps = it)) }))
            col.addView(ToolUi.note(host, "The interval is measured from the start of one tap to the start of the next."))

            col.addView(Ui.section(ctx, theme, "Run"))
            val runBtn = Ui.button(ctx, theme, if (controller.isRunning) "Stop" else "Start", true) {}
            runBtn.setOnClickListener {
                val err = controller.toggle()
                if (err != null) {
                    status.setTextColor(theme.hot)
                    status.text = err
                }
            }
            col.addView(runBtn, Ui.lp(Ui.MATCH, Ui.WRAP))
            col.addView(Ui.button(ctx, theme, "Reset target positions") {
                controller.stop()
                commit(cfg.copy(points = MacroConfig().points, controlX = -1, controlY = -1), rebuild = true)
            }, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 6), 0, 0))
            col.addView(status)

            host.scope.launch {
                controller.state.collect { s ->
                    runBtn.text = if (s.running) "Stop" else "Start"
                    status.setTextColor(if (s.running) theme.good else theme.textSecondary)
                    status.text = when {
                        s.running -> "Running: ${s.taps} taps sent"
                        s.message.isNotBlank() && s.taps > 0 -> "${s.message}. ${s.taps} taps sent"
                        else -> s.message
                    }
                    host.refreshTiles()
                }
            }
        }

        host.openDetail("Auto tapper", col)
    }
}
