package com.hyperengine.gameturbo.ui

import android.view.View
import com.hyperengine.gameturbo.core.EngineStatus
import com.hyperengine.gameturbo.core.TelemetrySample
import com.hyperengine.gameturbo.data.GameProfile
import com.hyperengine.gameturbo.data.GlobalSettings

/**
 * What HudController needs from whichever HUD is open: the classic one-column sidebar (portrait games) or
 * the landscape dual-wing HUD. Both are hosted in an overlay window and fed the same live data.
 */
interface HudPanel {
    val view: View

    /** True when the panel fills the whole screen (landscape wings) instead of being a slide-in column. */
    val isFullScreen: Boolean get() = false

    fun restyle(newTheme: HudTheme, newGlobal: GlobalSettings)
    fun changeGame(pkg: String)
    fun onProfile(p: GameProfile)
    fun onEngine(st: EngineStatus)
    fun onSample(s: TelemetrySample)
    fun dispose()

    /** A panel that animates itself returns true; the controller then skips its own slide animation. */
    fun playOpen(): Boolean = false
    fun playClose(done: () -> Unit): Boolean = false

    /** Hides the panel for the instant a screenshot is taken. */
    fun setCaptureHidden(hidden: Boolean) {
        view.visibility = if (hidden) View.INVISIBLE else View.VISIBLE
    }
}

/**
 * Tiny process-wide switchboard between the HUD tools and the controller that owns the overlay windows.
 * The controller fills these in while a game is showing and clears them when it goes away, so a tool that
 * runs with no HUD (for example the Quick Settings tile) simply finds them null.
 */
object HudBus {
    /** true = hide every HUD window (handle and panel) for a capture, false = bring them back. */
    @Volatile var captureHider: ((Boolean) -> Unit)? = null

    @Volatile var openHud: (() -> Unit)? = null
    @Volatile var closeHud: (() -> Unit)? = null
    @Volatile var toggleHud: (() -> Unit)? = null

    /**
     * A page inside the HUD needs the keyboard (a search box). true = make the HUD window focusable so the
     * keyboard can appear, false = hand focus back to the game.
     */
    @Volatile var focusRequest: ((Boolean) -> Unit)? = null

    /** Shows the call banner layout once (the HUD controller owns the banner window). */
    @Volatile var callPreview: (() -> Unit)? = null

    /** Opens the on-screen keyboard / mouse layout editor over the game. */
    @Volatile var kbmEditor: (() -> Unit)? = null

    /** Re-adds the HUD handle and panels on top of every other overlay window (the upscaler calls it after adding its own). */
    @Volatile var raiseHud: (() -> Unit)? = null

    /** Slide bar (UI redesign part 3): opens it (closing the HUD first), closes it, or flips it. */
    @Volatile var openSlideBar: (() -> Unit)? = null
    @Volatile var closeSlideBar: (() -> Unit)? = null
    @Volatile var slideBarOpen: (() -> Boolean)? = null

    /** The package the HUD is currently showing for, or null when no game is on screen. */
    @Volatile var game: String? = null
}
