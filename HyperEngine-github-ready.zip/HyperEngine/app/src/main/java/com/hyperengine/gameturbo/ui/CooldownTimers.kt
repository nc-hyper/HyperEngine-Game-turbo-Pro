package com.hyperengine.gameturbo.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Point
import android.graphics.RectF
import android.graphics.Typeface
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.os.Build
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import com.hyperengine.gameturbo.data.GameProfile
import com.hyperengine.gameturbo.data.MicroConfig
import com.hyperengine.gameturbo.data.TimerSlot
import java.util.Locale
import kotlin.math.hypot
import kotlin.math.max

const val TIMER_SLOTS = 4

fun formatDuration(totalSec: Long): String {
    val s = max(0L, totalSec)
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
    else String.format(Locale.US, "%02d:%02d", m, sec)
}

// =============================================================================================
// One timer pill
// =============================================================================================

class TimerPillView(context: Context) : View(context) {

    enum class Mode { IDLE, RUNNING, READY }

    var label = ""
    var durationSec = 60
    var mode = Mode.IDLE
    var remainingMs = 0L
    var flashing = false
    var accent = 0xFF00E5FF.toInt()
    var good = 0xFF69F0AE.toInt()
    var hot = 0xFFFF1744.toInt()

    var positionProvider: () -> Point = { Point(0, 0) }
    var onMove: (Int, Int) -> Unit = { _, _ -> }
    var onDragEnd: () -> Unit = {}
    var onTap: () -> Unit = {}
    var onHold: () -> Unit = {}

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val big = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
    }
    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0
    private var moved = false
    private var held = false
    private val holdRunnable = Runnable { held = true; onHold() }

    init {
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    private fun dp(v: Float) = v * resources.displayMetrics.density

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(dp(96f).toInt(), dp(48f).toInt())
    }

    private val rect = RectF()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val color = when (mode) {
            Mode.IDLE -> 0xFF8A94A0.toInt()
            Mode.RUNNING -> if (remainingMs <= 5000L) hot else accent
            Mode.READY -> good
        }
        val lit = mode == Mode.READY && flashing && (SystemClock.uptimeMillis() / 350) % 2 == 0L
        bg.color = if (lit) HudThemes.withAlpha(good, 0xCC) else 0xCC000000.toInt()
        rect.set(0f, 0f, w, h)
        c.drawRoundRect(rect, dp(12f), dp(12f), bg)
        stroke.strokeWidth = dp(1.5f)
        stroke.color = color
        rect.set(dp(0.75f), dp(0.75f), w - dp(0.75f), h - dp(0.75f))
        c.drawRoundRect(rect, dp(12f), dp(12f), stroke)

        small.textSize = dp(10f)
        small.color = if (lit) 0xFF000000.toInt() else 0xFFB8C0C8.toInt()
        c.drawText(label, w / 2f, dp(15f), small)

        big.textSize = dp(18f)
        big.color = if (lit) 0xFF000000.toInt() else color
        val txt = when (mode) {
            Mode.IDLE -> formatDuration(durationSec.toLong())
            Mode.RUNNING -> formatDuration((remainingMs + 999) / 1000)
            Mode.READY -> "READY"
        }
        c.drawText(txt, w / 2f, dp(37f), big)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX
                downY = e.rawY
                val p = positionProvider()
                startX = p.x
                startY = p.y
                moved = false
                held = false
                postDelayed(holdRunnable, 650L)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downX
                val dy = e.rawY - downY
                if (!moved && hypot(dx, dy) > slop) {
                    moved = true
                    removeCallbacks(holdRunnable)
                }
                if (moved) onMove((startX + dx).toInt(), (startY + dy).toInt())
                return true
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(holdRunnable)
                if (moved) onDragEnd() else if (!held) onTap()
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(holdRunnable)
                if (moved) onDragEnd()
                return true
            }
        }
        return super.onTouchEvent(e)
    }
}

// =============================================================================================
// Manager: up to 4 independent draggable timers
// =============================================================================================

/**
 * Tap a pill to (re)start its countdown, which is also the 1-tap reset. Long-press stops it and
 * clears it back to idle. When a timer ends the pill flashes, the phone beeps and vibrates (each can
 * be switched off). Timer state lives only while the game is open. Main thread only.
 */
class CooldownTimers(context: Context, private val wm: WindowManager, private val themeProvider: () -> HudTheme) {

    private val ctx: Context = context.applicationContext
    private val handler = Handler(Looper.getMainLooper())

    var onAttached: (() -> Unit)? = null
    var onPositionSaved: ((Int, Int, Int) -> Unit)? = null

    private class Slot(val index: Int) {
        var view: TimerPillView? = null
        var params: WindowManager.LayoutParams? = null
        var attached = false
        var mode = TimerPillView.Mode.IDLE
        var endAt = 0L
        var readyAt = 0L
    }

    private val slots = List(TIMER_SLOTS) { Slot(it) }
    private var active = false
    private var micro = MicroConfig()
    private var durations: List<Int> = listOf(60, 120, 300, 600)

    private val tick = object : Runnable {
        override fun run() {
            tickAll()
        }
    }

    fun anyRunning(): Boolean = slots.any { it.mode == TimerPillView.Mode.RUNNING }

    fun show(p: GameProfile) {
        active = true
        apply(p)
    }

    fun apply(p: GameProfile) {
        micro = p.micro
        durations = p.cooldownSeconds
        val theme = themeProvider()
        for (s in slots) {
            val cfg = micro.timers.getOrNull(s.index) ?: TimerSlot()
            if (!active || !cfg.enabled) {
                removeSlot(s)
                s.mode = TimerPillView.Mode.IDLE
                continue
            }
            val v = s.view ?: TimerPillView(ctx).also { wire(s, it); s.view = it }
            v.label = cfg.label.ifBlank { "Timer ${s.index + 1}" }
            v.durationSec = durations.getOrElse(s.index) { 60 }.coerceIn(5, 3600)
            v.accent = theme.accent
            v.good = theme.good
            v.hot = theme.hot
            v.mode = s.mode
            val size = Point(Ui.dp(ctx, 96), Ui.dp(ctx, 48))
            val prm = s.params ?: OverlayKit.params(size.x, size.y, "HyperEngineTimer${s.index + 1}", touchable = true)
                .also { s.params = it }
            val pos = clamp(
                if (cfg.x >= 0) cfg.x else Ui.dp(ctx, 12),
                if (cfg.y >= 0) cfg.y else Ui.dp(ctx, 110 + 54 * s.index),
                size
            )
            prm.x = pos.x
            prm.y = pos.y
            try {
                if (s.attached) {
                    wm.updateViewLayout(v, prm)
                } else {
                    wm.addView(v, prm)
                    s.attached = true
                    onAttached?.invoke()
                }
            } catch (_: Throwable) {
                s.attached = false
            }
            v.invalidate()
        }
        scheduleTick()
    }

    fun hide() {
        active = false
        handler.removeCallbacks(tick)
        for (s in slots) {
            removeSlot(s)
            s.mode = TimerPillView.Mode.IDLE
        }
    }

    fun relayout() {
        val size = Point(Ui.dp(ctx, 96), Ui.dp(ctx, 48))
        for (s in slots) {
            val v = s.view ?: continue
            val p = s.params ?: continue
            if (!s.attached) continue
            val pos = clamp(p.x, p.y, size)
            p.x = pos.x
            p.y = pos.y
            runCatching { wm.updateViewLayout(v, p) }
        }
    }

    /** Starts (or restarts from the full duration) timer [i]. */
    fun startOrReset(i: Int) {
        val s = slots.getOrNull(i) ?: return
        val v = s.view ?: return
        s.mode = TimerPillView.Mode.RUNNING
        s.endAt = SystemClock.elapsedRealtime() + v.durationSec * 1000L
        v.mode = s.mode
        v.remainingMs = v.durationSec * 1000L
        v.flashing = false
        v.invalidate()
        scheduleTick()
    }

    fun clear(i: Int) {
        val s = slots.getOrNull(i) ?: return
        s.mode = TimerPillView.Mode.IDLE
        s.view?.let { it.mode = s.mode; it.flashing = false; it.invalidate() }
    }

    fun startAll() { slots.forEach { if (it.view != null) startOrReset(it.index) } }
    fun clearAll() { slots.forEach { clear(it.index) } }

    // ---- internals ----

    private fun wire(s: Slot, v: TimerPillView) {
        v.positionProvider = { Point(s.params?.x ?: 0, s.params?.y ?: 0) }
        v.onMove = { x, y ->
            val p = s.params
            if (p != null && s.attached) {
                val pos = clamp(x, y, Point(p.width, p.height))
                p.x = pos.x
                p.y = pos.y
                runCatching { wm.updateViewLayout(v, p) }
            }
        }
        v.onDragEnd = {
            val p = s.params
            if (p != null) onPositionSaved?.invoke(s.index, p.x, p.y)
        }
        v.onTap = { startOrReset(s.index) }
        v.onHold = { clear(s.index) }
    }

    private fun clamp(x: Int, y: Int, size: Point): Point {
        val scr = OverlayKit.realSize(wm)
        return Point(x.coerceIn(0, max(0, scr.x - size.x)), y.coerceIn(0, max(0, scr.y - size.y)))
    }

    private fun removeSlot(s: Slot) {
        val v = s.view
        if (s.attached && v != null) runCatching { wm.removeViewImmediate(v) }
        s.attached = false
        s.view = null
        s.params = null
    }

    private fun scheduleTick() {
        handler.removeCallbacks(tick)
        if (slots.any { it.view != null && it.mode != TimerPillView.Mode.IDLE }) handler.postDelayed(tick, 200L)
    }

    private fun tickAll() {
        val now = SystemClock.elapsedRealtime()
        var again = false
        for (s in slots) {
            val v = s.view ?: continue
            when (s.mode) {
                TimerPillView.Mode.RUNNING -> {
                    val rem = s.endAt - now
                    if (rem <= 0L) {
                        s.mode = TimerPillView.Mode.READY
                        s.readyAt = now
                        v.mode = s.mode
                        v.flashing = true
                        alert()
                        again = true
                    } else {
                        v.remainingMs = rem
                        again = true
                    }
                }
                TimerPillView.Mode.READY -> {
                    if (now - s.readyAt < 8000L) {
                        again = true
                    } else {
                        v.flashing = false
                    }
                }
                else -> {}
            }
            v.invalidate()
        }
        if (again && active) handler.postDelayed(tick, 200L)
    }

    private fun alert() {
        if (micro.timerBeep) {
            runCatching {
                val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 90)
                tg.startTone(ToneGenerator.TONE_PROP_BEEP2, 450)
                handler.postDelayed({ runCatching { tg.release() } }, 700L)
            }
        }
        if (micro.timerVibrate) {
            runCatching {
                val vib: Vibrator? = if (Build.VERSION.SDK_INT >= 31) {
                    (ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
                } else {
                    ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                }
                vib?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 180, 110, 180), -1))
            }
        }
    }
}

// =============================================================================================
// Sidebar tool page
// =============================================================================================

class TimersTool(private val timers: CooldownTimers) : HudTool("timers") {

    private val labels = listOf("Boss", "Airdrop", "Burst", "Skill", "Respawn", "Buff")
    private val quick = listOf(10, 30, 60, 120, 300, 600)
    private val quickLabels = listOf("10 s", "30 s", "1 min", "2 min", "5 min", "10 min")

    override fun isActive(host: ToolHost): Boolean = timers.anyRunning()

    override fun onTap(host: ToolHost) {
        val ctx = host.hostContext
        val theme = host.theme
        val repo = host.deps.repo
        val col = Ui.vbox(ctx)

        col.addView(ToolUi.note(host,
            "Up to 4 timers that float over the game. Tap a timer to start it, tap again to restart it from the " +
                "full time. Long-press to stop it. Drag to move. When one ends it flashes, beeps and vibrates."))

        fun save(transform: (GameProfile) -> GameProfile, rebuild: Boolean = false) {
            repo.update(host.game, transform)
            timers.apply(GameActions.profileFor(host.deps, host.game))
            host.refreshTiles()
            if (rebuild) onTap(host)
        }

        fun slotOf(p: GameProfile, i: Int): TimerSlot = p.micro.timers.getOrNull(i) ?: TimerSlot()

        fun withSlot(p: GameProfile, i: Int, change: (TimerSlot) -> TimerSlot): GameProfile {
            val list = MutableList(TIMER_SLOTS) { slotOf(p, it) }
            list[i] = change(list[i])
            return p.copy(micro = p.micro.copy(timers = list))
        }

        fun withSeconds(p: GameProfile, i: Int, sec: Int): GameProfile {
            val list = MutableList(TIMER_SLOTS) { p.cooldownSeconds.getOrElse(it) { 60 } }
            list[i] = sec.coerceIn(5, 3600)
            return p.copy(cooldownSeconds = list)
        }

        val p0 = GameActions.profileFor(host.deps, host.game)
        for (i in 0 until TIMER_SLOTS) {
            val slot = slotOf(p0, i)
            col.addView(Ui.section(ctx, theme, "Timer ${i + 1}"))
            col.addView(ChipGroup(ctx, theme, listOf("Off", "On"), if (slot.enabled) 1 else 0, 2) { k ->
                save({ p -> withSlot(p, i) { it.copy(enabled = k == 1) } }, rebuild = true)
            })
            if (slot.enabled) {
                col.addView(ChipGroup(ctx, theme, labels, labels.indexOf(slot.label), 3) { k ->
                    save({ p -> withSlot(p, i) { it.copy(label = labels[k]) } })
                })
                val sec = p0.cooldownSeconds.getOrElse(i) { 60 }
                col.addView(ChipGroup(ctx, theme, quickLabels, quick.indexOf(sec), 3) { k ->
                    save({ p -> withSeconds(p, i, quick[k]) }, rebuild = true)
                })
                col.addView(Ui.labeledSlider(ctx, theme, "Duration", " s", 5, 1800, sec.coerceIn(5, 1800)) { v ->
                    save({ p -> withSeconds(p, i, v) })
                })
            }
        }

        col.addView(Ui.section(ctx, theme, "Controls"))
        col.addView(Ui.button(ctx, theme, "Start all", true) { timers.startAll() },
            Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, 0, 0, Ui.dp(ctx, 6)))
        col.addView(Ui.button(ctx, theme, "Reset all to idle") { timers.clearAll() })

        col.addView(Ui.section(ctx, theme, "When a timer ends"))
        col.addView(ToolUi.check(ctx, theme, "Beep", p0.micro.timerBeep) { on ->
            save({ p -> p.copy(micro = p.micro.copy(timerBeep = on)) })
        })
        col.addView(ToolUi.check(ctx, theme, "Vibrate", p0.micro.timerVibrate) { on ->
            save({ p -> p.copy(micro = p.micro.copy(timerVibrate = on)) })
        })

        host.openDetail("Cooldown timers", col)
    }
}
