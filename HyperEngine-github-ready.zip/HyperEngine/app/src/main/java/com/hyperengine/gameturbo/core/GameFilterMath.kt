package com.hyperengine.gameturbo.core

enum class ColorblindMode(val label: String) {
    OFF("Off"), PROTANOPIA("Protanopia"), DEUTERANOPIA("Deuteranopia"), TRITANOPIA("Tritanopia")
}

/**
 * Colour-filter settings for one game. Every slider is 0..100, 0 = no change.
 *  - [clarityPct]  contrast around mid grey. This is NOT edge sharpening: a colour matrix cannot see neighbouring pixels.
 *  - [vibrancePct] saturation up to +80%. A matrix cannot do true "vibrance" (which spares already-vivid colours).
 *  - [hdrPct]      HDR-style toning: lifts shadows and pulls highlights down, so dark areas show detail and
 *                  bright ones do not blow out. A flatter, wider-looking range, not real HDR.
 *  - [nightPct]    warmer colour (less blue) and up to 30% dimmer.
 *  - [colorblind]  red-green / blue-yellow assist (daltonization, applied in display space).
 */
data class GameFilterConfig(
    val enabled: Boolean = false,
    val clarityPct: Int = 0,
    val vibrancePct: Int = 0,
    val hdrPct: Int = 0,
    val nightPct: Int = 0,
    val colorblind: ColorblindMode = ColorblindMode.OFF
) {
    val isNeutral: Boolean
        get() = clarityPct == 0 && vibrancePct == 0 && hdrPct == 0 && nightPct == 0 && colorblind == ColorblindMode.OFF
}

/** Builds the 4x4 colour matrix SurfaceFlinger takes: column-major, m[col * 4 + row], translation in m[12..14]. */
object GameFilterMath {

    fun identity(): FloatArray = floatArrayOf(1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f)

    /** Applies [b] first, then [a]. */
    fun multiply(a: FloatArray, b: FloatArray): FloatArray {
        val c = FloatArray(16)
        for (col in 0..3) for (row in 0..3) {
            var sum = 0f
            for (k in 0..3) sum += a[k * 4 + row] * b[col * 4 + k]
            c[col * 4 + row] = sum
        }
        return c
    }

    /** The matrix for [cfg], or null when it changes nothing. */
    fun build(cfg: GameFilterConfig): FloatArray? {
        if (cfg.isNeutral) return null
        var m = identity()
        fun then(next: FloatArray) { m = multiply(next, m) }

        if (cfg.colorblind != ColorblindMode.OFF) then(colorblind(cfg.colorblind))
        if (cfg.vibrancePct > 0) then(saturation(1f + 0.8f * cfg.vibrancePct.coerceIn(0, 100) / 100f))
        if (cfg.clarityPct > 0) {
            val k = 1f + 0.35f * cfg.clarityPct.coerceIn(0, 100) / 100f
            then(scaleOffset(k, k, k, 0.5f * (1f - k)))
        }
        if (cfg.hdrPct > 0) {
            val p = cfg.hdrPct.coerceIn(0, 100) / 100f
            val lift = 0.10f * p
            val k = 1f - lift - 0.06f * p          // highlights roll off by 6%, shadows rise by 10%
            then(scaleOffset(k, k, k, lift))
        }
        if (cfg.nightPct > 0) {
            val p = cfg.nightPct.coerceIn(0, 100) / 100f
            val dim = 1f - 0.30f * p
            then(scaleOffset(dim, dim * (1f - 0.15f * p), dim * (1f - 0.45f * p), 0f))
        }
        return m
    }

    private fun scaleOffset(r: Float, g: Float, b: Float, offset: Float): FloatArray {
        val m = identity()
        m[0] = r; m[5] = g; m[10] = b
        m[12] = offset; m[13] = offset; m[14] = offset
        return m
    }

    private fun saturation(s: Float): FloatArray {
        val lr = 0.2126f; val lg = 0.7152f; val lb = 0.0722f
        return fromRows(
            arrayOf(
                floatArrayOf(lr * (1 - s) + s, lg * (1 - s), lb * (1 - s)),
                floatArrayOf(lr * (1 - s), lg * (1 - s) + s, lb * (1 - s)),
                floatArrayOf(lr * (1 - s), lg * (1 - s), lb * (1 - s) + s)
            )
        )
    }

    /** Daltonization: in + Shift * (in - Simulated(in)); the information the eye loses is moved into channels it keeps. */
    private fun colorblind(mode: ColorblindMode): FloatArray {
        val sim: Array<FloatArray>
        val shift: Array<FloatArray>
        when (mode) {
            ColorblindMode.PROTANOPIA -> {
                sim = arrayOf(floatArrayOf(0.567f, 0.433f, 0f), floatArrayOf(0.558f, 0.442f, 0f), floatArrayOf(0f, 0.242f, 0.758f))
                shift = RED_GREEN_SHIFT
            }
            ColorblindMode.DEUTERANOPIA -> {
                sim = arrayOf(floatArrayOf(0.625f, 0.375f, 0f), floatArrayOf(0.7f, 0.3f, 0f), floatArrayOf(0f, 0.3f, 0.7f))
                shift = RED_GREEN_SHIFT
            }
            else -> {
                sim = arrayOf(floatArrayOf(0.95f, 0.05f, 0f), floatArrayOf(0f, 0.433f, 0.567f), floatArrayOf(0f, 0.475f, 0.525f))
                shift = BLUE_YELLOW_SHIFT
            }
        }
        val err = Array(3) { r -> FloatArray(3) { c -> (if (r == c) 1f else 0f) - sim[r][c] } }   // I - Sim
        val out = Array(3) { r ->
            FloatArray(3) { c ->
                var v = if (r == c) 1f else 0f
                for (k in 0..2) v += shift[r][k] * err[k][c]
                v
            }
        }
        return fromRows(out)
    }

    private fun fromRows(rows: Array<FloatArray>): FloatArray {
        val m = identity()
        for (row in 0..2) for (col in 0..2) m[col * 4 + row] = rows[row][col]
        return m
    }

    private val RED_GREEN_SHIFT = arrayOf(floatArrayOf(0f, 0f, 0f), floatArrayOf(0.7f, 1f, 0f), floatArrayOf(0.7f, 0f, 1f))
    private val BLUE_YELLOW_SHIFT = arrayOf(floatArrayOf(1f, 0f, 0.7f), floatArrayOf(0f, 1f, 0.7f), floatArrayOf(0f, 0f, 0f))
}
