package com.hyperengine.gameturbo.ui

import android.content.Intent
import android.widget.TextView
import com.hyperengine.gameturbo.MicPermissionActivity
import com.hyperengine.gameturbo.core.AudioPresets
import com.hyperengine.gameturbo.core.GameAudioEngine
import com.hyperengine.gameturbo.core.VoiceStudio
import com.hyperengine.gameturbo.data.AudioConfig
import com.hyperengine.gameturbo.data.AudioPreset
import com.hyperengine.gameturbo.data.VoicePreset
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

// =============================================================================================
// Audio EQ tool
// =============================================================================================

class AudioTool(private val engine: GameAudioEngine) : HudTool("audio") {

    override fun isActive(host: ToolHost): Boolean =
        GameActions.profileFor(host.deps, host.game).audio.preset != AudioPreset.OFF

    override fun onTap(host: ToolHost) {
        val ctx = host.hostContext
        val theme = host.theme
        val repo = host.deps.repo
        var cfg = GameActions.profileFor(host.deps, host.game).audio
        val col = Ui.vbox(ctx)

        col.addView(ToolUi.note(host,
            "A 10-band equalizer with bass boost, virtualizer and loudness, applied to the phone's output while " +
                "you play and removed when the game closes. Android's own equalizer usually has only 5 bands, so " +
                "the 10 sliders are blended onto them. Some ROMs ignore effects on the global mix; the line below " +
                "says what the system accepted, but it cannot tell whether you will hear it."))

        val status = Ui.label(ctx, "", 11f, theme.textSecondary)
        status.setPadding(0, 0, 0, Ui.dp(ctx, 8))
        col.addView(status)
        host.scope.launch {
            engine.state.collect { s ->
                status.setTextColor(if (s.active) theme.good else theme.textSecondary)
                status.text = s.message
            }
        }

        var chips: ChipGroup? = null
        val presets = AudioPreset.values()

        fun persist() {
            repo.update(host.game) { it.copy(audio = cfg) }
            host.refreshTiles()
        }

        fun commit(next: AudioConfig, rebuild: Boolean = false) {
            cfg = next
            engine.apply(cfg, host.game)
            persist()
            if (rebuild) onTap(host)
        }

        /** Any manual edit turns a preset into "Custom", starting from the preset's own values. */
        fun edit(save: Boolean, change: (AudioConfig) -> AudioConfig) {
            val raw = if (cfg.preset == AudioPreset.CUSTOM) cfg else AudioPresets.toCustom(cfg)
            val base = raw.copy(bandGainsDb = List(10) { raw.bandGainsDb.getOrElse(it) { 0f } })
            cfg = change(base)
            engine.apply(cfg, host.game)
            chips?.select(presets.indexOf(AudioPreset.CUSTOM))
            if (save) persist()
        }

        col.addView(Ui.section(ctx, theme, "Preset"))
        chips = ChipGroup(
            ctx, theme, listOf("Off", "FPS footsteps", "Gunfire damper", "RPG orchestral", "Custom"),
            presets.indexOf(cfg.preset), 3
        ) { i ->
            val p = presets[i]
            val next = when {
                p == AudioPreset.CUSTOM && cfg.preset != AudioPreset.OFF -> AudioPresets.toCustom(cfg)
                else -> cfg.copy(preset = p)
            }
            commit(next, rebuild = true)
        }
        col.addView(chips)
        col.addView(ToolUi.note(host,
            "FPS footsteps cuts the rumble under 120 Hz and lifts 1.5 - 4 kHz. Gunfire damper softens 2 - 8 kHz. " +
                "RPG orchestral adds width and a gentle bass and treble lift."))

        val settings = AudioPresets.settingsFor(cfg)
        if (settings != null) {
            col.addView(Ui.section(ctx, theme, "Equalizer (dB)"))
            for (i in AudioPresets.BAND_HZ.indices) {
                val label = AudioPresets.BAND_LABELS[i] + " Hz"
                col.addView(ToolUi.liveSlider(
                    ctx, theme, label, " dB", -12, 12, settings.bands[i].roundToInt().coerceIn(-12, 12),
                    { v -> edit(false) { c -> c.copy(bandGainsDb = c.bandGainsDb.toMutableList().also { it[i] = v.toFloat() }) } },
                    { v -> edit(true) { c -> c.copy(bandGainsDb = c.bandGainsDb.toMutableList().also { it[i] = v.toFloat() }) } }
                ))
            }

            col.addView(Ui.section(ctx, theme, "Gain and space"))
            col.addView(ToolUi.liveSlider(
                ctx, theme, "Preamp", " dB", -12, 12, cfg.preampDb.roundToInt().coerceIn(-12, 12),
                { v -> cfg = cfg.copy(preampDb = v.toFloat()); engine.apply(cfg, host.game) },
                { v -> cfg = cfg.copy(preampDb = v.toFloat()); engine.apply(cfg, host.game); persist() }
            ))
            col.addView(ToolUi.liveSlider(
                ctx, theme, "Bass boost", "", 0, 1000, settings.bass.coerceIn(0, 1000),
                { v -> edit(false) { it.copy(bassBoost = v) } },
                { v -> edit(true) { it.copy(bassBoost = v) } }
            ))
            col.addView(ToolUi.liveSlider(
                ctx, theme, "Virtualizer (width)", "", 0, 1000, settings.virtualizer.coerceIn(0, 1000),
                { v -> edit(false) { it.copy(virtualizer = v) } },
                { v -> edit(true) { it.copy(virtualizer = v) } }
            ))
            col.addView(ToolUi.liveSlider(
                ctx, theme, "Loudness", " dB", 0, 15, (settings.loudnessMb / 100).coerceIn(0, 15),
                { v -> edit(false) { it.copy(loudnessMb = v * 100) } },
                { v -> edit(true) { it.copy(loudnessMb = v * 100) } }
            ))
            col.addView(ToolUi.note(host,
                "A positive preamp is added as loudness gain, a negative preamp lowers every band. Loud settings " +
                    "can distort small speakers; lower the preamp if it crackles."))
            col.addView(Ui.button(ctx, theme, "Reset and switch off") {
                commit(AudioConfig(), rebuild = true)
            }, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 8), 0, 0))
        }

        host.openDetail("Audio EQ", col)
    }
}

// =============================================================================================
// Voice changer tool
// =============================================================================================

class VoiceTool(private val studio: VoiceStudio) : HudTool("voice") {

    private val labels = listOf("Original", "Cyborg", "Deep Titan", "Helium", "Anime girl", "Walkie-talkie")

    override fun isActive(host: ToolHost): Boolean {
        val s = studio.state.value
        return s.busy || s.monitoring
    }

    override fun onTap(host: ToolHost) {
        val ctx = host.hostContext
        val theme = host.theme
        val repo = host.deps.repo
        val presets = VoicePreset.values()
        var voice = GameActions.profileFor(host.deps, host.game).audio.voice
        val col = Ui.vbox(ctx)

        col.addView(ToolUi.note(host,
            "Pick a voice, record 5 seconds and hear yourself with it. Android does not let one app feed its " +
                "processed microphone into another app, so this changes what you hear here, not what your " +
                "teammates hear in the game's voice chat. The microphone is kept open by a foreground service and " +
                "rebuilt automatically if Android drops it."))

        val status: TextView = Ui.label(ctx, "", 11f, theme.textSecondary)
        status.setPadding(0, Ui.dp(ctx, 8), 0, 0)

        if (!studio.micGranted()) {
            col.addView(Ui.label(ctx, "Microphone permission is not granted.", 12f, theme.warn))
            col.addView(Ui.button(ctx, theme, "Allow microphone", true) {
                host.scope.launch {
                    val bridge = host.deps.bridge
                    var done = false
                    if (bridge.hasShell()) {
                        val r = bridge.shell("pm grant ${ctx.packageName} android.permission.RECORD_AUDIO")
                        done = r.ok && studio.micGranted()
                    }
                    if (done) {
                        host.toast("Microphone allowed")
                        onTap(host)
                    } else {
                        runCatching {
                            ctx.startActivity(
                                Intent(ctx, MicPermissionActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                        host.toast("Answer the permission dialog, then reopen this page")
                    }
                }
            }, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 4), 0, Ui.dp(ctx, 4)))
        }

        col.addView(Ui.section(ctx, theme, "Voice"))
        col.addView(ChipGroup(ctx, theme, labels, presets.indexOf(voice), 3) { i ->
            voice = presets[i]
            studio.setLivePreset(voice)      // a running live monitor switches effect on the spot
            repo.update(host.game) { it.copy(audio = it.audio.copy(voice = voice)) }
        })

        col.addView(Ui.section(ctx, theme, "Test"))
        col.addView(Ui.button(ctx, theme, "Record 5 s, then play with this voice", true) {
            studio.recordAndPlay(voice)
        }, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, 0, 0, Ui.dp(ctx, 6)))
        col.addView(Ui.button(ctx, theme, "Play last recording with this voice") {
            studio.play(voice)
        }, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, 0, 0, Ui.dp(ctx, 6)))
        col.addView(Ui.button(ctx, theme, "Play last recording unchanged") {
            studio.play(VoicePreset.ORIGINAL)
        }, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, 0, 0, Ui.dp(ctx, 6)))

        col.addView(Ui.section(ctx, theme, "Live monitor"))
        col.addView(ToolUi.note(host, "Hear your processed voice while you talk. Needs headphones, otherwise it would feed back."))
        col.addView(Ui.button(ctx, theme, "Start live monitor") {
            val err = studio.startMonitor(voice)
            if (err != null) {
                status.setTextColor(theme.hot)
                status.text = err
            }
        }, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, 0, 0, Ui.dp(ctx, 6)))
        col.addView(Ui.button(ctx, theme, "Stop") { studio.stop() })

        col.addView(status)
        host.scope.launch {
            studio.state.collect { s ->
                if (s.message.isNotBlank()) {
                    val bad = s.micSilenced || s.message.contains("fail", true) || s.message.contains("missing", true) ||
                        s.message.contains("could not", true)
                    status.setTextColor(if (bad) theme.hot else if (s.busy || s.monitoring) theme.good else theme.textSecondary)
                    status.text = s.message +
                        (if (s.busy && s.progressMs > 0) "  (${s.progressMs / 1000.0} s)" else "") +
                        (if (s.sampleRate > 0) "\n${s.sampleRate} Hz" + (if (s.recoveries > 0) ", mic rebuilt ${s.recoveries}x" else "") else "")
                }
                host.refreshTiles()
            }
        }

        host.openDetail("Voice changer", col)
    }
}
