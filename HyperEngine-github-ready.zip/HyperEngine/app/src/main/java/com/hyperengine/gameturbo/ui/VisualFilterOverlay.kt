package com.hyperengine.gameturbo.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Point
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import com.hyperengine.gameturbo.core.OverlayState
import com.hyperengine.gameturbo.data.EdgeGuardConfig
import kotlin.math.min

/**
 * Everything the HUD draws over the whole screen, behind one object:
 *
 *  - the colour layer (shadow boost, RGB balance, Midnight extra-dimmer and the window brightness
 *    override). The colour maths lives in ColorMath and the sliders in the "Visual filter" and
 *    "Brightness lock" tools; this class only owns the window that shows the result when no shell
 *    can install a real SurfaceFlinger colour matrix ([ScreenOverlay]).
 *  - the four edge palm-rejection guards ([EdgeGuardOverlay]).
 *
 * Main thread only.
 */
class VisualFilterOverlay(context: Context, wm: WindowManager) {

    private val screen = ScreenOverlay(context.applicationContext, wm)
    val edgeGuard = EdgeGuardOverlay(context.applicationContext, wm)

    /** Shows [state] (null removes the layer). Wired to OptimizationEngine.overlayHook. */
    fun applyScreen(state: OverlayState?) = screen.apply(state)

    fun destroy() {
        edgeGuard.hide()
        screen.remove()
    }
}

// =============================================================================================
// Edge palm-rejection guards
// =============================================================================================

/** One strip. Touches that start inside it are swallowed, so a resting palm never reaches the game. */
private class GuardView(context: Context) : View(context) {

    var calibrate = false
    var label = ""

    private val fill = Paint().apply { color = 0x66FF1744 }
    private val border = Paint().apply {
        color = 0xCCFF1744.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt()
        textAlign = Paint.Align.CENTER
        textSize = 11f * resources.displayMetrics.scaledDensity
    }

    init {
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
        setOnTouchListener { _, _ -> true }
    }

    override fun onDraw(c: Canvas) {
        if (!calibrate) return
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawRect(0f, 0f, w, h, fill)
        c.drawRect(1f, 1f, w - 1f, h - 1f, border)
        if (min(w, h) < 14f * resources.displayMetrics.density) return
        c.save()
        if (h > w) c.rotate(-90f, w / 2f, h / 2f)
        val fm = text.fontMetrics
        c.drawText(label, w / 2f, h / 2f - (fm.ascent + fm.descent) / 2f, text)
        c.restore()
    }
}

/**
 * Left / Right / Top / Bottom touch-blocking strips, 0 to 120 px each, each its own overlay window.
 *
 * A touch that starts inside a strip goes to the strip and stops there. A touch that starts in the
 * game and slides into a strip stays with the game (Android keeps a gesture on the window that got
 * its first contact), which is exactly the behaviour you want for swipes. The system back-gesture
 * zones are handled by Android before any app window and are not affected.
 *
 * "Show red calibration zones" paints the strips red with their size, so the area can be set by
 * eye. A strip set to 0 px is parked as a 1 px, fully transparent, non-touchable window, so it
 * blocks nothing and keeps its place in the window stack.
 */
class EdgeGuardOverlay(context: Context, private val wm: WindowManager) {

    private val ctx: Context = context.applicationContext

    /** Called once when the strips are first added, so the controller can lift the handle/sidebar above them. */
    var onAttached: (() -> Unit)? = null

    private val views = arrayOfNulls<GuardView>(4)
    private val params = arrayOfNulls<WindowManager.LayoutParams>(4)
    private val attached = BooleanArray(4)
    private var active = false
    private var cfg = EdgeGuardConfig()

    fun show(c: EdgeGuardConfig) {
        active = true
        apply(c)
    }

    fun apply(c: EdgeGuardConfig) {
        cfg = c.copy(
            leftPx = c.leftPx.coerceIn(0, MAX_PX),
            rightPx = c.rightPx.coerceIn(0, MAX_PX),
            topPx = c.topPx.coerceIn(0, MAX_PX),
            bottomPx = c.bottomPx.coerceIn(0, MAX_PX)
        )
        if (!active) return
        val wanted = cfg.enabled && (cfg.leftPx + cfg.rightPx + cfg.topPx + cfg.bottomPx) > 0
        if (!wanted && !anyAttached()) return
        var added = false
        for (i in 0 until 4) {
            if (layoutSide(i)) added = true
        }
        if (added) onAttached?.invoke()
    }

    fun hide() {
        active = false
        for (i in 0 until 4) {
            val v = views[i]
            if (attached[i] && v != null) runCatching { wm.removeViewImmediate(v) }
            attached[i] = false
            views[i] = null
            params[i] = null
        }
    }

    fun relayout() {
        if (!active) return
        for (i in 0 until 4) if (attached[i]) layoutSide(i)
    }

    // ---- internals ----

    private fun anyAttached(): Boolean = attached.any { it }

    @Suppress("DEPRECATION")
    private fun realSize(): Point = Point().also { wm.defaultDisplay.getRealSize(it) }

    private fun thickness(i: Int): Int = when (i) {
        LEFT -> cfg.leftPx
        RIGHT -> cfg.rightPx
        TOP -> cfg.topPx
        else -> cfg.bottomPx
    }

    /** Lays out strip [i]. Returns true when this call added the window. */
    private fun layoutSide(i: Int): Boolean {
        val v = views[i] ?: GuardView(ctx).also { views[i] = it }
        val p = params[i] ?: buildParams().also { params[i] = it }
        val scr = realSize()
        val t = thickness(i)
        val live = cfg.enabled && t > 0

        v.calibrate = live && cfg.showCalibration
        v.label = NAMES[i] + " " + t + " px"
        if (live) {
            p.flags = LIVE_FLAGS
            p.alpha = 1f
            when (i) {
                LEFT -> { p.width = t; p.height = scr.y; p.x = 0; p.y = 0 }
                RIGHT -> { p.width = t; p.height = scr.y; p.x = scr.x - t; p.y = 0 }
                TOP -> { p.width = scr.x; p.height = t; p.x = 0; p.y = 0 }
                else -> { p.width = scr.x; p.height = t; p.x = 0; p.y = scr.y - t }
            }
        } else {
            p.flags = LIVE_FLAGS or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            p.alpha = 0f
            p.width = 1
            p.height = 1
            p.x = 0
            p.y = 0
        }
        v.invalidate()

        return try {
            if (attached[i]) {
                wm.updateViewLayout(v, p)
                false
            } else {
                wm.addView(v, p)
                attached[i] = true
                true
            }
        } catch (_: Throwable) {
            false
        }
    }

    private fun buildParams(): WindowManager.LayoutParams {
        val p = WindowManager.LayoutParams(
            1, 1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, LIVE_FLAGS, PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.LEFT
        p.title = "HyperEngineEdgeGuard"
        if (Build.VERSION.SDK_INT >= 28) {
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return p
    }

    companion object {
        const val MAX_PX = 120
        private const val LEFT = 0
        private const val RIGHT = 1
        private const val TOP = 2
        private val NAMES = arrayOf("LEFT", "RIGHT", "TOP", "BOTTOM")
        private const val LIVE_FLAGS =
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    }
}

// =============================================================================================
// Edge guard tool page
// =============================================================================================

class EdgeGuardTool(private val guard: EdgeGuardOverlay) : HudTool("edge_guard") {

    override fun isActive(host: ToolHost): Boolean =
        GameActions.profileFor(host.deps, host.game).edgeGuard.enabled

    override fun onTap(host: ToolHost) {
        val ctx = host.hostContext
        val theme = host.theme
        val repo = host.deps.repo
        var cfg = GameActions.profileFor(host.deps, host.game).edgeGuard
        val col = Ui.vbox(ctx)

        col.addView(ToolUi.note(host,
            "Touch-blocking strips along the screen edges, so a thumb or palm resting on the border never " +
                "presses anything in the game. A touch that starts in the game and slides into a strip keeps " +
                "working. Moving any slider switches the guard on. Turn on the red zones to see exactly " +
                "what is blocked while you adjust."))

        fun commit(next: EdgeGuardConfig, rebuild: Boolean = false) {
            cfg = next
            guard.apply(cfg)
            repo.update(host.game) { it.copy(edgeGuard = cfg) }
            host.refreshTiles()
            if (rebuild) onTap(host)
        }

        col.addView(ChipGroup(ctx, theme, listOf("Off", "On"), if (cfg.enabled) 1 else 0, 2) { i ->
            commit(cfg.copy(enabled = i == 1))
        })

        col.addView(ToolUi.check(ctx, theme, "Show red calibration zones", cfg.showCalibration) {
            commit(cfg.copy(showCalibration = it))
        })

        col.addView(Ui.section(ctx, theme, "Quick setup"))
        col.addView(ChipGroup(ctx, theme, listOf("Clear", "Sides 40", "Sides 80", "All 40"), -1, 4) { i ->
            val base = cfg.copy(leftPx = 0, rightPx = 0, topPx = 0, bottomPx = 0)
            commit(
                when (i) {
                    0 -> base.copy(enabled = false)
                    1 -> base.copy(enabled = true, leftPx = 40, rightPx = 40)
                    2 -> base.copy(enabled = true, leftPx = 80, rightPx = 80)
                    else -> base.copy(enabled = true, leftPx = 40, rightPx = 40, topPx = 40, bottomPx = 40)
                },
                rebuild = true
            )
        })

        col.addView(Ui.section(ctx, theme, "Thickness"))
        val max = EdgeGuardOverlay.MAX_PX
        col.addView(ToolUi.liveSlider(ctx, theme, "Left", " px", 0, max, cfg.leftPx,
            { guard.apply(cfg.copy(leftPx = it, enabled = true)) }, { commit(cfg.copy(leftPx = it, enabled = true)) }))
        col.addView(ToolUi.liveSlider(ctx, theme, "Right", " px", 0, max, cfg.rightPx,
            { guard.apply(cfg.copy(rightPx = it, enabled = true)) }, { commit(cfg.copy(rightPx = it, enabled = true)) }))
        col.addView(ToolUi.liveSlider(ctx, theme, "Top", " px", 0, max, cfg.topPx,
            { guard.apply(cfg.copy(topPx = it, enabled = true)) }, { commit(cfg.copy(topPx = it, enabled = true)) }))
        col.addView(ToolUi.liveSlider(ctx, theme, "Bottom", " px", 0, max, cfg.bottomPx,
            { guard.apply(cfg.copy(bottomPx = it, enabled = true)) }, { commit(cfg.copy(bottomPx = it, enabled = true)) }))

        host.openDetail("Edge guard", col)
    }
}
