package com.hyperengine.gameturbo.core

import android.content.Context
import com.hyperengine.gameturbo.data.GameProfileRepository
import com.hyperengine.gameturbo.service.WildBoostController
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.math.abs
import kotlin.math.max

/**
 * HyperBoost quality profiles. [scale] is the internal render scale; the display stays at native resolution.
 * [gainHint] is an ESTIMATE for GPU-bound games, not a measurement: CPU-bound games gain little.
 */
enum class HyperBoostQuality(val label: String, val scale: Float, val gainHint: String) {
    ULTRA_QUALITY("Ultra Quality", 0.85f, "about 25% more FPS"),
    QUALITY("Quality", 0.75f, "about 40% more FPS"),
    BALANCED("Balanced", 0.67f, "about 60% more FPS"),
    ULTRA_PERFORMANCE("Ultra Performance", 0.55f, "up to 2x FPS in heavy 3D games")
}

data class HyperBoostState(
    val active: Boolean = false,
    val game: String? = null,
    val quality: HyperBoostQuality = HyperBoostQuality.BALANCED,
    val busy: Boolean = false,
    val layers: List<StepResult> = emptyList(),
    /** True only when a render scale really went in (GameManager accepted it, or the system resolution changed). */
    val scaleApplied: Boolean = false,
    /** "GameManager", "system resolution" or "" . Says WHICH route is scaling the game. */
    val scaleMethod: String = "",
    /** GameManager scales a game when it starts; a game that was already running keeps its old size until restarted. */
    val needsRestart: Boolean = false
)

/**
 * HyperBoost, part 1 of 2: hardware render-buffer downscale plus frame pacing. (The CAS sharpening pass that hides
 * the softness is HyperBoostUpscaleOverlay, next part.)
 *
 *  1  `cmd game set --mode performance --downscale <scale> --fps <hz>` (via OptimizationEngine.setGameMode)
 *  2  `device_config put game_overlay <pkg> mode=2,fps=<hz>,downscaleFactor=<scale>`
 *  3  SurfaceFlinger: `debug.sf.enable_hwc_vds`, `debug.hwui.renderer skiagl`
 *  4  Frame pacing: early / GL / high-fps phase offsets, `debug.sf.disable_backpressure`
 *
 * Every property and device_config value goes through the enforcer's crash-safe store, so it is restored when the
 * FPS lock is released, on game exit, or after a crash.
 *
 * Limits, said plainly: GameManager downscaling needs Android 12+ and only affects games that honour the
 * GameManager intervention, so it is NOT universal. `debug.sf.*` and `debug.hwui.renderer` are read at process or
 * SurfaceFlinger start, so their effect is ROM dependent. Each step reports its own result.
 */
class HyperBoostEngine(
    context: Context,
    private val bridge: SystemBridgeExecutor,
    private val engine: OptimizationEngine,
    private val fps: FpsRefreshRateEnforcer,
    private val wild: CustomWildBoostEngine,
    private val repo: GameProfileRepository
) {
    private val appCtx = context.applicationContext
    private val prefs = appCtx.getSharedPreferences("hyper_hyperboost", Context.MODE_PRIVATE)
    private val scaler = ResolutionScaler(appCtx, bridge)
    private val mutex = Mutex()
    private val _state = MutableStateFlow(HyperBoostState())
    val state: StateFlow<HyperBoostState> = _state.asStateFlow()

    /** Saved choice for [pkg]; Balanced when none. */
    fun quality(pkg: String): HyperBoostQuality =
        runCatching { HyperBoostQuality.valueOf(prefs.getString("q.$pkg", null) ?: "") }
            .getOrDefault(HyperBoostQuality.BALANCED)

    /** Saves the choice and, if HyperBoost is on for this game, re-applies it at once. */
    suspend fun setQuality(pkg: String, q: HyperBoostQuality): List<StepResult> {
        prefs.edit().putString("q.$pkg", q.name).apply()
        return if (_state.value.active && _state.value.game == pkg) apply(pkg, q) else emptyList()
    }

    /** Per-game choice: scale with the system resolution (works in every game) instead of GameManager. */
    fun systemScaleForced(pkg: String): Boolean = prefs.getBoolean("sys.$pkg", false)

    suspend fun setSystemScaleForced(pkg: String, on: Boolean): List<StepResult> {
        prefs.edit().putBoolean("sys.$pkg", on).apply()
        return if (_state.value.active && _state.value.game == pkg) apply(pkg, quality(pkg)) else emptyList()
    }

    /** Finishes a restore that a crash or restart interrupted. Call when no game is running. */
    suspend fun recoverPending(): StepResult? = if (scaler.isActive()) scaler.restore() else null

    /** Force-stops and relaunches [pkg] so GameManager's render scale is read at process start. */
    suspend fun restartGame(pkg: String): StepResult {
        if (!Validators.PACKAGE.matches(pkg)) return StepResult("Restart game", false, "invalid package name")
        if (!bridge.hasShell()) return StepResult("Restart game", false, "needs Shizuku or root")
        val stop = bridge.shell("am force-stop $pkg", 8_000L)
        if (!stop.ok) return StepResult("Restart game", false, stop.message)
        delay(700L)
        val go = bridge.shell("monkey -p $pkg -c android.intent.category.LAUNCHER 1", 10_000L)
        return StepResult("Restart game", go.ok, if (go.ok) "restarted" else go.message)
    }

    /** Makes Wild Boost switch HyperBoost on and off with it. Call once after both exist. */
    fun registerWith(controller: WildBoostController) {
        controller.registerBooster(WildBoostController.Booster(WildBoostController.ID_HYPERBOOST) { game, on ->
            val steps = if (on) apply(game, quality(game)) else release(game)
            val bad = steps.filter { !it.ok }
            StepResult(
                "HyperBoost", bad.isEmpty() && steps.isNotEmpty(),
                if (bad.isEmpty()) (if (on) quality(game).label else "off") else bad.joinToString(" | ") { it.detail }
            )
        })
    }

    suspend fun apply(pkg: String, q: HyperBoostQuality): List<StepResult> = mutex.withLock {
        if (!Validators.PACKAGE.matches(pkg)) return@withLock listOf(StepResult("HyperBoost", false, "invalid package name"))
        if (!bridge.hasShell()) return@withLock listOf(StepResult("HyperBoost", false, "needs Shizuku or root"))
        _state.update { it.copy(busy = true, game = pkg, quality = q) }
        val out = ArrayList<StepResult>()
        try {
            val cap = capHz(pkg)
            val forceSys = systemScaleForced(pkg)
            // With the system resolution doing the scaling, GameManager gets no downscale (it would scale twice).
            val ds: Float? = if (forceSys) null else q.scale
            val gm = engine.setGameMode(pkg, GameModeLevel.PERFORMANCE, ds, cap)
                .map { it.copy(step = "Render scale ${q.scale}x: " + it.step) }
            out += gm
            var gmOk = ds != null && gm.firstOrNull { it.step.contains("Downscale", true) }?.ok == true
            out += fps.overrideGameOverlay(pkg, cap, ds).let { it.copy(step = "HyperBoost " + it.step) }
            if (gmOk) {
                val v = verifyDownscale(pkg, q.scale)
                out += v
                // The ROM took the command but reports another scale: that game is NOT being scaled by GameManager.
                // The mismatch used to be listed and then ignored; now it sends the game down the system-resolution route.
                if (!v.ok) {
                    gmOk = false
                    // Take the downscale back out so the game is not scaled twice if it picks it up after a restart.
                    out += engine.setGameMode(pkg, GameModeLevel.PERFORMANCE, null, cap)
                        .map { it.copy(step = "Clear GameManager scale: " + it.step) }
                }
            }
            out += fps.setPropTracked("debug.sf.enable_hwc_vds", "1")
            out += fps.setPropTracked("debug.hwui.renderer", "skiagl")
            for ((k, v) in PACING) out += fps.setPropTracked(k, v)

            // Universal route: used when asked for, and automatically when GameManager refused the downscale.
            var method = if (gmOk) "GameManager" else ""
            if (forceSys || !gmOk) {
                val sys = scaler.apply(q.scale)
                out += sys.copy(step = if (forceSys) sys.step else "GameManager refused, so " + sys.step)
                if (sys.ok) method = "system resolution"
            } else if (scaler.isActive()) {
                out += scaler.restore()
            }
            _state.update {
                it.copy(
                    active = out.any { r -> r.ok }, layers = out,
                    scaleApplied = method.isNotEmpty(), scaleMethod = method,
                    needsRestart = method == "GameManager"
                )
            }
        } finally {
            _state.update { it.copy(busy = false) }
        }
        out
    }

    /** Puts the profile's own scale and mode back. The tracked properties come back with the next FPS-lock release. */
    suspend fun release(pkg: String): List<StepResult> = mutex.withLock {
        // The system resolution outlives the app process, so it is put back even if our own state says "off".
        val resBack = if (scaler.isActive()) listOf(scaler.restore()) else emptyList()
        if (!_state.value.active || _state.value.game != pkg) return@withLock resBack
        val out = ArrayList<StepResult>()
        out += resBack
        val p = repo.profile(pkg)
        val cap = capHz(pkg)
        val level = if (wild.state.value.active) GameModeLevel.PERFORMANCE else (p?.gameMode ?: GameModeLevel.STANDARD)
        out += engine.setGameMode(pkg, level, p?.downscale, cap)
        out += fps.overrideGameOverlay(pkg, cap, p?.downscale)
        out += fps.restoreProps(PACING.map { it.first } + listOf("debug.sf.enable_hwc_vds", "debug.hwui.renderer"))
        _state.value = HyperBoostState(quality = quality(pkg))
        out
    }

    /** Reads `cmd game list-configs` back so "applied" means the system holds the scale, not just that the command ran. */
    private suspend fun verifyDownscale(pkg: String, scale: Float): StepResult {
        val dump = bridge.readGameConfig(pkg)
        if (dump.isBlank()) return StepResult("Render scale check", true, "this ROM cannot report it back; restart the game so it takes effect")
        val seen = Regex("(?i)downscale\\w*\\W{1,4}(\\d(?:\\.\\d+)?)").findAll(dump)
            .mapNotNull { it.groupValues[1].toFloatOrNull() }.toList()
        val want = Math.round(scale * 20f).coerceIn(6, 18) / 20f
        return when {
            seen.any { abs(it - want) < 0.03f } -> StepResult("Render scale check", true, "system confirms ${String.format(java.util.Locale.US, "%.2f", want)}x")
            seen.isNotEmpty() -> StepResult("Render scale check", false, "system reports " + seen.joinToString("/") + " instead of $want")
            else -> StepResult("Render scale check", true, "not listed by the system yet; restart the game so it takes effect")
        }
    }

    private fun capHz(pkg: String): Int {
        val locked = fps.lockedHz.value
        if (locked > 0) return locked
        val p = repo.profile(pkg)
        val panel = runCatching { engine.supportedRefreshRates().maxOrNull() }.getOrNull() ?: 0
        return max(max(p?.targetFps ?: 0, p?.turbo?.unlockFps ?: 0), panel).coerceAtLeast(60)
    }

    private companion object {
        val PACING = listOf(
            "debug.sf.early_phase_offset_ns" to "500000",
            "debug.sf.early_gl_phase_offset_ns" to "3000000",
            "debug.sf.high_fps_early_phase_offset_ns" to "6100000",
            "debug.sf.disable_backpressure" to "1"
        )
    }
}
