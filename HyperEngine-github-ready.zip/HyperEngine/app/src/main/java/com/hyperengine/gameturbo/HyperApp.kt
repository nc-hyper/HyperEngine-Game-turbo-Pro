package com.hyperengine.gameturbo

import android.app.Application
import com.hyperengine.gameturbo.core.AccessibilitySelfHealer
import com.hyperengine.gameturbo.core.AutoTouchEngine
import com.hyperengine.gameturbo.core.CustomWildBoostEngine
import com.hyperengine.gameturbo.core.FpsRefreshRateEnforcer
import com.hyperengine.gameturbo.core.HandsFreeCallManager
import com.hyperengine.gameturbo.core.KbmMapper
import com.hyperengine.gameturbo.core.MultiTouchInjector
import com.hyperengine.gameturbo.core.NativeSystemActions
import com.hyperengine.gameturbo.core.HyperBoostEngine
import com.hyperengine.gameturbo.core.GamingSuiteManager
import com.hyperengine.gameturbo.core.OptimizationEngine
import com.hyperengine.gameturbo.core.Phase2Store
import com.hyperengine.gameturbo.core.SystemBridgeExecutor
import com.hyperengine.gameturbo.core.VirtualDisplayUpscaler
import com.hyperengine.gameturbo.core.TelemetryMonitor
import com.hyperengine.gameturbo.data.GameProfileRepository
import com.hyperengine.gameturbo.service.WildBoostController

class HyperApp : Application() {

    lateinit var repository: GameProfileRepository
        private set
    lateinit var bridge: SystemBridgeExecutor
        private set
    lateinit var engine: OptimizationEngine
        private set
    lateinit var telemetry: TelemetryMonitor
        private set

    /** Phase 2: 5-layer FPS unlocker + app-switch watchdog. */
    lateinit var fps: FpsRefreshRateEnforcer
        private set

    /** Phase 2: Wild Boost / Diablo, turbo fan, charge separation, Battery Saver sync. */
    lateinit var wild: CustomWildBoostEngine
        private set

    /** Phase 3: the one "Wild Boost ON" used by the Quick Settings tile and the sidebar (boost + ignition). */
    lateinit var wildBoost: WildBoostController
        private set

    /** Phase 3 Step 2: hardware downscale + frame pacing (HyperBoost). Rides along with Wild Boost. */
    lateinit var hyperBoost: HyperBoostEngine
        private set

    /** Virtual-display upscaler: the game renders small on a private display, this shows it sharpened at native size. */
    lateinit var upscaler: VirtualDisplayUpscaler
        private set

    /** Phase 3 Step 2: HyperLab (low-latency mode so far). Rides along with Wild Boost. */
    lateinit var suite: GamingSuiteManager
        private set

    /** Phase 3 Step 3: keeps the auto-tapper accessibility service enabled and bound (Shizuku re-bind + watchdog). */
    lateinit var selfHealer: AccessibilitySelfHealer
        private set

    /** Phase 3: native screenshot / recorder / cast / ADB helper, keyboard + mouse mapper, in-game call handling. */
    lateinit var system: NativeSystemActions
        private set
    lateinit var kbm: KbmMapper
        private set
    lateinit var calls: HandsFreeCallManager
        private set

    /** Phase 4: dual-engine multi-touch injector (Shizuku pointer ids 3..6, accessibility fallback). */
    lateinit var touch: MultiTouchInjector
        private set

    /** Phase 4: Realme / OPPO style auto-touch engine (continuous, hold-to-rapid-fire, combo macros). */
    lateinit var autoTouch: AutoTouchEngine
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        repository = GameProfileRepository(this)
        bridge = SystemBridgeExecutor(this).also { it.start() }
        selfHealer = AccessibilitySelfHealer(this, bridge).also { it.heal("app start") }
        telemetry = TelemetryMonitor(this, bridge, repository)
        engine = OptimizationEngine(this, bridge, repository)
        val phase2Store = Phase2Store(this)
        fps = FpsRefreshRateEnforcer(this, bridge, engine, repository, phase2Store).also { it.start() }
        wild = CustomWildBoostEngine(this, bridge, engine, fps, repository, phase2Store).also { it.start() }
        wildBoost = WildBoostController(this, bridge, engine, fps, wild, repository)
        hyperBoost = HyperBoostEngine(this, bridge, engine, fps, wild, repository).also { it.registerWith(wildBoost) }
        upscaler = VirtualDisplayUpscaler(this, bridge) {
            hyperBoost.state.value.let { it.active && it.scaleMethod == "system resolution" }
        }
        suite = GamingSuiteManager(this, bridge, engine, fps, repository, telemetry).also { it.registerWith(wildBoost) }
        system = NativeSystemActions(this, bridge)
        kbm = KbmMapper(this, bridge)
        calls = HandsFreeCallManager(this, bridge)
        touch = MultiTouchInjector(this, bridge)
        autoTouch = AutoTouchEngine(this, touch)
    }

    companion object {
        lateinit var instance: HyperApp
            private set
    }
}
