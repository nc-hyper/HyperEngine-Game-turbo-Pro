package com.hyperengine.gameturbo.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import androidx.core.graphics.PathParser

/**
 * Every icon in the app is drawn here with paths and strokes: no emoji, no text glyphs, no image files.
 * Icons are authored in a 24 x 24 box and scaled to whatever size the caller asks for.
 */
enum class IconKind {
    BOLT, SPEAKER, SPEAKER_OFF, PHONE_ANSWER, PHONE_END, BELL_OFF, CAMERA, RECORD, STOP, CAST, GRID,
    KEYBOARD, FAN, BATTERY, CHIP, THERMO, CLOSE, BACK, CHEVRON_RIGHT, CHEVRON_LEFT, GEAR, SEARCH, PILL,
    CUBE, SIGNAL, WIFI, PLAY, PAUSE, PLUS, MINUS, CROSSHAIR, EYE, TAP, MIC, SLIDERS, TIMER, LOCK, GLOBE,
    CALC, NOTE, CHAT, SNOW, WAVE, EXPAND, SUN, CURSOR, BRACKET, GAUGE, GAMEPAD, SHIELD, LAYERS, PLUG,
    DISPLAY, BROWSER, VOLUME, GPU, RAM, PING, CLOCK, ARROW_UP, ARROW_DOWN, CHECK
}

object HudIcons {

    /** Icon for a sidebar tool id, or null when the tool has none (the caller then falls back to its text code). */
    fun forTool(id: String): IconKind? = when (id) {
        "game_mode" -> IconKind.GAMEPAD
        "boost" -> IconKind.BOLT
        "freeze" -> IconKind.SNOW
        "dns" -> IconKind.GLOBE
        "refresh" -> IconKind.DISPLAY
        "downscale" -> IconKind.EXPAND
        "crosshair" -> IconKind.CROSSHAIR
        "pill" -> IconKind.PILL
        "filter" -> IconKind.EYE
        "brightness" -> IconKind.SUN
        "edge_guard" -> IconKind.BRACKET
        "pointer" -> IconKind.CURSOR
        "macro" -> IconKind.TAP
        "audio" -> IconKind.SLIDERS
        "voice" -> IconKind.MIC
        "timers" -> IconKind.TIMER
        "danmaku" -> IconKind.WAVE
        "afk" -> IconKind.LOCK
        "turbo" -> IconKind.FAN
        "shot" -> IconKind.CAMERA
        "record" -> IconKind.RECORD
        "cast" -> IconKind.CAST
        "kbm" -> IconKind.KEYBOARD
        "calls" -> IconKind.PHONE_ANSWER
        "console" -> IconKind.CUBE
        "slidebar" -> IconKind.LAYERS
        else -> null
    }

    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 2f
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val rect = RectF()
    private val path = Path()

    private val phonePath: Path? by lazy(LazyThreadSafetyMode.NONE) {
        runCatching {
            PathParser.createPathFromPathData(
                "M6.62,10.79c1.44,2.83 3.76,5.14 6.59,6.59l2.2,-2.2c0.27,-0.27 0.67,-0.36 1.02,-0.24 " +
                    "1.12,0.37 2.33,0.57 3.57,0.57 0.55,0 1,0.45 1,1V20c0,0.55 -0.45,1 -1,1 " +
                    "-9.39,0 -17,-7.61 -17,-17 0,-0.55 0.45,-1 1,-1h3.5c0.55,0 1,0.45 1,1 0,1.25 0.2,2.45 0.57,3.57 " +
                    "0.11,0.35 0.03,0.74 -0.25,1.02l-2.2,2.2z"
            )
        }.getOrNull()
    }

    /** Draws [kind] centred at (cx, cy), [size] pixels wide and high. Main thread only. */
    fun draw(c: Canvas, kind: IconKind, cx: Float, cy: Float, size: Float, color: Int) {
        val s = size / 24f
        c.save()
        c.translate(cx - size / 2f, cy - size / 2f)
        c.scale(s, s)
        stroke.color = color
        stroke.strokeWidth = 2f
        fill.color = color
        try {
            drawUnit(c, kind, color)
        } catch (_: Throwable) {
            // an icon must never take the overlay down
        }
        c.restore()
    }

    private fun line(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float) = c.drawLine(x1, y1, x2, y2, stroke)

    private fun poly(c: Canvas, closed: Boolean, filled: Boolean, vararg pts: Float) {
        path.reset()
        path.moveTo(pts[0], pts[1])
        var i = 2
        while (i < pts.size) {
            path.lineTo(pts[i], pts[i + 1])
            i += 2
        }
        if (closed) path.close()
        c.drawPath(path, if (filled) fill else stroke)
    }

    private fun drawUnit(c: Canvas, kind: IconKind, color: Int) {
        when (kind) {
            IconKind.BOLT -> poly(c, true, true, 13f, 2f, 5f, 13.5f, 11f, 13.5f, 10f, 22f, 19f, 10f, 13f, 10f)

            IconKind.SPEAKER, IconKind.VOLUME, IconKind.SPEAKER_OFF -> {
                poly(c, true, true, 3f, 9f, 7.5f, 9f, 12.5f, 5f, 12.5f, 19f, 7.5f, 15f, 3f, 15f)
                if (kind == IconKind.SPEAKER_OFF) {
                    line(c, 16f, 9f, 21f, 15f)
                    line(c, 21f, 9f, 16f, 15f)
                } else {
                    rect.set(8f, 8f, 18f, 16f)
                    c.drawArc(rect, -50f, 100f, false, stroke)
                    rect.set(6f, 4f, 22f, 20f)
                    c.drawArc(rect, -50f, 100f, false, stroke)
                }
            }

            IconKind.PHONE_ANSWER -> phonePath?.let { c.drawPath(it, fill) } ?: c.drawCircle(12f, 12f, 8f, fill)

            IconKind.PHONE_END -> {
                c.save()
                c.rotate(135f, 12f, 12f)
                phonePath?.let { c.drawPath(it, fill) } ?: c.drawCircle(12f, 12f, 8f, fill)
                c.restore()
            }

            IconKind.BELL_OFF -> {
                path.reset()
                path.moveTo(6f, 17f)
                path.lineTo(6f, 11f)
                path.cubicTo(6f, 7f, 8.5f, 5f, 12f, 5f)
                path.cubicTo(15.5f, 5f, 18f, 7f, 18f, 11f)
                path.lineTo(18f, 17f)
                path.close()
                c.drawPath(path, stroke)
                line(c, 4f, 17f, 20f, 17f)
                rect.set(10f, 18.5f, 14f, 22f)
                c.drawArc(rect, 0f, 180f, false, stroke)
                line(c, 3f, 3f, 21f, 21f)
            }

            IconKind.CAMERA -> {
                // viewfinder corners plus a centre dot: the universal "capture the screen" mark
                poly(c, false, false, 3f, 8f, 3f, 3f, 8f, 3f)
                poly(c, false, false, 16f, 3f, 21f, 3f, 21f, 8f)
                poly(c, false, false, 21f, 16f, 21f, 21f, 16f, 21f)
                poly(c, false, false, 8f, 21f, 3f, 21f, 3f, 16f)
                c.drawCircle(12f, 12f, 3.2f, fill)
            }

            IconKind.RECORD -> {
                c.drawCircle(12f, 12f, 9f, stroke)
                c.drawCircle(12f, 12f, 4.6f, fill)
            }

            IconKind.STOP -> {
                rect.set(5f, 5f, 19f, 19f)
                c.drawRoundRect(rect, 3f, 3f, fill)
            }

            IconKind.CAST -> {
                poly(c, false, false, 3f, 7f, 3f, 5f, 21f, 5f, 21f, 19f, 14f, 19f)
                for (r in floatArrayOf(4f, 8f, 12f)) {
                    rect.set(3f - r, 19f - r, 3f + r, 19f + r)
                    c.drawArc(rect, 270f, 90f, false, stroke)
                }
                c.drawCircle(3f, 19f, 1.2f, fill)
            }

            IconKind.GRID -> {
                for (x in floatArrayOf(3f, 14f)) for (y in floatArrayOf(3f, 14f)) {
                    rect.set(x, y, x + 7f, y + 7f)
                    c.drawRoundRect(rect, 1.6f, 1.6f, stroke)
                }
            }

            IconKind.KEYBOARD -> {
                rect.set(2f, 6f, 22f, 18f)
                c.drawRoundRect(rect, 2.4f, 2.4f, stroke)
                for (i in 0 until 4) c.drawCircle(6.2f + i * 3.9f, 10f, 0.9f, fill)
                for (i in 0 until 3) c.drawCircle(8.1f + i * 3.9f, 13.2f, 0.9f, fill)
                line(c, 8f, 15.6f, 16f, 15.6f)
            }

            IconKind.FAN -> {
                c.drawCircle(12f, 12f, 10f, stroke.also { it.strokeWidth = 1.4f })
                stroke.strokeWidth = 2f
                for (i in 0 until 3) {
                    c.save()
                    c.rotate(i * 120f, 12f, 12f)
                    rect.set(9.6f, 3.4f, 14.4f, 11.2f)
                    c.drawOval(rect, fill)
                    c.restore()
                }
                c.drawCircle(12f, 12f, 1.8f, fill.also { it.color = color })
            }

            IconKind.BATTERY -> {
                rect.set(2.5f, 7f, 19f, 17f)
                c.drawRoundRect(rect, 2.4f, 2.4f, stroke)
                rect.set(20f, 10f, 22f, 14f)
                c.drawRoundRect(rect, 0.8f, 0.8f, fill)
                rect.set(5f, 9.4f, 12f, 14.6f)
                c.drawRoundRect(rect, 0.8f, 0.8f, fill)
            }

            IconKind.CHIP -> {
                rect.set(7f, 7f, 17f, 17f)
                c.drawRoundRect(rect, 1.4f, 1.4f, stroke)
                for (t in floatArrayOf(9.5f, 12f, 14.5f)) {
                    line(c, t, 3f, t, 7f); line(c, t, 17f, t, 21f)
                    line(c, 3f, t, 7f, t); line(c, 17f, t, 21f, t)
                }
            }

            IconKind.THERMO -> {
                rect.set(9.5f, 2.5f, 14.5f, 15f)
                c.drawRoundRect(rect, 2.5f, 2.5f, stroke)
                c.drawCircle(12f, 17.6f, 3.6f, fill)
                line(c, 12f, 8f, 12f, 16f)
            }

            IconKind.CLOSE -> {
                line(c, 6f, 6f, 18f, 18f)
                line(c, 18f, 6f, 6f, 18f)
            }

            IconKind.BACK, IconKind.CHEVRON_LEFT -> poly(c, false, false, 15f, 5f, 8f, 12f, 15f, 19f)
            IconKind.CHEVRON_RIGHT -> poly(c, false, false, 9f, 5f, 16f, 12f, 9f, 19f)
            IconKind.ARROW_UP -> poly(c, false, false, 5f, 15f, 12f, 8f, 19f, 15f)
            IconKind.ARROW_DOWN -> poly(c, false, false, 5f, 9f, 12f, 16f, 19f, 9f)
            IconKind.CHECK -> poly(c, false, false, 5f, 12.5f, 10f, 17.5f, 19f, 7f)

            IconKind.GEAR -> {
                c.drawCircle(12f, 12f, 3.2f, stroke)
                c.drawCircle(12f, 12f, 6.6f, stroke)
                for (i in 0 until 8) {
                    c.save()
                    c.rotate(i * 45f, 12f, 12f)
                    line(c, 12f, 2.8f, 12f, 5.4f)
                    c.restore()
                }
            }

            IconKind.SEARCH -> {
                c.drawCircle(10f, 10f, 6f, stroke)
                line(c, 14.6f, 14.6f, 20f, 20f)
            }

            IconKind.PILL -> {
                rect.set(2.5f, 7.5f, 21.5f, 16.5f)
                c.drawRoundRect(rect, 4.5f, 4.5f, stroke)
                c.drawCircle(7.6f, 12f, 1.6f, fill)
                line(c, 11.5f, 12f, 17.5f, 12f)
            }

            IconKind.CUBE -> {
                poly(c, true, false, 12f, 2f, 21f, 7f, 21f, 17f, 12f, 22f, 3f, 17f, 3f, 7f)
                line(c, 12f, 12f, 3f, 7f)
                line(c, 12f, 12f, 21f, 7f)
                line(c, 12f, 12f, 12f, 22f)
            }

            IconKind.SIGNAL -> {
                val hs = floatArrayOf(6f, 10f, 14f, 18f)
                for (i in 0 until 4) {
                    rect.set(3f + i * 4.6f, 21f - hs[i], 6.6f + i * 4.6f, 21f)
                    c.drawRoundRect(rect, 0.8f, 0.8f, fill)
                }
            }

            IconKind.WIFI -> {
                for (r in floatArrayOf(5f, 9f, 13f)) {
                    rect.set(12f - r, 19f - r, 12f + r, 19f + r)
                    c.drawArc(rect, 225f, 90f, false, stroke)
                }
                c.drawCircle(12f, 19f, 1.4f, fill)
            }

            IconKind.PLAY -> poly(c, true, true, 7f, 4f, 20f, 12f, 7f, 20f)

            IconKind.PAUSE -> {
                rect.set(6f, 4f, 10.5f, 20f); c.drawRoundRect(rect, 1.2f, 1.2f, fill)
                rect.set(13.5f, 4f, 18f, 20f); c.drawRoundRect(rect, 1.2f, 1.2f, fill)
            }

            IconKind.PLUS -> {
                line(c, 12f, 5f, 12f, 19f)
                line(c, 5f, 12f, 19f, 12f)
            }

            IconKind.MINUS -> line(c, 5f, 12f, 19f, 12f)

            IconKind.CROSSHAIR -> {
                c.drawCircle(12f, 12f, 6.2f, stroke)
                line(c, 12f, 2f, 12f, 7f); line(c, 12f, 17f, 12f, 22f)
                line(c, 2f, 12f, 7f, 12f); line(c, 17f, 12f, 22f, 12f)
                c.drawCircle(12f, 12f, 1.2f, fill)
            }

            IconKind.EYE -> {
                path.reset()
                path.moveTo(2f, 12f)
                path.quadTo(12f, 3f, 22f, 12f)
                path.quadTo(12f, 21f, 2f, 12f)
                path.close()
                c.drawPath(path, stroke)
                c.drawCircle(12f, 12f, 3.2f, fill)
            }

            IconKind.TAP -> {
                c.drawCircle(12f, 12f, 2.6f, fill)
                c.drawCircle(12f, 12f, 6.2f, stroke)
                stroke.alpha = 120
                c.drawCircle(12f, 12f, 9.8f, stroke)
                stroke.alpha = 255
            }

            IconKind.MIC -> {
                rect.set(9f, 3f, 15f, 14f)
                c.drawRoundRect(rect, 3f, 3f, stroke)
                rect.set(6f, 7f, 18f, 18f)
                c.drawArc(rect, 0f, 180f, false, stroke)
                line(c, 12f, 18f, 12f, 21f)
                line(c, 9f, 21f, 15f, 21f)
            }

            IconKind.SLIDERS -> {
                val ys = floatArrayOf(6f, 12f, 18f)
                val ks = floatArrayOf(8f, 16f, 10f)
                for (i in 0 until 3) {
                    line(c, 3f, ys[i], 21f, ys[i])
                    c.drawCircle(ks[i], ys[i], 2.6f, fill)
                }
            }

            IconKind.TIMER, IconKind.CLOCK -> {
                c.drawCircle(12f, 13f, 8.6f, stroke)
                line(c, 12f, 13f, 12f, 8f)
                line(c, 12f, 13f, 15.6f, 15f)
                if (kind == IconKind.TIMER) line(c, 9.5f, 2.6f, 14.5f, 2.6f)
            }

            IconKind.LOCK -> {
                rect.set(5f, 11f, 19f, 21f)
                c.drawRoundRect(rect, 2f, 2f, stroke)
                rect.set(8f, 3f, 16f, 13f)
                c.drawArc(rect, 180f, 180f, false, stroke)
                c.drawCircle(12f, 16f, 1.4f, fill)
            }

            IconKind.GLOBE -> {
                c.drawCircle(12f, 12f, 9f, stroke)
                rect.set(8f, 3f, 16f, 21f)
                c.drawOval(rect, stroke)
                line(c, 3f, 12f, 21f, 12f)
            }

            IconKind.CALC -> {
                rect.set(5f, 3f, 19f, 21f)
                c.drawRoundRect(rect, 2f, 2f, stroke)
                rect.set(8f, 6f, 16f, 9.4f)
                c.drawRoundRect(rect, 0.8f, 0.8f, fill)
                for (r in 0 until 2) for (q in 0 until 3) c.drawCircle(8.6f + q * 3.4f, 13f + r * 3.8f, 0.95f, fill)
            }

            IconKind.NOTE -> {
                rect.set(5f, 3f, 19f, 21f)
                c.drawRoundRect(rect, 2f, 2f, stroke)
                line(c, 8.5f, 8f, 15.5f, 8f)
                line(c, 8.5f, 12f, 15.5f, 12f)
                line(c, 8.5f, 16f, 13f, 16f)
            }

            IconKind.CHAT -> {
                rect.set(3f, 4f, 21f, 16f)
                c.drawRoundRect(rect, 3f, 3f, stroke)
                poly(c, false, false, 8f, 16f, 8f, 21f, 13.5f, 16f)
            }

            IconKind.SNOW -> {
                for (i in 0 until 3) {
                    c.save()
                    c.rotate(i * 60f, 12f, 12f)
                    line(c, 12f, 3f, 12f, 21f)
                    c.restore()
                }
                c.drawCircle(12f, 12f, 1.6f, fill)
            }

            IconKind.WAVE -> poly(c, false, false, 2f, 12f, 6f, 12f, 8f, 5f, 11f, 19f, 14f, 8f, 16f, 12f, 22f, 12f)

            IconKind.EXPAND -> {
                poly(c, false, false, 4f, 9f, 4f, 4f, 9f, 4f)
                poly(c, false, false, 15f, 4f, 20f, 4f, 20f, 9f)
                poly(c, false, false, 20f, 15f, 20f, 20f, 15f, 20f)
                poly(c, false, false, 9f, 20f, 4f, 20f, 4f, 15f)
            }

            IconKind.SUN -> {
                c.drawCircle(12f, 12f, 4.2f, fill)
                for (i in 0 until 8) {
                    c.save()
                    c.rotate(i * 45f, 12f, 12f)
                    line(c, 12f, 2.4f, 12f, 5f)
                    c.restore()
                }
            }

            IconKind.CURSOR -> poly(c, true, true, 5f, 3f, 5f, 19f, 9.5f, 14.6f, 13f, 21f, 15.6f, 19.6f, 12.2f, 13.4f, 18f, 13.4f)

            IconKind.BRACKET -> {
                rect.set(4f, 4f, 8f, 20f)
                c.drawRoundRect(rect, 2f, 2f, fill)
                poly(c, false, false, 12f, 7f, 18f, 12f, 12f, 17f)
            }

            IconKind.GAUGE -> {
                rect.set(3f, 5f, 21f, 23f)
                c.drawArc(rect, 180f, 180f, false, stroke)
                line(c, 12f, 14f, 17f, 8.4f)
                c.drawCircle(12f, 14f, 1.8f, fill)
            }

            IconKind.GAMEPAD -> {
                rect.set(2f, 7.5f, 22f, 18f)
                c.drawRoundRect(rect, 5.5f, 5.5f, stroke)
                line(c, 7.4f, 10.6f, 7.4f, 15f)
                line(c, 5.2f, 12.8f, 9.6f, 12.8f)
                c.drawCircle(15.8f, 11.8f, 1.1f, fill)
                c.drawCircle(18.4f, 14.2f, 1.1f, fill)
            }

            IconKind.SHIELD -> {
                path.reset()
                path.moveTo(12f, 2f)
                path.lineTo(20f, 5f)
                path.lineTo(20f, 12f)
                path.cubicTo(20f, 17f, 16.5f, 20.5f, 12f, 22f)
                path.cubicTo(7.5f, 20.5f, 4f, 17f, 4f, 12f)
                path.lineTo(4f, 5f)
                path.close()
                c.drawPath(path, stroke)
            }

            IconKind.LAYERS -> {
                rect.set(3f, 6f, 16f, 17f)
                c.drawRoundRect(rect, 2f, 2f, stroke)
                rect.set(9f, 9f, 21f, 20f)
                c.drawRoundRect(rect, 2f, 2f, stroke)
            }

            IconKind.PLUG -> {
                line(c, 9f, 3f, 9f, 8f)
                line(c, 15f, 3f, 15f, 8f)
                rect.set(6f, 8f, 18f, 14.5f)
                c.drawRoundRect(rect, 2f, 2f, stroke)
                line(c, 12f, 14.5f, 12f, 21f)
            }

            IconKind.DISPLAY -> {
                rect.set(3f, 4f, 21f, 16f)
                c.drawRoundRect(rect, 2f, 2f, stroke)
                line(c, 12f, 16f, 12f, 20f)
                line(c, 8f, 20f, 16f, 20f)
            }

            IconKind.BROWSER -> {
                rect.set(3f, 4f, 21f, 20f)
                c.drawRoundRect(rect, 2.4f, 2.4f, stroke)
                line(c, 3f, 9f, 21f, 9f)
                c.drawCircle(6.4f, 6.5f, 0.8f, fill)
                c.drawCircle(9.4f, 6.5f, 0.8f, fill)
            }

            IconKind.GPU -> {
                rect.set(2.5f, 6f, 19f, 17f)
                c.drawRoundRect(rect, 1.8f, 1.8f, stroke)
                c.drawCircle(10.7f, 11.5f, 3f, stroke)
                line(c, 19f, 9f, 22f, 9f)
                line(c, 19f, 14f, 22f, 14f)
                line(c, 5f, 17f, 5f, 20f)
            }

            IconKind.RAM -> {
                rect.set(2f, 7f, 22f, 15f)
                c.drawRoundRect(rect, 1.6f, 1.6f, stroke)
                for (i in 0 until 4) {
                    rect.set(4.5f + i * 4.4f, 9.2f, 7.2f + i * 4.4f, 12.8f)
                    c.drawRect(rect, fill)
                }
                for (i in 0 until 5) line(c, 4f + i * 4f, 15f, 4f + i * 4f, 18f)
            }

            IconKind.PING -> {
                // radar sweep: ring, cross hair lines and a quarter wedge
                c.drawCircle(12f, 12f, 9f, stroke)
                c.drawCircle(12f, 12f, 4.4f, stroke)
                line(c, 12f, 12f, 18.4f, 5.6f)
                c.drawCircle(12f, 12f, 1.3f, fill)
            }
        }
    }
}

/** A square view that draws one [IconKind]. */
class IconView(ctx: Context) : View(ctx) {

    var kind: IconKind = IconKind.GRID
        set(v) {
            field = v
            invalidate()
        }

    var color: Int = 0xFFFFFFFF.toInt()
        set(v) {
            field = v
            invalidate()
        }

    /** Fraction of the view that the glyph fills. */
    var fillFraction: Float = 0.72f
        set(v) {
            field = v
            invalidate()
        }

    constructor(ctx: Context, kind: IconKind, color: Int) : this(ctx) {
        this.kind = kind
        this.color = color
    }

    override fun onDraw(c: Canvas) {
        val side = minOf(width, height).toFloat() * fillFraction
        if (side <= 0f) return
        HudIcons.draw(c, kind, width / 2f, height / 2f, side, color)
    }
}
