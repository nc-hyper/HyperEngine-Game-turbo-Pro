package com.hyperengine.gameturbo.hub

import android.view.View
import android.widget.FrameLayout
import android.widget.ScrollView
import com.hyperengine.gameturbo.ui.Ui

/**
 * Game Space tab "ROM Lab" (Part 9): the ROM & Benchmark Optimizer Lab card for the lobby.
 * The card's live read-outs and the frame monitor run only while this tab is on screen.
 */
class RomLabPage(private val host: HubHost) : HubPage {

    override val id = "romlab"
    override val title = "ROM Lab"
    override val glyph = ""

    private var card: RomLabCard? = null

    override fun createView(): View {
        val ctx = host.activity
        val scroll = ScrollView(ctx)
        val root = Ui.vbox(ctx)
        root.setPadding(0, 0, 0, host.dp(12))
        scroll.addView(root, FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        val c = RomLabCard(ctx, host.theme, host.library) { msg, long -> host.toast(msg, long) }
        card = c
        root.addView(c.root, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(4), 0, 0))
        root.addView(
            Forms.note(
                host,
                "AOT compile, thermal override, fixed clocks, storage trim, RAM purge and the background-data block need Shizuku " +
                    "or root. The panel lock and the frame smoother also work without it. The thermal override changes what Android " +
                    "reports to apps; the battery-temperature limit ends the boost by itself. A score still depends on the chip: " +
                    "this removes the software reasons a phone scores lower than it could."
            ),
            Ui.lp(Ui.MATCH, Ui.WRAP, 0f, host.dp(2), host.dp(8), host.dp(2), 0)
        )
        return scroll
    }

    override fun onShow() {
        card?.attach(host.scope)
    }

    override fun onHide() {
        card?.detach()
    }

    override fun onDestroy() {
        card?.detach()
        card = null
    }
}
