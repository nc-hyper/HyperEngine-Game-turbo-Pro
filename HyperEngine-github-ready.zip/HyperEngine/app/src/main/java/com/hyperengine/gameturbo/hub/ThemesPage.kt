package com.hyperengine.gameturbo.hub

import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.hyperengine.gameturbo.data.EdgeSide
import com.hyperengine.gameturbo.data.HandleConfig
import com.hyperengine.gameturbo.data.SidebarConfig
import com.hyperengine.gameturbo.data.ThemeId
import com.hyperengine.gameturbo.data.ToolIds
import com.hyperengine.gameturbo.ui.ChipGroup
import com.hyperengine.gameturbo.ui.HexColorPicker
import com.hyperengine.gameturbo.ui.HudThemes
import com.hyperengine.gameturbo.ui.ToolCatalog
import com.hyperengine.gameturbo.ui.Ui

/**
 * Theme Customizer.
 *
 * Everything here edits GlobalSettings, which is the single source the in-game sidebar, the edge
 * handle and this hub all render from:
 *   - 4 themes
 *   - own primary / secondary accent colours (HEX picker)
 *   - panel opacity 20-100 % and corner radius 0-32 dp
 *   - which sidebar tools show, and in what order
 *   - edge handle side, offset, width, height, colour and idle opacity
 *
 * Theme, accent, opacity and radius rebuild the hub itself (HubActivity recreates on a theme change);
 * the tool grid and the handle update the running HUD directly.
 */
class ThemesPage(private val host: HubHost) : HubPage {

    override val id = "themes"
    override val title = "Themes"
    override val glyph = ""

    private val ctx = host.activity
    private val theme = host.theme
    private val repo = host.repo

    private lateinit var toolBox: LinearLayout

    private val themeText = listOf(
        "Frosted dark glass. Cyan for Balanced, fiery orange for Wild Boost, with turbine animations.",
        "Sharp cyber-yellow on carbon black. Angular panels over a tech grid.",
        "Tactical crimson and gunmetal with hexagonal gauges.",
        "Solid #000000, no blur, no animations. Lowest RAM and GPU use on 4 GB and 6 GB phones."
    )

    // ── view ──

    override fun createView(): View {
        val scroll = ScrollView(ctx)
        scroll.isFillViewport = false
        val root = Ui.vbox(ctx)
        root.setPadding(0, 0, 0, host.dp(16))
        scroll.addView(root, android.widget.FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        buildThemes(root)
        buildAccents(root)
        buildPanel(root)
        buildTools(root)
        buildHandle(root)

        root.addRow(
            host,
            Ui.button(ctx, theme, "Reset all appearance settings", false) {
                HubDialog.confirm(
                    host, "Reset appearance?",
                    "Theme, accent colours, panel opacity and radius, the tool grid and the edge handle go back to their defaults. Game profiles are not touched.",
                    "Reset"
                ) {
                    repo.updateGlobal { g -> g.copy(theme = ThemeId.HYPEROS_WILD_BOOST, sidebar = SidebarConfig(), handle = HandleConfig()) }
                    host.toast("Appearance reset")
                }
            },
            18
        )
        return scroll
    }

    // ── themes ──

    private fun buildThemes(root: LinearLayout) {
        root.addView(Ui.section(ctx, theme, "Theme"), Ui.lp(Ui.MATCH, Ui.WRAP))
        val g = repo.global.value
        ThemeId.values().forEachIndexed { i, id ->
            val preview = HudThemes.resolve(g.copy(theme = id, sidebar = SidebarConfig()))
            val active = id == g.theme

            val card = Ui.hbox(ctx)
            card.gravity = Gravity.CENTER_VERTICAL
            card.setPadding(host.dp(12), host.dp(12), host.dp(12), host.dp(12))
            card.background = Ui.rounded(
                HudThemes.blend(preview.panelTop, preview.panelBottom, 0.35f) or 0xFF000000.toInt(),
                HubStyle.radius(ctx, theme, 16),
                if (active) theme.accent else preview.stroke, host.dp(if (active) 2 else 1)
            )

            val col = Ui.vbox(ctx)
            val head = Ui.hbox(ctx)
            head.gravity = Gravity.CENTER_VERTICAL
            head.addView(Ui.label(ctx, HudThemes.LABELS[i], 14f, preview.textPrimary, true))
            if (active) head.addView(HubStyle.chip(host, "ACTIVE", theme.accent), Ui.lp(Ui.WRAP, Ui.WRAP, 0f, host.dp(8), 0, 0, 0))
            col.addView(head)
            col.addView(Ui.label(ctx, themeText[i], 11f, preview.textSecondary).apply {
                setLineSpacing(0f, 1.15f)
                setPadding(0, host.dp(3), 0, 0)
            })
            card.addView(col, Ui.lp(0, Ui.WRAP, 1f, 0, 0, host.dp(10), 0))

            val dots = Ui.vbox(ctx)
            for (c in listOf(preview.accent, preview.accent2, preview.stroke or 0xFF000000.toInt())) {
                dots.addView(View(ctx).apply { background = Ui.rounded(c, host.dp(7).toFloat()) }, Ui.lp(host.dp(14), host.dp(14), 0f, 0, host.dp(2), 0, host.dp(2)))
            }
            card.addView(dots, Ui.lp(Ui.WRAP, Ui.WRAP))

            card.setOnClickListener {
                if (!active) repo.updateGlobal { it.copy(theme = id) }
            }
            root.addView(card, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(8), 0, 0))
        }
        if (g.theme == ThemeId.AMOLED_BLACK) {
            root.addView(Forms.note(host, "Pitch Black always draws at full opacity, so the opacity slider below has no effect on it."), Ui.lp(Ui.MATCH, Ui.WRAP))
        }
    }

    // ── accents ──

    private fun buildAccents(root: LinearLayout) {
        root.addView(Ui.section(ctx, theme, "Accent colours"), Ui.lp(Ui.MATCH, Ui.WRAP))
        val s = repo.global.value.sidebar

        val pickers = Ui.vbox(ctx)
        pickers.visibility = if (s.useCustomAccent) View.VISIBLE else View.GONE
        pickers.addView(Ui.label(ctx, "Primary (Balanced mode, highlights)", 12f, theme.textPrimary, true))
        pickers.addView(
            HexColorPicker(ctx, theme, s.primaryHex) { hex ->
                repo.updateGlobal { g -> g.copy(sidebar = g.sidebar.copy(primaryHex = hex)) }
            },
            Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(4), 0, host.dp(10))
        )
        pickers.addView(Ui.label(ctx, "Secondary (Wild Boost mode)", 12f, theme.textPrimary, true))
        pickers.addView(
            HexColorPicker(ctx, theme, s.secondaryHex) { hex ->
                repo.updateGlobal { g -> g.copy(sidebar = g.sidebar.copy(secondaryHex = hex)) }
            },
            Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(4), 0, 0)
        )

        root.addRow(
            host,
            Forms.switchRow(host, "Use my own accent colours", "Off uses the colours that belong to the selected theme.", s.useCustomAccent) { on ->
                pickers.visibility = if (on) View.VISIBLE else View.GONE
                repo.updateGlobal { g -> g.copy(sidebar = g.sidebar.copy(useCustomAccent = on)) }
            },
            0
        )
        root.addRow(host, pickers, 8)
    }

    // ── panel look ──

    private fun buildPanel(root: LinearLayout) {
        root.addView(Ui.section(ctx, theme, "Sidebar panel"), Ui.lp(Ui.MATCH, Ui.WRAP))
        val s = repo.global.value.sidebar
        val card = Forms.card(host)
        card.addView(
            Ui.labeledSlider(ctx, theme, "Background opacity", " %", 20, 100, s.opacityPct.coerceIn(20, 100)) { v ->
                repo.updateGlobal { g -> g.copy(sidebar = g.sidebar.copy(opacityPct = v)) }
            }
        )
        card.addRow(
            host,
            Ui.labeledSlider(ctx, theme, "Corner radius", " dp", 0, 32, s.cornerRadiusDp.coerceIn(0, 32)) { v ->
                repo.updateGlobal { g -> g.copy(sidebar = g.sidebar.copy(cornerRadiusDp = v)) }
            },
            10
        )
        card.addRow(host, Forms.note(host, "The Cyber Matrix and RedMagic themes keep their own sharp corners; the radius applies to the glass and AMOLED themes."), 6)
        root.addView(card, Ui.lp(Ui.MATCH, Ui.WRAP))
    }

    // ── tool grid ──

    private fun currentOrder(): List<String> {
        val known = ToolIds.ALL.toSet()
        val saved = repo.global.value.sidebar.toolOrder.filter { it in known }.distinct()
        return saved + ToolIds.ALL.filter { it !in saved }
    }

    private fun buildTools(root: LinearLayout) {
        root.addView(Ui.section(ctx, theme, "Sidebar tools"), Ui.lp(Ui.MATCH, Ui.WRAP))
        root.addView(
            Forms.note(host, "Choose which shortcuts appear in the in-game sidebar and in what order. The first tool is the top-left tile."),
            Ui.lp(Ui.MATCH, Ui.WRAP)
        )
        val bar = Ui.hbox(ctx)
        bar.addView(Ui.button(ctx, theme, "Show all", false) {
            repo.updateGlobal { g -> g.copy(sidebar = g.sidebar.copy(hiddenTools = emptyList())) }
            fillTools()
        }, Ui.lp(0, Ui.WRAP, 1f))
        bar.addView(Ui.button(ctx, theme, "Default order", false) {
            repo.updateGlobal { g -> g.copy(sidebar = g.sidebar.copy(toolOrder = ToolIds.ALL)) }
            fillTools()
        }, Ui.lp(0, Ui.WRAP, 1f, host.dp(8), 0, 0, 0))
        root.addRow(host, bar, 6)

        toolBox = Ui.vbox(ctx)
        root.addRow(host, toolBox, 6)
        fillTools()
    }

    private fun fillTools() {
        toolBox.removeAllViews()
        val order = currentOrder()
        val hidden = repo.global.value.sidebar.hiddenTools.toSet()
        order.forEachIndexed { index, id ->
            val info = ToolCatalog.info(id)
            val visible = id !in hidden

            val row = Ui.hbox(ctx)
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(host.dp(8), host.dp(7), host.dp(8), host.dp(7))
            row.background = Ui.rounded(theme.tile, Ui.tileRadius(ctx, theme), theme.stroke, host.dp(1))
            row.alpha = if (visible) 1f else 0.55f

            val code: TextView = HubStyle.chip(host, info.code, if (visible) theme.accent else theme.textSecondary)
            code.minWidth = host.dp(34)
            code.gravity = Gravity.CENTER
            row.addView(code, Ui.lp(Ui.WRAP, Ui.WRAP))

            row.addView(
                Ui.label(ctx, info.title, 13f, theme.textPrimary, true).apply { maxLines = 1 },
                Ui.lp(0, Ui.WRAP, 1f, host.dp(10), 0, host.dp(6), 0)
            )
            row.addView(Forms.smallButton(host, "Up", enabled = index > 0) { move(id, -1) }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, 0, host.dp(4), 0))
            row.addView(Forms.smallButton(host, "Down", enabled = index < order.size - 1) { move(id, 1) }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, 0, host.dp(4), 0))
            row.addView(
                Forms.smallButton(host, if (visible) "Shown" else "Hidden") { setVisible(id, !visible) },
                Ui.lp(Ui.WRAP, Ui.WRAP)
            )
            toolBox.addView(row, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(5), 0, 0))
        }
    }

    private fun move(id: String, delta: Int) {
        val list = currentOrder().toMutableList()
        val i = list.indexOf(id)
        val j = i + delta
        if (i < 0 || j !in list.indices) return
        list.removeAt(i)
        list.add(j, id)
        repo.updateGlobal { g -> g.copy(sidebar = g.sidebar.copy(toolOrder = list)) }
        fillTools()
    }

    private fun setVisible(id: String, visible: Boolean) {
        repo.updateGlobal { g ->
            val hidden = g.sidebar.hiddenTools.toMutableList()
            if (visible) hidden.remove(id) else if (id !in hidden) hidden.add(id)
            g.copy(sidebar = g.sidebar.copy(hiddenTools = hidden))
        }
        fillTools()
    }

    // ── edge handle ──

    private fun buildHandle(root: LinearLayout) {
        root.addView(Ui.section(ctx, theme, "Edge handle"), Ui.lp(Ui.MATCH, Ui.WRAP))
        val h = repo.global.value.handle
        val card = Forms.card(host)

        fun save(block: (HandleConfig) -> HandleConfig) {
            repo.updateGlobal { g -> g.copy(handle = block(g.handle)) }
        }

        card.addView(Ui.label(ctx, "Screen edge", 12f, theme.textPrimary, true))
        val sides = EdgeSide.values().toList()
        card.addRow(
            host,
            ChipGroup(ctx, theme, listOf("Left", "Right", "Top"), sides.indexOf(h.side).coerceAtLeast(0), 3) { i ->
                save { it.copy(side = sides[i]) }
            },
            2
        )
        card.addRow(
            host,
            Ui.labeledSlider(ctx, theme, "Position along the edge", " dp", 0, 800, h.offsetDp.coerceIn(0, 800)) { v -> save { it.copy(offsetDp = v) } },
            10
        )
        card.addRow(
            host,
            Ui.labeledSlider(ctx, theme, "Width", " dp", 4, 16, h.widthDp.coerceIn(4, 16)) { v -> save { it.copy(widthDp = v) } },
            6
        )
        card.addRow(
            host,
            Ui.labeledSlider(ctx, theme, "Length", " dp", 40, 160, h.heightDp.coerceIn(40, 160)) { v -> save { it.copy(heightDp = v) } },
            6
        )
        card.addRow(
            host,
            Ui.labeledSlider(ctx, theme, "Opacity when idle", " %", 10, 100, h.autoHideAlphaPct.coerceIn(10, 100)) { v -> save { it.copy(autoHideAlphaPct = v) } },
            6
        )
        card.addRow(host, Ui.label(ctx, "Handle colour", 12f, theme.textPrimary, true), 12)
        card.addRow(host, HexColorPicker(ctx, theme, h.colorHex) { hex -> save { it.copy(colorHex = hex) } }, 4)
        card.addRow(host, Forms.note(host, "Changes show on the handle in the running game straight away."), 8)
        card.addRow(host, Ui.button(ctx, theme, "Reset handle", false) {
            save { HandleConfig() }
            host.toast("Edge handle reset")
            host.activity.recreate()
        }, 8)
        root.addView(card, Ui.lp(Ui.MATCH, Ui.WRAP))
    }
}
