package com.hyperengine.gameturbo.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.TextUtils
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

/**
 * Landscape console shell building blocks (UI redesign, part 2).
 *
 * The landscape HUD ([GameTurboLandscapeHudView]) is assembled from these pieces and from the part 1 kit
 * ([Hyper], [HyperSwitch]):
 *
 *  - [ConsolePanel]    themed panel frame (rounded glass, chamfered cyber, octagonal mecha, flat AMOLED)
 *  - [StatChip]        one live readout in the top status bar
 *  - [ModeSwitch]      ECO / BAL / WILD segmented control
 *  - [RailButton]      round quick-toggle in the left rail (tap flips, long-press opens the page)
 *  - [KeyHintBar]      gamepad glyph strip: B Back, Y Settings, X Tabs, L1 / R1 Cube face
 *  - [QuickCatalog]    which features can sit on the rail and what tap / long-press do for each
 */
object ConsoleKit {

    /** Corner radius for round-ish controls: a full pill on the soft HyperOS / AMOLED themes, hard on RedMagic / Realme. */
    fun radius(ctx: Context, theme: HudTheme): Float =
        if (Ui.isSoft(theme)) Ui.dpf(ctx, 22f) else Ui.tileRadius(ctx, theme)

    /** Draws the accent2 focus ring around [v] while a gamepad / keyboard has focus on it. */
    fun focusRing(v: View, theme: HudTheme, radius: Float) {
        v.isFocusable = true
        v.onFocusChangeListener = View.OnFocusChangeListener { view, has ->
            view.foreground = if (has) Ui.rounded(0, radius, theme.accent2, Ui.dp(view.context, 2)) else null
        }
    }

    /** A square icon button (status bar actions). Restyle later with [styleIconButton]. */
    fun iconButton(ctx: Context, theme: HudTheme, kind: IconKind, active: Boolean, onClick: () -> Unit): FrameLayout {
        val f = FrameLayout(ctx)
        f.isClickable = true
        f.setOnClickListener { onClick() }
        styleIconButton(f, theme, kind, active)
        return f
    }

    fun styleIconButton(f: FrameLayout, theme: HudTheme, kind: IconKind, active: Boolean) {
        f.removeAllViews()
        val r = radius(f.context, theme)
        val soft = Ui.isSoft(theme)
        val fill = if (active) theme.accent else theme.tile
        f.background = if (soft) Ui.rounded(fill, r) else Ui.rounded(fill, r, if (active) theme.accent else theme.stroke, Ui.dp(f.context, 1))
        f.addView(
            IconView(f.context, kind, if (active) HudThemes.onAccent(theme.accent) else theme.textPrimary).apply { fillFraction = 0.62f },
            FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH)
        )
        focusRing(f, theme, r)
    }
}

/** A panel whose outline follows the theme: rounded glass, chamfered cyber, octagonal mecha, flat AMOLED. */
class ConsolePanel(ctx: Context, private val theme: HudTheme, padPx: Int) : FrameLayout(ctx) {

    private val d = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val fx = Paint(Paint.ANTI_ALIAS_FLAG)
    private var shape = Path()
    private var glass: Shader? = null
    private var chamfer = 0f

    init {
        setWillNotDraw(false)
        isClickable = true   // swallow touches so the dim layer behind does not close the HUD
        val extra = if (theme.style == PanelStyle.CYBER_ANGULAR || theme.style == PanelStyle.MECHA) Ui.dp(ctx, 3) else 0
        setPadding(padPx + extra, padPx + extra, padPx + extra, padPx + extra)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (w <= 0 || h <= 0) return
        val wf = w.toFloat()
        val hf = h.toFloat()
        val r = Ui.dpf(context, min(theme.cornerDp, 22).toFloat())
        val p = Path()
        chamfer = 0f
        when (theme.style) {
            PanelStyle.GLASS, PanelStyle.FLAT -> p.addRoundRect(RectF(0f, 0f, wf, hf), r, r, Path.Direction.CW)
            PanelStyle.CYBER_ANGULAR -> {
                val c = min(Ui.dpf(context, 8f) + r * 0.5f, hf / 3f)
                chamfer = c
                p.moveTo(c, 0f); p.lineTo(wf, 0f); p.lineTo(wf, hf - c); p.lineTo(wf - c, hf)
                p.lineTo(0f, hf); p.lineTo(0f, c); p.close()
            }
            PanelStyle.MECHA -> {
                val c = min(Ui.dpf(context, 6f) + r * 0.4f, hf / 3f)
                chamfer = c
                p.moveTo(c, 0f); p.lineTo(wf - c, 0f); p.lineTo(wf, c); p.lineTo(wf, hf - c)
                p.lineTo(wf - c, hf); p.lineTo(c, hf); p.lineTo(0f, hf - c); p.lineTo(0f, c); p.close()
            }
        }
        shape = p
        val a = max(theme.panelAlpha, 200)
        fill.shader = LinearGradient(
            0f, 0f, 0f, hf,
            HudThemes.withAlpha(theme.panelTop, a), HudThemes.withAlpha(theme.panelBottom, a), Shader.TileMode.CLAMP
        )
        glass = LinearGradient(0f, 0f, 0f, hf * 0.4f, 0x30FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f) return
        c.drawPath(shape, fill)
        when (theme.style) {
            PanelStyle.GLASS -> {
                c.save()
                c.clipPath(shape)
                fx.shader = glass
                c.drawRect(0f, 0f, w, h * 0.4f, fx)
                fx.shader = null
                c.restore()
                line.color = theme.stroke
                line.strokeWidth = d
                c.drawPath(shape, line)
            }
            PanelStyle.CYBER_ANGULAR -> {
                c.save()
                c.clipPath(shape)
                fx.style = Paint.Style.STROKE
                fx.color = HudThemes.withAlpha(theme.accent, 18)
                fx.strokeWidth = d
                val step = 16f * d
                var x = 0f
                while (x < w) { c.drawLine(x, 0f, x, h, fx); x += step }
                var y = 0f
                while (y < h) { c.drawLine(0f, y, w, y, fx); y += step }
                fx.style = Paint.Style.FILL
                fx.color = HudThemes.withAlpha(theme.accent, 70)
                val tri = Path()
                tri.moveTo(chamfer, 0f); tri.lineTo(chamfer + 40f * d, 0f); tri.lineTo(chamfer, 40f * d); tri.close()
                c.drawPath(tri, fx)
                c.restore()
                line.color = theme.accent
                line.strokeWidth = 2f * d
                c.drawPath(shape, line)
            }
            PanelStyle.MECHA -> {
                line.color = theme.stroke
                line.strokeWidth = 1.5f * d
                c.drawPath(shape, line)
                line.color = theme.accent
                line.strokeWidth = 3f * d
                c.drawLine(chamfer, 1.5f * d, chamfer + 30f * d, 1.5f * d, line)
                c.drawLine(w - chamfer - 30f * d, h - 1.5f * d, w - chamfer, h - 1.5f * d, line)
            }
            PanelStyle.FLAT -> {
                line.color = theme.stroke
                line.strokeWidth = d
                c.drawPath(shape, line)
            }
        }
    }
}

/** One telemetry readout in the status bar: small icon and value on one line, caption underneath. */
class StatChip(ctx: Context, private val theme: HudTheme, kind: IconKind, caption: String) : LinearLayout(ctx) {

    private val ic = IconView(ctx, kind, theme.accent)
    private val value = Ui.label(ctx, "--", 14f, theme.textPrimary, true)
    private val cap = Ui.label(ctx, caption, 8f, theme.textSecondary)

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER
        setPadding(Ui.dp(ctx, 8), 0, Ui.dp(ctx, 8), 0)
        val row = Ui.hbox(ctx)
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(ic, Ui.lp(Ui.dp(ctx, 14), Ui.dp(ctx, 14), 0f, 0, 0, Ui.dp(ctx, 3), 0))
        row.addView(value)
        addView(row)
        addView(cap, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, Ui.dp(ctx, 1), 0, 0))
        minimumWidth = Ui.dp(ctx, 58)
    }

    fun set(text: String, color: Int, caption: String? = null) {
        value.text = text
        value.setTextColor(color)
        if (caption != null) cap.text = caption
    }

    fun icon(kind: IconKind) {
        if (ic.kind != kind) ic.kind = kind
    }
}

/** ECO / BAL / WILD segmented control. The selected segment fills with its own colour. */
class ModeSwitch(ctx: Context, private val theme: HudTheme, private val onPick: (Int) -> Unit) : LinearLayout(ctx) {

    private val labels = listOf("ECO", "BAL", "WILD")
    private val colors = listOf(theme.good, theme.accent, theme.accent2)
    private val cells = ArrayList<TextView>()
    private var selected = -1

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        val soft = Ui.isSoft(theme)
        val r = ConsoleKit.radius(ctx, theme)
        background = if (soft) Ui.rounded(theme.tile, r) else Ui.rounded(theme.tile, r, theme.stroke, Ui.dp(ctx, 1))
        val pad = Ui.dp(ctx, 2)
        setPadding(pad, pad, pad, pad)
        labels.forEachIndexed { i, text ->
            val tv = TextView(ctx).apply {
                this.text = text
                textSize = 10f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                isClickable = true
                setTextColor(colors[i])
                setOnClickListener { onPick(i) }
            }
            ConsoleKit.focusRing(tv, theme, r)
            cells += tv
            addView(tv, Ui.lp(Ui.dp(ctx, 40), Ui.dp(ctx, 26)))
        }
        select(1)
    }

    fun select(i: Int) {
        if (i == selected) return
        selected = i
        val r = ConsoleKit.radius(context, theme)
        cells.forEachIndexed { k, tv ->
            val on = k == i
            tv.setTextColor(if (on) HudThemes.onAccent(colors[k]) else colors[k])
            tv.background = if (on) Ui.rounded(colors[k], r) else null
        }
    }
}

/** What a rail button shows and does. [onLong] is optional (long-press opens the feature's page). */
class QuickItem(
    val id: String,
    val title: String,
    val icon: IconKind,
    val isOn: () -> Boolean,
    val onTap: () -> Unit,
    val onLong: (() -> Unit)? = null
)

/** Round quick-toggle: lit with the accent colour while the feature is on. */
class RailButton(ctx: Context, private val theme: HudTheme, val item: QuickItem) : LinearLayout(ctx) {

    private val disc = FrameLayout(ctx)
    private val glyph = IconView(ctx, item.icon, theme.textPrimary).apply { fillFraction = 0.56f }
    private val caption = Ui.label(ctx, item.title, 8f, theme.textSecondary).apply {
        gravity = Gravity.CENTER
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
    }

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(0, Ui.dp(ctx, 3), 0, Ui.dp(ctx, 3))
        disc.addView(glyph, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        addView(disc, Ui.lp(Ui.dp(ctx, 44), Ui.dp(ctx, 44)))
        addView(caption, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 3), 0, 0))
        isClickable = true
        setOnClickListener {
            item.onTap()
            refresh()
        }
        val long = item.onLong
        if (long != null) {
            setOnLongClickListener {
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                long()
                true
            }
        }
        ConsoleKit.focusRing(this, theme, ConsoleKit.radius(ctx, theme))
        refresh()
    }

    fun refresh() {
        val on = item.isOn()
        val r = ConsoleKit.radius(context, theme)
        val fill = if (on) theme.accent else theme.tile
        disc.background = if (Ui.isSoft(theme)) {
            Ui.rounded(fill, r)
        } else {
            Ui.rounded(fill, r, if (on) theme.accent else theme.stroke, Ui.dp(context, 1))
        }
        glyph.color = if (on) HudThemes.onAccent(theme.accent) else theme.textPrimary
        caption.setTextColor(if (on) theme.textPrimary else theme.textSecondary)
    }
}

/** Gamepad glyph strip along the bottom of the landscape HUD. Pure hints: the keys are handled by the HUD. */
class KeyHintBar(ctx: Context, private val theme: HudTheme) : LinearLayout(ctx) {

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(Ui.dp(ctx, 10), 0, Ui.dp(ctx, 10), 0)
        add("B", true, theme.hot, "Back")
        add("Y", true, theme.warn, "Console settings")
        add("X", true, theme.accent, "Dashboard / All tools")
        addView(View(ctx), Ui.lp(0, 1, 1f))
        add("L1", false, theme.textSecondary, null)
        add("R1", false, theme.textSecondary, "Energy Cube face")
    }

    private fun add(glyph: String, round: Boolean, color: Int, text: String?) {
        val ctx = context
        val chip = Ui.label(ctx, glyph, 9f, color, true).apply {
            gravity = Gravity.CENTER
            minWidth = Ui.dp(ctx, if (round) 18 else 26)
            minHeight = Ui.dp(ctx, 18)
            setPadding(Ui.dp(ctx, 4), 0, Ui.dp(ctx, 4), 0)
            background = Ui.rounded(
                HudThemes.withAlpha(color, 40),
                if (round) Ui.dpf(ctx, 12f) else Ui.dpf(ctx, 6f),
                color, Ui.dp(ctx, 1)
            )
        }
        addView(chip, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, Ui.dp(ctx, 4), 0, Ui.dp(ctx, 3), 0))
        if (text != null) {
            addView(Ui.label(ctx, text, 10f, theme.textSecondary), Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, 0, Ui.dp(ctx, 10), 0))
        }
    }
}

/** What the quick-toggle rail can hold, and what tap / long-press do for each entry. */
class QuickExtras(
    val wildActive: () -> Boolean,
    val toggleWild: () -> Unit,
    val togglePill: () -> Unit
)

object QuickCatalog {

    /** Every feature that may sit on the rail, in the order Console settings lists them. */
    val IDS = listOf(
        "boost", "pill", "crosshair", "danmaku", "edge_guard", "filter", "freeze",
        "shot", "record", "afk", "macro", "kbm", "brightness", "slidebar"
    )

    /** Short caption under the round button. */
    fun caption(id: String): String = when (id) {
        "boost" -> "Boost"
        "pill" -> "FPS pill"
        "crosshair" -> "Crosshair"
        "danmaku" -> "Danmaku"
        "edge_guard" -> "Edge guard"
        "filter" -> "Filter"
        "freeze" -> "Freeze"
        "shot" -> "Shot"
        "record" -> "Record"
        "afk" -> "AFK"
        "macro" -> "Tapper"
        "kbm" -> "Keys"
        "brightness" -> "Bright"
        "slidebar" -> "Slide bar"
        else -> ToolCatalog.info(id).title
    }

    /**
     * Builds the rail entry for [id], or null when the feature is not registered (a rail button never points at
     * nothing). Features that are a plain on/off flip directly; the rest open their normal tool page on tap.
     */
    fun create(host: ToolHost, id: String, x: QuickExtras): QuickItem? {
        val tool = ToolRegistry.get(id) ?: return null
        val repo = host.deps.repo
        val icon = HudIcons.forTool(id) ?: IconKind.GRID
        fun prof() = GameActions.profileFor(host.deps, host.game)
        val openPage: () -> Unit = { tool.onTap(host) }

        return when (id) {
            "boost" -> QuickItem(id, caption(id), icon, x.wildActive, x.toggleWild) {
                ToolRegistry.get("turbo")?.onTap(host)
            }
            "pill" -> QuickItem(id, caption(id), icon, { prof().pill.enabled }, x.togglePill, openPage)
            "crosshair" -> QuickItem(id, caption(id), icon, { prof().crosshair.enabled }, {
                repo.update(host.game) { it.copy(crosshair = it.crosshair.copy(enabled = !it.crosshair.enabled)) }
                host.refreshTiles()
            }, openPage)
            "edge_guard" -> QuickItem(id, caption(id), icon, { prof().edgeGuard.enabled }, {
                repo.update(host.game) { it.copy(edgeGuard = it.edgeGuard.copy(enabled = !it.edgeGuard.enabled)) }
                host.refreshTiles()
            }, openPage)
            "danmaku" -> QuickItem(id, caption(id), icon, { repo.global.value.danmaku.enabled }, {
                repo.updateGlobal { it.copy(danmaku = it.danmaku.copy(enabled = !it.danmaku.enabled)) }
                host.refreshTiles()
            }, openPage)
            // filter, freeze, shot, record, afk, macro, kbm, brightness: the tool decides (page or one-shot action)
            else -> QuickItem(id, caption(id), icon, { tool.isActive(host) }, openPage)
        }
    }
}
