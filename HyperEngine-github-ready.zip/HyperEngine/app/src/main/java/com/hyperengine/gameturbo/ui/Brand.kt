package com.hyperengine.gameturbo.ui

/**
 * Every user-facing name of the HyperLab features lives here and nowhere else in the UI code, so a rename is a
 * one-file edit. The names are deliberately generic: this project is independent software and is not made by,
 * licensed from or affiliated with NVIDIA, AMD or any game publisher. Each label only describes what the feature
 * does on an Android phone.
 */
object Brand {
    const val LAB_TITLE = "HyperLab"
    const val LAB_TILE = "HyperLab"
    const val LAB_TAB = "HyperLab"

    const val LOW_LATENCY = "Low-latency mode"
    const val LOW_LATENCY_SHORT = "Low latency"
    const val REPLAY = "Clip buffer"
    const val REPLAY_SAVE = "Save last clip"
    const val REPLAY_TILE = "Save clip"
    const val GAME_FILTERS = "Game colour filters"
    const val REFRESH_SYNC = "Refresh-rate matching"
    const val HYPERBOOST = "HyperBoost render scale"
    const val UPSCALER = "Virtual-display upscaler"
}
