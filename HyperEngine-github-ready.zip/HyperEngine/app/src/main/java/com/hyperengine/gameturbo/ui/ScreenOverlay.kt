package com.hyperengine.gameturbo.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.Build
import android.view.View
import android.view.WindowManager
import com.hyperengine.gameturbo.core.ColorMath
import com.hyperengine.gameturbo.core.OverlayState

/**
 * One full-screen, non-touchable window used for:
 *  - the dimmer / tint / shadow-lift fallback of the Visual filter (when no shell can install a real
 *    colour matrix), and
 *  - a window-level brightness override that works regardless of the ROM's brightness scale.
 *
 * Android blocks touches that pass through an overlay whose window alpha is above 0.8, so the window
 * alpha is pinned to 0.79 and the layers are drawn with the compensating per-pixel alpha.
 * Main thread only.
 */
class ScreenOverlay(private val ctx: Context, private val wm: WindowManager) {

    private var view: LayerView? = null
    private var params: WindowManager.LayoutParams? = null
    private var attached = false   // our own flag: View.isAttachedToWindow stays false until the first frame

    fun apply(state: OverlayState?) {
        if (state == null || state.isNeutral) {
            remove()
            return
        }
        val v = view ?: LayerView(ctx).also { view = it }
        v.state = state
        v.invalidate()
        val p = params ?: buildParams().also { params = it }
        p.screenBrightness = if (state.brightness >= 0f) state.brightness.coerceIn(0.01f, 1f)
        else WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        try {
            if (attached) {
                wm.updateViewLayout(v, p)
            } else {
                wm.addView(v, p)
                attached = true
            }
        } catch (_: Throwable) {
            if (attached) runCatching { wm.removeViewImmediate(v) }
            attached = false
            view = null
            params = null
        }
    }

    fun remove() {
        val v = view ?: return
        view = null
        params = null
        if (attached) runCatching { wm.removeViewImmediate(v) }
        attached = false
    }

    private fun buildParams(): WindowManager.LayoutParams {
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        p.alpha = ColorMath.MAX_OVERLAY_ALPHA
        p.title = "HyperEngineScreenFilter"
        if (Build.VERSION.SDK_INT >= 28) {
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return p
    }

    private class LayerView(context: Context) : View(context) {
        var state = OverlayState()
        private val paint = Paint()

        init {
            importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
        }

        private fun comp(effective: Float): Int =
            (255f * (effective / ColorMath.MAX_OVERLAY_ALPHA).coerceIn(0f, 1f)).toInt()

        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            if (state.liftAlpha > 0f) {
                paint.color = Color.argb(comp(state.liftAlpha), 255, 255, 255)
                canvas.drawRect(0f, 0f, w, h, paint)
            }
            if (state.tintAlpha > 0f) {
                paint.color = Color.argb(comp(state.tintAlpha), Color.red(state.tintColor), Color.green(state.tintColor), Color.blue(state.tintColor))
                canvas.drawRect(0f, 0f, w, h, paint)
            }
            if (state.veilAlpha > 0f) {
                paint.color = Color.argb(comp(state.veilAlpha), 0, 0, 0)
                canvas.drawRect(0f, 0f, w, h, paint)
            }
        }
    }
}
