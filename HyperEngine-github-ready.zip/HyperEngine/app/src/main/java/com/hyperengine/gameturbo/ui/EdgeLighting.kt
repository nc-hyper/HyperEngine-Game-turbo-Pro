package com.hyperengine.gameturbo.ui

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.RoundedCorner
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import com.hyperengine.gameturbo.data.EdgeLightConfig
import com.hyperengine.gameturbo.data.EdgePalette
import com.hyperengine.gameturbo.data.EdgeStyle
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.sin

// =============================================================================================
// Colours
// =============================================================================================

/**
 * Where the edge light gets its colours.
 *  - APP_COLOR: the notification's own brand colour, else the dominant hue of the app icon (cached per app)
 *  - RAINBOW / AURORA / SUNSET / REDMAGIC: fixed multi-colour palettes
 *  - CYCLE: a different palette on every notification
 *  - FIXED: one colour of the user's choice, with lighter and darker neighbours
 */
object EdgeLightColors {

    private val cache = HashMap<String, Int>()

    private val RAINBOW = intArrayOf(
        0xFFFF3B5C.toInt(), 0xFFFF9F1C.toInt(), 0xFFFFE14D.toInt(), 0xFF3DDC84.toInt(),
        0xFF22D3EE.toInt(), 0xFF4C8DFF.toInt(), 0xFFB45CFF.toInt()
    )
    private val AURORA = intArrayOf(0xFF00E5A0.toInt(), 0xFF00B8FF.toInt(), 0xFF7C4DFF.toInt(), 0xFFFF4FD8.toInt())
    private val SUNSET = intArrayOf(0xFFFF512F.toInt(), 0xFFFF9A3C.toInt(), 0xFFFF4F8B.toInt(), 0xFFB24BF3.toInt())
    private val REDMAGIC = intArrayOf(0xFFFF1744.toInt(), 0xFFFF5A36.toInt(), 0xFFFFFFFF.toInt(), 0xFFFF2D46.toInt())
    private val CYCLE_ORDER = listOf(EdgePalette.AURORA, EdgePalette.SUNSET, EdgePalette.RAINBOW, EdgePalette.REDMAGIC)

    /**
     * The colour that represents [pkg]. [notifColor] is Notification.color (0 = the app did not set one).
     * Returns 0 when the app has no usable colour (grey / white / black icon).
     */
    @Synchronized
    fun appColor(ctx: Context, pkg: String, notifColor: Int): Int {
        if (notifColor != 0) {
            val hsv = FloatArray(3)
            Color.colorToHSV(notifColor or 0xFF000000.toInt(), hsv)
            if (hsv[1] >= 0.25f && hsv[2] >= 0.35f) return vivid(hsv)
        }
        cache[pkg]?.let { return it }
        val c = runCatching { fromIcon(ctx, pkg) }.getOrDefault(0)
        cache[pkg] = c
        return c
    }

    private fun vivid(hsv: FloatArray): Int =
        Color.HSVToColor(floatArrayOf(hsv[0], hsv[1].coerceIn(0.55f, 1f), 1f))

    /** Dominant hue of the launcher icon, weighted by saturation x brightness so a grey background does not win. */
    private fun fromIcon(ctx: Context, pkg: String): Int {
        val size = 24
        val dr = ctx.packageManager.getApplicationIcon(pkg)
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        try {
            val cv = Canvas(bmp)
            dr.setBounds(0, 0, size, size)
            dr.draw(cv)
            val px = IntArray(size * size)
            bmp.getPixels(px, 0, size, 0, 0, size, size)
            val hsv = FloatArray(3)
            var x = 0.0
            var y = 0.0
            var w = 0.0
            var sat = 0.0
            for (p in px) {
                if (Color.alpha(p) < 160) continue
                Color.colorToHSV(p, hsv)
                val wt = (hsv[1] * hsv[2]).toDouble()
                if (wt < 0.12) continue
                val rad = hsv[0] * PI / 180.0
                x += cos(rad) * wt
                y += sin(rad) * wt
                sat += hsv[1] * wt
                w += wt
            }
            if (w < 1.0) return 0
            var hue = (atan2(y, x) * 180.0 / PI).toFloat()
            if (hue < 0f) hue += 360f
            val s = (sat / w).toFloat().coerceIn(0.55f, 1f)
            return Color.HSVToColor(floatArrayOf(hue, s, 1f))
        } finally {
            bmp.recycle()
        }
    }

    private fun shift(base: Int, hueDelta: Float, satScale: Float = 1f): Int {
        val hsv = FloatArray(3)
        Color.colorToHSV(base, hsv)
        hsv[0] = (hsv[0] + hueDelta + 360f) % 360f
        hsv[1] = (hsv[1] * satScale).coerceIn(0f, 1f)
        hsv[2] = 1f
        return Color.HSVToColor(hsv)
    }

    private fun lighter(base: Int, t: Float): Int = HudThemes.blend(base or 0xFF000000.toInt(), Color.WHITE, t)
    private fun darker(base: Int, t: Float): Int = HudThemes.blend(base or 0xFF000000.toInt(), Color.BLACK, t)

    /** The gradient stops for one pulse. [cycle] is a running counter used only by CYCLE. */
    fun colors(cfg: EdgeLightConfig, appColor: Int, cycle: Int): IntArray {
        val pal = when (cfg.palette) {
            EdgePalette.CYCLE -> CYCLE_ORDER[Math.floorMod(cycle, CYCLE_ORDER.size)]
            else -> cfg.palette
        }
        return when (pal) {
            EdgePalette.APP_COLOR ->
                if (appColor == 0) AURORA.copyOf()
                else intArrayOf(shift(appColor, -26f), appColor, shift(appColor, 26f), lighter(appColor, 0.55f))
            EdgePalette.RAINBOW -> RAINBOW.copyOf()
            EdgePalette.AURORA -> AURORA.copyOf()
            EdgePalette.SUNSET -> SUNSET.copyOf()
            EdgePalette.REDMAGIC -> REDMAGIC.copyOf()
            EdgePalette.FIXED -> {
                val base = HudThemes.parse(cfg.fixedHex, 0xFF4C8DFF.toInt()) or 0xFF000000.toInt()
                intArrayOf(darker(base, 0.25f), base, lighter(base, 0.35f), lighter(base, 0.65f))
            }
            EdgePalette.CYCLE -> AURORA.copyOf()   // unreachable: CYCLE was resolved above
        }
    }
}

// =============================================================================================
// The light itself
// =============================================================================================

/**
 * Full-screen, never-touchable view that draws the light: a glowing rounded border (four widening strokes fake
 * the glow, because a blur filter does not survive a hardware layer) plus a faint wash that bleeds inwards.
 * One ValueAnimator drives [progress] from 0 to 1; nothing is allocated per frame.
 */
private class EdgeLightView(ctx: Context) : View(ctx) {

    var progress = 0f
        set(v) { field = v; invalidate() }

    private var cfg = EdgeLightConfig()
    private var colors = intArrayOf(Color.WHITE)
    private val d = ctx.resources.displayMetrics.density

    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val wash = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val m = Matrix()
    private var sweep: SweepGradient? = null
    private val washShaders = arrayOfNulls<LinearGradient>(4)
    private val washRects = Array(4) { RectF() }
    private var radiusPx = 34f * d

    init { setLayerType(LAYER_TYPE_HARDWARE, null) }

    fun configure(c: EdgeLightConfig, cols: IntArray) {
        cfg = c
        colors = if (cols.isEmpty()) intArrayOf(Color.WHITE) else cols
        progress = 0f
        rebuild()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        rebuild()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        rebuild()
    }

    private fun cornerPx(): Float {
        if (cfg.cornerDp > 0) return cfg.cornerDp * d
        if (Build.VERSION.SDK_INT >= 31) {
            val rc = rootWindowInsets?.getRoundedCorner(RoundedCorner.POSITION_TOP_LEFT)
            if (rc != null && rc.radius > 0) return rc.radius.toFloat()
        }
        return 34f * d
    }

    private fun rebuild() {
        val w = width
        val h = height
        if (w <= 0 || h <= 0) return
        radiusPx = cornerPx()
        sweep = buildSweep(w / 2f, h / 2f)
        stroke.shader = sweep

        val depth = (28f + cfg.thicknessDp * 3f) * d
        val c = colors[(colors.size / 2).coerceIn(0, colors.size - 1)]
        val on = c or 0xFF000000.toInt()
        val off = HudThemes.withAlpha(c, 0)
        val wf = w.toFloat()
        val hf = h.toFloat()
        washShaders[0] = LinearGradient(0f, 0f, depth, 0f, on, off, Shader.TileMode.CLAMP)
        washShaders[1] = LinearGradient(wf, 0f, wf - depth, 0f, on, off, Shader.TileMode.CLAMP)
        washShaders[2] = LinearGradient(0f, 0f, 0f, depth, on, off, Shader.TileMode.CLAMP)
        washShaders[3] = LinearGradient(0f, hf, 0f, hf - depth, on, off, Shader.TileMode.CLAMP)
        washRects[0].set(0f, 0f, depth, hf)
        washRects[1].set(wf - depth, 0f, wf, hf)
        washRects[2].set(0f, 0f, wf, depth)
        washRects[3].set(0f, hf - depth, wf, hf)
        invalidate()
    }

    private fun buildSweep(cx: Float, cy: Float): SweepGradient {
        val n = colors.size
        if (cfg.style == EdgeStyle.FLOW) {
            // Two comets on opposite sides: a transparent tail, the palette, then a sharp bright head.
            val cols = ArrayList<Int>()
            val pos = ArrayList<Float>()
            for (k in 0..1) {
                val s = k * 0.5f
                cols += HudThemes.withAlpha(colors[0], 0); pos += s
                for (i in 0 until n) {
                    cols += colors[i]
                    pos += s + 0.08f + 0.36f * (i / max(1f, (n - 1).toFloat()))
                }
                cols += HudThemes.withAlpha(colors[n - 1], 0); pos += s + 0.5f
            }
            return SweepGradient(cx, cy, cols.toIntArray(), pos.toFloatArray())
        }
        // BREATHE / PULSE: a closed colour ring.
        val cols = IntArray(n + 1) { colors[it % n] }
        val pos = FloatArray(n + 1) { it / n.toFloat() }
        return SweepGradient(cx, cy, cols, pos)
    }

    private fun smooth(x: Float): Float {
        val t = x.coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    private fun bump(p: Float, c: Float, w: Float): Float {
        val z = (p - c) / w
        return exp(-(z * z))
    }

    private fun envelope(p: Float): Float = when (cfg.style) {
        EdgeStyle.FLOW -> smooth(p / 0.10f) * (1f - smooth((p - 0.72f) / 0.28f))
        EdgeStyle.BREATHE -> smooth(sin(PI * p).toFloat() * 1.15f)
        EdgeStyle.PULSE -> max(bump(p, 0.16f, 0.09f), 0.75f * bump(p, 0.46f, 0.10f)) * (1f - smooth((p - 0.85f) / 0.15f))
    }

    private fun angle(p: Float): Float = when (cfg.style) {
        EdgeStyle.FLOW -> 540f * p
        EdgeStyle.BREATHE -> 120f * p
        EdgeStyle.PULSE -> 60f * p
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f) return
        val master = cfg.intensityPct.coerceIn(10, 100) / 100f
        val env = envelope(progress) * master
        if (env <= 0.01f) return
        val sw = sweep ?: return

        // soft inner wash
        for (i in 0 until 4) {
            wash.shader = washShaders[i]
            wash.alpha = (255f * 0.30f * env).toInt().coerceIn(0, 255)
            c.drawRect(washRects[i], wash)
        }

        // glowing border
        m.setRotate(angle(progress), w / 2f, h / 2f)
        sw.setLocalMatrix(m)
        val t = cfg.thicknessDp.coerceIn(2, 10) * d
        val inset = t * 0.5f + d
        rect.set(inset, inset, w - inset, h - inset)
        val r = (radiusPx - inset).coerceAtLeast(0f)
        for (pass in PASSES) {
            stroke.strokeWidth = t * pass.first
            stroke.alpha = (255f * pass.second * env).toInt().coerceIn(0, 255)
            c.drawRoundRect(rect, r, r, stroke)
        }
    }

    companion object {
        /** stroke width multiplier to alpha: widest, faintest first. */
        private val PASSES = arrayOf(5.0f to 0.10f, 2.8f to 0.18f, 1.6f to 0.40f, 1.0f to 1.0f)
    }
}

// =============================================================================================
// Controller
// =============================================================================================

/**
 * Plays the edge light. Owned by [DanmakuTicker]: every bullet it shows also calls [pulse], so the light and the
 * scrolling text always arrive together. The window exists only while the light is playing.
 */
class EdgeLighting(context: Context, private val wm: WindowManager) {

    private val ctx: Context = context.applicationContext
    private val main = Handler(Looper.getMainLooper())

    private var cfg = EdgeLightConfig()
    private var active = false
    private var view: EdgeLightView? = null
    private var anim: ValueAnimator? = null
    private var lastPulse = 0L
    private var cycle = 0

    /** The danmaku ticker is on for a game: pulses are allowed. */
    fun start() { active = true }

    /** The game left the foreground: stop any light that is playing. */
    fun stop() {
        active = false
        cancel()
    }

    fun apply(c: EdgeLightConfig) {
        cfg = c
        if (!c.enabled) cancel()
    }

    /**
     * Lights the edge for one notification. [appColor] comes from [EdgeLightColors.appColor] (0 = none).
     * A burst of notifications inside half a second is one light show, not ten.
     */
    fun pulse(appColor: Int) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            main.post { pulse(appColor) }
            return
        }
        if (!active || !cfg.enabled) return
        val now = SystemClock.uptimeMillis()
        if (now - lastPulse < 500L) return
        lastPulse = now
        play(appColor)
    }

    /**
     * For callers outside the game HUD (the notification listener): applies [c], then lights the edge. Runs on the
     * main thread. The HUD path never needed this because DanmakuTicker kept the light started and configured.
     */
    fun pulseStandalone(c: EdgeLightConfig, appColor: Int) {
        main.post {
            start()
            apply(c)
            pulse(appColor)
        }
    }

    /** Settings-page preview. Ignores the on/off switches; returns false without the overlay permission. */
    fun preview(sampleColor: Int): Boolean {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            main.post { preview(sampleColor) }
            return true
        }
        if (!Settings.canDrawOverlays(ctx)) return false
        play(sampleColor)
        return true
    }

    private fun play(appColor: Int) {
        if (!Settings.canDrawOverlays(ctx)) return
        val c = cfg
        val cols = EdgeLightColors.colors(c, appColor, cycle++)
        cancel()
        val v = EdgeLightView(ctx)
        val lp = OverlayKit.params(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, "HyperEdgeLight", touchable = false
        )
        lp.x = 0
        lp.y = 0
        v.configure(c, cols)
        if (!runCatching { wm.addView(v, lp) }.isSuccess) return
        view = v
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = c.durationMs.coerceIn(1200, 6000).toLong()
            interpolator = LinearInterpolator()
            addUpdateListener { v.progress = it.animatedValue as Float }
            addListener(object : AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(a: Animator) { cancelled = true }
                override fun onAnimationEnd(a: Animator) { if (!cancelled) this@EdgeLighting.cancel() }
            })
            start()
        }
    }

    private fun cancel() {
        anim?.let { a -> a.removeAllListeners(); a.cancel() }
        anim = null
        view?.let { runCatching { wm.removeViewImmediate(it) } }
        view = null
    }
}

// =============================================================================================
// Settings page (shown inside the Danmaku tool page; Part 4 moves it into the merged Notifications page)
// =============================================================================================

object EdgeLightPanel {

    private val PALETTES = listOf(
        EdgePalette.APP_COLOR to "Per app",
        EdgePalette.RAINBOW to "Rainbow",
        EdgePalette.AURORA to "Aurora",
        EdgePalette.SUNSET to "Sunset",
        EdgePalette.REDMAGIC to "RedMagic",
        EdgePalette.CYCLE to "Cycle",
        EdgePalette.FIXED to "One colour"
    )
    private val STYLES = listOf(EdgeStyle.FLOW to "Flow", EdgeStyle.BREATHE to "Breathe", EdgeStyle.PULSE to "Pulse")

    /** [rebuild] re-opens the host page after a change that adds or removes controls. */
    fun build(host: ToolHost, edge: EdgeLighting, rebuild: () -> Unit): View {
        val ctx = host.hostContext
        val theme = host.theme
        val repo = host.deps.repo
        var cfg = repo.global.value.edgeLight

        fun commit(next: EdgeLightConfig, again: Boolean = false) {
            cfg = next
            repo.updateGlobal { it.copy(edgeLight = next) }
            edge.apply(next)
            if (again) rebuild()
        }
        fun preview() {
            if (!edge.preview(theme.accent)) host.toast("Edge lighting needs the display-over-apps permission")
        }

        val col = Ui.vbox(ctx)
        col.addView(Ui.section(ctx, theme, "Edge lighting"))
        val card = Hyper.card(ctx, theme)
        card.addView(Hyper.switchRow(
            ctx, theme, "Light up the screen edge",
            "A coloured light runs around the screen whenever a notification arrives. Works on its own: the danmaku ticker can stay off.",
            cfg.enabled
        ) { commit(cfg.copy(enabled = it), again = true) })
        if (cfg.enabled) {
            Hyper.addDivider(ctx, theme, card)
            card.addView(Hyper.switchRow(
                ctx, theme, "Also outside games",
                "Light the edge on the home screen and in other apps too, not only while a game is in front.",
                cfg.everywhere
            ) { commit(cfg.copy(everywhere = it)) })
        }
        col.addView(card, Ui.lp(Ui.MATCH, Ui.WRAP))
        if (!cfg.enabled) return col

        // ---- colours ----
        col.addView(Ui.section(ctx, theme, "Colours"))
        col.addView(ChipGroup(ctx, theme, PALETTES.map { it.second }, PALETTES.indexOfFirst { it.first == cfg.palette }, 3) { i ->
            commit(cfg.copy(palette = PALETTES[i].first), again = true)
        })
        val strip = GradientStrip(ctx, EdgeLightColors.colors(cfg, theme.accent, 0))
        col.addView(strip, Ui.lp(Ui.MATCH, Ui.dp(ctx, 14), 0f, Ui.dp(ctx, 3), Ui.dp(ctx, 10), Ui.dp(ctx, 3), Ui.dp(ctx, 2)))
        col.addView(ToolUi.note(host, when (cfg.palette) {
            EdgePalette.APP_COLOR -> "Each app lights the edge in its own colour. The bar shows a sample."
            EdgePalette.CYCLE -> "Every notification uses the next palette: Aurora, Sunset, Rainbow, RedMagic."
            else -> "The same palette for every app."
        }))
        if (cfg.palette == EdgePalette.FIXED) {
            col.addView(HexColorPicker(ctx, theme, cfg.fixedHex) { hex ->
                commit(cfg.copy(fixedHex = hex))
                strip.setColors(EdgeLightColors.colors(cfg, theme.accent, 0))
            })
        }

        // ---- motion ----
        col.addView(Ui.section(ctx, theme, "Motion"))
        col.addView(ChipGroup(ctx, theme, STYLES.map { it.second }, STYLES.indexOfFirst { it.first == cfg.style }, 3) { i ->
            commit(cfg.copy(style = STYLES[i].first))
            preview()
        })
        col.addView(ToolUi.liveSlider(ctx, theme, "Thickness", " dp", 2, 10, cfg.thicknessDp, { }) {
            commit(cfg.copy(thicknessDp = it)); preview()
        })
        col.addView(ToolUi.liveSlider(ctx, theme, "Brightness", " %", 30, 100, cfg.intensityPct, { }) {
            commit(cfg.copy(intensityPct = it)); preview()
        })
        col.addView(ToolUi.liveSlider(ctx, theme, "Duration", " ms", 1200, 6000, cfg.durationMs.coerceIn(1200, 6000), { }) {
            commit(cfg.copy(durationMs = it)); preview()
        })
        col.addView(ToolUi.liveSlider(ctx, theme, "Corner radius (0 = match screen)", " dp", 0, 60, cfg.cornerDp, { }) {
            commit(cfg.copy(cornerDp = it)); preview()
        })
        col.addView(Ui.button(ctx, theme, "Preview the light", true) { preview() },
            Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 8), 0, 0))
        return col
    }
}
