package com.hyperengine.gameturbo.hub

import android.app.Activity
import android.graphics.Typeface
import android.os.Build
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.hyperengine.gameturbo.HyperApp
import com.hyperengine.gameturbo.R
import com.hyperengine.gameturbo.core.AntutuBenchmarkBooster
import com.hyperengine.gameturbo.core.BoostOptions
import com.hyperengine.gameturbo.core.BoostState
import com.hyperengine.gameturbo.core.FrameStats
import com.hyperengine.gameturbo.core.GameSessionGuard
import com.hyperengine.gameturbo.core.GuardState
import com.hyperengine.gameturbo.core.HardwareFrameSmoother
import com.hyperengine.gameturbo.core.MaxHzState
import com.hyperengine.gameturbo.core.MaxPanelHzEngine
import com.hyperengine.gameturbo.core.SmootherState
import com.hyperengine.gameturbo.core.StepResult
import com.hyperengine.gameturbo.ui.AnimationController
import com.hyperengine.gameturbo.ui.ChipGroup
import com.hyperengine.gameturbo.ui.GameActions
import com.hyperengine.gameturbo.ui.Hyper
import com.hyperengine.gameturbo.ui.HudTheme
import com.hyperengine.gameturbo.ui.Ui
import com.hyperengine.gameturbo.ui.VIcon
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

/**
 * "ROM & Benchmark Optimizer Lab": the lobby card for Part 9.
 *
 *  - Live read-outs: panel refresh rate (rolling Hz badge), 1% low of this app's frames, battery temperature, thermal state.
 *  - Target picker: installed benchmark apps (AnTuTu, 3DMark, Geekbench, PCMark) first, then your recent games.
 *  - AOT Speed Compile: `cmd package compile -m speed -f <target>` through [AntutuBenchmarkBooster.compileAsync].
 *  - AnTuTu Prep: [AntutuBenchmarkBooster.engage] (thermal override, fixed clocks, storage trim, RAM purge, background
 *    data block, max panel Hz + GameManager fps for the target) followed by [HardwareFrameSmoother.engage].
 *    The same button reads "Stop and restore" while the boost is on and puts every setting back.
 *  - Lock panel: [MaxPanelHzEngine] on its own, for the lobby and any game you start next.
 *  - Open: starts the picked app.
 *
 * Nothing here is simulated: every number comes from a Flow of the three engines, every result line from a real StepResult.
 * Use it from an Activity: add [root] to a layout, call [attach] in onResume / onShow and [detach] in onPause / onHide.
 */
class RomLabCard(
    activity: Activity,
    private val theme: HudTheme,
    private val library: GameLibrary,
    private val toast: (String, Boolean) -> Unit
) {

    private val ctx: Activity = activity
    private val hz by lazy { MaxPanelHzEngine.from(ctx) }
    private val smoother by lazy { HardwareFrameSmoother.from(ctx) }
    private val booster by lazy { AntutuBenchmarkBooster.from(ctx) }
    private val guard by lazy { GameSessionGuard.from(ctx) }

    val root: LinearLayout = Hyper.card(ctx, theme)

    private val icon: ImageView
    private val sub: TextView
    private val hzValue: TextView
    private val lowValue: TextView
    private val tempValue: TextView
    private val liveLine: TextView
    private val targetHolder: LinearLayout
    private val compileBtn: TextView
    private val prepBtn: TextView
    private val lockBtn: TextView
    private val openBtn: TextView
    private val resultView: TextView
    private val autoLine: TextView

    private val hzBadge: AnimationController.HzBadge
    private val shimmer = AnimationController.BusyShimmer(root, Ui.dpf(ctx, Hyper.cardRadiusDp(theme)))

    private class Entry(val pkg: String, val label: String)

    private var entries: List<Entry> = emptyList()
    private var selectedPkg: String? = null
    private var games: List<GameEntry> = emptyList()

    private var lastHz = MaxHzState()
    private var lastStats = FrameStats()
    private var lastBoost = BoostState()
    private var lastSmooth = SmootherState()
    private var lastGuard = GuardState()

    private var romLabel: String = Build.MANUFACTURER.take(1).uppercase(Locale.US) + Build.MANUFACTURER.drop(1)
    private var badgeHz = -1
    private var badgeMax = -1
    private var job: Job? = null
    private var scopeRef: CoroutineScope? = null
    private var introPlayed = false
    private var iconBusy = false
    private var prepWasActive = false
    private var resultExpanded = false

    init {
        // ---- header -------------------------------------------------------------------------
        val head = Ui.hbox(ctx)
        head.gravity = Gravity.CENTER_VERTICAL
        icon = VIcon.view(ctx, R.drawable.ic_rom_lab, 40)
        head.addView(icon, Ui.lp(dp(40), dp(40), 0f, 0, 0, dp(10), 0))
        val info = Ui.vbox(ctx)
        info.addView(Ui.label(ctx, "ROM & Benchmark Optimizer Lab", 14f, theme.textPrimary, true).apply { maxLines = 2 })
        sub = Ui.label(ctx, "", 10f, theme.textSecondary).apply {
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }
        info.addView(sub, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, dp(2), 0, 0))
        head.addView(info, Ui.lp(0, Ui.WRAP, 1f))
        root.addView(head, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, dp(2), 0, dp(2)))
        Hyper.addDivider(ctx, theme, root)

        // ---- live read-outs ---------------------------------------------------------------
        hzValue = Ui.label(ctx, "--", 20f, theme.textPrimary, true)
        lowValue = Ui.label(ctx, "--", 20f, theme.textSecondary, true)
        tempValue = Ui.label(ctx, "--", 20f, theme.textSecondary, true)
        val stats = Ui.hbox(ctx)
        stats.addView(cell("REFRESH", hzValue), Ui.lp(0, Ui.WRAP, 1f))
        stats.addView(cell("1% LOW", lowValue), Ui.lp(0, Ui.WRAP, 1f))
        stats.addView(cell("BATTERY", tempValue), Ui.lp(0, Ui.WRAP, 1f))
        root.addView(stats, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, dp(8), 0, dp(4)))
        liveLine = Ui.label(ctx, "", 10f, theme.textSecondary).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }
        root.addView(liveLine, Ui.lp(Ui.MATCH, Ui.WRAP))
        hzBadge = AnimationController.HzBadge(hzValue)
        Hyper.addDivider(ctx, theme, root)

        // ---- target picker ----------------------------------------------------------------
        root.addView(Ui.label(ctx, "Target", 11f, theme.textSecondary, true), Ui.lp(Ui.WRAP, Ui.WRAP, 0f, dp(2), dp(6), 0, dp(2)))
        targetHolder = Ui.vbox(ctx)
        root.addView(targetHolder, Ui.lp(Ui.MATCH, Ui.WRAP))

        // ---- actions ----------------------------------------------------------------------
        compileBtn = action("AOT Speed Compile", R.drawable.ic_aot_compile, false) { onCompile() }
        prepBtn = action("AnTuTu Prep", R.drawable.ic_antutu_benchmark, true) { onPrep() }
        lockBtn = action("Lock panel", R.drawable.ic_refresh_rate_hz, false) { onLock() }
        openBtn = action("Open", R.drawable.ic_play, false) { onOpen() }.apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val row1 = Ui.hbox(ctx)
        row1.addView(compileBtn, Ui.lp(0, Ui.WRAP, 1f, dp(3), dp(3), dp(3), dp(3)))
        row1.addView(prepBtn, Ui.lp(0, Ui.WRAP, 1f, dp(3), dp(3), dp(3), dp(3)))
        val row2 = Ui.hbox(ctx)
        row2.addView(lockBtn, Ui.lp(0, Ui.WRAP, 1f, dp(3), dp(3), dp(3), dp(3)))
        row2.addView(openBtn, Ui.lp(0, Ui.WRAP, 1f, dp(3), dp(3), dp(3), dp(3)))
        root.addView(row1, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, dp(8), 0, 0))
        root.addView(row2, Ui.lp(Ui.MATCH, Ui.WRAP))

        // ---- automatic restore (Part 10): what the watcher does by itself around a game or benchmark ----
        Hyper.addDivider(ctx, theme, root)
        root.addView(Ui.label(ctx, "Automatic mode", 11f, theme.textSecondary, true), Ui.lp(Ui.WRAP, Ui.WRAP, 0f, dp(4), dp(4), 0, 0))
        root.addView(
            Hyper.switchRow(ctx, theme, "Lock max Hz when a game starts", "Skipped when the game's profile picks its own rate", guard.autoPanel) { guard.autoPanel = it },
            Ui.lp(Ui.MATCH, Ui.WRAP)
        )
        root.addView(
            Hyper.switchRow(ctx, theme, "Frame smoother during games", "Keeps the HUD and this app smooth while you play", guard.autoSmoother) { guard.autoSmoother = it },
            Ui.lp(Ui.MATCH, Ui.WRAP)
        )
        root.addView(
            Hyper.switchRow(ctx, theme, "End boost when its app closes", "45 s after you leave it, or 15 min if it was never opened", guard.autoEndBoost) { guard.autoEndBoost = it },
            Ui.lp(Ui.MATCH, Ui.WRAP)
        )
        autoLine = Ui.label(ctx, "", 10f, theme.textSecondary).apply {
            maxLines = 3
            ellipsize = TextUtils.TruncateAt.END
            setPadding(Ui.dp(ctx, 2), Ui.dp(ctx, 2), Ui.dp(ctx, 2), 0)
        }
        root.addView(autoLine, Ui.lp(Ui.MATCH, Ui.WRAP))

        // ---- result of the last action (real step results, tap to expand) -------------------
        resultView = Ui.label(ctx, "", 10.5f, theme.textSecondary).apply {
            typeface = Typeface.MONOSPACE
            setLineSpacing(0f, 1.1f)
            maxLines = RESULT_LINES
            ellipsize = TextUtils.TruncateAt.END
            visibility = View.GONE
            setPadding(0, dp(10), 0, 0)
            setOnClickListener {
                resultExpanded = !resultExpanded
                maxLines = if (resultExpanded) 60 else RESULT_LINES
            }
        }
        root.addView(resultView, Ui.lp(Ui.MATCH, Ui.WRAP))

        rebuildTargets()
        renderLive()
        renderButtons()
        renderAuto()
    }

    // =========================================================================================
    // Lifecycle
    // =========================================================================================

    /** Starts the live read-outs and the frame monitor. Safe to call again; the previous run is cancelled first. */
    fun attach(scope: CoroutineScope) {
        detach()
        scopeRef = scope
        lastHz = hz.state.value
        lastBoost = booster.state.value
        lastSmooth = smoother.state.value
        lastStats = smoother.stats.value
        smoother.startMonitor(MONITOR_OWNER)
        job = scope.launch {
            launch { hz.state.collect { lastHz = it; renderLive(); renderButtons() } }
            launch { smoother.stats.collect { lastStats = it; renderLive() } }
            launch { smoother.state.collect { lastSmooth = it; renderButtons() } }
            launch { booster.state.collect { lastBoost = it; renderLive(); renderButtons() } }
            launch { guard.state.collect { lastGuard = it; renderAuto() } }
            launch {
                romLabel = withContext(Dispatchers.Default) { hz.detectRom().label }
                renderLive()
            }
            launch {
                games = library.scan(GameSort.RECENT).take(MAX_GAMES)
                rebuildTargets()
            }
            launch {
                // temperature and thermal state while the boost is off (while it is on, the engine's own watchdog updates them)
                while (isActive) {
                    if (!lastBoost.active) withContext(Dispatchers.Default) { booster.refreshInfo() }
                    delay(REFRESH_MS)
                }
            }
        }
        if (!introPlayed) {
            introPlayed = true
            root.post {
                AnimationController.staggerIn((0 until root.childCount).map { root.getChildAt(it) }, theme)
            }
        }
    }

    /** Stops the read-outs and the frame monitor (a running boost keeps running; it lives in its own engine). */
    fun detach() {
        job?.cancel()
        job = null
        scopeRef = null
        smoother.stopMonitor(MONITOR_OWNER)
        shimmer.stop()
        hzBadge.release()
        badgeHz = -1
        badgeMax = -1
        if (iconBusy) {
            iconBusy = false
            icon.setImageDrawable(VIcon.drawable(ctx, R.drawable.ic_rom_lab))
        }
    }

    // =========================================================================================
    // Actions
    // =========================================================================================

    private fun busyText(): String? = lastBoost.busy ?: lastHz.busy ?: lastSmooth.busy

    private fun deny(msg: String) {
        AnimationController.shake(root, theme)
        toast(msg, false)
    }

    private fun selected(): Entry? = entries.firstOrNull { it.pkg == selectedPkg }

    /** Real `cmd package compile -m speed -f <pkg>` on the picked app. Takes minutes; progress shows in the header. */
    private fun onCompile() {
        busyText()?.let { deny("Busy: $it"); return }
        val t = selected() ?: run { deny("Pick an app or game first"); return }
        showText("Compiling ${t.label}. Keep this screen open or leave it; the compile continues.", theme.textSecondary)
        booster.compileAsync(listOf(t.pkg)) { steps -> showResult(steps, "AOT speed compile") }
    }

    /** One tap: boost on (benchmark apps and, if picked, a game), then the frame smoother. Tap again to restore. */
    private fun onPrep() {
        busyText()?.let { deny("Busy: $it"); return }
        if (lastBoost.active) {
            booster.releaseAsync("Lab card") { s1 ->
                smoother.releaseAsync { s2 -> showResult(s1 + s2, "Restore") }
            }
            return
        }
        val opts = BoostOptions(targets = prepTargets())
        showText("Preparing the phone. Thermal, clocks, storage, RAM and panel steps follow.", theme.textSecondary)
        booster.engageAsync(opts) { rep ->
            if (booster.state.value.active) {
                smoother.engageAsync { s ->
                    showResult(rep.steps + s, "AnTuTu prep")
                    AnimationController.Shockwave.play(root, theme.accent2, 2, theme)
                }
            } else {
                // not engaged (no shell, too hot ...): nothing to smooth, show why
                showResult(rep.steps, "AnTuTu prep")
                AnimationController.shake(root, theme)
            }
        }
    }

    private fun prepTargets(): List<String> {
        val sel = selected() ?: return emptyList() // empty = every installed benchmark app
        val known = AntutuBenchmarkBooster.KNOWN.map { it.pkg }
        return if (sel.pkg in known) listOf(sel.pkg) else (booster.installedTargets().map { it.pkg } + sel.pkg).distinct()
    }

    private fun onLock() {
        lastHz.busy?.let { deny("Busy: $it"); return }
        if (lastBoost.active) {
            deny("The benchmark boost holds the panel lock. Stop it first.")
            return
        }
        if (lastHz.engaged) {
            hz.releaseAsync("Lab card") { toast("Refresh rate lock released", false) }
        } else {
            hz.engageAsync(null) { rep ->
                toast(
                    if (rep.reachedMax) "Panel locked at ${rep.shownHz} Hz (${rep.rom.label})"
                    else "Panel shows ${rep.shownHz} of ${rep.panelMaxHz} Hz; ${rep.failures} layer(s) refused",
                    false
                )
            }
        }
    }

    private fun onOpen() {
        val t = selected() ?: run { deny("Pick an app or game first"); return }
        val scope = scopeRef ?: run { deny("Open this screen again, then retry"); return }
        scope.launch {
            val r = booster.launchBenchmark(t.pkg)
            if (!r.ok) {
                AnimationController.shake(root, theme)
                showText(r.detail, theme.hot)
            }
        }
    }

    // =========================================================================================
    // Rendering
    // =========================================================================================

    private fun renderLive() {
        val h = lastHz
        val shown = if (h.shownHz > 0) h.shownHz else hz.currentHz()
        val max = if (h.panelMaxHz > 0) h.panelMaxHz else (hz.caps()?.hzInt ?: 0)
        if (shown != badgeHz || max != badgeMax) { // the rolling badge only needs a call when a number changed
            badgeHz = shown
            badgeMax = max
            hzBadge.set(shown, max, theme)
        }

        val st = lastStats
        if (!st.running || st.frames < 30) {
            lowValue.text = "--"
            lowValue.setTextColor(theme.textSecondary)
        } else {
            lowValue.text = String.format(Locale.US, "%.0f", st.low1Fps)
            lowValue.setTextColor(
                when {
                    st.stabilityPct >= 95f -> theme.good
                    st.stabilityPct >= 85f -> theme.warn
                    else -> theme.hot
                }
            )
        }

        val b = lastBoost
        if (b.tempC > 0f) {
            tempValue.text = String.format(Locale.US, "%.1f\u00B0C", b.tempC)
            tempValue.setTextColor(
                when {
                    b.tempC >= b.limitC - 2f -> theme.hot
                    b.tempC >= b.limitC - 7f -> theme.warn
                    else -> theme.good
                }
            )
        } else {
            tempValue.text = "--"
            tempValue.setTextColor(theme.textSecondary)
        }

        liveLine.text = buildString {
            append("Thermal ").append(b.thermalStatus.ifBlank { "n/a" })
            b.report?.takeIf { b.active && it.ramGainedMb > 0 }?.let { append("  |  +${it.ramGainedMb} MB RAM") }
            if (b.active) append("  |  boost on")
            if (lastSmooth.engaged) append("  |  frame smoother on")
            if (h.engaged) append("  |  panel locked")
            if (!HyperApp.instance.bridge.hasShell()) append("  |  Shizuku or root needed for most steps")
        }

        val caps = hz.caps()
        sub.text = busyText() ?: buildString {
            append(romLabel)
            if (caps != null) append("  |  ${caps.width}x${caps.height}, up to ${caps.hzInt} Hz")
        }
    }

    private fun renderAuto() {
        val g = lastGuard
        val failed = g.lastRestore.count { !it.ok }
        val restoreIn = g.restoreInSec
        val boostIn = g.boostEndsInSec
        autoLine.text = when {
            restoreIn != null -> "Game closed: panel lock and frame smoother are restored in ${restoreIn}s"
            boostIn != null -> "Benchmark app closed: the boost ends in ${boostIn}s"
            g.holding -> "In game: " +
                listOfNotNull(if (g.panelOwned) "panel locked" else null, if (g.smootherOwned) "frame smoother on" else null)
                    .joinToString(", ") + ". Restored by itself when the game closes."
            g.lastRestore.isNotEmpty() ->
                "Last automatic restore: ${g.lastRestore.size} step(s), " + if (failed == 0) "all done" else "$failed failed (see Diagnostics)"
            else -> "Idle. What this app changes is put back by itself when the game or benchmark closes."
        }
        autoLine.setTextColor(if (failed > 0 && !g.holding && restoreIn == null) theme.hot else theme.textSecondary)
    }

    private fun renderButtons() {
        val busy = busyText()
        val b = lastBoost

        if (busy != null) shimmer.start() else shimmer.stop()
        if ((busy != null) != iconBusy) {
            iconBusy = busy != null
            icon.setImageDrawable(VIcon.drawable(ctx, if (iconBusy) R.drawable.avd_rom_lab_bubble else R.drawable.ic_rom_lab))
            if (iconBusy) VIcon.start(icon.drawable)
        }

        val dim = if (busy != null) 0.6f else 1f
        compileBtn.alpha = dim
        prepBtn.alpha = dim
        lockBtn.alpha = if (busy != null || b.active) 0.6f else 1f
        openBtn.alpha = if (selected() == null) 0.5f else 1f

        if (b.active != prepWasActive) {
            prepWasActive = b.active
            prepBtn.text = if (b.active) "Stop and restore" else "AnTuTu Prep"
            VIcon.setOnText(prepBtn, if (b.active) R.drawable.ic_restore else R.drawable.ic_antutu_benchmark, 16, null, true, 6)
        } else if (prepBtn.text.isNullOrEmpty()) {
            prepBtn.text = "AnTuTu Prep"
        }

        val maxHz = lastHz.panelMaxHz.takeIf { it > 0 } ?: (hz.caps()?.hzInt ?: 0)
        lockBtn.text = when {
            lastHz.engaged -> "Release panel"
            maxHz > 0 -> "Lock $maxHz Hz"
            else -> "Lock panel"
        }
        openBtn.text = "Open " + (selected()?.label ?: "app")
    }

    private fun rebuildTargets() {
        val list = ArrayList<Entry>()
        booster.installedTargets().forEach { list += Entry(it.pkg, it.label) }
        games.forEach { g -> if (list.none { it.pkg == g.pkg }) list += Entry(g.pkg, g.label) }
        entries = list
        if (selectedPkg == null || list.none { it.pkg == selectedPkg }) selectedPkg = list.firstOrNull()?.pkg

        targetHolder.removeAllViews()
        if (list.isEmpty()) {
            targetHolder.addView(
                Ui.label(
                    ctx,
                    "No benchmark app or game found. Install AnTuTu, 3DMark or Geekbench, or add a game in the Games tab.",
                    11f, theme.textSecondary
                ).apply { setLineSpacing(0f, 1.15f) },
                Ui.lp(Ui.MATCH, Ui.WRAP)
            )
        } else {
            val idx = list.indexOfFirst { it.pkg == selectedPkg }.coerceAtLeast(0)
            targetHolder.addView(
                ChipGroup(ctx, theme, list.map { it.label }, idx, 3) { i ->
                    selectedPkg = list[i].pkg
                    renderButtons()
                },
                Ui.lp(Ui.MATCH, Ui.WRAP)
            )
        }
        renderButtons()
    }

    /** Shows the real result of an action: one headline, then every step (failures in the error colour). */
    private fun showResult(steps: List<StepResult>, title: String) {
        val (ok, text) = GameActions.summary(steps)
        val failed = steps.count { !it.ok }
        val head = if (ok) "$title: done, ${steps.size} step(s) ok" else "$title: $failed of ${steps.size} step(s) failed"
        showText(head + "\n" + text, if (ok) theme.good else theme.hot)
        toast(head, false)
    }

    private fun showText(text: String, color: Int) {
        resultExpanded = false
        resultView.maxLines = RESULT_LINES
        resultView.setTextColor(color)
        resultView.text = text
        resultView.visibility = View.VISIBLE
    }

    // =========================================================================================
    // View helpers
    // =========================================================================================

    private fun dp(v: Int): Int = Ui.dp(ctx, v)

    private fun cell(title: String, value: TextView): LinearLayout {
        val c = Ui.vbox(ctx)
        c.gravity = Gravity.CENTER_HORIZONTAL
        c.addView(Ui.label(ctx, title, 9f, theme.textSecondary, true).apply { letterSpacing = 0.1f })
        c.addView(value, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, dp(2), 0, 0))
        return c
    }

    private fun action(label: String, iconRes: Int, filled: Boolean, onClick: () -> Unit): TextView {
        val b = Ui.button(ctx, theme, label, filled, onClick)
        b.maxLines = 2
        b.setPadding(dp(8), dp(10), dp(8), dp(10))
        VIcon.setOnText(b, iconRes, 16, null, true, 6)
        AnimationController.attachPressSpring(b, 0.95f, theme)
        return b
    }

    private companion object {
        const val MONITOR_OWNER = "romlab"
        const val MAX_GAMES = 6
        const val REFRESH_MS = 3_000L
        const val RESULT_LINES = 7
    }
}
