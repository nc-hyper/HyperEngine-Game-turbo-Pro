package com.hyperengine.gameturbo.ui

import android.annotation.SuppressLint
import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Point
import android.graphics.Rect
import android.graphics.Typeface
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.hyperengine.gameturbo.R
import com.hyperengine.gameturbo.core.SystemBridgeExecutor
import com.hyperengine.gameturbo.data.MicroConfig
import kotlinx.coroutines.launch
import java.io.File
import java.math.BigDecimal
import java.math.MathContext
import java.net.URLEncoder
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

// =============================================================================================
// Window frame: title bar (drag), close, resize grip
// =============================================================================================

/** EditText that tells its window when the Back key closes the keyboard. */
class ImeEditText(context: Context) : EditText(context) {
    var onBack: () -> Unit = {}
    override fun onKeyPreIme(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) onBack()
        return super.onKeyPreIme(keyCode, event)
    }
}

/**
 * A draggable, resizable floating window. It starts non-focusable so the game keeps running; a
 * window that has a text field calls [setFocusable] when the field is touched (the keyboard needs
 * focus) and switches it off again when the keyboard closes.
 */
class MiniWindow(
    private val ctx: Context,
    private val wm: WindowManager,
    val id: String,
    titleText: String,
    private val theme: HudTheme
) {
    var onAttached: (() -> Unit)? = null
    var onClosed: ((String) -> Unit)? = null
    var onBounds: ((Rect) -> Unit)? = null
    var onDestroy: (() -> Unit)? = null

    private val frame = FrameLayout(ctx)
    private val doneBtn = TextView(ctx)
    private lateinit var params: WindowManager.LayoutParams
    var attached = false
        private set
    private var focusable = false

    private val minW = Ui.dp(ctx, 180)
    private val minH = Ui.dp(ctx, 140)

    init {
        val radius = Ui.dpf(ctx, 14f)
        frame.background = Ui.rounded(HudThemes.withAlpha(theme.panelBottom, 0xF2), radius, theme.stroke, Ui.dp(ctx, 1))
        frame.clipToOutline = true
        frame.outlineProvider = ViewOutlineProvider.BACKGROUND

        val column = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val bar = Ui.hbox(ctx).apply {
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(HudThemes.blend(theme.panelTop, 0xFFFFFFFF.toInt(), 0.1f))
            setPadding(Ui.dp(ctx, 10), 0, 0, 0)
        }
        val title = Ui.label(ctx, titleText, 12f, theme.textPrimary, true)
        bar.addView(title, Ui.lp(0, Ui.WRAP, 1f))
        doneBtn.apply {
            text = "Done"
            textSize = 12f
            setTextColor(theme.accent)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(Ui.dp(ctx, 10), 0, Ui.dp(ctx, 10), 0)
            visibility = View.GONE
            setOnClickListener { releaseFocus() }
        }
        bar.addView(doneBtn, Ui.lp(Ui.WRAP, Ui.MATCH))
        val close = TextView(ctx).apply {
            text = ""
            gravity = Gravity.CENTER
            VIcon.setOnText(this, R.drawable.ic_close, 14, theme.hot)
            setOnClickListener { close() }
        }
        VIcon.pressSpring(close)
        bar.addView(close, Ui.lp(Ui.dp(ctx, 40), Ui.MATCH))
        column.addView(bar, Ui.lp(Ui.MATCH, Ui.dp(ctx, 34)))
        column.tag = "column"
        frame.addView(column, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))

        // drag by the title bar
        var dx = 0f
        var dy = 0f
        var sx = 0
        var sy = 0
        bar.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = params.x; sy = params.y; true }
                MotionEvent.ACTION_MOVE -> {
                    val scr = OverlayKit.realSize(wm)
                    params.x = (sx + e.rawX - dx).toInt().coerceIn(0, max(0, scr.x - params.width))
                    params.y = (sy + e.rawY - dy).toInt().coerceIn(0, max(0, scr.y - params.height))
                    push()
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { reportBounds(); true }
                else -> false
            }
        }

        // resize grip in the bottom-right corner
        val grip = object : View(ctx) {
            private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = theme.textSecondary
                strokeWidth = Ui.dpf(ctx, 1.5f)
            }
            override fun onDraw(c: Canvas) {
                val w = width.toFloat()
                val h = height.toFloat()
                c.drawLine(w * 0.35f, h - 4f, w - 4f, h * 0.35f, p)
                c.drawLine(w * 0.65f, h - 4f, w - 4f, h * 0.65f, p)
            }
        }
        var gx = 0f
        var gy = 0f
        var sw = 0
        var sh = 0
        grip.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { gx = e.rawX; gy = e.rawY; sw = params.width; sh = params.height; true }
                MotionEvent.ACTION_MOVE -> {
                    val scr = OverlayKit.realSize(wm)
                    params.width = (sw + e.rawX - gx).toInt().coerceIn(minW, max(minW, scr.x - params.x))
                    params.height = (sh + e.rawY - gy).toInt().coerceIn(minH, max(minH, scr.y - params.y))
                    push()
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { reportBounds(); true }
                else -> false
            }
        }
        frame.addView(grip, FrameLayout.LayoutParams(Ui.dp(ctx, 28), Ui.dp(ctx, 28), Gravity.BOTTOM or Gravity.END))
    }

    fun show(content: View, bounds: Rect) {
        val column = frame.getChildAt(0) as LinearLayout
        column.addView(content, Ui.lp(Ui.MATCH, 0, 1f))
        val scr = OverlayKit.realSize(wm)
        val w = bounds.width().coerceIn(minW, scr.x)
        val h = bounds.height().coerceIn(minH, scr.y)
        params = OverlayKit.params(w, h, "HyperEngineMini_$id", touchable = true)
        params.x = bounds.left.coerceIn(0, max(0, scr.x - w))
        params.y = bounds.top.coerceIn(0, max(0, scr.y - h))
        try {
            wm.addView(frame, params)
            attached = true
            onAttached?.invoke()
        } catch (_: Throwable) {
            attached = false
        }
    }

    fun close() {
        if (!attached) return
        hideKeyboard()
        runCatching { onDestroy?.invoke() }
        runCatching { wm.removeViewImmediate(frame) }
        attached = false
        onClosed?.invoke(id)
    }

    fun relayout() {
        if (!attached) return
        val scr = OverlayKit.realSize(wm)
        params.width = params.width.coerceAtMost(scr.x)
        params.height = params.height.coerceAtMost(scr.y)
        params.x = params.x.coerceIn(0, max(0, scr.x - params.width))
        params.y = params.y.coerceIn(0, max(0, scr.y - params.height))
        push()
    }

    /** Called by a text field when it is touched: the keyboard needs a focusable window. */
    fun requestFocusFor(field: EditText) {
        if (!attached) return
        if (!focusable) {
            focusable = true
            OverlayKit.setFocusable(params, true)
            push()
            doneBtn.visibility = View.VISIBLE
        }
        field.post {
            field.requestFocus()
            val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(field, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    /** Hides the keyboard and gives focus back to the game. */
    fun releaseFocus() {
        hideKeyboard()
        if (focusable && attached) {
            focusable = false
            OverlayKit.setFocusable(params, false)
            push()
        }
        doneBtn.visibility = View.GONE
    }

    private fun hideKeyboard() {
        val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        runCatching { imm.hideSoftInputFromWindow(frame.windowToken, 0) }
        frame.clearFocus()
    }

    private fun push() {
        if (attached) runCatching { wm.updateViewLayout(frame, params) }
    }

    private fun reportBounds() {
        onBounds?.invoke(Rect(params.x, params.y, params.x + params.width, params.y + params.height))
    }
}

// =============================================================================================
// Calculator
// =============================================================================================

object CalcEngine {

    fun eval(src: String): Double {
        val s = src.replace(" ", "")
        if (s.isEmpty()) throw IllegalArgumentException("empty")
        val open = s.count { it == '(' } - s.count { it == ')' }
        val full = s + ")".repeat(max(0, open))
        val p = Parser(full)
        val v = p.expr()
        if (p.pos != full.length) throw IllegalArgumentException("unexpected input")
        return v
    }

    fun format(d: Double): String {
        if (d.isNaN() || d.isInfinite()) return "Error"
        val l = d.toLong()
        if (d == l.toDouble() && abs(d) < 1e15) return l.toString()
        return BigDecimal(d).round(MathContext(12)).stripTrailingZeros().toPlainString()
    }

    private class Parser(val s: String) {
        var pos = 0

        fun expr(): Double {
            var v = term()
            while (pos < s.length && (s[pos] == '+' || s[pos] == '-')) {
                val op = s[pos++]
                val r = term()
                v = if (op == '+') v + r else v - r
            }
            return v
        }

        private fun term(): Double {
            var v = factor()
            while (pos < s.length && (s[pos] == '*' || s[pos] == '/')) {
                val op = s[pos++]
                val r = factor()
                if (op == '*') {
                    v *= r
                } else {
                    if (r == 0.0) throw ArithmeticException("divide by zero")
                    v /= r
                }
            }
            return v
        }

        private fun factor(): Double {
            if (pos >= s.length) throw IllegalArgumentException("unexpected end")
            if (s[pos] == '-') { pos++; return -factor() }
            if (s[pos] == '+') { pos++; return factor() }
            var v = primary()
            while (pos < s.length && s[pos] == '%') { pos++; v /= 100.0 }
            return v
        }

        private fun primary(): Double {
            if (pos >= s.length) throw IllegalArgumentException("unexpected end")
            if (s[pos] == '(') {
                pos++
                val v = expr()
                if (pos >= s.length || s[pos] != ')') throw IllegalArgumentException("missing )")
                pos++
                return v
            }
            val st = pos
            while (pos < s.length && (s[pos].isDigit() || s[pos] == '.')) pos++
            if (st == pos) throw IllegalArgumentException("number expected")
            return s.substring(st, pos).toDouble()
        }
    }
}

private fun buildCalculator(ctx: Context, theme: HudTheme): View {
    val root = Ui.vbox(ctx)
    root.setPadding(Ui.dp(ctx, 8), Ui.dp(ctx, 6), Ui.dp(ctx, 8), Ui.dp(ctx, 8))
    val display = Ui.label(ctx, "", 22f, theme.textPrimary, true).apply { gravity = Gravity.END; maxLines = 2 }
    val preview = Ui.label(ctx, " ", 13f, theme.textSecondary).apply { gravity = Gravity.END }
    root.addView(display, Ui.lp(Ui.MATCH, Ui.WRAP))
    root.addView(preview, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, 0, 0, Ui.dp(ctx, 6)))
    var expr = ""

    fun refresh() {
        display.text = if (expr.isEmpty()) "0" else expr
        preview.text = try {
            if (expr.isEmpty() || expr.last() in "+-*/(") " " else "= " + CalcEngine.format(CalcEngine.eval(expr))
        } catch (_: Throwable) {
            " "
        }
    }

    fun press(k: String) {
        when (k) {
            "C" -> expr = ""
            "BKSP" -> expr = expr.dropLast(1)
            "=" -> {
                try {
                    expr = CalcEngine.format(CalcEngine.eval(expr))
                    if (expr == "Error") expr = ""
                } catch (_: Throwable) {
                    preview.text = "Error"
                    return
                }
            }
            else -> expr += k
        }
        refresh()
    }

    val rows = listOf(
        listOf("C", "BKSP", "%", "/"),
        listOf("7", "8", "9", "*"),
        listOf("4", "5", "6", "-"),
        listOf("1", "2", "3", "+"),
        listOf("(", "0", ")", "."),
        listOf("=")
    )
    // Key faces that are vector icons instead of text glyphs. The key string stays the logic token.
    val keyIcons = mapOf(
        "BKSP" to R.drawable.ic_backspace,
        "/" to R.drawable.ic_op_divide,
        "*" to R.drawable.ic_op_multiply,
        "-" to R.drawable.ic_minus,
        "+" to R.drawable.ic_plus
    )
    for (r in rows) {
        val row = Ui.hbox(ctx)
        for (k in r) {
            val op = k in listOf("/", "*", "-", "+", "=", "%")
            val faceColor = if (k == "=") HudThemes.onAccent(theme.accent) else if (op) theme.accent else theme.textPrimary
            val key = TextView(ctx).apply {
                text = if (keyIcons.containsKey(k)) "" else k
                textSize = 16f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(faceColor)
                keyIcons[k]?.let { VIcon.setOnText(this, it, 18, faceColor) }
                background = Ui.rounded(if (k == "=") theme.accent else theme.tile, Ui.tileRadius(ctx, theme), theme.stroke, Ui.dp(ctx, 1))
                setOnClickListener { press(k) }
            }
            VIcon.pressSpring(key, 0.9f)
            row.addView(key, Ui.lp(0, Ui.MATCH, 1f, Ui.dp(ctx, 2), Ui.dp(ctx, 2), Ui.dp(ctx, 2), Ui.dp(ctx, 2)))
        }
        root.addView(row, Ui.lp(Ui.MATCH, 0, 1f))
    }
    refresh()
    return root
}

// =============================================================================================
// Notes
// =============================================================================================

private fun notesFile(ctx: Context, game: String): File =
    File(ctx.filesDir, "notes_" + game.replace(Regex("[^A-Za-z0-9_.]"), "_") + ".txt")

private fun buildNotes(ctx: Context, theme: HudTheme, win: MiniWindow, game: String): View {
    val root = Ui.vbox(ctx)
    root.setPadding(Ui.dp(ctx, 8), Ui.dp(ctx, 6), Ui.dp(ctx, 8), Ui.dp(ctx, 8))
    val file = notesFile(ctx, game)
    val edit = ImeEditText(ctx).apply {
        hint = "Notes for this game"
        setHintTextColor(theme.textSecondary)
        setTextColor(theme.textPrimary)
        textSize = 14f
        gravity = Gravity.TOP or Gravity.START
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        background = Ui.rounded(theme.tile, Ui.tileRadius(ctx, theme), theme.stroke, Ui.dp(ctx, 1))
        setPadding(Ui.dp(ctx, 8), Ui.dp(ctx, 8), Ui.dp(ctx, 8), Ui.dp(ctx, 8))
        setText(runCatching { if (file.exists()) file.readText() else "" }.getOrDefault(""))
        setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) win.requestFocusFor(this)
            false
        }
        onBack = { win.releaseFocus() }
    }
    val saver = Runnable {
        val text = edit.text.toString()
        thread(name = "hyper-notes-save", isDaemon = true) { runCatching { file.writeText(text) } }
    }
    edit.addTextChangedListener(object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun afterTextChanged(s: Editable?) {
            edit.removeCallbacks(saver)
            edit.postDelayed(saver, 600L)
        }
    })
    root.addView(edit, Ui.lp(Ui.MATCH, 0, 1f))
    root.addView(Ui.button(ctx, theme, "Clear notes") { edit.setText("") },
        Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 6), 0, 0))
    // save on close, even when the debounce has not fired yet
    val prev = win.onDestroy
    win.onDestroy = {
        prev?.invoke()
        edit.removeCallbacks(saver)
        val text = edit.text.toString()
        runCatching { file.writeText(text) }
    }
    return root
}

// =============================================================================================
// Browser
// =============================================================================================

object BrowserPresets {
    private const val GENSHIN_MAP = "https://act.hoyolab.com/ys/app/interactive-map/index.html"

    private fun search(q: String) = "https://www.google.com/search?q=" + URLEncoder.encode(q, "UTF-8")

    /** Quick links for [game]; the first one is the default home page. */
    fun linksFor(pkg: String, label: String): List<Pair<String, String>> {
        val name = if (label.isBlank() || label == pkg) pkg.substringAfterLast('.') else label
        val out = ArrayList<Pair<String, String>>()
        if (pkg.equals("com.miHoYo.GenshinImpact", true) || pkg.equals("com.mihoyo.yuanshen", true)) {
            out += "Map" to GENSHIN_MAP
        } else {
            out += "Map" to search("$name interactive map")
        }
        out += "Wiki" to search("$name wiki")
        out += "Tier list" to search("$name tier list")
        out += "Guides" to search("$name guide")
        return out
    }

    fun normalize(input: String): String {
        val t = input.trim()
        if (t.isEmpty()) return t
        if (t.startsWith("http://") || t.startsWith("https://")) return t
        if (!t.contains(' ') && t.contains('.')) return "https://$t"
        return search(t)
    }
}

@SuppressLint("SetJavaScriptEnabled")
private fun buildBrowser(
    ctx: Context,
    theme: HudTheme,
    win: MiniWindow,
    game: String,
    label: String,
    home: String,
    saveHome: (String) -> Unit
): View {
    val root = Ui.vbox(ctx)
    val links = BrowserPresets.linksFor(game, label)
    val web: WebView = try {
        WebView(ctx)
    } catch (t: Throwable) {
        return Ui.label(ctx, "No WebView is available on this phone.", 13f, theme.hot).apply {
            setPadding(Ui.dp(ctx, 12), Ui.dp(ctx, 12), Ui.dp(ctx, 12), Ui.dp(ctx, 12))
        }
    }
    web.settings.javaScriptEnabled = true
    web.settings.domStorageEnabled = true
    web.settings.setSupportZoom(true)
    web.settings.builtInZoomControls = true
    web.settings.displayZoomControls = false
    web.settings.useWideViewPort = true
    web.settings.loadWithOverviewMode = true

    val url = ImeEditText(ctx).apply {
        setSingleLine(true)
        textSize = 12f
        setTextColor(theme.textPrimary)
        setHintTextColor(theme.textSecondary)
        hint = "Search or type an address"
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        imeOptions = EditorInfo.IME_ACTION_GO
        background = Ui.rounded(theme.tile, Ui.dpf(ctx, 8f), theme.stroke, Ui.dp(ctx, 1))
        setPadding(Ui.dp(ctx, 8), Ui.dp(ctx, 6), Ui.dp(ctx, 8), Ui.dp(ctx, 6))
        setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) win.requestFocusFor(this)
            false
        }
        onBack = { win.releaseFocus() }
    }
    fun go(raw: String) {
        val target = BrowserPresets.normalize(raw)
        if (target.isNotEmpty()) web.loadUrl(target)
    }
    url.setOnEditorActionListener { _, action, _ ->
        if (action == EditorInfo.IME_ACTION_GO) {
            go(url.text.toString())
            win.releaseFocus()
            true
        } else {
            false
        }
    }

    web.webViewClient = object : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val scheme = request.url.scheme
            return !(scheme == "http" || scheme == "https")
        }

        override fun onPageFinished(view: WebView, u: String?) {
            if (!url.hasFocus() && u != null) url.setText(u)
        }
    }
    web.webChromeClient = WebChromeClient()

    fun smallBtn(text: String, onClick: () -> Unit): TextView = TextView(ctx).apply {
        this.text = text
        textSize = 12f
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(theme.textPrimary)
        setPadding(Ui.dp(ctx, 8), Ui.dp(ctx, 6), Ui.dp(ctx, 8), Ui.dp(ctx, 6))
        background = Ui.rounded(theme.tile, Ui.dpf(ctx, 8f), theme.stroke, Ui.dp(ctx, 1))
        setOnClickListener { onClick() }
    }

    // Icon-only variant of smallBtn: a fixed-size vector face instead of a text glyph.
    fun smallIconBtn(res: Int, onClick: () -> Unit): TextView = smallBtn("", onClick).also {
        it.minWidth = Ui.dp(ctx, 34)
        it.minHeight = Ui.dp(ctx, 30)
        VIcon.setOnText(it, res, 14, theme.textPrimary)
        VIcon.pressSpring(it)
    }

    val bar = Ui.hbox(ctx)
    bar.gravity = Gravity.CENTER_VERTICAL
    bar.setPadding(Ui.dp(ctx, 6), Ui.dp(ctx, 4), Ui.dp(ctx, 6), Ui.dp(ctx, 4))
    val m = Ui.dp(ctx, 2)
    bar.addView(smallIconBtn(R.drawable.ic_chevron_left) { if (web.canGoBack()) web.goBack() }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, m, 0, m, 0))
    bar.addView(smallIconBtn(R.drawable.ic_chevron_right) { if (web.canGoForward()) web.goForward() }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, m, 0, m, 0))
    bar.addView(smallIconBtn(R.drawable.ic_refresh) { web.reload() }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, m, 0, m, 0))
    bar.addView(url, Ui.lp(0, Ui.WRAP, 1f, m, 0, m, 0))
    bar.addView(smallBtn("Go") { go(url.text.toString()); win.releaseFocus() }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, m, 0, m, 0))
    root.addView(bar, Ui.lp(Ui.MATCH, Ui.WRAP))

    val chips = Ui.hbox(ctx)
    chips.setPadding(Ui.dp(ctx, 6), 0, Ui.dp(ctx, 6), Ui.dp(ctx, 4))
    for ((name, link) in links) chips.addView(smallBtn(name) { web.loadUrl(link) }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, m, 0, m, 0))
    chips.addView(smallBtn("Save page as home") {
        val u = web.url
        if (u != null && u.startsWith("http")) {
            saveHome(u)
            Toast.makeText(ctx, "Home page saved for this game", Toast.LENGTH_SHORT).show()
        }
    }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, m, 0, m, 0))
    val scroller = HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = false; addView(chips) }
    root.addView(scroller, Ui.lp(Ui.MATCH, Ui.WRAP))

    root.addView(web, Ui.lp(Ui.MATCH, 0, 1f))
    val prev = win.onDestroy
    win.onDestroy = {
        prev?.invoke()
        runCatching {
            (web.parent as? ViewGroup)?.removeView(web)
            web.stopLoading()
            web.destroy()
        }
    }
    go(home.ifBlank { links.first().second })
    return root
}

// =============================================================================================
// Host: opens, remembers and closes the mini windows
// =============================================================================================

class MiniWindowHost(context: Context, private val wm: WindowManager, private val themeProvider: () -> HudTheme) {

    private val ctx: Context = context.applicationContext
    var onAttached: (() -> Unit)? = null

    /** A window opened or closed (the slide bar uses this to relight its buttons). */
    var onChanged: (() -> Unit)? = null

    private val open = LinkedHashMap<String, MiniWindow>()
    private val bounds = HashMap<String, Rect>()

    fun isOpen(id: String): Boolean = open[id]?.attached == true
    val anyOpen: Boolean get() = open.values.any { it.attached }

    fun closeAll() {
        open.values.toList().forEach { it.close() }
        open.clear()
    }

    fun relayout() {
        open.values.forEach { it.relayout() }
    }

    fun toggleBrowser(game: String, label: String, micro: MicroConfig, saveHome: (String) -> Unit): Boolean =
        toggle("browser", "Browser", 0.55f, 0.7f, 520, 400, 0) { win, theme ->
            buildBrowser(ctx, theme, win, game, label, micro.browserHome, saveHome)
        }

    fun toggleCalculator(): Boolean =
        toggle("calculator", "Calculator", 0.3f, 0.6f, 250, 360, 1) { _, theme -> buildCalculator(ctx, theme) }

    fun toggleNotes(game: String): Boolean =
        toggle("notes", "Quick notes", 0.35f, 0.4f, 300, 240, 2) { win, theme -> buildNotes(ctx, theme, win, game) }

    /** Returns true when the window is open afterwards. */
    private fun toggle(
        id: String,
        title: String,
        fracW: Float,
        fracH: Float,
        maxWdp: Int,
        maxHdp: Int,
        slot: Int,
        build: (MiniWindow, HudTheme) -> View
    ): Boolean {
        open[id]?.let {
            if (it.attached) {
                it.close()
                return false
            }
        }
        val theme = themeProvider()
        val win = MiniWindow(ctx, wm, id, title, theme)
        win.onAttached = { onAttached?.invoke() }
        win.onClosed = { open.remove(it); onChanged?.invoke() }
        win.onBounds = { bounds[id] = it }
        val scr: Point = OverlayKit.realSize(wm)
        val w = min((scr.x * fracW).toInt(), Ui.dp(ctx, maxWdp))
        val h = min((scr.y * fracH).toInt(), Ui.dp(ctx, maxHdp))
        val r = bounds[id] ?: Rect(
            Ui.dp(ctx, 40 + slot * 28), Ui.dp(ctx, 60 + slot * 28),
            Ui.dp(ctx, 40 + slot * 28) + w, Ui.dp(ctx, 60 + slot * 28) + h
        )
        val content = build(win, theme)
        open[id] = win
        win.show(content, r)
        if (!win.attached) {
            open.remove(id)
            return false
        }
        onChanged?.invoke()
        return true
    }
}

// =============================================================================================
// Chat apps in a floating or split window
// =============================================================================================

object ChatLauncher {

    val APPS = listOf(
        "WhatsApp" to "com.whatsapp",
        "WhatsApp Business" to "com.whatsapp.w4b",
        "Discord" to "com.discord",
        "Telegram" to "org.telegram.messenger",
        "Messenger" to "com.facebook.orca",
        "Signal" to "org.thoughtcrime.securesms"
    )

    private val COMPONENT = Regex("^[A-Za-z0-9_.]+/[A-Za-z0-9_.$]+$")

    fun installed(ctx: Context): List<Pair<String, String>> =
        APPS.filter { ctx.packageManager.getLaunchIntentForPackage(it.second) != null }

    fun freeformAvailable(ctx: Context): Boolean =
        ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT) ||
            Settings.Global.getInt(ctx.contentResolver, "enable_freeform_support", 0) == 1

    /** Asks Android for a floating (freeform) window. Reports honestly what it could do. */
    suspend fun launchFloating(ctx: Context, bridge: SystemBridgeExecutor, pkg: String): String {
        val intent = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return "That app is not installed"
        val comp = intent.component?.flattenToShortString()
        if (comp != null && bridge.hasShell() && COMPONENT.matches(comp)) {
            val r = bridge.shell("am start --windowingMode 5 -n " + comp.replace("$", "\\$"))
            val text = (r.stdout + " " + r.stderr)
            if (r.ok && !text.contains("Error", true) && !text.contains("Exception", true)) {
                return if (freeformAvailable(ctx)) "Opened in a floating window"
                else "Opened. This phone does not advertise freeform windows, so it may fill the screen"
            }
        }
        return try {
            val dm = ctx.resources.displayMetrics
            val w = (dm.widthPixels * 0.5f).toInt()
            val h = (dm.heightPixels * 0.8f).toInt()
            val left = (dm.widthPixels - w) / 2
            val top = (dm.heightPixels - h) / 2
            val opts = ActivityOptions.makeBasic().setLaunchBounds(Rect(left, top, left + w, top + h))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent, opts.toBundle())
            if (freeformAvailable(ctx)) "Opened with a floating-window size"
            else "Opened. This phone has no freeform windows, so it fills the screen"
        } catch (t: Throwable) {
            "Could not open it: " + (t.message ?: t.javaClass.simpleName)
        }
    }

    /** Opens next to the game. Android only does that when the game is already in split-screen. */
    fun launchSplit(ctx: Context, pkg: String): String {
        val intent = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return "That app is not installed"
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT)
            ctx.startActivity(intent)
            "Opened. It sits beside the game only if the game is already in split-screen"
        } catch (t: Throwable) {
            "Could not open it: " + (t.message ?: t.javaClass.simpleName)
        }
    }
}

// =============================================================================================
// Chat apps page (shown in the slide bar flyout)
// =============================================================================================

object ChatPanel {

    /** One block per installed chat app with Floating and Split buttons. [onLaunched] fires after either is pressed. */
    fun build(host: ToolHost, onLaunched: () -> Unit = {}): View {
        val ctx = host.hostContext
        val theme = host.theme
        val col = Ui.vbox(ctx)
        val free = ChatLauncher.freeformAvailable(ctx)
        col.addView(ToolUi.note(host,
            "Opens a chat app over or beside the game. Floating windows need a ROM with freeform windows " +
                "(this phone: " + (if (free) "available" else "not advertised") + "), and the best result comes with " +
                "Shizuku. Otherwise the app opens full screen and the game goes to the background."))
        val result = Ui.label(ctx, "", 11f, theme.textSecondary)
        result.setPadding(0, Ui.dp(ctx, 8), 0, 0)
        val apps = ChatLauncher.installed(ctx)
        if (apps.isEmpty()) {
            col.addView(Ui.label(ctx, "None of WhatsApp, Discord, Telegram, Messenger or Signal is installed.", 12f, theme.warn))
        }
        for ((name, pkg) in apps) {
            col.addView(Ui.section(ctx, theme, name))
            val row = Ui.hbox(ctx)
            row.addView(Ui.button(ctx, theme, "Floating", true) {
                host.scope.launch {
                    result.text = ChatLauncher.launchFloating(ctx, host.deps.bridge, pkg)
                    onLaunched()
                }
            }, Ui.lp(0, Ui.WRAP, 1f, 0, 0, Ui.dp(ctx, 4), 0))
            row.addView(Ui.button(ctx, theme, "Split") {
                result.text = ChatLauncher.launchSplit(ctx, pkg)
                onLaunched()
            }, Ui.lp(0, Ui.WRAP, 1f, Ui.dp(ctx, 4), 0, 0, 0))
            col.addView(row)
        }
        col.addView(result)
        return col
    }
}
