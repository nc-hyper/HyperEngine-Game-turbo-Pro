package com.hyperengine.gameturbo.core

import android.content.Context
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.math.roundToInt

/**
 * Universal render scale: lowers the system display resolution (`wm size` + `wm density`) so EVERY game renders
 * fewer pixels, whether or not it honours Android's GameManager downscale. The panel's hardware scaler stretches the
 * result back to the full screen, so the picture is a little softer and the GPU does less work.
 *
 * Needs Shizuku or root. Density is scaled with the size so the layout of apps and games keeps its proportions.
 *
 * Safety: the display settings in force BEFORE the first change (an explicit override, or none) are written to disk
 * with commit() before anything is touched, and [restore] puts exactly those back. [isActive] stays true until a
 * restore succeeds, so the app can finish the job after a crash or a restart ([HyperBoostEngine.recoverPending]).
 * The scale is always computed from the PHYSICAL size, so repeated calls never compound.
 */
class ResolutionScaler(context: Context, private val bridge: SystemBridgeExecutor) {

    private val prefs = context.applicationContext.getSharedPreferences("hyper_resscale", Context.MODE_PRIVATE)
    private val mutex = Mutex()

    fun isActive(): Boolean = prefs.getBoolean(K_ACTIVE, false)

    /** The scale currently applied (1.0 when none). */
    fun currentScale(): Float = if (isActive()) prefs.getFloat(K_SCALE, 1f) else 1f

    suspend fun apply(scale: Float): StepResult = mutex.withLock {
        if (!bridge.hasShell()) return@withLock StepResult(NAME, false, "needs Shizuku or root")
        val size = bridge.shell("wm size", 6_000L)
        val dens = bridge.shell("wm density", 6_000L)
        if (!size.ok || !dens.ok) return@withLock StepResult(NAME, false, "could not read wm size / density: " + (size.stderr + dens.stderr).take(120))

        val phys = SIZE_PHYS.find(size.stdout)
        val physDpi = DPI_PHYS.find(dens.stdout)?.groupValues?.get(1)?.toIntOrNull()
        if (phys == null || physDpi == null) return@withLock StepResult(NAME, false, "unexpected wm output: " + size.stdout.take(80))
        val pw = phys.groupValues[1].toInt()
        val ph = phys.groupValues[2].toInt()
        val ovSize = SIZE_OVR.find(size.stdout)?.let { it.groupValues[1] + "x" + it.groupValues[2] } ?: ""
        val ovDpi = DPI_OVR.find(dens.stdout)?.groupValues?.get(1) ?: ""

        if (!isActive()) {
            // Original first, to disk, before the first change.
            val saved = prefs.edit().putBoolean(K_ACTIVE, true).putString(K_O_SIZE, ovSize).putString(K_O_DPI, ovDpi)
                .putFloat(K_SCALE, 1f).commit()
            if (!saved) return@withLock StepResult(NAME, false, "could not save the original display settings, nothing changed")
        }

        val s = scale.coerceIn(0.5f, 1f)
        val w = even(pw * s)
        val h = even(ph * s)
        val dpi = (physDpi * s).roundToInt().coerceAtLeast(120)
        val r1 = bridge.shell("wm size ${w}x$h", 8_000L)
        val r2 = bridge.shell("wm density $dpi", 8_000L)
        if (!r1.ok || !r2.ok) {
            val msg = (r1.stderr + " " + r2.stderr).trim().ifBlank { (r1.stdout + r2.stdout).take(120) }
            restoreLocked()
            return@withLock StepResult(NAME, false, "wm refused the change ($msg); original restored")
        }
        prefs.edit().putFloat(K_SCALE, s).commit()
        StepResult(NAME, true, "${w}x$h at $dpi dpi (${String.format(java.util.Locale.US, "%.2f", s)}x of ${pw}x$ph)")
    }

    suspend fun restore(): StepResult = mutex.withLock { restoreLocked() }

    private suspend fun restoreLocked(): StepResult {
        if (!isActive()) return StepResult(NAME, true, "not changed")
        if (!bridge.hasShell()) return StepResult(NAME, false, "needs Shizuku or root to restore; will retry")
        val size = prefs.getString(K_O_SIZE, "").orEmpty()
        val dpi = prefs.getString(K_O_DPI, "").orEmpty()
        val c1 = if (size.matches(SIZE_ARG)) "wm size $size" else "wm size reset"
        val c2 = if (dpi.matches(DPI_ARG)) "wm density $dpi" else "wm density reset"
        val r1 = bridge.shell(c1, 8_000L)
        val r2 = bridge.shell(c2, 8_000L)
        return if (r1.ok && r2.ok) {
            prefs.edit().clear().commit()
            StepResult(NAME, true, "original resolution restored")
        } else {
            StepResult(NAME, false, "restore failed: " + (r1.message + " " + r2.message).take(120) + "; will retry")
        }
    }

    private fun even(v: Float): Int = ((v / 2f).roundToInt() * 2).coerceAtLeast(2)

    private companion object {
        const val NAME = "System resolution"
        const val K_ACTIVE = "active"
        const val K_SCALE = "scale"
        const val K_O_SIZE = "o.size"
        const val K_O_DPI = "o.dpi"
        val SIZE_PHYS = Regex("Physical size:\\s*(\\d+)x(\\d+)")
        val SIZE_OVR = Regex("Override size:\\s*(\\d+)x(\\d+)")
        val DPI_PHYS = Regex("Physical density:\\s*(\\d+)")
        val DPI_OVR = Regex("Override density:\\s*(\\d+)")
        val SIZE_ARG = Regex("\\d{3,5}x\\d{3,5}")
        val DPI_ARG = Regex("\\d{2,4}")
    }
}
