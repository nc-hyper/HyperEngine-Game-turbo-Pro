package com.hyperengine.gameturbo.hub

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import com.hyperengine.gameturbo.ui.AnimationController
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Cover-flow carousel built from a plain ViewGroup (the project has no AndroidX/RecyclerView).
 *
 * Only [SLOTS] card views ever exist; the card for item i always lives in slot (i mod SLOTS), so a
 * window of up to 9 consecutive items never collides. Each frame, [updateTransforms] places the
 * cards with translation, rotationY, scale and alpha, and rebinds a slot only when it is handed a
 * different item. Works with hundreds of games at constant cost.
 *
 * Gestures: drag, fling (snaps to the nearest card), tap a side card to bring it to the centre,
 * tap / long-press the centre card for the owner's callbacks.
 */
class Carousel3DView(ctx: Context) : ViewGroup(ctx) {

    interface Adapter {
        fun count(): Int
        fun createCard(parent: ViewGroup): View
        fun bind(card: View, index: Int)
    }

    /** Implemented by cards that want to know how centred they are (1 = centre, 0 = far away). */
    interface Focusable {
        fun onFocus(amount: Float)

        /** Colour of the elevation glow under the centre card. */
        fun glowColor(): Int = 0xFF00E5FF.toInt()
    }

    var adapter: Adapter? = null
        set(value) {
            field = value
            notifyDataChanged()
        }

    var onCenterChanged: ((Int) -> Unit)? = null
    var onCenterTap: ((Int) -> Unit)? = null
    var onCenterLongPress: ((Int) -> Unit)? = null

    /**
     * Which way side cards turn. Cover-flow cards should turn their faces toward the middle; if they
     * turn away on a device, flip this to +1f.
     */
    var tiltSign: Float = -1f

    private val slots = arrayOfNulls<View>(SLOTS)
    private val slotItem = IntArray(SLOTS) { -1 }
    private val distance = FloatArray(SLOTS) { 99f }
    private var drawOrder = IntArray(SLOTS) { it }

    private var pos = 0f
    private var lastCenter = -1
    private var cardW = 0
    private var cardH = 0

    private var animator: ValueAnimator? = null
    private var velocity: VelocityTracker? = null
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var dragging = false

    init {
        setChildrenDrawingOrderEnabled(true)
        clipChildren = false
        clipToPadding = false
    }

    // ── public API ──

    val centerIndex: Int
        get() {
            val n = adapter?.count() ?: 0
            return if (n == 0) -1 else pos.roundToInt().coerceIn(0, n - 1)
        }

    /** Re-reads the adapter: every slot is rebound, the position is kept (clamped to the new size). */
    fun notifyDataChanged() {
        val n = adapter?.count() ?: 0
        ensureSlots()
        for (i in slotItem.indices) slotItem[i] = -1
        pos = if (n == 0) 0f else pos.coerceIn(0f, (n - 1).toFloat())
        lastCenter = -1
        updateTransforms()
    }

    /** Jumps (or glides) so item [index] is in the centre. */
    fun setIndex(index: Int, animate: Boolean) {
        val n = adapter?.count() ?: 0
        if (n == 0) return
        val target = index.coerceIn(0, n - 1)
        if (animate) animateTo(target) else {
            animator?.cancel()
            setPos(target.toFloat())
        }
    }

    // ── layout ──

    private fun ensureSlots() {
        val a = adapter ?: return
        for (s in 0 until SLOTS) {
            if (slots[s] == null) {
                val card = a.createCard(this)
                card.tag = s
                card.setOnClickListener { onCardClick(s) }
                card.setOnLongClickListener {
                    val idx = slotItem[s]
                    if (idx >= 0 && idx == centerIndex) {
                        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                        onCenterLongPress?.invoke(idx)
                        true
                    } else {
                        false
                    }
                }
                slots[s] = card
                addView(card, LayoutParams(0, 0))
                card.visibility = INVISIBLE
            }
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        var h = MeasureSpec.getSize(heightMeasureSpec)
        if (h <= 0) h = (resources.displayMetrics.density * 360f).toInt()
        val d = resources.displayMetrics.density
        cardW = min((w * 0.64f).toInt(), (300 * d).toInt()).coerceAtLeast((180 * d).toInt())
        cardH = min(h - (12 * d).toInt(), (cardW * 1.5f).toInt()).coerceAtLeast((220 * d).toInt())
        setMeasuredDimension(w, h)
        val cw = MeasureSpec.makeMeasureSpec(cardW, MeasureSpec.EXACTLY)
        val ch = MeasureSpec.makeMeasureSpec(cardH, MeasureSpec.EXACTLY)
        for (i in 0 until childCount) getChildAt(i).measure(cw, ch)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val left = (r - l - cardW) / 2
        val top = (b - t - cardH) / 2
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            c.layout(left, top, left + cardW, top + cardH)
            c.pivotX = cardW / 2f
            c.pivotY = cardH / 2f
            c.cameraDistance = cardW * 7f
        }
        updateTransforms()
    }

    override fun getChildDrawingOrder(childCount: Int, drawingPosition: Int): Int =
        if (drawingPosition < drawOrder.size) drawOrder[drawingPosition] else drawingPosition

    // ── transforms ──

    private fun setPos(p: Float) {
        val n = adapter?.count() ?: 0
        pos = if (n == 0) 0f else p.coerceIn(-0.4f, n - 0.6f)
        updateTransforms()
        val c = centerIndex
        if (c != lastCenter && c >= 0) {
            val first = lastCenter == -1
            lastCenter = c
            if (!first) performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            onCenterChanged?.invoke(c)
        }
    }

    private fun updateTransforms() {
        val a = adapter
        val n = a?.count() ?: 0
        if (a == null || n == 0 || cardW == 0) {
            for (s in slots) s?.visibility = INVISIBLE
            return
        }
        val spacing = cardW * 0.50f
        val lo = floor(pos).toInt() - 3
        for (s in 0 until SLOTS) distance[s] = 99f

        for (i in lo..lo + 7) {
            if (i < 0 || i >= n) continue
            val s = ((i % SLOTS) + SLOTS) % SLOTS
            val card = slots[s] ?: continue
            if (slotItem[s] != i) {
                a.bind(card, i)
                slotItem[s] = i
            }
            val d = i - pos
            val ad = abs(d)
            if (ad > 3f) {
                card.visibility = INVISIBLE
                continue
            }
            distance[s] = ad
            card.visibility = VISIBLE
            val sign = if (d < 0f) -1f else 1f
            val shift = if (ad <= 1f) ad * spacing else spacing + (ad - 1f) * spacing * 0.55f
            card.translationX = sign * shift
            // 3D perspective tilt (deep camera distance), scale, fade and a coloured elevation glow on the centre card
            AnimationController.carouselTransform(
                card, d, tiltSign, (card as? Focusable)?.glowColor() ?: 0xFF00E5FF.toInt()
            )
            (card as? Focusable)?.onFocus((1f - min(1f, ad)).coerceIn(0f, 1f))
        }
        // farthest first, so the centre card is drawn last (on top) and gets touches first
        drawOrder = (0 until SLOTS).sortedByDescending { distance[it] }.toIntArray()
        for (s in 0 until SLOTS) if (distance[s] >= 99f) slots[s]?.visibility = INVISIBLE
        invalidate()
    }

    private fun onCardClick(slot: Int) {
        val idx = slotItem[slot]
        if (idx < 0) return
        if (idx == centerIndex) onCenterTap?.invoke(idx) else animateTo(idx)
    }

    // ── animation ──

    private fun animateTo(target: Int) {
        animator?.cancel()
        val from = pos
        if (abs(from - target) < 0.001f) {
            setPos(target.toFloat())
            return
        }
        val anim = ValueAnimator.ofFloat(from, target.toFloat())
        anim.duration = (180L + 90L * abs(from - target).toLong().coerceAtLeast(1L)).coerceAtMost(520L)
        anim.interpolator = DecelerateInterpolator(1.6f)
        anim.addUpdateListener { setPos(it.animatedValue as Float) }
        anim.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                if (animator === animation) animator = null
            }
        })
        animator = anim
        anim.start()
    }

    // ── touch ──

    private fun itemsPerPx(): Float = 1f / (cardW * 0.5f).coerceAtLeast(1f)

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x
                downY = e.y
                lastX = e.x
                dragging = false
                animator?.cancel()
                velocity?.recycle()
                velocity = VelocityTracker.obtain().also { it.addMovement(e) }
            }
            MotionEvent.ACTION_MOVE -> {
                velocity?.addMovement(e)
                val dx = e.x - downX
                val dy = e.y - downY
                if (!dragging && abs(dx) > slop && abs(dx) > abs(dy)) {
                    dragging = true
                    lastX = e.x
                    parent?.requestDisallowInterceptTouchEvent(true)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (!dragging) {
                    velocity?.recycle()
                    velocity = null
                }
            }
        }
        return dragging
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        velocity?.addMovement(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x
                downY = e.y
                lastX = e.x
                if (velocity == null) velocity = VelocityTracker.obtain().also { it.addMovement(e) }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && abs(e.x - downX) > slop) {
                    dragging = true
                    lastX = e.x
                    parent?.requestDisallowInterceptTouchEvent(true)
                }
                if (dragging) {
                    val dx = e.x - lastX
                    lastX = e.x
                    setPos(pos - dx * itemsPerPx())
                }
            }
            MotionEvent.ACTION_UP -> {
                val n = adapter?.count() ?: 0
                if (n > 0) {
                    var target = pos.roundToInt()
                    if (dragging) {
                        velocity?.computeCurrentVelocity(1000)
                        val vx = velocity?.xVelocity ?: 0f
                        target = (pos - vx * itemsPerPx() * 0.25f).roundToInt()
                    }
                    animateTo(target.coerceIn(0, n - 1))
                }
                dragging = false
                velocity?.recycle()
                velocity = null
            }
            MotionEvent.ACTION_CANCEL -> {
                val n = adapter?.count() ?: 0
                if (n > 0) animateTo(pos.roundToInt().coerceIn(0, n - 1))
                dragging = false
                velocity?.recycle()
                velocity = null
            }
        }
        return true
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        velocity?.recycle()
        velocity = null
        super.onDetachedFromWindow()
    }

    companion object {
        private const val SLOTS = 9
    }
}
