package com.hyperengine.gameturbo.service

import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Point
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import com.hyperengine.gameturbo.HyperApp
import com.hyperengine.gameturbo.core.DisplayModeLock
import com.hyperengine.gameturbo.core.GameAudioEngine
import com.hyperengine.gameturbo.core.OptimizationEngine
import com.hyperengine.gameturbo.core.VoiceStudio
import com.hyperengine.gameturbo.core.SystemBridgeExecutor
import com.hyperengine.gameturbo.core.TelemetryMonitor
import com.hyperengine.gameturbo.service.TouchMacroService
import com.hyperengine.gameturbo.data.EdgeSide
import com.hyperengine.gameturbo.data.GlobalSettings
import com.hyperengine.gameturbo.data.GameProfile
import com.hyperengine.gameturbo.data.GameProfileRepository
import com.hyperengine.gameturbo.ui.AnimationController
import com.hyperengine.gameturbo.ui.AudioTool
import com.hyperengine.gameturbo.ui.CallBannerController
import com.hyperengine.gameturbo.ui.ClipBufferTool
import com.hyperengine.gameturbo.ui.CallsTool
import com.hyperengine.gameturbo.ui.ConsoleTool
import com.hyperengine.gameturbo.ui.GameTurboLandscapeHudView
import com.hyperengine.gameturbo.ui.HudBus
import com.hyperengine.gameturbo.ui.HudPanel
import com.hyperengine.gameturbo.ui.KbmEditorOverlay
import com.hyperengine.gameturbo.ui.KbmTool
import com.hyperengine.gameturbo.ui.LabTool
import com.hyperengine.gameturbo.ui.RecordTool
import com.hyperengine.gameturbo.ui.ShotTool
import com.hyperengine.gameturbo.ui.StudioTool
import com.hyperengine.gameturbo.ui.BuiltinTools
import com.hyperengine.gameturbo.ui.MacroTool
import com.hyperengine.gameturbo.ui.MicroToolsManager
import com.hyperengine.gameturbo.ui.TouchMacroController
import com.hyperengine.gameturbo.ui.VoiceTool
import com.hyperengine.gameturbo.ui.CrosshairOverlayManager
import com.hyperengine.gameturbo.ui.CrosshairTool
import com.hyperengine.gameturbo.ui.EdgeGuardTool
import com.hyperengine.gameturbo.ui.EdgeTriggerView
import com.hyperengine.gameturbo.ui.FloatingTelemetryPill
import com.hyperengine.gameturbo.ui.GameTurboSidebarView
import com.hyperengine.gameturbo.ui.HudTheme
import com.hyperengine.gameturbo.ui.HudThemes
import com.hyperengine.gameturbo.ui.PillTool
import com.hyperengine.gameturbo.ui.SidebarDeps
import com.hyperengine.gameturbo.ui.SlideBarController
import com.hyperengine.gameturbo.ui.SlideBarTool
import com.hyperengine.gameturbo.ui.ToolRegistry
import com.hyperengine.gameturbo.ui.TurboTool
import com.hyperengine.gameturbo.ui.Ui
import com.hyperengine.gameturbo.ui.VisualFilterOverlay
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min

/**
 * Owns the overlay windows and keeps them in sync with settings, telemetry and engine state:
 *  - Phase 3: edge handle and sidebar
 *  - Phase 4: crosshair, floating FPS pill, edge palm-rejection guards, screen colour layer
 *  - Phase 5: auto tapper, audio EQ / voice studio, timers, danmaku ticker, AFK lock, mini windows
 *  - UI redesign part 3: the slide bar (edge tab, dock, flyout) that hosts Apps, Chat apps, Browser, Notes, Calculator
 *  - Phase 3 (second pass): landscape dual-wing console HUD, in-game call banner, keyboard + mouse mapper,
 *    freeform app launcher, screenshot / recorder / cast tools, and the HudBus switchboard
 * Everything here runs on the main thread.
 *
 * The sidebar window is exactly the panel size, anchored to the handle's side, and receives
 * ACTION_OUTSIDE touches so tapping the game closes it. It never takes focus, so the game keeps
 * running underneath.
 */
class HudController(
    context: Context,
    private val engine: OptimizationEngine,
    private val telemetry: TelemetryMonitor,
    private val repo: GameProfileRepository,
    bridge: SystemBridgeExecutor
) {

    private val ctx: Context = context.applicationContext
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val deps = SidebarDeps(ctx, engine, telemetry, repo, bridge)

    private val visualFilter = VisualFilterOverlay(ctx, wm)
    private val crosshair = CrosshairOverlayManager(ctx, wm)
    private val pill = FloatingTelemetryPill(ctx, wm)
    private val macro = TouchMacroController(ctx, wm)
    private val audio = GameAudioEngine(ctx)
    private val voice = VoiceStudio(ctx)
    private val micro = MicroToolsManager(ctx, wm, repo, bridge)
    private val callBanner = CallBannerController(
        ctx, wm, HyperApp.instance.calls,
        themeProvider = { HudThemes.resolve(repo.global.value) },
        configProvider = { repo.global.value.calls },
        onTopSaved = { dp -> repo.updateGlobal { it.copy(calls = it.calls.copy(bannerTopDp = dp)) } }
    )
    private val slideBar = SlideBarController(
        ctx, wm, deps, micro, scope,
        handleProvider = { repo.global.value.handle }
    )
    private var kbmEditor: KbmEditorOverlay? = null
    private var sidebarFocusable = false

    /** The parts of GlobalSettings that change how the handle and sidebar look. */
    private data class Look(val theme: Any?, val sidebar: Any?, val handle: Any?, val layout: Any?, val slide: Any?)
    private var lastLook: Look? = null
    private var game: String? = null
    private var handle: EdgeTriggerView? = null
    private var sidebar: HudPanel? = null
    private var sidebarParams: WindowManager.LayoutParams? = null
    private var closing = false
    private var initialShow = false     // true while show() is still building the stack in the right order
    private var raiseQueued = false

    val isShowing: Boolean get() = game != null && handle != null

    init {
        BuiltinTools.register(deps)

        // Phase 4 tools: a tile appears in the sidebar as soon as its tool is registered.
        ToolRegistry.register(CrosshairTool(crosshair))
        ToolRegistry.register(PillTool(pill))
        ToolRegistry.register(EdgeGuardTool(visualFilter.edgeGuard))

        // Phase 2 tool: FPS unlocker, Wild Boost, fan, charge separation, Battery Saver
        ToolRegistry.register(TurboTool(HyperApp.instance.fps, HyperApp.instance.wild))

        // Phase 3 (second pass) tools
        ToolRegistry.register(SlideBarTool())
        ToolRegistry.register(ShotTool())
        ToolRegistry.register(RecordTool())
        ToolRegistry.register(StudioTool())
        ToolRegistry.register(KbmTool())
        ToolRegistry.register(CallsTool())
        ToolRegistry.register(ConsoleTool())
        // Phase 3 Step 3: HyperLab tab (low-latency mode, clip buffer, colour filters, refresh-rate matching, HyperBoost)
        // and the one-tap "Save last clip" tile.
        ToolRegistry.register(LabTool(HyperApp.instance.suite))
        ToolRegistry.register(ClipBufferTool(HyperApp.instance.suite))

        // Phase 5 tools
        ToolRegistry.register(MacroTool(macro))
        ToolRegistry.register(AudioTool(audio))
        ToolRegistry.register(VoiceTool(voice))
        micro.registerTools()
        micro.recoverPending()   // puts Do Not Disturb back if an earlier run was killed before it could

        // New overlay windows land on top of the stack; lift the handle and sidebar back above them.
        crosshair.onAttached = { requestRaise() }
        pill.onAttached = { requestRaise() }
        visualFilter.edgeGuard.onAttached = { requestRaise() }
        macro.onAttached = { requestRaise() }
        micro.onAttached = { requestRaise() }
        micro.windows.onChanged = { slideBar.onWindowsChanged() }
        slideBar.onOpening = { closeSidebar() }

        // The auto tapper saves its target positions into the game's profile.
        macro.accentProvider = { HudThemes.resolve(repo.global.value).accent }
        macro.onConfigChanged = { cfg ->
            game?.let { g -> repo.update(g) { it.copy(macro = cfg) } }
        }
        // While the tapper runs, the AFK screen must let its taps through.
        macro.onRunningChanged = { running -> micro.afk.setPassThrough(running) }

        // Best-effort touch signal from the accessibility service (more precise than the outside-touch probe).
        TouchMacroService.touchListener = { started -> if (started) crosshair.pulse() }

        // Dragging or pinning the pill is saved into the game's profile.
        pill.onPositionSaved = { x, y ->
            game?.let { g -> repo.update(g) { it.copy(pill = it.pill.copy(posX = x, posY = y)) } }
        }
        pill.onPinChanged = { pinned ->
            game?.let { g -> repo.update(g) { it.copy(pill = it.pill.copy(pinned = pinned)) } }
        }

        // Screen overlay for the Visual filter fallback and the window brightness override.
        engine.overlayHook = { state ->
            if (state != null && !Settings.canDrawOverlays(ctx)) {
                false
            } else {
                scope.launch { visualFilter.applyScreen(state) }
                true
            }
        }

        // Phase 2: every overlay window carries the refresh-rate lock, re-stamped when the enforcer's rate changes
        HyperApp.instance.fps.overlayRefresh = { scope.launch { applyDisplayMode() } }
        scope.launch { HyperApp.instance.fps.lockedHz.collect { applyDisplayMode() } }

        scope.launch {
            repo.global.collect { g ->
                micro.applyGlobal(g)
                slideBar.onGlobal()
                // Settings that do not change the look (danmaku, freeze list, ...) must not rebuild the
                // sidebar: restyle() sends an open tool page back to the main page.
                if (game != null) {
                    if (g.calls.bannerEnabled) callBanner.enable() else callBanner.disable()
                }
                val look = Look(g.theme, g.sidebar, g.handle, g.hudLayout, g.slideBar)
                if (look == lastLook) return@collect
                lastLook = look
                restyleHud(g)
            }
        }
        scope.launch {
            telemetry.sample.collect {
                sidebar?.onSample(it)
                pill.onSample(it)
                micro.onSample(it)
            }
        }
        scope.launch { engine.status.collect { sidebar?.onEngine(it) } }
        scope.launch {
            repo.profiles.collect { map ->
                val g = game ?: return@collect
                map[g]?.let {
                    sidebar?.onProfile(it)
                    applyHudProfile(it)
                }
            }
        }
    }

    // =========================================================================================
    // Public API (called by GameDetectorService)
    // =========================================================================================

    /** Shows the edge handle for [pkg]. Returns false when the overlay permission is missing. */
    fun show(pkg: String): Boolean {
        if (!Settings.canDrawOverlays(ctx)) return false
        if (game == pkg && handle != null) return true
        if (game != null && game != pkg) removeSidebar(animated = false)
        game = pkg
        telemetry.acquire(OWNER, pkg)
        sidebar?.changeGame(pkg)

        // Phase 4 overlays first, so the handle and sidebar are added above them.
        initialShow = true
        val profile = repo.profile(pkg) ?: repo.getOrCreate(pkg, pkg)
        visualFilter.edgeGuard.show(profile.edgeGuard)
        crosshair.show(profile.crosshair)
        pill.show(profile.pill, telemetry.sample.value)

        // Phase 5: tapper nodes, timers, danmaku strip and the audio chain for this game.
        macro.show(profile.macro)
        micro.show(pkg, profile, repo.global.value)
        slideBar.show(pkg)
        audio.apply(profile.audio, pkg)

        ensureHandle()
        initialShow = false

        // Wild Boost ignition (tile or sidebar): when the turbine lands, the real edge handle lights up.
        HyperApp.instance.wildBoost.onIgnitionDocked = { handle?.wake() }

        // Phase 3 (second pass)
        HudBus.game = pkg
        installBus()
        if (repo.global.value.calls.bannerEnabled) callBanner.enable()
        HyperApp.instance.kbm.start(profile.kbm)
        return true
    }

    fun hide() {
        kbmEditor?.close(false)
        callBanner.disable()
        HyperApp.instance.kbm.stop()
        clearBus()
        slideBar.hide()
        removeSidebar(animated = false)
        // Phase 5 first: stop tapping, release audio effects, close mini windows, restore Do Not Disturb.
        macro.hide()
        voice.release()
        audio.release()
        micro.hide()
        pill.hide()
        crosshair.hide()
        visualFilter.edgeGuard.hide()
        handle?.let { runCatching { wm.removeViewImmediate(it) } }
        handle = null
        if (game != null) telemetry.release(OWNER)
        game = null
    }

    /** Landscape dual-wing HUD when the screen is wider than tall (or forced), the one-column sidebar otherwise. */
    private fun useLandscapeHud(g: GlobalSettings): Boolean {
        val mode = g.hudLayout.mode
        val s = screenSize()
        return mode == 1 || (mode == 0 && s.x > s.y)
    }

    fun openSidebar() {
        val g = game ?: return
        if (sidebar != null) return
        slideBar.close(animated = false)
        val global = repo.global.value
        val theme = HudThemes.resolve(global)
        val landscape = useLandscapeHud(global)
        val panel: HudPanel = if (landscape) {
            GameTurboLandscapeHudView(
                context = ctx,
                deps = deps,
                theme = theme,
                global = global,
                game = g,
                onClose = { closeSidebar() }
            )
        } else {
            GameTurboSidebarView(
                context = ctx,
                deps = deps,
                theme = theme,
                global = global,
                game = g,
                screen = { screenSize() },
                onClose = { closeSidebar() }
            )
        }
        // A gamepad or keyboard is connected: let the HUD window take focus so D-pad and buttons navigate it.
        sidebarFocusable = landscape && global.hudLayout.controllerNav && GameTurboLandscapeHudView.inputDeviceAttached()
        val params = sidebarParams(theme, landscape)
        try {
            wm.addView(panel.view, params)
        } catch (_: Throwable) {
            panel.dispose()
            return
        }
        sidebar = panel
        sidebarParams = params
        closing = false
        handle?.visibility = View.INVISIBLE
        panel.onSample(telemetry.sample.value)
        panel.onEngine(engine.status.value)
        if (panel is GameTurboSidebarView) {
            // Spring wing: the panel slides in with a low-bounce spring while the tool tiles cascade in 30 ms apart.
            AnimationController.openWing(
                AnimationController.Wing(panel, global.handle.side, panel.wingChildren()),
                theme, wingDistance(global.handle.side, params)
            )
        } else if (!panel.playOpen() && theme.animations && !panel.isFullScreen) {
            val v = panel.view
            val side = global.handle.side
            v.translationX = slideFrom(side, params.width, params.height, true)
            v.translationY = slideFrom(side, params.width, params.height, false)
            v.animate().translationX(0f).translationY(0f).setDuration(180L).start()
        }
    }

    fun closeSidebar() {
        val p = sidebar ?: return
        if (closing) return
        val theme = HudThemes.resolve(repo.global.value)
        if (!theme.animations) {
            removeSidebar(animated = false)
            return
        }
        closing = true
        if (p is GameTurboSidebarView) {
            val side = repo.global.value.handle.side
            val lp = sidebarParams
            AnimationController.closeWing(
                AnimationController.Wing(p, side, p.wingChildren()),
                theme,
                if (lp != null) wingDistance(side, lp) else (if (side == EdgeSide.TOP) p.height else p.width) + Ui.dp(ctx, 16).toFloat()
            ) { removeSidebar(animated = false) }
            return
        }
        if (p.playClose { removeSidebar(animated = false) }) return
        val v = p.view
        val side = repo.global.value.handle.side
        v.animate()
            .translationX(slideFrom(side, v.width, v.height, true))
            .translationY(slideFrom(side, v.width, v.height, false))
            .setDuration(150L)
            .withEndAction { removeSidebar(animated = false) }
            .start()
    }

    private fun wingDistance(side: EdgeSide, p: WindowManager.LayoutParams): Float =
        (if (side == EdgeSide.TOP) p.height else p.width).toFloat() + Ui.dp(ctx, 16)

    fun toggleSidebar() {
        if (sidebar != null) closeSidebar() else openSidebar()
    }

    // ---- HudBus: lets tools, the tile and the key chord reach this controller ----

    private fun installBus() {
        HudBus.openHud = { openSidebar() }
        HudBus.closeHud = { closeSidebar() }
        HudBus.toggleHud = { toggleSidebar() }
        HudBus.openSlideBar = { slideBar.open() }
        HudBus.closeSlideBar = { slideBar.close() }
        HudBus.slideBarOpen = { slideBar.isOpen }
        HudBus.captureHider = { hidden ->
            sidebar?.setCaptureHidden(hidden)
            slideBar.setCaptureHidden(hidden)
            handle?.visibility = if (hidden || sidebar != null) View.INVISIBLE else View.VISIBLE
        }
        HudBus.focusRequest = { focus -> setSidebarFocusable(focus) }
        HudBus.callPreview = { callBanner.preview() }
        HudBus.kbmEditor = { openKbmEditor() }
        HudBus.raiseHud = { requestRaise() }
    }

    private fun clearBus() {
        HudBus.game = null
        HudBus.raiseHud = null
        HudBus.openHud = null
        HudBus.closeHud = null
        HudBus.toggleHud = null
        HudBus.openSlideBar = null
        HudBus.closeSlideBar = null
        HudBus.slideBarOpen = null
        HudBus.captureHider = null
        HudBus.focusRequest = null
        HudBus.callPreview = null
        HudBus.kbmEditor = null
    }

    /** Lets a page inside the HUD (a search box) bring up the keyboard, then gives focus back to the game. */
    private fun setSidebarFocusable(focus: Boolean) {
        val s = sidebar ?: return
        val p = sidebarParams ?: return
        if (focus) {
            p.flags = p.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
            p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        } else if (!sidebarFocusable) {
            p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        }
        updateLayoutSafe(s.view, p)
    }

    private fun openKbmEditor() {
        val g = game ?: return
        if (kbmEditor?.isShowing == true) return
        closeSidebar()
        val editor = KbmEditorOverlay(
            ctx, wm, HudThemes.resolve(repo.global.value), g, repo, HyperApp.instance.kbm
        ) {
            kbmEditor = null
            handle?.let { h -> if (sidebar == null) h.visibility = View.VISIBLE }
        }
        kbmEditor = editor
        handle?.visibility = View.INVISIBLE
        editor.show()
    }

    /** Re-measures after rotation or display size changes. */
    /** Re-stamps the edge handle, sidebar and FPS pill with the display mode the FPS enforcer is holding. */
    private fun applyDisplayMode() {
        // Only touch the windows when the requested rate really changed. This used to run on every
        // display event and re-laid-out the full-screen HUD each time, which was the HUD lag.
        val hz = DisplayModeLock.currentHz
        if (hz == stampedHz) return
        stampedHz = hz
        handle?.let { updateLayoutSafe(it, handleParams()) }
        val s = sidebar
        val p = sidebarParams
        if (s != null && p != null) {
            DisplayModeLock.applyCurrent(ctx, p)   // keeps the focus flags and position the window already has
            updateLayoutSafe(s.view, p)
        }
        pill.refreshDisplayMode()
        slideBar.refreshDisplayMode()
    }

    private var stampedHz = -1

    fun relayout() {
        crosshair.relayout()
        pill.relayout()
        visualFilter.edgeGuard.relayout()
        macro.relayout()
        micro.relayout()
        slideBar.relayout()
        handle?.let { updateLayoutSafe(it, handleParams()) }
        callBanner.relayout()
        val open = sidebar
        if (open != null) {
            // Rotated: swap between the wings and the sidebar when the layout is on Automatic.
            if (open.isFullScreen != useLandscapeHud(repo.global.value)) {
                removeSidebar(animated = false)
                openSidebar()
            } else {
                val p = sidebarParams(HudThemes.resolve(repo.global.value), open.isFullScreen)
                sidebarParams = p
                updateLayoutSafe(open.view, p)
            }
        }
    }

    fun destroy() {
        hide()
        TouchMacroService.touchListener = null
        HyperApp.instance.fps.overlayRefresh = null
        macro.destroy()
        micro.destroy()
        callBanner.destroy()
        HyperApp.instance.wildBoost.onIgnitionDocked = null
        engine.overlayHook = null
        visualFilter.destroy()
        scope.cancel()
    }

    /**
     * A touch started somewhere on screen. The crosshair already listens through its own probe window;
     * the accessibility service (Phase 5) feeds this as well, when the ROM delivers touch events.
     */
    fun onTouchActivity() {
        crosshair.pulse()
    }

    // =========================================================================================
    // Windows
    // =========================================================================================

    private fun ensureHandle() {
        val g = repo.global.value
        val theme = HudThemes.resolve(g)
        val existing = handle
        if (existing != null) {
            existing.apply(g.handle, theme.animations)
            updateLayoutSafe(existing, handleParams())
            return
        }
        val v = EdgeTriggerView(ctx) { openSidebar() }
        v.onReposition = { rawX, rawY, finished -> moveHandle(rawX, rawY, finished) }
        v.apply(g.handle, theme.animations)
        try {
            wm.addView(v, handleParams())
            handle = v
        } catch (_: Throwable) {
            handle = null
        }
    }

    /** The handle was long-pressed and dragged along its edge. */
    private fun moveHandle(rawX: Float, rawY: Float, finished: Boolean) {
        val h = repo.global.value.handle
        val v = handle ?: return
        val scr = screenSize()
        val len = Ui.dp(ctx, h.heightDp.coerceIn(40, 160))
        val vertical = h.side != EdgeSide.TOP
        val limit = if (vertical) scr.y else scr.x
        val off = ((if (vertical) rawY else rawX) - len / 2f).toInt().coerceIn(0, max(0, limit - len))
        if (finished) {
            val dp = (off / ctx.resources.displayMetrics.density).toInt()
            repo.updateGlobal { it.copy(handle = it.handle.copy(offsetDp = dp)) }
        } else {
            val p = handleParams()
            if (vertical) p.y = off else p.x = off
            updateLayoutSafe(v, p)
        }
    }

    private fun applyHudProfile(p: GameProfile) {
        HyperApp.instance.kbm.update(p.kbm)
        visualFilter.edgeGuard.apply(p.edgeGuard)
        crosshair.apply(p.crosshair)
        pill.apply(p.pill)
        macro.apply(p.macro)
        micro.apply(p)
        audio.apply(p.audio, game)
    }

    private fun restyleHud(g: GlobalSettings) {
        val theme = HudThemes.resolve(g)
        slideBar.restyle()
        handle?.let {
            it.apply(g.handle, theme.animations)
            updateLayoutSafe(it, handleParams())
        }
        val open = sidebar
        if (open != null) {
            if (open.isFullScreen != useLandscapeHud(g)) {
                // the layout mode changed: reopen in the other layout
                removeSidebar(animated = false)
                openSidebar()
            } else {
                open.restyle(theme, g)
                val p = sidebarParams(theme, open.isFullScreen)
                sidebarParams = p
                updateLayoutSafe(open.view, p)
            }
        }
    }

    /**
     * Asked for when an overlay window is added while the handle or sidebar already exist. Posted to the
     * next main-loop turn so the sidebar is never re-added from inside one of its own touch handlers.
     */
    private fun requestRaise() {
        if (initialShow || raiseQueued) return
        raiseQueued = true
        scope.launch {
            raiseQueued = false
            raiseHud()
        }
    }

    /** Re-adds the handle and the sidebar so they sit above any overlay window that was just added. */
    private fun raiseHud() {
        if (game == null) return
        handle?.let { h ->
            runCatching {
                wm.removeViewImmediate(h)
                wm.addView(h, handleParams())
            }
        }
        val s = sidebar
        val sp = sidebarParams
        if (s != null && sp != null) {
            runCatching {
                wm.removeViewImmediate(s.view)
                wm.addView(s.view, sp)
            }
        }
        slideBar.raise()
    }

    private fun removeSidebar(animated: Boolean) {
        val v = sidebar ?: return
        sidebar = null
        sidebarParams = null
        closing = false
        runCatching { v.view.animate().cancel() }
        runCatching { AnimationController.cancelSprings(v.view) }
        runCatching { wm.removeViewImmediate(v.view) }
        v.dispose()
        sidebarFocusable = false
        handle?.let {
            it.visibility = View.VISIBLE
            it.wake()
        }
    }

    private fun updateLayoutSafe(v: View, p: WindowManager.LayoutParams) {
        runCatching { if (v.isAttachedToWindow) wm.updateViewLayout(v, p) }
    }

    @Suppress("DEPRECATION")
    private fun screenSize(): Point {
        val p = Point()
        wm.defaultDisplay.getRealSize(p)
        return p
    }

    private fun baseFlags(): Int =
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

    private fun handleParams(): WindowManager.LayoutParams {
        val h = repo.global.value.handle
        val scr = screenSize()
        val vertical = h.side != EdgeSide.TOP
        val thick = Ui.dp(ctx, max(h.widthDp + 14, 24))
        val len = Ui.dp(ctx, h.heightDp.coerceIn(40, 160))
        val w = if (vertical) thick else len
        val hh = if (vertical) len else thick
        val p = WindowManager.LayoutParams(
            w, hh, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, baseFlags(), PixelFormat.TRANSLUCENT
        )
        val offset = Ui.dp(ctx, h.offsetDp)
        when (h.side) {
            EdgeSide.LEFT -> {
                p.gravity = Gravity.LEFT or Gravity.TOP
                p.x = 0
                p.y = offset.coerceIn(0, max(0, scr.y - len))
            }
            EdgeSide.RIGHT -> {
                p.gravity = Gravity.RIGHT or Gravity.TOP
                p.x = 0
                p.y = offset.coerceIn(0, max(0, scr.y - len))
            }
            EdgeSide.TOP -> {
                p.gravity = Gravity.LEFT or Gravity.TOP
                p.x = offset.coerceIn(0, max(0, scr.x - len))
                p.y = 0
            }
        }
        p.title = "HyperEngineHandle"
        if (Build.VERSION.SDK_INT >= 28) {
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        DisplayModeLock.applyCurrent(ctx, p)   // Phase 2, layer 5: hardware window keeps requesting the locked rate
        return p
    }

    private fun sidebarParams(theme: HudTheme, landscape: Boolean = false): WindowManager.LayoutParams {
        if (landscape) return landscapeParams()
        val side = repo.global.value.handle.side
        val scr = screenSize()
        val margin = Ui.dp(ctx, 8)
        val w: Int
        val h: Int
        if (side == EdgeSide.TOP) {
            w = min(Ui.dp(ctx, 520), scr.x - margin * 2)
            h = (scr.y * 0.86f).toInt()
        } else {
            w = min(Ui.dp(ctx, 340), (scr.x * 0.9f).toInt())
            h = scr.y - margin * 2
        }
        var flags = baseFlags() or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
        val p = WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
        )
        when (side) {
            EdgeSide.LEFT -> { p.gravity = Gravity.LEFT or Gravity.TOP; p.x = margin; p.y = margin }
            EdgeSide.RIGHT -> { p.gravity = Gravity.RIGHT or Gravity.TOP; p.x = margin; p.y = margin }
            EdgeSide.TOP -> { p.gravity = Gravity.CENTER_HORIZONTAL or Gravity.TOP; p.x = 0; p.y = margin }
        }
        p.title = "HyperEngineSidebar"
        if (Build.VERSION.SDK_INT >= 28) {
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        DisplayModeLock.applyCurrent(ctx, p)
        // Real background blur (Android 12+), only where the device allows it. Best effort.
        if (theme.blur && Build.VERSION.SDK_INT >= 31) {
            runCatching {
                if (wm.isCrossWindowBlurEnabled) {
                    flags = flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
                    p.flags = flags
                    p.blurBehindRadius = Ui.dp(ctx, 24)
                }
            }
        }
        return p
    }

    /** Full-screen window for the landscape wings. It only takes focus when a gamepad / keyboard is attached. */
    private fun landscapeParams(): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!sidebarFocusable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.LEFT or Gravity.TOP
        p.x = 0
        p.y = 0
        p.title = "HyperEngineLandscapeHud"
        if (Build.VERSION.SDK_INT >= 28) {
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        DisplayModeLock.applyCurrent(ctx, p)
        return p
    }

    private fun slideFrom(side: EdgeSide, w: Int, h: Int, horizontal: Boolean): Float {
        val gap = Ui.dp(ctx, 16)
        return when (side) {
            EdgeSide.LEFT -> if (horizontal) -(w + gap).toFloat() else 0f
            EdgeSide.RIGHT -> if (horizontal) (w + gap).toFloat() else 0f
            EdgeSide.TOP -> if (horizontal) 0f else -(h + gap).toFloat()
        }
    }

    companion object {
        private const val OWNER = "hud"
    }
}
