package com.hyperengine.gameturbo.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Path
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.accessibility.AccessibilityEvent
import com.hyperengine.gameturbo.HyperApp
import com.hyperengine.gameturbo.R
import com.hyperengine.gameturbo.hub.HubActivity
import com.hyperengine.gameturbo.ui.HudBus
import java.util.concurrent.CopyOnWriteArrayList
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * The only thing this accessibility service does is inject taps with dispatchGesture for the auto
 * tapper. It does not read window content (canRetrieveWindowContent is false in its config).
 *
 * It also forwards "a finger touched the screen" events (TYPE_TOUCH_INTERACTION_START) to
 * [touchListener], which the crosshair uses for tap-expansion. Whether Android delivers those events
 * depends on the ROM, so the crosshair's own touch probe stays as the baseline.
 *
 * Phase 2: window-state events (package name only) tell the FPS watchdog when the game regains focus or the
 * notification shade / Recents opens, so the refresh-rate lock can be re-applied immediately.
 *
 * Phase 3: key events (Volume Up + Volume Down held = the virtual hardware switch; other handlers such as the
 * keyboard mapper plug in through [addKeyHandler]), the native screenshot action, and mouse button events on
 * Android 14+. Key events are only inspected for those jobs; nothing is logged or stored.
 *
 * Phase 3 (self-heal): it promotes itself to a quiet foreground service (type specialUse) the moment Android connects
 * it, so the OEM battery manager treats it as a running service instead of a cached background process, and it tells
 * the [com.hyperengine.gameturbo.core.AccessibilitySelfHealer] when it is unbound or its task is removed, which
 * restores it at once (and through an AlarmManager broadcast if the process dies).
 */
class TouchMacroService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _connected.value = true
        if (Build.VERSION.SDK_INT >= 34) {
            // Mouse buttons (right-click for aim-down-sights in the keyboard mapper). Best effort.
            runCatching {
                val info = serviceInfo
                info.motionEventSources = InputDevice.SOURCE_MOUSE
                serviceInfo = info
            }
        }
        promoteToForeground()
        HyperApp.instance.selfHealer.onServiceConnected()
    }

    /** Android calls this for a started service; keep the foreground promotion and ask to be restarted. */
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (_connected.value) promoteToForeground()
        return START_STICKY
    }

    /** The user swiped the app away. With stopWithTask=false (manifest) we get here instead of being stopped. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        HyperApp.instance.selfHealer.onServiceLost("task removed")
        super.onTaskRemoved(rootIntent)
    }

    // ---------------------------------------------------------------------------------------------
    // Keys
    // ---------------------------------------------------------------------------------------------

    private var upDown = false
    private var downDown = false
    private var chordAttempt = false
    private var chordFired = false
    private var baseVolume = -1
    private val chordFire = Runnable { fireChord() }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        // Other handlers first (keyboard mapper, Phase 4 shoulder triggers). One that returns true owns the key.
        for ((_, h) in keyHandlers) {
            val used = try { h(event) } catch (_: Throwable) { false }
            if (used) return true
        }
        return handleChord(event)
    }

    private fun handleChord(e: KeyEvent): Boolean {
        val code = e.keyCode
        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) return false
        val cfg = HyperApp.instance.repository.global.value.chord
        if (!cfg.enabled) return false
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager

        if (e.action == KeyEvent.ACTION_DOWN) {
            if (!upDown && !downDown) {
                baseVolume = runCatching { am.getStreamVolume(AudioManager.STREAM_MUSIC) }.getOrDefault(-1)
            }
            if (code == KeyEvent.KEYCODE_VOLUME_UP) upDown = true else downDown = true
            if (upDown && downDown) {
                if (!chordAttempt) {
                    chordAttempt = true
                    chordFired = false
                    handler.postDelayed(chordFire, cfg.holdMs.coerceIn(600, 3000).toLong())
                }
                return true   // swallow the second key and every repeat so the volume does not wobble
            }
            return false      // a lone press behaves exactly as before
        }

        if (e.action == KeyEvent.ACTION_UP) {
            if (code == KeyEvent.KEYCODE_VOLUME_UP) upDown = false else downDown = false
            if (chordAttempt) {
                handler.removeCallbacks(chordFire)
                // The first key of the pair had already moved the volume one step: put it back.
                if (baseVolume >= 0) runCatching { am.setStreamVolume(AudioManager.STREAM_MUSIC, baseVolume, 0) }
                if (!upDown && !downDown) {
                    chordAttempt = false
                    chordFired = false
                    baseVolume = -1
                }
                return true
            }
        }
        return false
    }

    private fun fireChord() {
        if (!(upDown && downDown) || chordFired) return
        chordFired = true
        val app = HyperApp.instance
        val cfg = app.repository.global.value.competitive
        com.hyperengine.gameturbo.service.SliderFeedback.play(applicationContext, cfg.sound, cfg.haptic)
        val toggle = HudBus.toggleHud
        if (HudBus.game != null && toggle != null) {
            toggle()   // in a game: open or close the HUD with the Energy Cube
        } else {
            // not in a game: open Game Space
            runCatching {
                startActivity(
                    Intent(this, HubActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                )
            }
        }
    }

    override fun onMotionEvent(event: MotionEvent) {
        mouseListener?.invoke(event)
    }

    /** The phone's own screenshot (power + volume down equivalent). True when Android accepted the action. */
    fun takeScreenshot(): Boolean = Build.VERSION.SDK_INT >= 28 && performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        when (event?.eventType) {
            AccessibilityEvent.TYPE_TOUCH_INTERACTION_START -> touchListener?.invoke(true)
            AccessibilityEvent.TYPE_TOUCH_INTERACTION_END -> touchListener?.invoke(false)
            // Which window came forward (game, notification shade, Recents ...). Only the package name is
            // used, to re-apply the refresh-rate lock within ~50 ms. Content is never read.
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ->
                windowListener?.invoke(event.packageName?.toString().orEmpty())
        }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        clear()
        runCatching { stopForeground(STOP_FOREGROUND_REMOVE) }
        HyperApp.instance.selfHealer.onServiceLost("unbound")
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        val wasConnected = _connected.value
        clear()
        if (wasConnected) HyperApp.instance.selfHealer.onServiceLost("destroyed")
        super.onDestroy()
    }

    /**
     * Persistent binder lock: a low-importance ongoing notification + startForeground. Some Android versions refuse a
     * foreground start from a service that is only bound; that is caught, the service still works, it just keeps
     * no foreground priority, and the heal report still says "Connected".
     */
    private fun promoteToForeground() {
        // No persistent "Connected. Keeps the auto tapper alive." notification unless the user asked the app to
        // keep running after it is closed. The accessibility service itself still works while it is enabled.
        if (!HyperApp.instance.selfHealer.autoHeal) {
            runCatching { stopForeground(STOP_FOREGROUND_REMOVE) }
            return
        }
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CHANNEL) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL, "Auto tapper service", NotificationManager.IMPORTANCE_MIN).apply {
                        setShowBadge(false)
                    }
                )
            }
            val n = Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_qs_wild_boost)
                .setContentTitle("HyperEngine touch service")
                .setContentText("Connected. Keeps the auto tapper alive.")
                .setOngoing(true)
                .build()
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(NOTIF_ID, n)
            }
        } catch (_: Throwable) {
            // not allowed right now (background start rules): the service itself keeps working
        }
    }

    private fun clear() {
        handler.removeCallbacks(chordFire)
        upDown = false; downDown = false; chordAttempt = false
        if (instance === this) instance = null
        _connected.value = false
    }

    /**
     * Taps (x, y) in real screen pixels, holding for [durationMs]. Returns true when Android reports
     * the gesture completed, false when it was cancelled or refused (for example while the screen is off).
     */
    suspend fun tap(x: Float, y: Float, durationMs: Long): Boolean = suspendCancellableCoroutine { cont ->
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, durationMs.coerceAtLeast(1L)))
            .build()
        val callback = object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                if (cont.isActive) cont.resume(true)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                if (cont.isActive) cont.resume(false)
            }
        }
        val accepted = try {
            dispatchGesture(gesture, callback, null)
        } catch (_: Throwable) {
            false
        }
        if (!accepted && cont.isActive) cont.resume(false)
    }

    /**
     * Phase 4: dispatches a ready-made gesture (several strokes = several simultaneous fingers, continued
     * strokes = fingers that stay down) and waits for the result. True when Android completed it, false when it
     * was cancelled or refused. Used by the accessibility engine of the multi-touch injector.
     */
    suspend fun dispatchGestureAwait(gesture: GestureDescription): Boolean = suspendCancellableCoroutine { cont ->
        val callback = object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                if (cont.isActive) cont.resume(true)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                if (cont.isActive) cont.resume(false)
            }
        }
        val accepted = try {
            dispatchGesture(gesture, callback, null)
        } catch (_: Throwable) {
            false
        }
        if (!accepted && cont.isActive) cont.resume(false)
    }

    companion object {
        private const val CHANNEL = "hyper_a11y"
        private const val NOTIF_ID = 4102

        @Volatile
        var instance: TouchMacroService? = null
            private set

        private val _connected = MutableStateFlow(false)
        val connected: StateFlow<Boolean> = _connected.asStateFlow()

        /** true = a touch started, false = it ended. Called on the main thread. */
        @Volatile
        var touchListener: ((Boolean) -> Unit)? = null

        /** Package of the window that just came to the front. Called on the main thread; must return quickly. */
        @Volatile
        var windowListener: ((String) -> Unit)? = null

        /** Mouse events (Android 14+). Observe only: the system still delivers them to the game. */
        @Volatile
        var mouseListener: ((MotionEvent) -> Unit)? = null

        private val keyHandlers = CopyOnWriteArrayList<Pair<String, (KeyEvent) -> Boolean>>()

        /** Registers a key handler under [id] (replacing any earlier one). Return true from it to consume the key. */
        fun addKeyHandler(id: String, handler: (KeyEvent) -> Boolean) {
            removeKeyHandler(id)
            keyHandlers.add(id to handler)
        }

        fun removeKeyHandler(id: String) {
            keyHandlers.removeAll { it.first == id }
        }
    }
}
