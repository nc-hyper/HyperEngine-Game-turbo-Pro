package com.hyperengine.gameturbo.core

import android.Manifest
import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Choreographer
import com.hyperengine.gameturbo.R
import com.hyperengine.gameturbo.data.PingTarget
import com.hyperengine.gameturbo.data.GameProfileRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.runInterruptible
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sqrt

// ---------------------------------------------------------------------------------------------
// Public data types
// ---------------------------------------------------------------------------------------------

/**
 * Where the FPS number came from. The UI must show this honestly:
 *  SURFACE_FLINGER: frames actually presented by the game's layer (the real game FPS).
 *  VSYNC:           Choreographer vsync cadence = how fast the DISPLAY refreshes. It is a ceiling,
 *                   not the game's FPS. Used only when SurfaceFlinger cannot be read.
 */
enum class FpsSource { NONE, SURFACE_FLINGER, VSYNC }

data class PingStat(
    val targetName: String = "",
    val host: String = "",
    val lastMs: Int = -1,              // -1 = last probe lost / no data yet
    val avgMs: Int = -1,
    val minMs: Int = -1,
    val maxMs: Int = -1,
    val jitterMs: Float = 0f,          // standard deviation over the last 10 successful samples
    val varianceMs2: Float = 0f,       // variance over the last 10 successful samples
    val lossPct: Int = 0,              // over the last 20 probes
    val history: List<Int> = emptyList() // last 60 probes, -1 = lost (for the mini line chart)
)

data class TelemetrySample(
    val timestamp: Long = 0L,
    val fps: Float = -1f,                       // -1 = unavailable
    val fpsSource: FpsSource = FpsSource.NONE,
    val fpsLayer: String = "",
    val cpuPct: Float = -1f,                    // -1 = unavailable (needs shell, see readCpu)
    val coreCurMhz: List<Int> = emptyList(),    // 0 = offline / unreadable
    val coreMaxMhz: List<Int> = emptyList(),    // hardware maximum per core
    val availRamMb: Long = 0L,
    val totalRamMb: Long = 0L,
    val batteryTempC: Float = 0f,
    val batteryPct: Int = -1,
    val voltageV: Float = 0f,
    val currentMa: Int = 0,                     // magnitude, always positive
    val powerW: Float = -1f,                    // -1 = current sensor unsupported
    val charging: Boolean = false,
    val overTemp: Boolean = false,
    val ping: PingStat = PingStat(),
    val fpsHistory: List<Float> = emptyList(),
    val cpuHistory: List<Float> = emptyList(),
    val tempHistory: List<Float> = emptyList(),
    val powerHistory: List<Float> = emptyList()
) {
    val peakCoreMhz: Int get() = coreCurMhz.maxOrNull() ?: 0
    val peakCoreGhz: Float get() = peakCoreMhz / 1000f
    val usedRamMb: Long get() = (totalRamMb - availRamMb).coerceAtLeast(0L)
}

data class TelemetryAlert(val kind: String, val message: String, val valueC: Float, val limitC: Int)

object MemoryReader {
    private const val MB = 1024L * 1024L

    private fun info(ctx: Context): ActivityManager.MemoryInfo {
        val am = ctx.applicationContext.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        return ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
    }

    fun availBytes(ctx: Context): Long = info(ctx).availMem
    fun availMb(ctx: Context): Long = info(ctx).availMem / MB
    fun totalMb(ctx: Context): Long = info(ctx).totalMem / MB
}

// ---------------------------------------------------------------------------------------------
// The monitor
// ---------------------------------------------------------------------------------------------

/**
 * Real-time telemetry. Nothing here is simulated:
 *
 *  FPS      dumpsys SurfaceFlinger --latency <game layer> (frame present timestamps). The layer is
 *           discovered with dumpsys SurfaceFlinger --list. Needs Shizuku/root or the DUMP permission
 *           granted over ADB. Without it the vsync rate from Choreographer is reported and labelled.
 *  CPU      Delta of the aggregate line in /proc/stat. Android 8+ blocks that file for normal apps, so
 *           this needs Shizuku/root. Otherwise cpuPct = -1 (the UI shows "--"), never a made-up value.
 *  Cores    scaling_cur_freq / cpuinfo_max_freq per core.
 *  RAM      ActivityManager.MemoryInfo.
 *  Battery  BatteryManager (temperature, voltage, BATTERY_PROPERTY_CURRENT_NOW) -> W = V x I.
 *  Ping     TCP connect round trip (port > 0) or ICMP via the system ping binary (port <= 0).
 *
 * Consumers (sidebar, pill, hub) call acquire(owner) / release(owner); sampling runs only while at
 * least one owner is attached.
 */
class TelemetryMonitor(
    context: Context,
    private val bridge: SystemBridgeExecutor,
    private val repo: GameProfileRepository
) {

    private val ctx: Context = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val lock = Any()
    private val owners = LinkedHashSet<String>()
    private var samplerJob: Job? = null
    private var pingJob: Job? = null

    @Volatile private var targetPackage: String? = null
    @Volatile private var pingIndex: Int = 0
    @Volatile private var intervalMs: Long = 1000L

    private val _sample = MutableStateFlow(TelemetrySample())
    val sample: StateFlow<TelemetrySample> = _sample.asStateFlow()

    private val _ping = MutableStateFlow(PingStat())
    val ping: StateFlow<PingStat> = _ping.asStateFlow()

    private val _alerts = MutableSharedFlow<TelemetryAlert>(
        extraBufferCapacity = 8,
        onBufferOverflow = kotlinx.coroutines.channels.BufferOverflow.DROP_OLDEST
    )
    val alerts: SharedFlow<TelemetryAlert> = _alerts.asSharedFlow()

    // history buffers (touched only by the sampler coroutine)
    private val fpsHist = ArrayList<Float>()
    private val cpuHist = ArrayList<Float>()
    private val tempHist = ArrayList<Float>()
    private val powerHist = ArrayList<Float>()

    // cpu delta state
    private var prevTotal = 0L
    private var prevIdle = 0L

    // static per-core hardware maximum (MHz), loaded once
    @Volatile private var coreMaxMhz: List<Int> = emptyList()
    private var coreMaxLoaded = false

    // surfaceflinger state
    private var layer: String? = null
    private var layerPkg: String? = null
    private var layerSearchAt = 0L
    private var layerMisses = 0
    private var lastSfNewest = 0L

    // choreographer state (vsync* are touched on the main thread only, except the atomic counter)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val vsyncFrames = AtomicInteger(0)
    private var vsyncWanted = false
    private var vsyncPosted = false
    private var vsyncRequested = false           // sampler thread only
    @Volatile private var vsyncLastCount = 0
    @Volatile private var vsyncLastNs = 0L
    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            vsyncFrames.incrementAndGet()
            if (vsyncWanted) Choreographer.getInstance().postFrameCallback(this) else vsyncPosted = false
        }
    }

    // alert state
    private var overTemp = false
    private var lastAlertAt = 0L

    // ---- lifecycle ----

    /** Starts sampling (idempotent). gamePackage selects the layer for FPS; null keeps the previous one. */
    fun acquire(owner: String, gamePackage: String? = null, intervalMs: Long = 1000L) {
        synchronized(lock) {
            owners += owner
            if (gamePackage != null) setTargetPackage(gamePackage)
            this.intervalMs = intervalMs.coerceIn(500L, 5000L)
            if (samplerJob == null) {
                resetHistory()
                samplerJob = scope.launch { samplerLoop() }
                pingJob = scope.launch { pingLoop() }
            }
        }
    }

    fun release(owner: String) {
        synchronized(lock) {
            owners -= owner
            if (owners.isEmpty()) {
                samplerJob?.cancel(); samplerJob = null
                pingJob?.cancel(); pingJob = null
                setVsync(false)
            }
        }
    }

    fun setTargetPackage(pkg: String?) {
        if (pkg == targetPackage) return
        targetPackage = pkg
        layer = null
        layerPkg = null
        layerMisses = 0
        lastSfNewest = 0L
        layerSearchAt = 0L
    }

    fun selectPingTarget(index: Int) {
        pingIndex = index.coerceAtLeast(0)
    }

    private fun resetHistory() {
        fpsHist.clear(); cpuHist.clear(); tempHist.clear(); powerHist.clear()
        prevTotal = 0L; prevIdle = 0L
    }

    // ---- sampler ----

    private suspend fun samplerLoop() {
        loadStaticCoreInfo()
        while (currentCoroutineContext().isActive) {
            val t0 = SystemClock.elapsedRealtime()
            val s = try {
                collect()
            } catch (e: CancellationException) {
                throw e
            } catch (_: Throwable) {
                null
            }
            if (s != null) {
                _sample.value = s
                checkThermal(s)
            }
            val spent = SystemClock.elapsedRealtime() - t0
            delay((intervalMs - spent).coerceAtLeast(100L))
        }
    }

    private class Raw(val stat: String?, val freqKhz: Map<Int, Long>, val latency: String?)

    private suspend fun collect(): TelemetrySample {
        val pkg = targetPackage
        val activeLayer = if (pkg != null) ensureLayer(pkg) else null
        val raw = readKernelAndLatency(activeLayer)

        // CPU
        val cpu = cpuPercent(raw.stat)

        // Cores
        val cores = raw.freqKhz.toSortedMap()
        val curMhz = cores.values.map { (it / 1000L).toInt() }
        val maxList = coreMaxMhz
        val maxMhz = cores.keys.map { idx -> maxList.getOrNull(idx) ?: 0 }

        // FPS
        var fps = -1f
        var source = FpsSource.NONE
        if (pkg != null) {
            val sf = raw.latency?.let { parseSurfaceFlingerFps(it) }
            if (sf != null) {
                fps = if (sf.newest == lastSfNewest) 0f else sf.fps
                lastSfNewest = sf.newest
                source = FpsSource.SURFACE_FLINGER
                layerMisses = 0
                setVsync(false)
            } else {
                if (activeLayer != null && ++layerMisses >= 3) {
                    layer = null; layerPkg = null; layerMisses = 0 // force rediscovery
                }
                setVsync(true)
                val v = vsyncRate()
                if (v >= 0f) {
                    fps = v
                    source = FpsSource.VSYNC
                }
            }
        } else {
            setVsync(false)
        }

        // Memory
        val avail = MemoryReader.availMb(ctx)
        val total = MemoryReader.totalMb(ctx)

        // Battery
        val b = readBattery()

        pushHistory(fpsHist, if (fps >= 0f) fps else 0f)
        pushHistory(cpuHist, if (cpu >= 0f) cpu else 0f)
        pushHistory(tempHist, b.tempC)
        pushHistory(powerHist, if (b.powerW >= 0f) b.powerW else 0f)

        return TelemetrySample(
            timestamp = System.currentTimeMillis(),
            fps = fps,
            fpsSource = source,
            fpsLayer = activeLayer.orEmpty(),
            cpuPct = cpu,
            coreCurMhz = curMhz,
            coreMaxMhz = maxMhz,
            availRamMb = avail,
            totalRamMb = total,
            batteryTempC = b.tempC,
            batteryPct = b.pct,
            voltageV = b.voltageV,
            currentMa = b.currentMa,
            powerW = b.powerW,
            charging = b.charging,
            overTemp = overTemp,
            ping = _ping.value,
            fpsHistory = fpsHist.toList(),
            cpuHistory = cpuHist.toList(),
            tempHistory = tempHist.toList(),
            powerHistory = powerHist.toList()
        )
    }

    private fun pushHistory(list: MutableList<Float>, v: Float) {
        list += v
        while (list.size > HISTORY) list.removeAt(0)
    }

    // ---- kernel reads (/proc/stat + cpufreq + surfaceflinger in ONE shell call when privileged) ----

    private suspend fun readKernelAndLatency(layerName: String?): Raw {
        if (bridge.hasShell()) {
            val r = bridge.shell(buildBatchScript(layerName), 4000L)
            if (r.ok || r.stdout.isNotBlank()) return parseBatch(r.stdout)
        }
        // Unprivileged path: whatever the kernel/SELinux lets a normal app read.
        val stat = runCatching {
            File("/proc/stat").bufferedReader().use { it.readLine() }
        }.getOrNull()?.takeIf { it.startsWith("cpu") }
        val freq = readCoreFreqDirect()
        val latency = if (layerName != null) dumpsys("SurfaceFlinger", "--latency", layerName) else null
        return Raw(stat, freq, latency)
    }

    private fun buildBatchScript(layerName: String?): String {
        val sb = StringBuilder()
        sb.append("head -n 1 /proc/stat; echo @@F; ")
        sb.append(
            "for d in /sys/devices/system/cpu/cpu[0-9]*; do n=\${d##*/cpu}; " +
                "c=\$(cat \$d/cpufreq/scaling_cur_freq 2>/dev/null); echo \"\$n \${c:-0}\"; done"
        )
        if (layerName != null) {
            sb.append("; echo @@S; dumpsys SurfaceFlinger --latency ").append(shQuote(layerName))
        }
        return sb.toString()
    }

    private fun parseBatch(out: String): Raw {
        var section = 0
        var stat: String? = null
        val freq = HashMap<Int, Long>()
        val lat = StringBuilder()
        for (line in out.lineSequence()) {
            if (line.startsWith("@@F")) { section = 1; continue }
            if (line.startsWith("@@S")) { section = 2; continue }
            when (section) {
                0 -> if (stat == null && line.startsWith("cpu")) stat = line
                1 -> {
                    val p = line.trim().split(' ')
                    val idx = p.getOrNull(0)?.toIntOrNull()
                    val v = p.getOrNull(1)?.toLongOrNull()
                    if (idx != null && v != null) freq[idx] = v
                }
                else -> lat.append(line).append('\n')
            }
        }
        return Raw(stat, freq, if (lat.isEmpty()) null else lat.toString())
    }

    private fun readCoreFreqDirect(): Map<Int, Long> {
        val out = HashMap<Int, Long>()
        val dirs = File("/sys/devices/system/cpu").listFiles() ?: return out
        for (d in dirs) {
            val m = CPU_DIR.matchEntire(d.name) ?: continue
            val idx = m.groupValues[1].toInt()
            val v = runCatching { File(d, "cpufreq/scaling_cur_freq").readText().trim().toLong() }.getOrDefault(0L)
            out[idx] = v
        }
        return out
    }

    private suspend fun loadStaticCoreInfo() {
        if (coreMaxLoaded) return
        val map = HashMap<Int, Long>()
        if (bridge.hasShell()) {
            val cmd = "for d in /sys/devices/system/cpu/cpu[0-9]*; do n=\${d##*/cpu}; " +
                "c=\$(cat \$d/cpufreq/cpuinfo_max_freq 2>/dev/null); echo \"\$n \${c:-0}\"; done"
            val r = bridge.shell(cmd, 4000L)
            for (line in r.stdout.lineSequence()) {
                val p = line.trim().split(' ')
                val idx = p.getOrNull(0)?.toIntOrNull() ?: continue
                val v = p.getOrNull(1)?.toLongOrNull() ?: continue
                map[idx] = v
            }
        } else {
            File("/sys/devices/system/cpu").listFiles()?.forEach { d ->
                val m = CPU_DIR.matchEntire(d.name) ?: return@forEach
                val v = runCatching { File(d, "cpufreq/cpuinfo_max_freq").readText().trim().toLong() }.getOrDefault(0L)
                map[m.groupValues[1].toInt()] = v
            }
        }
        if (map.isNotEmpty()) {
            val size = (map.keys.maxOrNull() ?: -1) + 1
            coreMaxMhz = List(size) { i -> ((map[i] ?: 0L) / 1000L).toInt() }
            coreMaxLoaded = true
        }
    }

    private fun cpuPercent(statLine: String?): Float {
        if (statLine == null) return -1f
        val f = statLine.trim().split(Regex("\\s+"))
        if (f.size < 9 || f[0] != "cpu") return -1f
        val nums = f.drop(1).take(8).map { it.toLongOrNull() ?: 0L }
        val total = nums.sum()
        val idle = nums[3] + nums[4]
        val pdt = total - prevTotal
        val pdi = idle - prevIdle
        val first = prevTotal == 0L
        prevTotal = total
        prevIdle = idle
        if (first || pdt <= 0L) return -1f
        return ((pdt - pdi).toFloat() / pdt.toFloat() * 100f).coerceIn(0f, 100f)
    }

    // ---- SurfaceFlinger layer discovery and FPS parsing ----

    private class SfReading(val fps: Float, val newest: Long)

    private suspend fun ensureLayer(pkg: String): String? {
        if (layer != null && layerPkg == pkg) return layer
        val now = SystemClock.elapsedRealtime()
        if (now - layerSearchAt < 4000L) return null
        layerSearchAt = now
        val list = dumpsys("SurfaceFlinger", "--list") ?: return null
        val chosen = chooseLayer(list, pkg)
        layer = chosen
        layerPkg = if (chosen != null) pkg else null
        return chosen
    }

    private fun chooseLayer(list: String, pkg: String): String? {
        var best: String? = null
        var bestScore = Int.MIN_VALUE
        for (raw in list.lineSequence()) {
            val name = raw.trim()
            if (name.isEmpty() || !name.contains(pkg)) continue
            if (name.contains('\'') || name.length > 300) continue
            var score = 0
            if (name.contains("SurfaceView")) score += 4
            if (name.contains("BLAST")) score += 2
            if (name.contains('#')) score += 1
            if (name.startsWith("Background for") || name.startsWith("Task=") ||
                name.startsWith("Letterbox") || name.startsWith("WindowToken") ||
                name.startsWith("ActivityRecord")
            ) score -= 5
            if (score > bestScore) {
                bestScore = score
                best = name
            }
        }
        return if (bestScore >= 0) best else null
    }

    /**
     * Output format: line 1 = refresh period (ns); then up to 127 lines of
     * "desiredPresent actualPresent frameReady" in CLOCK_MONOTONIC nanoseconds.
     * FPS = (frames - 1) / time span, over the newest 1 second of presented frames.
     */
    private fun parseSurfaceFlingerFps(text: String): SfReading? {
        val lines = text.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.toList()
        if (lines.size < 2) return null
        val stamps = ArrayList<Long>(128)
        for (i in 1 until lines.size) {
            val parts = lines[i].split(Regex("\\s+"))
            if (parts.size < 3) continue
            val t = parts[1].toLongOrNull() ?: continue
            if (t <= 0L || t == Long.MAX_VALUE) continue
            stamps += t
        }
        if (stamps.isEmpty()) return null
        val newest = stamps.max()
        val window = stamps.filter { it > newest - 1_000_000_000L }
        val fps = if (window.size >= 2) {
            val span = (window.max() - window.min()).toDouble() / 1e9
            if (span > 0.0) ((window.size - 1) / span).toFloat() else 0f
        } else {
            window.size.toFloat()
        }
        return SfReading(fps, newest)
    }

    // ---- Choreographer vsync fallback ----

    private fun setVsync(on: Boolean) {
        if (on == vsyncRequested) return
        vsyncRequested = on
        if (!on) vsyncLastNs = 0L
        mainHandler.post {
            vsyncWanted = on
            if (on && !vsyncPosted) {
                vsyncPosted = true
                Choreographer.getInstance().postFrameCallback(frameCallback)
            }
        }
    }

    /** Frames counted since the previous call. The first call after enabling only primes the counters. */
    private fun vsyncRate(): Float {
        val nowNs = System.nanoTime()
        val count = vsyncFrames.get()
        val prevNs = vsyncLastNs
        val prevCount = vsyncLastCount
        vsyncLastNs = nowNs
        vsyncLastCount = count
        if (prevNs == 0L) return -1f
        val dtNs = nowNs - prevNs
        val frames = count - prevCount
        if (dtNs <= 0L || frames < 0) return -1f
        return (frames * 1e9 / dtNs).toFloat()
    }

    // ---- dumpsys helper ----

    private class Battery(
        val tempC: Float,
        val pct: Int,
        val voltageV: Float,
        val currentMa: Int,
        val powerW: Float,
        val charging: Boolean
    )

    private fun shQuote(s: String): String = "'" + s + "'"

    private suspend fun dumpsys(vararg parts: String): String? {
        if (parts.any { it.contains('\'') || it.contains('\n') }) return null
        if (bridge.hasShell()) {
            val cmd = "dumpsys " + parts.joinToString(" ") { shQuote(it) }
            val r = bridge.shell(cmd, 3000L)
            return if (r.ok) r.stdout else null
        }
        if (ctx.checkSelfPermission(Manifest.permission.DUMP) == PackageManager.PERMISSION_GRANTED) {
            return localExec(arrayOf("dumpsys", *parts), 3000L)
        }
        return null
    }

    private suspend fun localExec(cmd: Array<String>, timeoutMs: Long): String? = withContext(Dispatchers.IO) {
        try {
            val p = ProcessBuilder(*cmd).redirectErrorStream(true).start()
            val out = async { runCatching { p.inputStream.bufferedReader().use { it.readText() } }.getOrDefault("") }
            val code = withTimeoutOrNull(timeoutMs) { runInterruptible { p.waitFor() } }
            if (code == null) {
                runCatching { p.destroy() }
                null
            } else {
                out.await()
            }
        } catch (_: Throwable) {
            null
        }
    }

    // ---- battery / power ----

    private fun readBattery(): Battery {
        val i: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val tempC = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        var mv = i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
        if (mv in 1..99) mv *= 1000 // a few devices report whole volts
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val pct = if (level >= 0 && scale > 0) (level * 100f / scale).roundToInt() else -1
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val raw = runCatching { bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) }
            .getOrDefault(Long.MIN_VALUE)
        val supported = raw != Long.MIN_VALUE && raw != Int.MIN_VALUE.toLong() && raw != 0L
        // The spec says microamps; some OEMs report milliamps. Real draw is never below ~20 mA while
        // the screen is on, so anything under 20000 is treated as milliamps.
        val ma = if (!supported) 0 else if (abs(raw) >= 20_000L) (abs(raw) / 1000L).toInt() else abs(raw).toInt()
        val volts = mv / 1000f
        val watts = if (supported && mv > 0) volts * (ma / 1000f) else -1f
        return Battery(tempC, pct, volts, ma, watts, charging)
    }

    // ---- thermal alert ----

    private fun checkThermal(s: TelemetrySample) {
        val limit = repo.global.value.tempAlertC
        val t = s.batteryTempC
        if (!overTemp && t >= limit) {
            overTemp = true
            val now = SystemClock.elapsedRealtime()
            if (now - lastAlertAt > 60_000L) {
                lastAlertAt = now
                val msg = String.format(Locale.US, "Battery %.1f C reached the %d C limit", t, limit)
                _alerts.tryEmit(TelemetryAlert("thermal", msg, t, limit))
                postThermalNotification(t, limit)
                vibrateAlert()
            }
        } else if (overTemp && t <= limit - 2) {
            overTemp = false
        }
    }

    private fun postThermalNotification(temp: Float, limit: Int) {
        runCatching {
            val allowed = Build.VERSION.SDK_INT < 33 ||
                ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            if (!allowed) return
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CHANNEL_THERMAL) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL_THERMAL, "Thermal alerts", NotificationManager.IMPORTANCE_HIGH)
                )
            }
            val n = Notification.Builder(ctx, CHANNEL_THERMAL)
                .setSmallIcon(R.drawable.ic_alert)
                .setContentTitle("Device is running hot")
                .setContentText(
                    String.format(Locale.US, "Battery %.1f C (limit %d C). Lower graphics or let it cool.", temp, limit)
                )
                .setAutoCancel(true)
                .build()
            nm.notify(NOTIF_THERMAL, n)
        }
    }

    @Suppress("DEPRECATION")
    private fun vibrateAlert() {
        runCatching {
            val v = ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
            if (!v.hasVibrator()) return
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 120, 80, 120), -1))
        }
    }

    // ---- ping and jitter ----

    private class PingWindow {
        val rtts = ArrayList<Double>()        // last 10 successful round trips (ms)
        val attempts = ArrayList<Boolean>()   // last 20 probe outcomes
        val history = ArrayList<Int>()        // last 60, -1 = lost

        fun add(ms: Double?) {
            if (ms != null) {
                rtts += ms
                while (rtts.size > 10) rtts.removeAt(0)
            }
            attempts += (ms != null)
            while (attempts.size > 20) attempts.removeAt(0)
            history += if (ms != null) max(1, ms.roundToInt()) else -1
            while (history.size > HISTORY) history.removeAt(0)
        }
    }

    private val pingWindows = ConcurrentHashMap<String, PingWindow>()
    private val dnsCache = ConcurrentHashMap<String, Pair<InetAddress, Long>>()

    private suspend fun pingLoop() {
        while (currentCoroutineContext().isActive) {
            val g = repo.global.value
            val t = g.pingTargets.getOrNull(pingIndex) ?: g.pingTargets.firstOrNull()
            if (t != null) {
                val key = t.host + ":" + t.port
                val w = pingWindows.getOrPut(key) { PingWindow() }
                val ms = probe(t)
                w.add(ms)
                _ping.value = statOf(t, w)
            }
            delay(g.pingIntervalMs.coerceIn(250L, 10_000L))
        }
    }

    private fun statOf(t: PingTarget, w: PingWindow): PingStat {
        val n = w.rtts.size
        val lost = w.attempts.count { !it }
        val loss = if (w.attempts.isEmpty()) 0 else (lost * 100f / w.attempts.size).roundToInt()
        if (n == 0) {
            return PingStat(t.name, t.host, lossPct = loss, history = w.history.toList())
        }
        val avg = w.rtts.average()
        var sq = 0.0
        for (v in w.rtts) sq += (v - avg) * (v - avg)
        val variance = sq / n
        return PingStat(
            targetName = t.name,
            host = t.host,
            lastMs = w.history.lastOrNull() ?: -1,
            avgMs = avg.roundToInt(),
            minMs = (w.rtts.minOrNull() ?: 0.0).roundToInt(),
            maxMs = (w.rtts.maxOrNull() ?: 0.0).roundToInt(),
            jitterMs = sqrt(variance).toFloat(),
            varianceMs2 = variance.toFloat(),
            lossPct = loss,
            history = w.history.toList()
        )
    }

    /** One probe. Returns round trip in ms, or null when lost. port <= 0 selects ICMP. */
    private suspend fun probe(t: PingTarget): Double? =
        if (t.port <= 0) icmpPing(t.host) else tcpPing(t.host, t.port)

    private suspend fun resolve(host: String): InetAddress? {
        val cached = dnsCache[host]
        val now = SystemClock.elapsedRealtime()
        if (cached != null && now - cached.second < 60_000L) return cached.first
        val deferred = scope.async(Dispatchers.IO) { runCatching { InetAddress.getByName(host) }.getOrNull() }
        val addr = withTimeoutOrNull(3000L) { deferred.await() }
        if (addr != null) dnsCache[host] = addr to now
        return addr
    }

    private suspend fun tcpPing(host: String, port: Int): Double? {
        val addr = resolve(host) ?: return null
        return withContext(Dispatchers.IO) {
            val s = Socket()
            try {
                val t0 = System.nanoTime()
                s.connect(InetSocketAddress(addr, port), 2000)
                (System.nanoTime() - t0) / 1e6
            } catch (_: Throwable) {
                dnsCache.remove(host)
                null
            } finally {
                runCatching { s.close() }
            }
        }
    }

    private suspend fun icmpPing(host: String): Double? {
        if (!com.hyperengine.gameturbo.core.Validators.HOST.matches(host)) return null
        val out = localExec(arrayOf("ping", "-c", "1", "-W", "2", host), 4000L) ?: return null
        val m = Regex("time[=<]\\s*([0-9]+(?:\\.[0-9]+)?)\\s*ms").find(out) ?: return null
        return m.groupValues[1].toDoubleOrNull()
    }

    /**
     * Measures every configured server region (several probes each) for the region selector.
     * Independent of the live loop; safe to call while sampling is running.
     */
    suspend fun probeAllTargets(probes: Int = 4): List<PingStat> = withContext(Dispatchers.IO) {
        repo.global.value.pingTargets.map { t ->
            val w = PingWindow()
            repeat(probes.coerceIn(1, 10)) {
                w.add(probe(t))
                delay(150L)
            }
            statOf(t, w)
        }
    }

    companion object {
        private const val HISTORY = 60
        private const val CHANNEL_THERMAL = "hyper_thermal"
        private const val NOTIF_THERMAL = 4201
        private val CPU_DIR = Regex("^cpu(\\d+)$")
    }
}
