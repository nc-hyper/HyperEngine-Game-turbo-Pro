package com.hyperengine.gameturbo.core

import android.content.pm.ApplicationInfo
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.zip.ZipFile

/**
 * The one definition of "this installed app is a game", shared by the foreground detector and the Game Space library
 * so they can never disagree again: the Game category, the legacy FLAG_IS_GAME, or a known game engine's native library.
 * Many games never declare the category (older titles, regional publishers, sideloaded builds); the engine library is a
 * reliable tell for them.
 */
object GameHeuristics {

    private val ENGINE_LIBS = listOf(
        "libunity", "libil2cpp", "libue4", "libunreal", "libcocos", "libgodot", "libgdx", "libgamemaker",
        "libdefold", "libcryengine", "libmonogame"
    )

    private class Verdict(val stamp: Long, val engine: Boolean)

    // Listing a native library folder is disk I/O, and the library screen asks about every installed app. The answer
    // only changes when the app is updated, so it is remembered against the APK's modification time.
    private val cache = ConcurrentHashMap<String, Verdict>()

    @Suppress("DEPRECATION")
    fun looksLikeGame(ai: ApplicationInfo): Boolean =
        ai.category == ApplicationInfo.CATEGORY_GAME ||
            (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0 ||
            hasEngineLibs(ai)

    /** True when the app ships the native library of a known game engine (Unity, Unreal, Cocos, Godot, libGDX ...). */
    fun hasEngineLibs(ai: ApplicationInfo): Boolean {
        val stamp = try { File(ai.sourceDir).lastModified() } catch (_: Throwable) { 0L }
        cache[ai.packageName]?.let { if (it.stamp == stamp) return it.engine }
        // Two places to look. Apps installed with extractNativeLibs=false (the default for modern builds and for split
        // installs) never unpack their libraries, so the folder is empty and the libraries only exist inside the APKs.
        val engine = inLibraryDir(ai) || inApks(ai)
        cache[ai.packageName] = Verdict(stamp, engine)
        return engine
    }

    private fun isEngineLib(fileName: String): Boolean {
        val n = fileName.lowercase()
        return ENGINE_LIBS.any { n.contains(it) }
    }

    private fun inLibraryDir(ai: ApplicationInfo): Boolean = try {
        File(ai.nativeLibraryDir).list().orEmpty().any { isEngineLib(it) }
    } catch (_: Throwable) {
        false
    }

    /** Reads only the APK's file list (its central directory), never the contents. Includes split APKs. */
    private fun inApks(ai: ApplicationInfo): Boolean {
        val paths = ArrayList<String>()
        ai.sourceDir?.let { paths.add(it) }
        ai.splitSourceDirs?.let { paths.addAll(it) }
        return paths.any { apk ->
            try {
                ZipFile(apk).use { zip ->
                    val entries = zip.entries()
                    var found = false
                    while (!found && entries.hasMoreElements()) {
                        val name = entries.nextElement().name
                        if (name.startsWith("lib/") && name.endsWith(".so") && isEngineLib(name.substringAfterLast('/'))) found = true
                    }
                    found
                }
            } catch (_: Throwable) {
                false
            }
        }
    }
}
