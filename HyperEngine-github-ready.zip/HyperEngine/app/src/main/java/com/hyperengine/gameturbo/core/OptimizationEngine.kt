package com.hyperengine.gameturbo.core

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.display.DisplayManager
import android.os.Build
import android.provider.Settings
import android.provider.Telephony
import android.telecom.TelecomManager
import android.view.Display
import com.hyperengine.gameturbo.data.DnsPreset
import com.hyperengine.gameturbo.data.GameProfile
import com.hyperengine.gameturbo.data.PrecompileMode
import com.hyperengine.gameturbo.data.GameProfileRepository
import com.hyperengine.gameturbo.data.SettingBackup
import com.hyperengine.gameturbo.data.SystemSnapshot
import com.hyperengine.gameturbo.data.VisualFilterConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

// ---------------------------------------------------------------------------------------------
// Public result / status types
// ---------------------------------------------------------------------------------------------

data class StepResult(val step: String, val ok: Boolean, val detail: String = "")

data class EngineLogLine(val time: Long, val step: String, val ok: Boolean, val detail: String)

data class FreezeReport(
    val requested: Int,
    val frozen: Int,
    val skippedProtected: Int,
    val skippedAlreadyRestricted: Int,
    val notInstalled: Int,
    val failed: Int,
    val availBeforeMb: Long,
    val availAfterMb: Long,
    val usedShell: Boolean
) {
    /** Real measured difference of MemoryInfo.availMem (after minus before). Can be negative. */
    val reclaimedMb: Long get() = availAfterMb - availBeforeMb
}

data class ApplyReport(
    val game: String,
    val steps: List<StepResult>,
    val freeze: FreezeReport?,
    val durationMs: Long
) {
    val failures: Int get() = steps.count { !it.ok }
}

data class RestoreReport(val reason: String, val steps: List<StepResult>, val complete: Boolean)

data class EngineStatus(
    val activeGame: String? = null,
    val sessionActive: Boolean = false,     // true while ANY system change is waiting to be restored
    val busy: String? = null,
    val restoreCountdownSec: Int? = null,
    val lastFreeze: FreezeReport? = null,
    val refreshHzNow: Int = 0,
    val log: List<EngineLogLine> = emptyList()
)

// ---------------------------------------------------------------------------------------------
// Session = everything we changed and how to undo it. Mirrors SystemSnapshot 1:1 so it can be
// rebuilt from disk after a crash or reboot.
// ---------------------------------------------------------------------------------------------

private class Session(var game: String, val startedAt: Long) {
    val backups = LinkedHashMap<String, SettingBackup>()      // "ns/key" -> original value
    var restrictBackground: Boolean? = null                    // value to restore to; null = untouched
    var whitelistUid: Int = -1
    var masterSync: Boolean? = null                            // value to restore to; null = untouched
    val frozen = LinkedHashSet<String>()                       // RUN_ANY_IN_BACKGROUND set to ignore by us
    val gameConfigPkgs = LinkedHashSet<String>()
    val gameModeOriginals = LinkedHashMap<String, String>()
    var availBeforeMb = 0L
    var pinned = false                                         // created by applyProfile for a running game
    var filterMatrix = false                                   // SurfaceFlinger colour matrix installed
    var overlayActive = false                                  // screen overlay (dimmer / brightness override) shown; memory only

    fun isEmpty(): Boolean =
        backups.isEmpty() && frozen.isEmpty() && gameConfigPkgs.isEmpty() && gameModeOriginals.isEmpty() &&
            restrictBackground == null && masterSync == null && whitelistUid < 0 && !filterMatrix && !overlayActive

    fun toSnapshot() = SystemSnapshot(
        gamePackage = game,
        takenAt = startedAt,
        settings = backups.values.toList(),
        restrictBackground = restrictBackground,
        masterSync = masterSync,
        frozenPackages = frozen.toList(),
        gameConfigChanged = gameConfigPkgs.isNotEmpty(),
        availMemBeforeMb = availBeforeMb,
        gameConfigPackages = gameConfigPkgs.toList(),
        gameModeOriginals = LinkedHashMap(gameModeOriginals),
        restrictWhitelistUid = whitelistUid,
        filterMatrixActive = filterMatrix
    )

    companion object {
        fun from(s: SystemSnapshot): Session = Session(s.gamePackage, s.takenAt).also {
            s.settings.forEach { b -> it.backups[b.ns + "/" + b.key] = b }
            it.restrictBackground = s.restrictBackground
            it.whitelistUid = s.restrictWhitelistUid
            it.masterSync = s.masterSync
            it.frozen.addAll(s.frozenPackages)
            it.gameConfigPkgs.addAll(s.gameConfigPackages)
            it.gameModeOriginals.putAll(s.gameModeOriginals)
            it.availBeforeMb = s.availMemBeforeMb
            it.filterMatrix = s.filterMatrixActive
        }
    }
}

// ---------------------------------------------------------------------------------------------
// The engine
// ---------------------------------------------------------------------------------------------

/**
 * Applies and (always) undoes every optimization. All commands go through SystemBridgeExecutor, so
 * each one runs through Shizuku/root when available and falls back to standard APIs otherwise. Every
 * result is the real command outcome; failures are reported, never hidden.
 *
 * Safety model:
 *  1. Before ANY value is changed, its original is captured and the snapshot is fsynced to disk.
 *  2. Restoration is driven from that snapshot, so it works after the process died or the phone rebooted.
 *  3. Partial failures keep only the unrestored items in the snapshot and are retried later.
 *  4. Backups are never overwritten, so repeated toggles always return to the true original.
 *
 * Phase 3 hooks: onGameForeground(pkg) / onGameBackground() (15 s default restore timer) and
 * recoverPendingRestore() at service start.
 */
class OptimizationEngine(
    context: Context,
    private val bridge: SystemBridgeExecutor,
    private val repo: GameProfileRepository
) {

    private val ctx: Context = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutex = Mutex()

    @Volatile private var session: Session? = null
    @Volatile private var restoreJob: Job? = null
    private val restoreJobLock = Any()

    private val _status = MutableStateFlow(EngineStatus())
    val status: StateFlow<EngineStatus> = _status.asStateFlow()

    /**
     * Set by the HUD controller. Receives the screen overlay to show (null = remove it) and returns
     * false when an overlay cannot be drawn (missing overlay permission / no HUD running).
     */
    @Volatile var overlayHook: ((OverlayState?) -> Boolean)? = null
    @Volatile private var overlay = OverlayState()

    private fun pushOverlay(): Boolean = overlayHook?.invoke(if (overlay.isNeutral) null else overlay) ?: false

    init {
        repo.loadSnapshot()?.let { snap ->
            session = Session.from(snap)
            publish()
        }
    }

    // =========================================================================================
    // Lifecycle entry points used by the foreground game watcher (Phase 3)
    // =========================================================================================

    /** Game came to the foreground: cancels a pending restore, or applies the profile if needed. */
    fun onGameForeground(pkg: String) {
        scope.launch {
            cancelPendingRestore()
            val needApply = mutex.withLock {
                val s = session
                s == null || !s.pinned || s.game != pkg
            }
            if (needApply) applyProfile(pkg)
        }
    }

    /** Game left the foreground: restores everything after the configured delay (default 15 s). */
    fun onGameBackground() {
        val s = session ?: return
        cancelPendingRestore()
        val delaySec = repo.global.value.restoreDelayFor(repo.profile(s.game))
        val job = scope.launch {
            var left = delaySec
            while (left > 0) {
                _status.update { it.copy(restoreCountdownSec = left) }
                delay(1000L)
                left--
            }
            _status.update { it.copy(restoreCountdownSec = null) }
            restoreInternal("game in background for more than ${delaySec}s")
        }
        synchronized(restoreJobLock) { restoreJob = job }
    }

    private fun cancelPendingRestore() {
        synchronized(restoreJobLock) {
            restoreJob?.cancel()
            restoreJob = null
        }
        _status.update { it.copy(restoreCountdownSec = null) }
    }

    /** Call once when the service starts: undoes leftovers from a crash/reboot when no game is running. */
    suspend fun recoverPendingRestore(): RestoreReport? =
        if (session == null) null else restoreInternal("recovery after restart")

    // =========================================================================================
    // Profile application
    // =========================================================================================

    suspend fun applyProfile(pkg: String): ApplyReport {
        if (!Validators.PACKAGE.matches(pkg)) {
            return ApplyReport(pkg, listOf(StepResult("Profile", false, "invalid package name")), null, 0L)
        }
        val profile = repo.profile(pkg) ?: repo.getOrCreate(pkg, appLabel(pkg))
        return applyProfile(profile)
    }

    suspend fun applyProfile(profile: GameProfile): ApplyReport {
        val pkg = profile.packageName
        val started = System.currentTimeMillis()
        cancelPendingRestore()

        if (!profile.enabled) {
            val r = StepResult("Profile", true, "profile disabled, nothing applied").also { record(it) }
            return ApplyReport(pkg, listOf(r), null, 0L)
        }

        // Switching games: put the phone back first so the new game's originals are the true originals.
        val current = mutex.withLock { session?.game }
        if (!current.isNullOrEmpty() && current != pkg) restoreInternal("switching to $pkg")

        setBusy("Applying profile for ${profile.label.ifBlank { pkg }}")
        val steps = ArrayList<StepResult>()
        var freeze: FreezeReport? = null
        try {
            inSession(pkg) { s ->
                s.pinned = true
                persist(s)

                // 1. native game mode + downscaler + fps cap
                steps += gameModeLocked(s, pkg, profile.gameMode, profile.downscale, profile.targetFps)

                // 2. refresh rate
                if (profile.refreshHz != 0) steps += refreshLocked(s, profile.refreshHz)
                steps += fpsDisplayCapLocked(s, profile.targetFps, profile.fpsCapViaDisplay, profile.refreshHz)

                // 3. compositor, input, brightness
                if (profile.zeroAnimation) steps += animationLocked(s, true)
                profile.pointerSpeed?.let { steps += pointerLocked(s, it) }
                if (profile.filter.brightnessLock) steps += brightnessLockLocked(s, profile.filter.brightnessLevel)
                if (profile.filter.enabled) steps += filterLocked(s, profile.filter)
                if (profile.longPressMs != null || profile.touchSensitivity) {
                    steps += touchLocked(s, profile.longPressMs, profile.touchSensitivity)
                }

                // 4. network
                if (profile.dns != DnsPreset.NO_CHANGE) steps += dnsLocked(s, profile.dns)
                if (profile.blockBackgroundData) steps += restrictBackgroundLocked(s, true)
                if (profile.pauseSync) steps += syncLocked(s, true)

                // 5. caches then freezer (freezer last so the RAM delta includes everything above)
                if (profile.trimCachesOnLaunch) steps += bridge.trimCaches().step("Trim caches")
                if (profile.freezeOnLaunch) {
                    val rep = freezeLocked(s, pkg, null)
                    freeze = rep
                    steps += StepResult(
                        "Background freezer",
                        rep.failed == 0,
                        "${rep.frozen} frozen, ${rep.skippedProtected} protected, " +
                            "${rep.skippedAlreadyRestricted} already restricted, ${rep.failed} failed, " +
                            "RAM reclaimed ${rep.reclaimedMb} MB"
                    )
                }
            }
        } finally {
            setBusy(null)
        }
        steps.forEach { record(it) }
        return ApplyReport(pkg, steps, freeze, System.currentTimeMillis() - started)
    }

    // =========================================================================================
    // Pre-launch maintenance (not part of applyProfile: compiling while the game runs would hurt it)
    // =========================================================================================

    /** Zero-Stutter Boost: ART compile per the profile, plus optional cache trim. Run BEFORE launching. */
    suspend fun prepareForLaunch(profile: GameProfile): List<StepResult> {
        val out = ArrayList<StepResult>()
        when (profile.precompile) {
            PrecompileMode.FAST -> out += compileGame(profile.packageName, CompileMode.FAST)
            PrecompileMode.FULL -> out += compileGame(profile.packageName, CompileMode.FULL)
            PrecompileMode.NONE -> Unit
        }
        if (profile.trimCachesOnLaunch) out += trimShaderCaches(false)
        return out
    }

    suspend fun compileGame(pkg: String, mode: CompileMode): StepResult {
        setBusy("Compiling $pkg (${mode.cmd})")
        try {
            return bridge.compilePackage(pkg, mode)
                .step("ART compile ${mode.cmd}", "compiled")
                .also { record(it) }
        } finally {
            setBusy(null)
        }
    }

    /** pm trim-caches 999G, optionally followed by cmd activity idle-maintenance. */
    suspend fun trimShaderCaches(runIdleMaintenance: Boolean): StepResult {
        setBusy("Trimming caches")
        try {
            val trim = bridge.trimCaches()
            val results = arrayListOf(trim)
            if (runIdleMaintenance) results += bridge.idleMaintenance()
            return results.step("Shader/Dalvik trim", "caches trimmed").also { record(it) }
        } finally {
            setBusy(null)
        }
    }

    // =========================================================================================
    // Live tools (used by sidebar toggles). Every one is tracked, so Restore always undoes it.
    // =========================================================================================

    suspend fun setGameMode(pkg: String, level: GameModeLevel, downscale: Float? = null, fps: Int = 0): List<StepResult> =
        inSession(pkg) { gameModeLocked(it, pkg, level, downscale, fps) }.logAll()

    /** Game mode + downscale + FPS cap, plus the display-rate lock that makes the cap hold in every game. */
    suspend fun setGameTuning(
        pkg: String, level: GameModeLevel, downscale: Float?, fps: Int, viaDisplay: Boolean, explicitHz: Int
    ): List<StepResult> = inSession(pkg) { s ->
        gameModeLocked(s, pkg, level, downscale, fps) + fpsDisplayCapLocked(s, fps, viaDisplay, explicitHz)
    }.logAll()

    /**
     * the colour-filter matrix. SurfaceFlinger holds only one, so it is multiplied with the profile's Visual filter
     * ([base]) instead of replacing it; [m] null removes the colour filter and keeps the Visual filter as it was.
     */
    suspend fun setGameFilterMatrix(m: FloatArray?, base: VisualFilterConfig, fallback: OverlayState? = null): StepResult =
        inSession("") { s -> extraMatrix = m; extraOverlay = fallback; lastBase = base; filterLocked(s, base) }.also { record(it) }

    @Volatile private var extraMatrix: FloatArray? = null
    @Volatile private var extraOverlay: OverlayState? = null     // drawn when the real matrix cannot be installed
    @Volatile private var lastBase: VisualFilterConfig? = null   // the Visual filter the current matrix was built with

    /**
     * Sends the current colour matrix to SurfaceFlinger again. The compositor drops it on screen off/on, display
     * mode switches and some ROM colour services, so the game filter keeper calls this every few seconds.
     * Returns false when there is nothing to re-send or the shell refused.
     */
    suspend fun reassertColorMatrix(): Boolean = mutex.withLock {
        val s = session
        if (s == null || !s.filterMatrix || !bridge.hasShell()) return@withLock false
        val base = lastBase
        val m = if (base != null && base.enabled && !ColorMath.isIdentity(base)) composedMatrix(base) else extraMatrix
        if (m == null) false else withContext(Dispatchers.IO) { bridge.setColorMatrix(m).ok }
    }

    private fun composedMatrix(cfg: VisualFilterConfig): FloatArray {
        val base = ColorMath.matrix(cfg)
        return extraMatrix?.let { GameFilterMath.multiply(it, base) } ?: base
    }

    suspend fun setVisualFilter(cfg: VisualFilterConfig): StepResult =
        inSession("") { filterLocked(it, cfg) }.also { record(it) }

    suspend fun clearVisualFilter(): StepResult =
        inSession("") { lastBase = null; clearFilterLocked(it) }.also { record(it) }

    /** longPressMs null = restore the original; sens false = restore the original. */
    suspend fun setTouchTweaks(longPressMs: Int?, sens: Boolean): List<StepResult> = inSession("") { s ->
        val out = ArrayList<StepResult>()
        if (longPressMs == null && s.backups.containsKey("secure/long_press_timeout")) {
            out += releaseKeys(s, LONGPRESS_KEYS).step("Long-press delay", "restored original")
        }
        if (!sens && s.backups.containsKey("system/high_touch_sensitivity_enable")) {
            out += releaseKeys(s, SENS_KEYS).step("Touch sensitivity", "restored original")
        }
        out += touchLocked(s, longPressMs, sens)
        out
    }.logAll()

    // ---- generic tracked writes (Phase 2 engines use these so restoreAll() always undoes them) ----

    /**
     * Writes any settings key through the same crash-safe snapshot as every other tool: the original is
     * captured and fsynced BEFORE the first change, and never overwritten, so Restore always returns the
     * true original.
     */
    suspend fun putTracked(ns: Ns, key: String, value: String): StepResult =
        inSession("") { s ->
            track(s, ns, key)
            bridge.putSetting(ns, key, value).step("${ns.cmd}/$key", "set to $value")
        }.also { record(it) }

    /** Puts the given keys back to their captured originals (keys we never touched are skipped). */
    suspend fun releaseTracked(keys: List<Pair<Ns, String>>): StepResult =
        inSession("") { s ->
            releaseKeys(s, keys).step("Restore ${keys.joinToString { it.second }}", "restored original")
        }.also { record(it) }

    /** True while a backup of this key is held, i.e. the engine still owns the change and will undo it. */
    fun isTracked(ns: Ns, key: String): Boolean = session?.backups?.containsKey(ns.cmd + "/" + key) == true

    /** True when the ROM exposes the OEM high-touch-sensitivity switch (Samsung-style key). */
    fun hasTouchSensitivityKey(): Boolean = bridge.getSetting(Ns.SYSTEM, "high_touch_sensitivity_enable") != null

    fun brightnessMax(): Int = bridge.brightnessMax()

    suspend fun resetGameTuning(pkg: String): List<StepResult> = inSession(pkg) { s ->
        val out = ArrayList<StepResult>()
        if ((repo.profile(pkg)?.refreshHz ?: 0) == 0 && s.backups.containsKey("system/peak_refresh_rate")) {
            out += releaseKeys(s, REFRESH_KEYS).step("FPS cap display lock", "released")
        }
        val orig = s.gameModeOriginals[pkg]?.let { levelOf(it) } ?: GameModeLevel.STANDARD
        val r1 = bridge.resetGameConfig(pkg)
        val r2 = bridge.setGameMode(pkg, orig)
        out += listOf(r1, r2).step("Reset game tuning", "back to ${orig.cmd}")
        if (r1.ok && r2.ok) {
            s.gameConfigPkgs -= pkg
            s.gameModeOriginals.remove(pkg)
        }
        out
    }.logAll()

    suspend fun lockRefreshRate(hz: Int): StepResult = inSession("") { refreshLocked(it, hz) }.also { record(it) }

    suspend fun unlockRefreshRate(): StepResult = inSession("") { s ->
        releaseKeys(s, REFRESH_KEYS).step("Refresh rate unlock", "restored original")
    }.also { record(it) }

    suspend fun setDns(preset: DnsPreset): StepResult = inSession("") { dnsLocked(it, preset) }.also { record(it) }

    suspend fun restoreDns(): StepResult = inSession("") { s ->
        releaseKeys(s, DNS_KEYS).step("DNS restore", "restored original")
    }.also { record(it) }

    suspend fun setZeroAnimation(on: Boolean): StepResult = inSession("") { s ->
        if (on) animationLocked(s, true)
        else releaseKeys(s, ANIM_KEYS).step("Animations restore", "restored original")
    }.also { record(it) }

    suspend fun setBackgroundDataBlock(on: Boolean): StepResult =
        inSession("") { restrictBackgroundLocked(it, on) }.also { record(it) }

    suspend fun setBackgroundSyncPaused(paused: Boolean): StepResult =
        inSession("") { syncLocked(it, paused) }.also { record(it) }

    suspend fun setPointerSpeed(speed: Int): StepResult = inSession("") { pointerLocked(it, speed) }.also { record(it) }

    suspend fun restorePointerSpeed(): StepResult = inSession("") { s ->
        releaseKeys(s, POINTER_KEYS).step("Pointer speed restore", "restored original")
    }.also { record(it) }

    suspend fun lockBrightness(level: Int): StepResult =
        inSession("") { brightnessLockLocked(it, level) }.also { record(it) }

    suspend fun unlockBrightness(): StepResult = inSession("") { s ->
        overlay = overlay.copy(brightness = -1f)
        pushOverlay()
        s.overlayActive = !overlay.isNeutral
        releaseKeys(s, BRIGHTNESS_KEYS).step("Brightness unlock", "restored original")
    }.also { record(it) }

    /** Freezes the given list (or the global Freeze List when null). Reports the real RAM delta. */
    suspend fun freezeNow(game: String, only: List<String>? = null): FreezeReport =
        inSession(game) { freezeLocked(it, game, only) }.also { r ->
            record(
                StepResult(
                    "Background freezer",
                    r.failed == 0,
                    "${r.frozen} frozen, RAM reclaimed ${r.reclaimedMb} MB"
                )
            )
        }

    // ---- read-only helpers for the UI ----

    fun supportedRefreshRates(): List<Int> {
        val d = defaultDisplay() ?: return emptyList()
        val cur = d.mode
        val all = d.supportedModes
        val sameRes = all.filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
        return (if (sameRes.isEmpty()) all.toList() else sameRes)
            .map { it.refreshRate.roundToInt() }.distinct().sorted()
    }

    fun maxRefreshRate(): Int = supportedRefreshRates().maxOrNull() ?: 0

    fun currentRefreshRate(): Int = defaultDisplay()?.refreshRate?.roundToInt() ?: 0

    fun currentDns(): Pair<String?, String?> =
        bridge.getSetting(Ns.GLOBAL, "private_dns_mode") to bridge.getSetting(Ns.GLOBAL, "private_dns_specifier")

    fun hasPendingRestore(): Boolean = session != null

    // =========================================================================================
    // Restoration
    // =========================================================================================

    /** Immediately restores everything (manual button, or end of game). */
    suspend fun restoreAll(reason: String = "manual"): RestoreReport {
        cancelPendingRestore()
        return restoreInternal(reason)
    }

    private suspend fun restoreInternal(reason: String): RestoreReport = withContext(NonCancellable + Dispatchers.IO) {
        mutex.withLock {
            val s = session
                ?: return@withLock RestoreReport(reason, listOf(StepResult("Restore", true, "nothing to restore")), true)
            setBusy("Restoring system settings")
            val steps = ArrayList<StepResult>()
            try {
                // 1. unfreeze apps
                if (s.frozen.isNotEmpty()) {
                    if (!bridge.hasShell()) {
                        steps += StepResult("Unfreeze apps", false, "needs Shizuku or root; will retry")
                    } else {
                        val okSet = unfreezeScript(s.frozen.toList())
                        s.frozen.removeAll(okSet)
                        steps += StepResult(
                            "Unfreeze apps",
                            s.frozen.isEmpty(),
                            "${okSet.size} restored to allow" + if (s.frozen.isEmpty()) "" else ", ${s.frozen.size} pending"
                        )
                    }
                }

                // 2. game mode + downscale overrides
                for (pkg in s.gameModeOriginals.keys.toList()) {
                    val orig = s.gameModeOriginals[pkg]?.let { levelOf(it) } ?: GameModeLevel.STANDARD
                    val needReset = pkg in s.gameConfigPkgs
                    val r1 = if (needReset) bridge.resetGameConfig(pkg) else CommandResult(true)
                    val r2 = bridge.setGameMode(pkg, orig)
                    val ok = r1.ok && r2.ok
                    steps += listOf(r1, r2).step("Game mode $pkg", "back to ${orig.cmd}")
                    if (ok) {
                        s.gameConfigPkgs -= pkg
                        s.gameModeOriginals.remove(pkg)
                    }
                }
                // config entries without a recorded mode (older snapshots)
                for (pkg in s.gameConfigPkgs.toList()) {
                    val r = bridge.resetGameConfig(pkg)
                    steps += r.step("Reset game config $pkg")
                    if (r.ok) s.gameConfigPkgs -= pkg
                }

                // 2b. visual filter: colour matrix lives in SurfaceFlinger (survives our process), overlay in memory
                if (s.filterMatrix) {
                    val r = bridge.setColorMatrix(null)
                    steps += r.step("Visual filter", "colour matrix removed")
                    if (r.ok) { s.filterMatrix = false; extraMatrix = null; extraOverlay = null; lastBase = null }
                }
                if (s.overlayActive || !overlay.isNeutral) {
                    overlay = OverlayState()
                    pushOverlay()
                    s.overlayActive = false
                    steps += StepResult("Screen overlay", true, "removed")
                }

                // 3. settings (refresh, animations, dns, pointer, brightness ...) in capture order
                var restored = 0
                val failures = ArrayList<String>()
                for ((id, b) in s.backups.entries.toList()) {
                    val ns = Ns.values().firstOrNull { it.cmd == b.ns }
                    if (ns == null) {
                        s.backups.remove(id)
                        continue
                    }
                    val r = bridge.restoreSetting(ns, b.key, b.original)
                    if (r.ok) {
                        s.backups.remove(id)
                        restored++
                    } else {
                        failures += "${b.ns}/${b.key}: ${r.message}"
                    }
                }
                if (restored > 0 || failures.isNotEmpty()) {
                    steps += StepResult(
                        "System settings",
                        failures.isEmpty(),
                        "$restored restored" + if (failures.isEmpty()) "" else "; failed: " + failures.joinToString(" | ")
                    )
                }

                // 4. Data Saver + whitelist
                val rb = s.restrictBackground
                if (rb != null) {
                    val r = bridge.setRestrictBackground(rb)
                    steps += r.step("Background data policy", "restored")
                    if (r.ok) s.restrictBackground = null
                }
                val uid = s.whitelistUid
                if (uid >= 0 && s.restrictBackground == null) {
                    val r = bridge.shell("cmd netpolicy remove restrict-background-whitelist $uid")
                    steps += r.step("Data Saver whitelist", "removed")
                    if (r.ok) s.whitelistUid = -1
                }

                // 5. account sync
                val ms = s.masterSync
                if (ms != null) {
                    val ok = bridge.setMasterSync(ms)
                    steps += StepResult("Account sync", ok, if (ok) "restored to $ms" else "setMasterSyncAutomatically failed")
                    if (ok) s.masterSync = null
                }

                val complete = s.isEmpty()
                if (complete) {
                    session = null
                    repo.clearSnapshot()
                } else {
                    s.pinned = false
                    persist(s)
                }
                steps.forEach { record(it) }
                publish()
                RestoreReport(reason, steps, complete)
            } finally {
                setBusy(null)
            }
        }
    }

    // =========================================================================================
    // Step implementations. All *Locked functions assume `mutex` is held through inSession().
    // =========================================================================================

    private suspend fun <T> inSession(game: String, block: suspend (Session) -> T): T = mutex.withLock {
        val s = session ?: Session(game, System.currentTimeMillis()).also {
            it.availBeforeMb = MemoryReader.availMb(ctx)
            session = it
        }
        if (s.game.isEmpty() && game.isNotEmpty()) s.game = game
        try {
            // disk fsync and settings reads must never run on the caller's (possibly main) thread
            withContext(Dispatchers.IO) { block(s) }
        } finally {
            withContext(NonCancellable + Dispatchers.IO) {
                if (s.isEmpty() && !s.pinned) {
                    session = null
                    repo.clearSnapshot()
                } else {
                    persist(s)
                }
                publish()
            }
        }
    }

    private fun persist(s: Session) = repo.saveSnapshotBlocking(s.toSnapshot())

    /** Captures the original BEFORE the caller writes. Never overwrites an existing backup. */
    private fun track(s: Session, ns: Ns, key: String) {
        val id = ns.cmd + "/" + key
        if (s.backups.containsKey(id)) return
        s.backups[id] = SettingBackup(ns.cmd, key, bridge.getSetting(ns, key))
        persist(s)
    }

    private fun trackKeys(s: Session, keys: List<Pair<Ns, String>>) = keys.forEach { track(s, it.first, it.second) }

    private suspend fun releaseKeys(s: Session, keys: List<Pair<Ns, String>>): List<CommandResult> {
        val res = ArrayList<CommandResult>()
        for ((ns, key) in keys) {
            val id = ns.cmd + "/" + key
            val b = s.backups[id] ?: continue
            val r = bridge.restoreSetting(ns, key, b.original)
            if (r.ok) s.backups.remove(id)
            res += r
        }
        persist(s)
        return res
    }

    // ---- game mode, downscaler, fps cap ----

    private suspend fun gameModeLocked(
        s: Session,
        pkg: String,
        level: GameModeLevel,
        downscale: Float?,
        fps: Int
    ): List<StepResult> {
        val out = ArrayList<StepResult>()
        if (!s.gameModeOriginals.containsKey(pkg)) {
            // If the current mode cannot be read we record "standard": restoring to the system default
            // is still better than leaving Wild Boost on after the game.
            s.gameModeOriginals[pkg] = (readGameMode(pkg) ?: GameModeLevel.STANDARD).cmd
            persist(s)
        }
        val m = bridge.setGameMode(pkg, level)
        out += m.step("Game mode ${level.cmd}", "switched")
        val wantsConfig = level != GameModeLevel.STANDARD && (downscale != null || fps > 0)
        run {
            if (wantsConfig) {
                s.gameConfigPkgs += pkg
                persist(s)
                val r = bridge.setGameConfig(pkg, level, downscale, fps)
                out += r.step(
                    "Downscale and FPS cap",
                    "downscale=" + (downscale?.let { String.format(Locale.US, "%.2f", it) } ?: "off") +
                        " fps=" + (if (fps > 0) fps.toString() else "off")
                )
            } else if (pkg in s.gameConfigPkgs) {
                val r = bridge.resetGameConfig(pkg)
                out += r.step("Clear downscale and FPS cap", "cleared")
                if (r.ok) s.gameConfigPkgs -= pkg
            }
        }
        return out
    }

    private suspend fun readGameMode(pkg: String): GameModeLevel? {
        if (!bridge.hasShell() || !Validators.PACKAGE.matches(pkg)) return null
        val r = bridge.shell("cmd game list-modes $pkg", 8000L)
        if (!r.ok) return null
        val m = Regex("(?i)current\\W*(?:game\\W*)?mode\\W+(\\w+)").find(r.stdout) ?: return null
        return when (m.groupValues[1].lowercase(Locale.US)) {
            "battery", "3" -> GameModeLevel.BATTERY
            "performance", "2" -> GameModeLevel.PERFORMANCE
            "standard", "1" -> GameModeLevel.STANDARD
            else -> null
        }
    }

    private fun levelOf(cmd: String): GameModeLevel? = GameModeLevel.values().firstOrNull { it.cmd == cmd }

    // ---- refresh rate ----

    private fun defaultDisplay(): Display? =
        (ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY)

    /** requested: -1 = max supported; otherwise the nearest supported rate. */
    private fun resolveHz(requested: Int, rates: List<Int>): Int {
        if (requested == 0) return 0
        if (rates.isEmpty()) return if (requested < 0) 60 else requested
        return if (requested < 0) rates.max() else rates.minByOrNull { abs(it - requested) } ?: requested
    }

    private fun shouldWriteMiuiKey(): Boolean {
        val m = Build.MANUFACTURER.lowercase(Locale.US)
        return m.contains("xiaomi") || m.contains("redmi") || m.contains("poco") || m.contains("blackshark") ||
            bridge.getSetting(Ns.SECURE, "miui_refresh_rate") != null
    }

    private suspend fun refreshLocked(s: Session, requestedHz: Int): StepResult {
        if (requestedHz == 0) return StepResult("Refresh rate", true, "untouched")
        val rates = supportedRefreshRates()
        val hz = resolveHz(requestedHz, rates)
        val miui = shouldWriteMiuiKey()
        trackKeys(s, REFRESH_KEYS.filter { miui || it.second != "miui_refresh_rate" })
        val f = String.format(Locale.US, "%.1f", hz.toFloat())
        val results = ArrayList<CommandResult>()
        results += bridge.putSetting(Ns.SYSTEM, "peak_refresh_rate", f)
        results += bridge.putSetting(Ns.SYSTEM, "min_refresh_rate", f)
        results += bridge.putSetting(Ns.SECURE, "user_refresh_rate", f)
        if (miui) results += bridge.putSetting(Ns.SECURE, "miui_refresh_rate", hz.toString())
        delay(600L)
        val now = currentRefreshRate()
        _status.update { it.copy(refreshHzNow = now) }
        val note = "requested $hz Hz (panel supports ${rates.joinToString("/")}), display reports $now Hz"
        val okCount = results.count { it.ok }
        return if (okCount > 0) {
            StepResult("Refresh rate lock", true, note + if (okCount < results.size) " (some keys rejected)" else "")
        } else {
            StepResult("Refresh rate lock", false, results.joinToString("; ") { it.message })
        }
    }

    // ---- compositor / input / brightness ----

    private suspend fun animationLocked(s: Session, zero: Boolean): StepResult {
        trackKeys(s, ANIM_KEYS)
        return bridge.setAnimationScales(if (zero) 0f else 1f).step("Zero-animation mode", "animations off")
    }

    private suspend fun pointerLocked(s: Session, speed: Int): StepResult {
        trackKeys(s, POINTER_KEYS)
        return bridge.setPointerSpeed(speed).step("Pointer speed", "set to ${speed.coerceIn(-7, 7)}")
    }

    /**
     * level255 is the stored 0..255 level; it is scaled to this device's real brightness range (many ROMs
     * use 2047/4095). The value is read back to prove the ROM accepted it, and a window-level brightness
     * override is applied as a second layer that is independent of the ROM's scale.
     */
    private suspend fun brightnessLockLocked(s: Session, level255: Int): StepResult {
        trackKeys(s, BRIGHTNESS_KEYS)
        val frac = level255.coerceIn(3, 255) / 255f
        val maxB = bridge.brightnessMax()
        val value = maxOf(1, (frac * maxB).roundToInt())
        val pct = (frac * 100f).roundToInt()
        val mode = bridge.putSetting(Ns.SYSTEM, "screen_brightness_mode", "0")
        val set = bridge.putSetting(Ns.SYSTEM, "screen_brightness", value.toString())
        val back = bridge.getSetting(Ns.SYSTEM, "screen_brightness")?.toIntOrNull()
        overlay = overlay.copy(brightness = frac)
        val windowOk = pushOverlay()
        s.overlayActive = !overlay.isNeutral
        val sysOk = mode.ok && set.ok && back == value
        return when {
            sysOk -> StepResult(
                "Brightness lock", true,
                "manual mode, $value of $maxB ($pct%)" + if (windowOk) ", window override on" else ""
            )
            windowOk -> StepResult(
                "Brightness lock", true,
                "window override $pct% active; system setting " +
                    (if (!set.ok) "rejected: " + set.message else "read back $back, wanted $value")
            )
            else -> StepResult(
                "Brightness lock", false,
                if (!set.ok) set.message else "ROM ignored the write (read back $back, wanted $value) and the overlay permission is missing"
            )
        }
    }

    // ---- fps cap through the display ----

    /** Smallest panel rate that is a whole multiple of the cap (clean frame pacing), else the next one up. */
    private fun capRate(fps: Int, rates: List<Int>): Int {
        if (rates.isEmpty()) return fps
        rates.firstOrNull { it >= fps && it % fps == 0 }?.let { return it }
        rates.firstOrNull { it >= fps }?.let { return it }
        return rates.max()
    }

    /**
     * `cmd game set --fps` only works for games the ROM's GameManager accepts overrides for. Locking the
     * panel's refresh rate to the cap works for EVERY game, because nothing can be shown faster than the
     * panel refreshes. An explicit refresh-rate choice in the profile always wins.
     */
    private suspend fun fpsDisplayCapLocked(s: Session, fps: Int, viaDisplay: Boolean, explicitHz: Int): List<StepResult> {
        if (explicitHz != 0 || !viaDisplay) return emptyList()
        if (fps <= 0) {
            if (!s.backups.containsKey("system/peak_refresh_rate")) return emptyList()
            return listOf(releaseKeys(s, REFRESH_KEYS).step("FPS cap display lock", "released"))
        }
        val hz = capRate(fps, supportedRefreshRates())
        val st = refreshLocked(s, hz)
        return listOf(
            st.copy(
                step = "FPS cap via display lock",
                detail = if (st.ok) "panel locked to $hz Hz, so no game can exceed it (cap $fps FPS). " + st.detail else st.detail
            )
        )
    }

    // ---- visual filter ----

    private suspend fun filterLocked(s: Session, cfg: VisualFilterConfig): StepResult {
        lastBase = cfg
        if (!cfg.enabled || ColorMath.isIdentity(cfg)) return clearFilterLocked(s)
        var why: String? = null
        if (bridge.hasShell()) {
            val r = bridge.setColorMatrix(composedMatrix(cfg))
            if (r.ok) {
                s.filterMatrix = true
                persist(s)
                overlay = overlay.copy(veilAlpha = 0f, tintColor = 0, tintAlpha = 0f, liftAlpha = 0f)
                pushOverlay()
                s.overlayActive = !overlay.isNeutral
                return StepResult(
                    "Visual filter", true,
                    "real colour matrix: saturation ${cfg.saturationPct}%, RGB ${cfg.redPct}/${cfg.greenPct}/${cfg.bluePct}, " +
                        "shadow +${cfg.shadowBoostPct}%, dim ${cfg.extraDimPct}%"
                )
            }
            why = r.message
        }
        overlay = ColorMath.overlayFor(cfg, overlay.brightness)
        val shown = pushOverlay()
        s.overlayActive = !overlay.isNeutral
        return if (shown) {
            StepResult(
                "Visual filter", true,
                "overlay mode: dimmer, tint and shadow lift only. Saturation needs Shizuku or root" +
                    (why?.let { " ($it)" } ?: "")
            )
        } else {
            StepResult("Visual filter", false, (why ?: "needs Shizuku or root for colour grading") + "; overlay permission is also missing")
        }
    }

    private suspend fun clearFilterLocked(s: Session): StepResult {
        // Visual filter is off but the game colour filter is on: keep its matrix instead of clearing everything.
        val extra = extraMatrix
        if (extra != null) {
            // Used to fall through to "filter off, ok" when SurfaceFlinger refused, so the UI said success and
            // nothing changed. Now a refusal is reported, and the overlay approximation is drawn instead.
            var why = "needs Shizuku or root for colour grading"
            if (bridge.hasShell()) {
                val fr = bridge.setColorMatrix(extra)
                if (fr.ok) {
                    s.filterMatrix = true
                    persist(s)
                    overlay = overlay.copy(veilAlpha = 0f, tintColor = 0, tintAlpha = 0f, liftAlpha = 0f)
                    pushOverlay()
                    s.overlayActive = !overlay.isNeutral
                    return StepResult("Visual filter", true, "real colour matrix installed")
                }
                why = fr.message
            }
            val fb = extraOverlay
            if (fb != null && !fb.isNeutral) {
                overlay = fb.copy(brightness = overlay.brightness)
                val shown = pushOverlay()
                s.overlayActive = !overlay.isNeutral
                return StepResult(
                    "Visual filter", shown,
                    if (shown) "overlay mode: only night mode and HDR lift can be drawn ($why)"
                    else "$why; overlay permission is missing too"
                )
            }
            return StepResult("Visual filter", false, why)
        }
        var ok = true
        var msg = "filter off"
        if (s.filterMatrix) {
            val r = bridge.setColorMatrix(null)
            if (r.ok) s.filterMatrix = false else { ok = false; msg = r.message }
            persist(s)
        }
        overlay = overlay.copy(veilAlpha = 0f, tintColor = 0, tintAlpha = 0f, liftAlpha = 0f)
        pushOverlay()
        s.overlayActive = !overlay.isNeutral
        return StepResult("Visual filter", ok, msg)
    }

    // ---- touch response ----

    private suspend fun touchLocked(s: Session, longPressMs: Int?, sens: Boolean): List<StepResult> {
        val out = ArrayList<StepResult>()
        if (longPressMs != null) {
            trackKeys(s, LONGPRESS_KEYS)
            val v = longPressMs.coerceIn(100, 1500)
            out += bridge.putSetting(Ns.SECURE, "long_press_timeout", v.toString()).step("Long-press delay", "$v ms")
        }
        if (sens && hasTouchSensitivityKey()) {
            trackKeys(s, SENS_KEYS)
            out += bridge.putSetting(Ns.SYSTEM, "high_touch_sensitivity_enable", "1").step("Touch sensitivity", "high")
        }
        return out
    }

    // ---- network ----

    private suspend fun dnsLocked(s: Session, preset: DnsPreset): StepResult {
        if (preset == DnsPreset.NO_CHANGE) return StepResult("Private DNS", true, "unchanged")
        trackKeys(s, DNS_KEYS)
        return bridge.setPrivateDns(preset.mode, preset.host).step("Private DNS ${preset.label}", "applied")
    }

    private suspend fun restrictBackgroundLocked(s: Session, on: Boolean): StepResult {
        if (!on) {
            val out = ArrayList<CommandResult>()
            val rb = s.restrictBackground
            if (rb != null) {
                val r = bridge.setRestrictBackground(rb)
                out += r
                if (r.ok) s.restrictBackground = null
            }
            val uid = s.whitelistUid
            if (uid >= 0 && s.restrictBackground == null) {
                val r = bridge.shell("cmd netpolicy remove restrict-background-whitelist $uid")
                out += r
                if (r.ok) s.whitelistUid = -1
            }
            persist(s)
            return if (out.isEmpty()) StepResult("Background data block", true, "nothing to undo")
            else out.step("Background data block off", "restored")
        }
        if (bridge.isRestrictBackgroundOn()) {
            return StepResult("Background data block", true, "Data Saver already on, left untouched")
        }
        // Our own uid must stay online (ping radar) while every other background app is blocked.
        val uid = ctx.applicationInfo.uid
        s.whitelistUid = uid
        s.restrictBackground = false
        persist(s)
        val results = ArrayList<CommandResult>()
        if (bridge.hasShell()) {
            results += bridge.shell("cmd netpolicy add restrict-background-whitelist $uid")
        }
        results += bridge.setRestrictBackground(true)
        val applied = results.last().ok
        if (!applied) {
            s.restrictBackground = null
            s.whitelistUid = -1
            persist(s)
        }
        return StepResult(
            "Background data block",
            applied,
            if (applied) "Data Saver forced on, own uid whitelisted"
            else results.filter { !it.ok }.joinToString("; ") { it.message }
        )
    }

    private fun syncLocked(s: Session, pause: Boolean): StepResult {
        if (pause) {
            if (!bridge.isMasterSyncOn()) return StepResult("Account sync", true, "already off, left untouched")
            s.masterSync = true
            persist(s)
            val ok = bridge.setMasterSync(false)
            if (!ok) {
                s.masterSync = null
                persist(s)
            }
            return StepResult("Pause account sync", ok, if (ok) "paused" else "setMasterSyncAutomatically failed")
        }
        val orig = s.masterSync ?: return StepResult("Account sync", true, "nothing to undo")
        val ok = bridge.setMasterSync(orig)
        if (ok) s.masterSync = null
        persist(s)
        return StepResult("Resume account sync", ok, if (ok) "resumed" else "setMasterSyncAutomatically failed")
    }

    // ---- Brevent-style freezer ----

    private fun isInstalled(pkg: String): Boolean = try {
        @Suppress("DEPRECATION")
        ctx.packageManager.getPackageInfo(pkg, 0)
        true
    } catch (_: Throwable) {
        false
    }

    private fun protectedPackages(game: String): Set<String> {
        val set = hashSetOf(
            ctx.packageName, "android", "com.android.systemui", "com.android.phone",
            "com.android.server.telecom", "com.android.providers.telephony",
            "com.android.providers.settings", "moe.shizuku.privileged.api"
        )
        if (game.isNotEmpty()) set += game
        runCatching {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            ctx.packageManager.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)
                ?.activityInfo?.packageName?.let { set += it }
        }
        runCatching {
            Settings.Secure.getString(ctx.contentResolver, "default_input_method")
                ?.substringBefore('/')?.takeIf { it.isNotBlank() }?.let { set += it }
        }
        runCatching {
            (ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).defaultDialerPackage?.let { set += it }
        }
        runCatching { Telephony.Sms.getDefaultSmsPackage(ctx)?.let { set += it } }
        return set
    }

    /**
     * With a shell: for each app, RUN_ANY_IN_BACKGROUND -> ignore, then am force-stop, then one am kill-all.
     * Apps that were already restricted by the user are skipped so restoring never loosens their choice.
     * Without a shell: ActivityManager.killBackgroundProcesses only (no persistent appop change).
     * The list is written to the snapshot BEFORE any appop is touched.
     */
    private suspend fun freezeLocked(s: Session, game: String, only: List<String>?): FreezeReport {
        val requested = (only ?: repo.global.value.freezeList).distinct().filter { Validators.PACKAGE.matches(it) }
        val protectedSet = protectedPackages(game)
        val candidates = ArrayList<String>()
        var skippedProtected = 0
        var notInstalled = 0
        for (p in requested) {
            when {
                p in protectedSet -> skippedProtected++
                !isInstalled(p) -> notInstalled++
                else -> candidates += p
            }
        }

        val before = MemoryReader.availBytes(ctx)
        var frozen = 0
        var failed = 0
        var alreadyRestricted = 0
        val useShell = bridge.hasShell()

        if (useShell) {
            s.frozen.addAll(candidates)
            persist(s)
            for (chunk in candidates.chunked(12)) {
                val script = buildString {
                    append("for p in ").append(chunk.joinToString(" ")).append("; do ")
                    append("m=\$(cmd appops get \$p RUN_ANY_IN_BACKGROUND 2>/dev/null | head -n 1); ")
                    append("case \"\$m\" in *ignore*|*deny*) echo \"\$p SKIP\";; ")
                    append("*) cmd appops set \$p RUN_ANY_IN_BACKGROUND ignore >/dev/null 2>&1; a=\$?; ")
                    append("am force-stop \$p >/dev/null 2>&1; b=\$?; echo \"\$p DONE \$a \$b\";; esac; done")
                }
                val r = bridge.shell(script, 60_000L)
                val seen = HashSet<String>()
                for (line in r.stdout.lineSequence()) {
                    val t = line.trim().split(' ')
                    if (t.size < 2) continue
                    val pkg = t[0]
                    if (pkg !in chunk) continue
                    seen += pkg
                    when (t[1]) {
                        "SKIP" -> {
                            alreadyRestricted++
                            s.frozen.remove(pkg)
                        }
                        "DONE" -> {
                            val a = t.getOrNull(2)?.toIntOrNull() ?: 1
                            val b = t.getOrNull(3)?.toIntOrNull() ?: 1
                            if (a == 0 && b == 0) {
                                frozen++
                            } else {
                                failed++
                                if (a != 0) s.frozen.remove(pkg) // appop was not changed, nothing to undo
                            }
                        }
                    }
                }
                for (pkg in chunk) if (pkg !in seen) {
                    failed++
                    s.frozen.remove(pkg)
                }
                persist(s)
            }
            bridge.killAllBackground()
        } else {
            for (p in candidates) {
                val r = bridge.forceStop(p)
                if (r.ok) frozen++ else failed++
            }
        }

        delay(800L) // let the kernel actually return the pages before measuring
        val after = MemoryReader.availBytes(ctx)
        val mb = 1024L * 1024L
        val report = FreezeReport(
            requested = requested.size,
            frozen = frozen,
            skippedProtected = skippedProtected,
            skippedAlreadyRestricted = alreadyRestricted,
            notInstalled = notInstalled,
            failed = failed,
            availBeforeMb = before / mb,
            availAfterMb = after / mb,
            usedShell = useShell
        )
        _status.update { it.copy(lastFreeze = report) }
        return report
    }

    /** Sets RUN_ANY_IN_BACKGROUND back to allow. Returns the packages that succeeded. */
    private suspend fun unfreezeScript(pkgs: List<String>): Set<String> {
        val ok = HashSet<String>()
        for (chunk in pkgs.filter { Validators.PACKAGE.matches(it) }.chunked(12)) {
            val script = "for p in ${chunk.joinToString(" ")}; do " +
                "cmd appops set \$p RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1; echo \"\$p \$?\"; done"
            val r = bridge.shell(script, 60_000L)
            for (line in r.stdout.lineSequence()) {
                val t = line.trim().split(' ')
                if (t.size == 2 && t[0] in chunk && t[1] == "0") ok += t[0]
            }
        }
        // entries that no longer validate cannot be restored and must not block the session forever
        pkgs.filter { !Validators.PACKAGE.matches(it) }.forEach { ok += it }
        return ok
    }

    // =========================================================================================
    // Status / logging helpers
    // =========================================================================================

    private fun publish() {
        val s = session
        _status.update {
            it.copy(
                activeGame = s?.game?.takeIf { g -> g.isNotEmpty() },
                sessionActive = s != null
            )
        }
    }

    private fun setBusy(text: String?) {
        _status.update { it.copy(busy = text) }
    }

    private fun record(r: StepResult) {
        _status.update {
            it.copy(log = (it.log + EngineLogLine(System.currentTimeMillis(), r.step, r.ok, r.detail)).takeLast(100))
        }
    }

    private fun List<StepResult>.logAll(): List<StepResult> = also { list -> list.forEach { record(it) } }

    private fun appLabel(pkg: String): String = try {
        @Suppress("DEPRECATION")
        ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (_: Throwable) {
        pkg
    }

    private fun CommandResult.step(name: String, okText: String = ""): StepResult =
        StepResult(name, ok, if (ok) okText else message)

    private fun List<CommandResult>.step(name: String, okText: String = ""): StepResult {
        val bad = filter { !it.ok }
        return if (bad.isEmpty()) StepResult(name, true, okText)
        else StepResult(name, false, bad.joinToString("; ") { it.message })
    }

    companion object {
        private val REFRESH_KEYS = listOf(
            Ns.SYSTEM to "peak_refresh_rate",
            Ns.SYSTEM to "min_refresh_rate",
            Ns.SECURE to "user_refresh_rate",
            Ns.SECURE to "miui_refresh_rate"
        )
        private val ANIM_KEYS = listOf(
            Ns.GLOBAL to "window_animation_scale",
            Ns.GLOBAL to "transition_animation_scale",
            Ns.GLOBAL to "animator_duration_scale"
        )
        // specifier first, mode second: restore order matters for hostname mode
        private val DNS_KEYS = listOf(
            Ns.GLOBAL to "private_dns_specifier",
            Ns.GLOBAL to "private_dns_mode"
        )
        private val POINTER_KEYS = listOf(Ns.SYSTEM to "pointer_speed")
        private val LONGPRESS_KEYS = listOf(Ns.SECURE to "long_press_timeout")
        private val SENS_KEYS = listOf(Ns.SYSTEM to "high_touch_sensitivity_enable")
        private val BRIGHTNESS_KEYS = listOf(
            Ns.SYSTEM to "screen_brightness_mode",
            Ns.SYSTEM to "screen_brightness"
        )
    }
}
