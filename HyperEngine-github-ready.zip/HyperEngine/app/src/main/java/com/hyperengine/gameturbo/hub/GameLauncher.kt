package com.hyperengine.gameturbo.hub

import android.content.Intent
import android.content.res.ColorStateList
import android.widget.ProgressBar
import android.widget.TextView
import com.hyperengine.gameturbo.core.CompileMode
import com.hyperengine.gameturbo.core.GameModeLevel
import com.hyperengine.gameturbo.core.StepResult
import com.hyperengine.gameturbo.data.GameProfile
import com.hyperengine.gameturbo.service.GameDetectorService
import com.hyperengine.gameturbo.ui.ChipGroup
import com.hyperengine.gameturbo.ui.Ui
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * "Boost & Play": runs the real pre-launch work (ART compile / cache trim per the profile), applies the
 * whole profile through the optimization engine, then opens the game. The progress text comes from
 * the engine's own status, not from a timer.
 *
 * The game watcher is started if needed so the sidebar HUD appears and the phone is restored
 * automatically after the game closes.
 */
object GameLauncher {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    @Volatile
    private var busy = false

    fun boostAndPlay(host: HubHost, entry: GameEntry) {
        if (busy) {
            host.toast("Already preparing a game")
            return
        }
        val intent = host.library.launchIntent(entry.pkg)
        if (intent == null) {
            host.toast("${entry.label} has no launcher entry and cannot be opened", true)
            return
        }
        val profile = host.repo.profile(entry.pkg) ?: host.repo.getOrCreate(entry.pkg, entry.label)
        if (!profile.enabled) {
            host.toast("This profile is turned off, opening the game without a boost")
            start(host, intent, entry.pkg, guard = false)
            return
        }

        busy = true
        if (!GameDetectorService.state.value.running) GameDetectorService.start(host.activity)

        val dialog = HubDialog(host, "Preparing ${entry.label}").setCancelable(false)
        val spinner = ProgressBar(host.activity).apply {
            isIndeterminate = true
            indeterminateTintList = ColorStateList.valueOf(host.theme.accent)
        }
        dialog.add(spinner, 10)
        val status: TextView = dialog.text("Starting...", host.theme.textPrimary, 13f)
        dialog.show()

        val watch = scope.launch {
            host.engine.status.collect { st -> status.text = st.busy ?: "Applying the profile..." }
        }
        scope.launch {
            try {
                val pre = host.engine.prepareForLaunch(profile) +
                    com.hyperengine.gameturbo.HyperApp.instance.wild.prepareForLaunch(profile)
                val rep = host.engine.applyProfile(profile)
                watch.cancel()
                dialog.dismiss()
                val failed = pre.filter { !it.ok } + rep.steps.filter { !it.ok }
                if (failed.isEmpty()) {
                    start(host, intent, entry.pkg, guard = true)
                    val f = rep.freeze
                    host.toast(
                        if (f != null) "Boost applied  |  ${f.availAfterMb} MB free (${signed(f.reclaimedMb)} MB), ${f.frozen} apps frozen"
                        else "Boost applied"
                    )
                } else {
                    showFailures(host, entry, intent, failed)
                }
            } catch (t: Throwable) {
                watch.cancel()
                dialog.dismiss()
                host.toast("Boost failed: ${t.message ?: t.javaClass.simpleName}", true)
            } finally {
                busy = false
            }
        }
    }

    private fun showFailures(host: HubHost, entry: GameEntry, intent: Intent, failed: List<StepResult>) {
        val lines = failed.take(8).joinToString("\n") { "${it.step}: ${it.detail.take(110)}" } +
            if (failed.size > 8) "\nand ${failed.size - 8} more" else ""
        val d = HubDialog(host, "${failed.size} step(s) did not apply")
        d.text(lines, host.theme.textPrimary, 12f)
        d.text(
            "Most of these need Shizuku or root. Everything that did apply is still active and is restored when the game closes.",
            host.theme.textSecondary, 11f
        )
        d.button("Cancel and restore") {
            scope.launch { host.engine.restoreAll("boost cancelled by the user") }
        }
        d.button("Launch anyway", filled = true) { start(host, intent, entry.pkg, guard = true) }
        d.show()
    }

    private fun start(host: HubHost, intent: Intent, pkg: String, guard: Boolean) {
        try {
            host.activity.startActivity(intent)
        } catch (t: Throwable) {
            host.toast("Could not open the game: ${t.message ?: "unknown error"}", true)
            if (guard) host.engine.onGameBackground()
            return
        }
        if (guard) watchLaunch(host, pkg)
    }

    /**
     * If the game never reaches the foreground (crashed, blocked, user backed out) the watcher never
     * sees it, so nothing would restore the phone. 25 s after launch, hand the session to the engine's
     * normal timed restore. Skipped when the watcher cannot detect games at all: restoring then would
     * undo the boost in the middle of a real play session.
     */
    private fun watchLaunch(host: HubHost, pkg: String) {
        scope.launch {
            delay(25_000L)
            val st = GameDetectorService.state.value
            if (!st.running || st.problem != null) return@launch
            if (st.game != pkg && host.engine.status.value.activeGame == pkg) host.engine.onGameBackground()
        }
    }

    private fun signed(v: Long): String = if (v >= 0) "+$v" else v.toString()
}

/** The sheet that opens from a card's menu button, a grid tile, or a long press. */
object GameActions {

    private val MODES = listOf(GameModeLevel.BATTERY, GameModeLevel.STANDARD, GameModeLevel.PERFORMANCE)

    private fun ensure(host: HubHost, e: GameEntry): GameProfile =
        host.repo.profile(e.pkg) ?: host.repo.getOrCreate(e.pkg, e.label)

    fun show(host: HubHost, e: GameEntry) {
        val theme = host.theme
        val profile = host.repo.profile(e.pkg)
        val d = HubDialog(host, e.label)
        d.text(e.pkg, theme.textSecondary, 10f, mono = true)
        d.text(GameText.summary(profile), theme.textPrimary, 12f)

        d.row("Boost & Play", "Apply this game's profile, then open it", filled = true) {
            GameLauncher.boostAndPlay(host, e)
        }

        // 3-tier mode switch, saved immediately and applied live if this game is the active one
        d.add(Ui.section(host.activity, theme, "Game mode"), 0)
        val current = MODES.indexOf(profile?.gameMode ?: GameModeLevel.PERFORMANCE).coerceAtLeast(0)
        d.add(
            ChipGroup(host.activity, theme, listOf("Battery saver", "Balanced", "Wild Boost"), current, 3) { i ->
                val level = MODES[i]
                val p = ensure(host, e)
                host.repo.update(e.pkg) { it.copy(gameMode = level) }
                if (host.engine.status.value.activeGame == e.pkg) {
                    host.scope.launch {
                        val steps = host.engine.setGameMode(e.pkg, level, p.downscale, p.targetFps)
                        val bad = steps.firstOrNull { !it.ok }
                        host.toast(
                            if (bad == null) "${GameText.modeLabel(level)} applied to the running game"
                            else "Saved, but the live switch failed: ${bad.detail.take(80)}",
                            bad != null
                        )
                    }
                } else {
                    host.toast("${GameText.modeLabel(level)} saved for ${e.label}")
                }
            },
            2
        )

        val enabled = profile?.enabled ?: true
        d.row(
            if (enabled) "Profile is ON" else "Profile is OFF",
            if (enabled) "Tap to turn it off. The game is then ignored by auto-boost." else "Tap to turn auto-boost back on for this game."
        ) {
            ensure(host, e)
            host.repo.update(e.pkg) { it.copy(enabled = !enabled) }
        }

        d.add(Ui.section(host.activity, theme, "Zero-Stutter Boost"), 0)
        d.row("Fast optimize (speed-profile)", "Compiles the game's code ahead of time. Needs Shizuku or root.") {
            compile(host, e, CompileMode.FAST)
        }
        d.row("Full AOT compile (speed)", "Maximum CPU speed, uses more storage and takes longer.") {
            compile(host, e, CompileMode.FULL)
        }

        d.add(Ui.section(host.activity, theme, "Manage"), 0)
        host.rulesEditor?.let { open ->
            d.row("Rules and automation", "Refresh rate, resolution, DNS, HUD tools and more") { open(e.pkg) }
        }
        d.row("App info", "Open Android's settings page for this game") { HubIntents.appDetails(host, e.pkg) }
        d.row("Reset profile to defaults", "Clears every custom value for this game") {
            HubDialog.confirm(host, "Reset ${e.label}?", "All per-game tuning, crosshair, macro and timer settings go back to their defaults.", "Reset") {
                host.repo.upsert(GameProfile(packageName = e.pkg, label = e.label))
                host.toast("Profile reset")
            }
        }
        d.row("Hide from Game Space", "Removes it from this list. The profile is kept.") {
            host.repo.updateGlobal { g -> if (e.pkg in g.hubHidden) g else g.copy(hubHidden = g.hubHidden + e.pkg) }
            host.toast("${e.label} hidden. Use Add to bring it back.")
        }
        d.button("Close")
        d.show()
    }

    private fun compile(host: HubHost, e: GameEntry, mode: CompileMode) {
        ensure(host, e)
        host.toast("Compiling ${e.label}. Large games can take a few minutes.", true)
        host.scope.launch {
            val r = host.engine.compileGame(e.pkg, mode)
            HubDialog.info(
                host,
                if (r.ok) "Compile finished" else "Compile failed",
                (if (r.ok) "${e.label} was compiled with ${mode.cmd}." else r.detail.take(300)) +
                    if (r.ok && r.detail.isNotBlank()) "\n\n${r.detail.take(200)}" else ""
            )
        }
    }
}
