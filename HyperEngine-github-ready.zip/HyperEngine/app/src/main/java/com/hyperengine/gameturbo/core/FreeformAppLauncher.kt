package com.hyperengine.gameturbo.core

import android.app.ActivityOptions
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Point
import android.graphics.Rect
import android.provider.Settings
import android.view.WindowManager
import com.hyperengine.gameturbo.data.AppsConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.Locale

/** One launchable app. [activity] is the launcher activity class name. */
data class AppEntry(
    val label: String,
    val pkg: String,
    val activity: String,
    val system: Boolean
)

data class LaunchReport(val ok: Boolean, val message: String)

/**
 * Lists EVERY app that has a launcher icon (user and system) and opens it in a full-size floating (freeform)
 * window over the game instead of a postage stamp.
 *
 * Launch order, each step reported honestly:
 *  1. ActivityOptions with launch bounds and WINDOWING_MODE_FREEFORM (5, set by reflection: the setter is hidden).
 *     This is how launcher apps open floating windows; it needs no privileges on ROMs that allow freeform.
 *  2. With Shizuku or root: `am start --windowingMode 5`, then `am task resize` to the same bounds.
 *
 * Android only draws a freeform window when the ROM supports it (a developer option on stock Android, native on
 * many HyperOS / ColorOS builds). When it does not, the app still opens, full screen, and the result says so.
 * [setFreeformSupport] flips the two developer switches (needs Shizuku / root) for ROMs where it is just off.
 */
class FreeformAppLauncher(
    private val ctx: Context,
    private val bridge: SystemBridgeExecutor
) {

    private val app: Context = ctx.applicationContext

    /** Every launcher app on the phone, sorted by name. Own package is left out. */
    @Suppress("DEPRECATION")
    fun loadAll(): List<AppEntry> {
        val pm = app.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val infos = runCatching { pm.queryIntentActivities(intent, 0) }.getOrDefault(emptyList())
        return infos.mapNotNull { ri ->
            val ai = ri.activityInfo ?: return@mapNotNull null
            if (ai.packageName == app.packageName) return@mapNotNull null
            val flags = ai.applicationInfo?.flags ?: 0
            val system = (flags and ApplicationInfo.FLAG_SYSTEM) != 0 && (flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
            AppEntry(ri.loadLabel(pm)?.toString().orEmpty().ifBlank { ai.packageName }, ai.packageName, ai.name, system)
        }.distinctBy { it.pkg + "/" + it.activity }.sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    fun freeformAvailable(): Boolean =
        app.packageManager.hasSystemFeature(PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT) ||
            runCatching { Settings.Global.getInt(app.contentResolver, "enable_freeform_support", 0) == 1 }.getOrDefault(false)

    @Suppress("DEPRECATION")
    private fun screen(): Point {
        val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return Point().also { wm.defaultDisplay.getRealSize(it) }
    }

    /**
     * The window rectangle: 85% of the height and 45% of the width in landscape (both adjustable), or about
     * 420 x 720 dp in portrait, centred and never larger than the screen.
     */
    fun bounds(cfg: AppsConfig): Rect {
        val s = screen()
        val d = app.resources.displayMetrics.density
        val landscape = s.x > s.y
        val w: Int
        val h: Int
        if (landscape) {
            w = (s.x * cfg.widthPct.coerceIn(25, 90) / 100f).toInt()
            h = (s.y * cfg.heightPct.coerceIn(40, 98) / 100f).toInt()
        } else {
            w = minOf((420 * d).toInt(), (s.x * 0.96f).toInt())
            h = minOf((720 * d).toInt(), (s.y * 0.90f).toInt())
        }
        val left = (s.x - w) / 2
        val top = (s.y - h) / 2
        return Rect(left, top, left + w, top + h)
    }

    suspend fun launch(entry: AppEntry, cfg: AppsConfig): LaunchReport = withContext(Dispatchers.Main) {
        val rect = bounds(cfg)
        val comp = ComponentName(entry.pkg, entry.activity)
        val sizeText = "${rect.width() * 100 / screen().x}% x ${rect.height() * 100 / screen().y}%"
        val free = freeformAvailable()

        // 1. ActivityOptions
        var optionsError: String? = null
        try {
            val intent = Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER)
                .setComponent(comp)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            var modeSet = false
            if (free) {
                // Bounds and a freeform windowing mode are only sent to ROMs that really have freeform windows.
                // Forcing them on a ROM without it is what made apps open broken or crash.
                HiddenApiUnlock.ensure()
                val opts = ActivityOptions.makeBasic()
                opts.setLaunchBounds(rect)
                modeSet = runCatching {
                    ActivityOptions::class.java.getMethod("setLaunchWindowingMode", Int::class.javaPrimitiveType).invoke(opts, 5)
                    true
                }.getOrDefault(false)
                app.startActivity(intent, opts.toBundle())
            } else {
                app.startActivity(intent)
            }
            return@withContext LaunchReport(
                true,
                when {
                    free && modeSet -> "Opened in a floating window ($sizeText of the screen)"
                    free -> "Opened with floating bounds ($sizeText). The windowing-mode switch is blocked on this ROM."
                    else -> "Opened. This phone has no freeform windows, so it fills the screen. " +
                        (if (bridge.hasShell()) "Use Enable freeform below, then reboot if needed." else "Start Shizuku to enable freeform.")
                }
            )
        } catch (t: Throwable) {
            optionsError = t.message ?: t.javaClass.simpleName
        }

        // 2. privileged shell (freeform ROMs only; a windowing mode the ROM lacks just breaks the app)
        if (free && bridge.hasShell()) {
            val flat = entry.pkg + "/" + entry.activity
            if (SAFE_COMPONENT.matches(flat)) {
                val r = bridge.shell("am start -n '" + flat.replace("$", "\\$") + "' --windowingMode 5")
                val out = r.stdout + " " + r.stderr
                if (r.ok && !out.contains("Error", true) && !out.contains("Exception", true)) {
                    val resized = resizeTask(entry.pkg, rect)
                    return@withContext LaunchReport(
                        true,
                        if (resized) "Opened in a floating window ($sizeText) through Shizuku"
                        else "Opened through Shizuku. It could not be resized, so the ROM's default floating size is used."
                    )
                }
                optionsError = (optionsError ?: "") + " / shell: " + out.trim().take(120)
            }
        }
        LaunchReport(false, "Could not open ${entry.label}: ${optionsError ?: "unknown error"}")
    }

    /** Opens the app in the other half of the screen. Works only when the game is already in split-screen. */
    fun launchAdjacent(entry: AppEntry): LaunchReport = try {
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(ComponentName(entry.pkg, entry.activity))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT)
        app.startActivity(intent)
        LaunchReport(true, "Opened. It sits beside the game only if the game is already in split-screen.")
    } catch (t: Throwable) {
        LaunchReport(false, "Could not open it: " + (t.message ?: t.javaClass.simpleName))
    }

    /** Finds the freshly opened task and gives it the requested bounds. */
    private suspend fun resizeTask(pkg: String, r: Rect): Boolean {
        delay(450L)
        val dump = bridge.shell("dumpsys activity activities | grep -E 'Task\\{'", 6_000L)
        if (!dump.ok && dump.stdout.isBlank()) return false
        val id = Regex("Task\\{[0-9a-fA-F]+ #(\\d+)[^}]*A=\\d+:" + Regex.escape(pkg))
            .find(dump.stdout)?.groupValues?.get(1)?.toIntOrNull() ?: return false
        val res = bridge.shell("am task resize $id ${r.left} ${r.top} ${r.right} ${r.bottom}")
        return res.ok && !(res.stdout + res.stderr).contains("Error", true)
    }

    /**
     * Turns the two developer switches for freeform windows on or off. They are persistent and most ROMs apply
     * them after a reboot, so this is an explicit button and is never undone automatically.
     */
    suspend fun setFreeformSupport(on: Boolean): List<StepResult> {
        val v = if (on) "1" else "0"
        val a = bridge.putSetting(Ns.GLOBAL, "enable_freeform_support", v)
        // force_resizable_activities is always written as 0 now. Turning it on forces apps that are not built to
        // be resized into resizable windows, which makes many of them crash. It also repairs phones where an
        // earlier version of this app switched it on.
        val b = bridge.putSetting(Ns.GLOBAL, "force_resizable_activities", "0")
        return listOf(
            StepResult("enable_freeform_support = $v", a.ok, if (a.ok) "set" else a.message),
            StepResult("force_resizable_activities = 0", b.ok, if (b.ok) "set (keeps apps from crashing)" else b.message)
        )
    }

    private companion object {
        val SAFE_COMPONENT = Regex("^[A-Za-z0-9_.]+/[A-Za-z0-9_.$]+$")
    }
}
