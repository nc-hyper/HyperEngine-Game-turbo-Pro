package com.hyperengine.gameturbo.core

import android.content.Context
import android.graphics.Point
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import com.hyperengine.gameturbo.data.KbmConfig
import com.hyperengine.gameturbo.data.KbmKeyNode
import com.hyperengine.gameturbo.service.TouchMacroService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.sqrt

/** Mouse buttons are stored as negative key codes in [KbmKeyNode.keyCode]. */
object KbmCodes {
    const val MOUSE_LEFT = -1
    const val MOUSE_RIGHT = -2
    const val MOUSE_MIDDLE = -3

    fun isMouse(code: Int) = code < 0

    fun name(code: Int): String = when (code) {
        MOUSE_LEFT -> "Left click"
        MOUSE_RIGHT -> "Right click"
        MOUSE_MIDDLE -> "Middle click"
        else -> KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_").replace('_', ' ').lowercase()
            .replaceFirstChar { it.uppercase() }
    }

    /** Short text for the on-screen node. */
    fun short(code: Int): String = when (code) {
        MOUSE_LEFT -> "LMB"
        MOUSE_RIGHT -> "RMB"
        MOUSE_MIDDLE -> "MMB"
        KeyEvent.KEYCODE_SPACE -> "Space"
        KeyEvent.KEYCODE_SHIFT_LEFT, KeyEvent.KEYCODE_SHIFT_RIGHT -> "Shift"
        KeyEvent.KEYCODE_CTRL_LEFT, KeyEvent.KEYCODE_CTRL_RIGHT -> "Ctrl"
        KeyEvent.KEYCODE_ALT_LEFT, KeyEvent.KEYCODE_ALT_RIGHT -> "Alt"
        KeyEvent.KEYCODE_TAB -> "Tab"
        KeyEvent.KEYCODE_ENTER -> "Enter"
        else -> name(code).take(5)
    }
}

/** Starter layout (battle-royale style). Positions are fractions of the screen; the editor moves them. */
object KbmPreset {
    fun default(): KbmConfig = KbmConfig(
        enabled = true,
        joystick = true,
        joyX = 0.17f, joyY = 0.72f, joyRadius = 0.10f,
        nodes = listOf(
            KbmKeyNode(KeyEvent.KEYCODE_SPACE, 0.88f, 0.60f, false, "Jump"),
            KbmKeyNode(KeyEvent.KEYCODE_C, 0.80f, 0.82f, false, "Crouch"),
            KbmKeyNode(KeyEvent.KEYCODE_Z, 0.91f, 0.78f, false, "Prone"),
            KbmKeyNode(KeyEvent.KEYCODE_R, 0.70f, 0.86f, false, "Reload"),
            KbmKeyNode(KeyEvent.KEYCODE_F, 0.62f, 0.48f, false, "Interact"),
            KbmKeyNode(KeyEvent.KEYCODE_E, 0.55f, 0.20f, false, "Item"),
            KbmKeyNode(KeyEvent.KEYCODE_Q, 0.30f, 0.20f, false, "Lean"),
            KbmKeyNode(KeyEvent.KEYCODE_1, 0.62f, 0.10f, false, "Slot 1"),
            KbmKeyNode(KeyEvent.KEYCODE_2, 0.68f, 0.10f, false, "Slot 2"),
            KbmKeyNode(KeyEvent.KEYCODE_3, 0.74f, 0.10f, false, "Slot 3"),
            KbmKeyNode(KbmCodes.MOUSE_LEFT, 0.83f, 0.66f, true, "Fire"),
            KbmKeyNode(KbmCodes.MOUSE_RIGHT, 0.93f, 0.42f, false, "Scope")
        )
    )
}

data class KbmStatus(
    val running: Boolean = false,
    val keyboardSeen: Boolean = false,
    val lastKey: String = "",
    val injectionOk: Boolean = true,
    val note: String = ""
)

/**
 * Turns a physical (USB OTG or Bluetooth) keyboard and mouse into real multi-touch for a touch game.
 *
 *  W A S D     one synthetic finger placed on the on-screen joystick and pushed in the pressed direction
 *              (diagonals are normalised, so W + D is not faster than W)
 *  other keys  a tap on the mapped screen point, or a held finger while the key is held ("hold" nodes)
 *  mouse       left / right / middle button press the mapped points (Android 14+ reports mouse buttons to
 *              accessibility services; before that only the system's own click-to-tap applies)
 *
 * Keys arrive through the accessibility service, which only forwards events from real external keyboards (the
 * on-screen keyboard and the phone's own buttons are ignored). Touches are injected with synthetic pointer slots
 * through [SyntheticPointerTable], so the player's own fingers are never cancelled. Without Shizuku or root the
 * tap nodes fall back to accessibility taps, but a held joystick cannot be done that way and is reported.
 *
 * Mapped keys are consumed so the game does not also see them as a keyboard event.
 */
class KbmMapper(
    private val ctx: Context,
    private val bridge: SystemBridgeExecutor
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val app: Context = ctx.applicationContext

    @Volatile
    private var cfg = KbmConfig()

    @Volatile
    private var running = false

    /** While set, the next physical key press is handed to this callback (and consumed) instead of being mapped. */
    @Volatile
    var capture: ((keyCode: Int) -> Unit)? = null

    private val dirs = BooleanArray(4)           // up, left, down, right
    private var joyDown = false
    private val held = HashMap<Int, Int>()       // key code -> synthetic slot
    private var lastButtons = 0

    private val _status = MutableStateFlow(KbmStatus())
    val status: StateFlow<KbmStatus> = _status.asStateFlow()

    fun start(config: KbmConfig) {
        cfg = config
        if (!config.enabled) {
            stop()
            return
        }
        if (!running) {
            running = true
            TouchMacroService.addKeyHandler(HANDLER_ID) { onKey(it) }
            TouchMacroService.mouseListener = { onMouse(it) }
        }
        _status.value = _status.value.copy(running = true, note = if (bridge.hasShell()) "" else "No Shizuku: held joystick is unavailable")
    }

    /** Registers the key handler without enabling any mapping, so the editor can capture keys. */
    fun beginEdit() {
        if (running) return
        running = true
        TouchMacroService.addKeyHandler(HANDLER_ID) { onKey(it) }
        TouchMacroService.mouseListener = { onMouse(it) }
    }

    fun endEdit() {
        capture = null
        if (!cfg.enabled) stop()
    }

    fun update(config: KbmConfig) {
        if (running || config.enabled) start(config) else cfg = config
    }

    fun stop() {
        if (running) {
            TouchMacroService.removeKeyHandler(HANDLER_ID)
            TouchMacroService.mouseListener = null
        }
        running = false
        releaseEverything()
        _status.value = KbmStatus()
    }

    fun destroy() {
        stop()
        scope.cancel()
    }

    /** Asks for the next key press. Used by the editor's "Add key" button. */
    fun captureNextKey(onKey: (Int) -> Unit) {
        capture = { code ->
            capture = null
            onKey(code)
        }
    }

    // =========================================================================================

    private fun isHardwareKeyboard(ev: KeyEvent): Boolean {
        val d: InputDevice = ev.device ?: return false
        if (d.isVirtual) return false
        return d.keyboardType == InputDevice.KEYBOARD_TYPE_ALPHABETIC &&
            (d.sources and InputDevice.SOURCE_KEYBOARD) == InputDevice.SOURCE_KEYBOARD
    }

    private fun onKey(ev: KeyEvent): Boolean {
        if (!running) return false
        if (!isHardwareKeyboard(ev)) return false
        val code = ev.keyCode
        val down = ev.action == KeyEvent.ACTION_DOWN

        capture?.let { cb ->
            if (down && ev.repeatCount == 0) cb(code)
            return true
        }
        val c = cfg
        if (!c.enabled) return false
        _status.value = _status.value.copy(keyboardSeen = true, lastKey = KbmCodes.name(code))

        if (c.joystick) {
            val idx = when (code) {
                c.upKey -> 0
                c.leftKey -> 1
                c.downKey -> 2
                c.rightKey -> 3
                else -> -1
            }
            if (idx >= 0) {
                if (ev.repeatCount == 0) {
                    dirs[idx] = down
                    pushJoystick(c)
                }
                return true
            }
        }
        val node = c.nodes.firstOrNull { it.keyCode == code } ?: return false
        if (ev.repeatCount == 0) {
            if (down) press(node) else release(node)
        }
        return true
    }

    private fun onMouse(ev: MotionEvent) {
        if (!running) return
        val c = cfg
        if (!c.enabled) return
        val b = ev.buttonState
        val changed = b xor lastButtons
        lastButtons = b
        if (changed == 0) return
        val map = listOf(
            MotionEvent.BUTTON_PRIMARY to KbmCodes.MOUSE_LEFT,
            MotionEvent.BUTTON_SECONDARY to KbmCodes.MOUSE_RIGHT,
            MotionEvent.BUTTON_TERTIARY to KbmCodes.MOUSE_MIDDLE
        )
        for ((mask, code) in map) {
            if ((changed and mask) == 0) continue
            val node = c.nodes.firstOrNull { it.keyCode == code } ?: continue
            if ((b and mask) != 0) press(node) else release(node)
        }
    }

    // ---- touches ----

    private fun screen(): Point {
        val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        @Suppress("DEPRECATION")
        return Point().also { wm.defaultDisplay.getRealSize(it) }
    }

    /** Slots 1..3 are for key nodes; slot 0 is the joystick. */
    private fun freeSlot(): Int? = (1..3).firstOrNull { s -> !bridge.pointers.isDown(s) }

    private fun press(node: KbmKeyNode) {
        val s = screen()
        val x = node.x * s.x
        val y = node.y * s.y
        if (bridge.hasShell()) {
            val slot = freeSlot()
            if (slot != null) {
                if (node.hold) {
                    if (bridge.pointers.down(slot, x, y)) {
                        held[node.keyCode] = slot
                        return
                    }
                } else {
                    scope.launch {
                        if (!bridge.pointers.tap(slot, x, y, 35L)) accessibilityTap(x, y, 40L)
                    }
                    return
                }
            }
        }
        // no injector (or it refused): a plain accessibility tap, which cannot be held
        scope.launch { accessibilityTap(x, y, if (node.hold) 120L else 40L) }
    }

    private suspend fun accessibilityTap(x: Float, y: Float, ms: Long) {
        TouchMacroService.instance?.tap(x, y, ms)
    }

    private fun release(node: KbmKeyNode) {
        val slot = held.remove(node.keyCode) ?: return
        bridge.pointers.up(slot)
    }

    private fun pushJoystick(c: KbmConfig) {
        if (!bridge.hasShell()) {
            _status.value = _status.value.copy(injectionOk = false, note = "The joystick needs Shizuku or root (a held finger cannot be made by accessibility)")
            return
        }
        var dx = (if (dirs[3]) 1f else 0f) - (if (dirs[1]) 1f else 0f)
        var dy = (if (dirs[2]) 1f else 0f) - (if (dirs[0]) 1f else 0f)
        if (dx == 0f && dy == 0f) {
            if (joyDown) bridge.pointers.up(0)
            joyDown = false
            return
        }
        val len = sqrt(dx * dx + dy * dy)
        dx /= len
        dy /= len
        val s = screen()
        val cx = c.joyX * s.x
        val cy = c.joyY * s.y
        val r = c.joyRadius * s.y
        val tx = cx + dx * r
        val ty = cy + dy * r
        val ok = if (!joyDown) {
            val a = bridge.pointers.down(0, cx, cy)
            joyDown = a
            a && bridge.pointers.move(0, tx, ty)
        } else {
            bridge.pointers.move(0, tx, ty)
        }
        _status.value = _status.value.copy(injectionOk = ok, note = if (ok) "" else "Injection was refused by the system")
    }

    private fun releaseEverything() {
        for (i in dirs.indices) dirs[i] = false
        if (joyDown) runCatching { bridge.pointers.up(0) }
        joyDown = false
        for ((_, slot) in held) runCatching { bridge.pointers.up(slot) }
        held.clear()
        lastButtons = 0
        capture = null
    }

    private companion object {
        const val HANDLER_ID = "kbm"
    }
}
