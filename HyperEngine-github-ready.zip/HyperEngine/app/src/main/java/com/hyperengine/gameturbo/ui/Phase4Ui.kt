package com.hyperengine.gameturbo.ui

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.widget.LinearLayout
import android.widget.TextView
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce

/**
 * Small widgets shared by the Phase 4 tool pages (crosshair studio, FPS pill, edge guard).
 * Everything is built in code so it works inside the overlay windows.
 */
object ToolUi {

    fun note(host: ToolHost, text: String): TextView =
        Ui.label(host.hostContext, text, 11f, host.theme.textSecondary).apply {
            setPadding(0, 0, 0, Ui.dp(host.hostContext, 8))
        }

    /** A setting row with a HyperOS switch. (Was a CheckBox; every caller only adds it to a layout.) */
    fun check(ctx: Context, theme: HudTheme, text: String, checked: Boolean, onChange: (Boolean) -> Unit): LinearLayout =
        Hyper.switchRow(ctx, theme, text, null, checked, onChange)

    /**
     * Title + live value + slider. [onPreview] fires on every move (use it to redraw the overlay
     * while the finger is down), [onCommit] fires once when the finger lifts (use it to save).
     */
    fun liveSlider(
        ctx: Context,
        theme: HudTheme,
        title: String,
        unit: String,
        min: Int,
        max: Int,
        value: Int,
        onPreview: (Int) -> Unit,
        onCommit: (Int) -> Unit
    ): LinearLayout {
        val box = Ui.vbox(ctx)
        val row = Ui.hbox(ctx)
        val name = Ui.label(ctx, title, 12f, theme.textPrimary)
        val valueView = Ui.label(ctx, "$value$unit", 12f, theme.accent, true)
        row.addView(name, Ui.lp(0, Ui.WRAP, 1f))
        row.addView(valueView, Ui.lp(Ui.WRAP, Ui.WRAP))
        box.addView(row, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 4), 0, 0))
        box.addView(
            Ui.slider(
                ctx, theme, min, max, value,
                { v -> valueView.text = "$v$unit"; onPreview(v) },
                { v -> valueView.text = "$v$unit"; onCommit(v) }
            ),
            Ui.lp(Ui.MATCH, Ui.WRAP)
        )
        return box
    }

    /**
     * A button that fires [onStep] immediately and then repeats while it is held (first repeat after
     * 400 ms, then every 70 ms). [onRelease] fires once when the finger lifts, so callers can save
     * once instead of on every step.
     */
    fun repeatButton(
        ctx: Context,
        theme: HudTheme,
        label: String,
        onStep: () -> Unit,
        onRelease: () -> Unit,
        iconRes: Int = 0
    ): TextView {
        val handler = Handler(Looper.getMainLooper())
        val repeater = object : Runnable {
            override fun run() {
                onStep()
                handler.postDelayed(this, 70L)
            }
        }
        val tv = TextView(ctx)
        tv.text = label
        tv.textSize = 16f
        tv.gravity = Gravity.CENTER
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.setTextColor(theme.textPrimary)
        tv.background = Ui.rounded(theme.tile, Ui.tileRadius(ctx, theme), theme.stroke, Ui.dp(ctx, 1))
        // Vector face instead of a text glyph (arrow nudge buttons). [label] is ignored when an icon is given.
        if (iconRes != 0) {
            tv.text = ""
            VIcon.setOnText(tv, iconRes, 18, theme.textPrimary)
        }
        fun press(prop: DynamicAnimation.ViewProperty): SpringAnimation {
            val force = SpringForce()
            force.setDampingRatio(SpringForce.DAMPING_RATIO_MEDIUM_BOUNCY)
            force.setStiffness(SpringForce.STIFFNESS_MEDIUM)
            val anim = SpringAnimation(tv, prop)
            anim.setSpring(force)
            return anim
        }
        val sx = press(DynamicAnimation.SCALE_X)
        val sy = press(DynamicAnimation.SCALE_Y)
        tv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                    v.isPressed = true
                    sx.animateToFinalPosition(0.86f)
                    sy.animateToFinalPosition(0.86f)
                    onStep()
                    handler.postDelayed(repeater, 400L)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(repeater)
                    v.isPressed = false
                    sx.animateToFinalPosition(1f)
                    sy.animateToFinalPosition(1f)
                    onRelease()
                }
            }
            true
        }
        return tv
    }
}
