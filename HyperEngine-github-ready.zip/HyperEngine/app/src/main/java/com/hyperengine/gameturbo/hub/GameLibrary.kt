package com.hyperengine.gameturbo.hub

import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import com.hyperengine.gameturbo.core.GameHeuristics
import com.hyperengine.gameturbo.core.SystemBridgeExecutor
import com.hyperengine.gameturbo.data.GameProfileRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.Locale

/** One game shown in the Game Space. Everything here is read from the system, nothing is invented. */
data class GameEntry(
    val pkg: String,
    val label: String,
    val lastUsedMs: Long = 0L,     // 0 = unknown / never (also 0 when Usage Access is off)
    val todayMin: Int = 0,
    val weekMin: Int = 0,
    val hasProfile: Boolean = false
)

/** A launchable app, for the "Add a game" picker. */
data class AppRow(val pkg: String, val label: String)

object GameSort {
    const val RECENT = 0
    const val NAME = 1
    const val PLAYTIME = 2
    val LABELS = listOf("Recent", "A-Z", "Most played")
}

/**
 * Finds the games to show:
 *  - every game that already has a profile (even if the user added it by hand), and
 *  - every installed non-system app that is a game by [GameHeuristics] (the same rule the foreground detector uses:
 *    the Game category, FLAG_IS_GAME, or a game engine's native library).
 * Apps the user hid are skipped; apps that are uninstalled or have no launcher entry are skipped.
 *
 * Play time and "last played" come from UsageStatsManager and need Usage Access; without it they
 * stay 0 and the UI says so.
 */
class GameLibrary(
    context: Context,
    private val repo: GameProfileRepository,
    private val bridge: SystemBridgeExecutor
) {

    private val ctx: Context = context.applicationContext
    private val pm = ctx.packageManager

    private class Usage(
        val last: Map<String, Long> = emptyMap(),
        val today: Map<String, Long> = emptyMap(),
        val week: Map<String, Long> = emptyMap()
    )

    fun hasUsageAccess(): Boolean = bridge.state.value.usageAccess

    fun launchIntent(pkg: String): Intent? =
        pm.getLaunchIntentForPackage(pkg)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)

    @Suppress("DEPRECATION")
    suspend fun scan(sort: Int): List<GameEntry> = withContext(Dispatchers.Default) {
        val global = repo.global.value
        val hidden = global.hubHidden.toHashSet()
        val profiles = repo.profiles.value
        val usage = readUsage()

        val candidates = LinkedHashSet<String>()
        candidates.addAll(profiles.keys)
        for (ai in runCatching { pm.getInstalledApplications(0) }.getOrDefault(emptyList())) {
            // system apps first: it is a flag test, while the game test can touch the disk
            if (!isPureSystem(ai) && GameHeuristics.looksLikeGame(ai)) candidates.add(ai.packageName)
        }
        candidates.remove(ctx.packageName)

        val out = ArrayList<GameEntry>()
        for (pkg in candidates) {
            if (pkg in hidden) continue
            val ai = runCatching { pm.getApplicationInfo(pkg, 0) }.getOrNull() ?: continue
            if (pm.getLaunchIntentForPackage(pkg) == null) continue
            val label = runCatching { pm.getApplicationLabel(ai).toString() }.getOrDefault(pkg)
                .ifBlank { profiles[pkg]?.label.orEmpty() }
                .ifBlank { pkg }
            out += GameEntry(
                pkg = pkg,
                label = label,
                lastUsedMs = usage.last[pkg] ?: 0L,
                todayMin = ((usage.today[pkg] ?: 0L) / 60_000L).toInt(),
                weekMin = ((usage.week[pkg] ?: 0L) / 60_000L).toInt(),
                hasProfile = profiles.containsKey(pkg)
            )
        }
        sorted(out, sort)
    }

    fun sorted(list: List<GameEntry>, sort: Int): List<GameEntry> = when (sort) {
        GameSort.NAME -> list.sortedBy { it.label.lowercase(Locale.getDefault()) }
        GameSort.PLAYTIME -> list.sortedWith(
            compareByDescending<GameEntry> { it.weekMin }.thenBy { it.label.lowercase(Locale.getDefault()) }
        )
        else -> list.sortedWith(
            compareByDescending<GameEntry> { it.lastUsedMs }.thenBy { it.label.lowercase(Locale.getDefault()) }
        )
    }

    /** Every launchable app that is not a pure system app, minus [excluding]. For the "Add a game" picker. */
    @Suppress("DEPRECATION")
    suspend fun launchableApps(excluding: Set<String>): List<AppRow> = withContext(Dispatchers.Default) {
        val rows = ArrayList<AppRow>()
        for (ai in runCatching { pm.getInstalledApplications(0) }.getOrDefault(emptyList())) {
            val pkg = ai.packageName
            if (pkg == ctx.packageName || pkg in excluding || isPureSystem(ai)) continue
            if (pm.getLaunchIntentForPackage(pkg) == null) continue
            val label = runCatching { pm.getApplicationLabel(ai).toString() }.getOrDefault(pkg).ifBlank { pkg }
            rows += AppRow(pkg, label)
        }
        rows.sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    // ── helpers ──

    private fun isPureSystem(ai: ApplicationInfo): Boolean =
        (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 && (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0

    private fun readUsage(): Usage {
        if (!hasUsageAccess()) return Usage()
        return try {
            val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val dayStart = cal.timeInMillis

            val last = HashMap<String, Long>()
            usm.queryAndAggregateUsageStats(now - 30L * 86_400_000L, now).forEach { (pkg, s) ->
                last[pkg] = s.lastTimeUsed
            }

            val today = HashMap<String, Long>()
            val week = HashMap<String, Long>()
            for (s in usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 7L * 86_400_000L, now)) {
                week[s.packageName] = (week[s.packageName] ?: 0L) + s.totalTimeInForeground
                if (s.lastTimeStamp >= dayStart) {
                    today[s.packageName] = (today[s.packageName] ?: 0L) + s.totalTimeInForeground
                }
            }
            Usage(last, today, week)
        } catch (_: Throwable) {
            Usage()
        }
    }
}
