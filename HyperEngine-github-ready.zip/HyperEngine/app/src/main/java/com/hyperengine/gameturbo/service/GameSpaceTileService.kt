package com.hyperengine.gameturbo.service

import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.hyperengine.gameturbo.HyperApp
import com.hyperengine.gameturbo.R
import com.hyperengine.gameturbo.core.Ns
import com.hyperengine.gameturbo.core.PerfTier
import com.hyperengine.gameturbo.hub.HubActivity
import com.hyperengine.gameturbo.ui.HudBus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * The virtual RedMagic hardware slider. A Quick Settings tile (and the Volume Up + Volume Down chord, see
 * [TouchMacroService]) that flips the phone into Competitive Mode: mechanical slider sound, heavy haptic thud,
 * landscape, Wild Boost and the Game Space lobby. Tapping it again undoes the parts that are not tied to a game.
 */
class GameSpaceTileService : TileService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onStartListening() {
        super.onStartListening()
        refresh()
    }

    override fun onClick() {
        super.onClick()
        val on = CompetitiveMode.isActive(this)
        scope.launch {
            if (on) {
                CompetitiveMode.exit(applicationContext)
            } else {
                CompetitiveMode.enter(applicationContext)
                if (HyperApp.instance.repository.global.value.competitive.openLobby) openLobby()
            }
            refresh()
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun refresh() {
        val tile = qsTile ?: return
        val on = CompetitiveMode.isActive(this)
        tile.state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = "Competitive Mode"
        if (Build.VERSION.SDK_INT >= 29) tile.subtitle = if (on) "On" else "Off"
        tile.icon = Icon.createWithResource(this, R.drawable.ic_tile_competitive)
        tile.updateTile()
    }

    private fun openLobby() {
        val intent = Intent(this, HubActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra(EXTRA_LOBBY_LANDSCAPE, true)
        runCatching {
            if (Build.VERSION.SDK_INT >= 34) {
                val pi = PendingIntent.getActivity(this, 7, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                startActivityAndCollapse(pi)
            } else {
                @Suppress("DEPRECATION")
                startActivityAndCollapse(intent)
            }
        }
    }

    companion object {
        /** Read by the lobby (Phase 6) to open in landscape console layout. */
        const val EXTRA_LOBBY_LANDSCAPE = "com.hyperengine.gameturbo.extra.LOBBY_LANDSCAPE"

        /** Asks the system to re-read the tile state (after the chord or a game exit changed it). */
        fun requestRefresh(ctx: Context) {
            runCatching {
                TileService.requestListeningState(ctx, ComponentName(ctx, GameSpaceTileService::class.java))
            }
        }
    }
}

// =============================================================================================
// Competitive mode
// =============================================================================================

object CompetitiveMode {

    private const val PREFS = "competitive_mode"
    private const val KEY_ACTIVE = "active"

    private val _active = MutableStateFlow(false)
    val active: StateFlow<Boolean> = _active.asStateFlow()

    fun isActive(ctx: Context): Boolean {
        val v = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ACTIVE, false)
        _active.value = v
        return v
    }

    private fun set(ctx: Context, on: Boolean) {
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ACTIVE, on).apply()
        _active.value = on
        GameSpaceTileService.requestRefresh(ctx)
    }

    /** Flip from anywhere (tile, key chord, HUD button). Returns a one-line summary of what happened. */
    suspend fun toggle(ctx: Context): String =
        if (isActive(ctx)) exit(ctx) else enter(ctx)

    suspend fun enter(ctx: Context): String {
        val app = HyperApp.instance
        val cfg = app.repository.global.value.competitive
        set(ctx, true)
        withContext(Dispatchers.Main) { SliderFeedback.play(ctx, cfg.sound, cfg.haptic) }
        val parts = ArrayList<String>()

        if (cfg.forceLandscape) {
            val a = app.engine.putTracked(Ns.SYSTEM, "accelerometer_rotation", "0")
            val b = app.engine.putTracked(Ns.SYSTEM, "user_rotation", "1")
            parts += if (a.ok && b.ok) "landscape locked" else "rotation not changed (${(if (!b.ok) b else a).detail})"
        }
        if (cfg.wildBoost) {
            val game = HudBus.game ?: GameDetectorService.state.value.game
            if (game != null) {
                val failed = fullBoost(game, cfg.diablo)
                parts += (if (cfg.diablo) "Diablo" else "Wild Boost") + if (failed == 0) " on" else " on, $failed step(s) failed"
            } else {
                parts += "Wild Boost starts with your next game"
            }
        }
        GameDetectorService.start(ctx)
        return parts.joinToString(", ").ifBlank { "Competitive Mode on" }
    }

    suspend fun exit(ctx: Context): String {
        val app = HyperApp.instance
        val cfg = app.repository.global.value.competitive
        set(ctx, false)
        withContext(Dispatchers.Main) { SliderFeedback.play(ctx, cfg.sound, cfg.haptic) }
        val parts = ArrayList<String>()
        if (cfg.forceLandscape) {
            val r = app.engine.releaseTracked(listOf(Ns.SYSTEM to "accelerometer_rotation", Ns.SYSTEM to "user_rotation"))
            parts += if (r.ok) "rotation restored" else "rotation: ${r.detail}"
        }
        val game = HudBus.game ?: GameDetectorService.state.value.game
        if (cfg.wildBoost && (app.wild.state.value.active || app.wildBoost.state.value.on)) {
            // boostOff also lets go of the refresh-rate lock, HyperBoost scaling and low-latency mode that boostOn added
            app.wildBoost.boostOff(game, persistMode = false)
            parts += "Wild Boost off"
        }
        return parts.joinToString(", ").ifBlank { "Competitive Mode off" }
    }

    /** A game just came forward while the mode is armed and no game was running: start Wild Boost for it. */
    suspend fun onGameForeground(ctx: Context, game: String) {
        if (!isActive(ctx)) return
        val app = HyperApp.instance
        val cfg = app.repository.global.value.competitive
        if (cfg.wildBoost && !app.wild.state.value.active) fullBoost(game, cfg.diablo)
        if (!cfg.wildBoost) app.wild.setTier(game, PerfTier.BALANCED)
    }

    /**
     * The same full boost the Wild Boost tile and the HUD chip run (fixed performance, refresh-rate lock, HyperBoost
     * scaling, low-latency mode). Diablo is an engine variant, so it is activated first and the controller adds the rest.
     * Returns how many steps failed.
     */
    private suspend fun fullBoost(game: String, diablo: Boolean): Int {
        val app = HyperApp.instance
        val steps = ArrayList<com.hyperengine.gameturbo.core.StepResult>()
        if (diablo) {
            steps += app.wild.activate(game, true)
            steps += app.wildBoost.boostOn(game, persistMode = false, activateWild = false)
        } else {
            steps += app.wildBoost.boostOn(game, persistMode = false)
        }
        return steps.count { !it.ok }
    }

    /** The game closed: the engine restores rotation and the rest, so the mode simply switches itself off. */
    fun onGameEnded(ctx: Context) {
        if (isActive(ctx)) set(ctx, false)
    }
}

// =============================================================================================
// Slider sound and thud
// =============================================================================================

object SliderFeedback {

    private val main = Handler(Looper.getMainLooper())

    @Volatile
    private var pcm: ShortArray? = null

    fun play(ctx: Context, sound: Boolean, haptic: Boolean) {
        if (haptic) runCatching { thud(ctx.applicationContext) }
        if (sound) Thread { runCatching { click() } }.also { it.isDaemon = true }.start()
    }

    private fun thud(ctx: Context) {
        val v: Vibrator = if (Build.VERSION.SDK_INT >= 31) {
            (ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        if (!v.hasVibrator()) return
        // latch release, then the heavy stop of the slider hitting its end
        v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 12, 22, 55), intArrayOf(0, 140, 0, 255), -1))
    }

    private fun click() {
        val data = pcm ?: synth().also { pcm = it }
        val rate = 44_100
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(data.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track.write(data, 0, data.size)
        track.play()
        main.postDelayed({
            runCatching { track.stop() }
            runCatching { track.release() }
        }, data.size * 1000L / rate + 120L)
    }

    /**
     * A mechanical switch, built from maths instead of a sound file: a sharp latch click, a short rattle while the
     * slider travels, then a low thunk when it reaches the stop.
     */
    private fun synth(): ShortArray {
        val rate = 44_100
        val n = rate * 300 / 1000
        val out = ShortArray(n)
        val rnd = java.util.Random(11)
        var rattleLp = 0.0
        for (i in 0 until n) {
            val t = i.toDouble() / rate
            val click = (rnd.nextDouble() * 2 - 1) * 0.55 * exp(-t / 0.004) + 0.45 * sin(2 * PI * 2400 * t) * exp(-t / 0.006)
            val tr = t - 0.014
            val rattleRaw = if (tr in 0.0..0.085) (rnd.nextDouble() * 2 - 1) * 0.5 * sin(PI * tr / 0.085) else 0.0
            rattleLp += (rattleRaw - rattleLp) * 0.35
            val tt = t - 0.115
            val thunk = if (tt >= 0) {
                0.9 * sin(2 * PI * 92 * tt) * exp(-tt / 0.055) +
                    0.3 * sin(2 * PI * 186 * tt) * exp(-tt / 0.03) +
                    0.35 * (rnd.nextDouble() * 2 - 1) * exp(-tt / 0.003)
            } else 0.0
            val s = (click * 0.7 + rattleLp * 0.45 + thunk).coerceIn(-1.0, 1.0)
            out[i] = (s * 0.85 * Short.MAX_VALUE).toInt().toShort()
        }
        return out
    }
}
