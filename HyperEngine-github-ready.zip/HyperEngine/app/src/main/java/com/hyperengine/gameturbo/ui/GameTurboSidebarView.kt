package com.hyperengine.gameturbo.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Point
import android.graphics.RectF
import android.graphics.Shader
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.hyperengine.gameturbo.core.EngineStatus
import com.hyperengine.gameturbo.core.FpsSource
import com.hyperengine.gameturbo.core.GameModeLevel
import com.hyperengine.gameturbo.core.TelemetrySample
import com.hyperengine.gameturbo.data.EdgeSide
import com.hyperengine.gameturbo.data.GameProfile
import com.hyperengine.gameturbo.data.GlobalSettings
import com.hyperengine.gameturbo.data.HandleConfig
import com.hyperengine.gameturbo.data.SidebarConfig
import com.hyperengine.gameturbo.data.ThemeId
import com.hyperengine.gameturbo.data.ToolIds
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.max

/**
 * The slide-out HUD. Everything on it is live:
 *  - panel look comes from HudTheme (4 themes, opacity, corner radius, custom accents)
 *  - turbine, gauges and charts are driven by TelemetryMonitor samples
 *  - the tool grid shows only registered tools, in the user's order, minus hidden ones
 *  - Customize page edits GlobalSettings, which the controller feeds back through restyle()
 */
class GameTurboSidebarView(
    context: Context,
    override val deps: SidebarDeps,
    override var theme: HudTheme,
    private var global: GlobalSettings,
    override var game: String,
    private val screen: () -> Point,
    private val onClose: () -> Unit
) : FrameLayout(context), ToolHost, HudPanel {

    override val view: View get() = this
    override val hostContext: Context get() = context
    override val scope: CoroutineScope = MainScope()

    private enum class Page { MAIN, DETAIL, CUSTOMIZE }

    private var page = Page.MAIN
    private var detailContent: View? = null
    private var detailTitle = ""
    private var lastSample: TelemetrySample? = null
    private var lastEngine = EngineStatus()

    // ---- chrome ----
    private val column = LinearLayout(context)
    private val titleView = Ui.label(context, "", 16f, 0xFFFFFFFF.toInt(), true)
    private val subtitleView = Ui.label(context, "", 10f, 0xFFFFFFFF.toInt())
    private val statusView = Ui.label(context, "", 10f, 0xFFFFFFFF.toInt())
    private val backBtn = TextView(context)
    private val closeBtn = TextView(context)
    private val scroll = ScrollView(context)
    private val bodyHolder = FrameLayout(context)

    // ---- panel drawing ----
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val fxPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var panelPath = Path()
    private var glassShader: Shader? = null
    private var chamfer = 0f

    // ---- main page refs (null while another page is shown) ----
    private var turbine: TurbineView? = null
    private var modeLabel: TextView? = null
    private var modeSub: TextView? = null
    private var modeChips: ChipGroup? = null
    private var modeResult: TextView? = null
    private var cpuGauge: GaugeView? = null
    private var tempGauge: GaugeView? = null
    private var ramGauge: GaugeView? = null
    private var fpsView: TextView? = null
    private var fpsNote: TextView? = null
    private var statLine: TextView? = null
    private var fpsChart: MiniChartView? = null
    private var pingChart: MiniChartView? = null
    private var tempChart: MiniChartView? = null
    private var gridHolder: LinearLayout? = null
    private var cpuSmooth: AnimationController.SmoothGauge? = null
    private var tempSmooth: AnimationController.SmoothGauge? = null
    private var ramSmooth: AnimationController.SmoothGauge? = null
    private var fanView: ImageView? = null
    private var fanSpinner: AnimationController.FanSpinner? = null

    private val flashReset = Runnable { updateStatus() }

    init {
        setWillNotDraw(false)
        column.orientation = LinearLayout.VERTICAL

        val header = Ui.hbox(context)
        header.gravity = Gravity.CENTER_VERTICAL
        val titles = Ui.vbox(context)
        titles.addView(titleView)
        titles.addView(subtitleView, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, Ui.dp(context, 2), 0, 0))
        backBtn.text = "Back"
        backBtn.setOnClickListener { goMain() }
        closeBtn.text = "Close"
        closeBtn.setOnClickListener { onClose() }
        header.addView(backBtn, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, 0, Ui.dp(context, 8), 0))
        header.addView(titles, Ui.lp(0, Ui.WRAP, 1f))
        header.addView(closeBtn)
        column.addView(header, Ui.lp(Ui.MATCH, Ui.WRAP))
        column.addView(statusView, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(context, 6), 0, Ui.dp(context, 4)))

        scroll.isVerticalScrollBarEnabled = false
        scroll.addView(bodyHolder, ViewGroup.LayoutParams(Ui.MATCH, Ui.WRAP))
        column.addView(scroll, Ui.lp(Ui.MATCH, 0, 1f))
        addView(column, LayoutParams(Ui.MATCH, Ui.MATCH))

        styleChrome()
        render()
    }

    // =========================================================================================
    // Public hooks used by HudController
    // =========================================================================================

    override fun restyle(newTheme: HudTheme, newGlobal: GlobalSettings) {
        theme = newTheme
        global = newGlobal
        if (page == Page.DETAIL) {
            page = Page.MAIN
            detailContent = null
        }
        val y = scroll.scrollY
        styleChrome()
        rebuildPanel()
        render()
        invalidate()
        scroll.post { scroll.scrollTo(0, y) }
    }

    override fun changeGame(pkg: String) {
        if (pkg == game) return
        game = pkg
        goMain()
    }

    override fun onProfile(p: GameProfile) {
        if (p.packageName != game || page != Page.MAIN) return
        refreshBoost()
        fillGrid()
    }

    override fun onEngine(st: EngineStatus) {
        lastEngine = st
        updateStatus()
    }

    override fun onSample(s: TelemetrySample) {
        lastSample = s
        if (page != Page.MAIN) return
        val fpsV = fpsView ?: return
        val limit = global.tempAlertC

        when (s.fpsSource) {
            FpsSource.SURFACE_FLINGER -> {
                fpsV.text = String.format(Locale.US, "%.0f FPS", s.fps)
                fpsV.setTextColor(
                    when {
                        s.fps >= 60f -> theme.good
                        s.fps >= 30f -> theme.warn
                        else -> theme.hot
                    }
                )
                fpsNote?.text = "game layer"
            }
            FpsSource.VSYNC -> {
                fpsV.text = String.format(Locale.US, "%.0f Hz", s.fps)
                fpsV.setTextColor(theme.textSecondary)
                fpsNote?.text = "display vsync, not game FPS (needs Shizuku for real FPS)"
            }
            FpsSource.NONE -> {
                fpsV.text = "--"
                fpsV.setTextColor(theme.textSecondary)
                fpsNote?.text = "waiting for the game"
            }
        }

        cpuSmooth?.set(
            if (s.cpuPct >= 0f) s.cpuPct / 100f else 0f,
            if (s.cpuPct >= 0f) String.format(Locale.US, "%.0f%%", s.cpuPct) else "--",
            "CPU " + String.format(Locale.US, "%.1f", s.peakCoreGhz) + " GHz",
            if (s.cpuPct > 85f) theme.hot else theme.accent,
            theme
        )
        val t = s.batteryTempC
        tempSmooth?.set(
            ((t - 25f) / max(1f, limit + 8f - 25f)).coerceIn(0f, 1f),
            String.format(Locale.US, "%.1f", t),
            "TEMP C",
            when {
                t >= limit -> theme.hot
                t >= limit - 4 -> theme.warn
                else -> theme.good
            },
            theme
        )
        val usedFrac = if (s.totalRamMb > 0) s.usedRamMb.toFloat() / s.totalRamMb else 0f
        ramSmooth?.set(
            usedFrac,
            String.format(Locale.US, "%.0f%%", usedFrac * 100f),
            "RAM " + s.availRamMb + " MB free",
            if (usedFrac > 0.9f) theme.hot else theme.accent,
            theme
        )

        val p = s.ping
        val power = if (s.powerW >= 0f) String.format(Locale.US, "%.1f W", s.powerW) else "n/a"
        statLine?.text = "Power $power   Battery ${s.batteryPct}%" + (if (s.charging) " charging" else "") +
            "   Ping " + (if (p.lastMs >= 0) "${p.lastMs} ms" else "--") +
            String.format(Locale.US, "   Jitter %.1f ms", p.jitterMs)

        fpsChart?.update(s.fpsHistory, if (s.fps >= 0f) String.format(Locale.US, "%.0f", s.fps) else "--")
        pingChart?.update(
            p.history.map { it.toFloat() },
            if (p.lastMs >= 0) "${p.lastMs} ms" else "--"
        )
        tempChart?.update(s.tempHistory, String.format(Locale.US, "%.1f C", t))
        updateFan(s.cpuPct)
    }

    override fun dispose() {
        releaseAnimators()
        removeCallbacks(flashReset)
        scope.cancel()
    }

    // =========================================================================================
    // ToolHost
    // =========================================================================================

    override fun toast(msg: String) {
        statusView.setTextColor(theme.accent)
        statusView.text = msg
        removeCallbacks(flashReset)
        postDelayed(flashReset, 3000L)
    }

    override fun openDetail(title: String, content: View) {
        page = Page.DETAIL
        detailTitle = title
        detailContent = content
        render()
    }

    override fun refreshTiles() {
        if (page == Page.MAIN) {
            refreshBoost()
            fillGrid()
        }
    }

    // =========================================================================================
    // Panel drawing
    // =========================================================================================

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        rebuildPanel()
    }

    private fun rebuildPanel() {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val r = Ui.dpf(context, theme.cornerDp.toFloat())
        val p = Path()
        chamfer = 0f
        when (theme.style) {
            PanelStyle.GLASS, PanelStyle.FLAT -> p.addRoundRect(RectF(0f, 0f, w, h), r, r, Path.Direction.CW)
            PanelStyle.CYBER_ANGULAR -> {
                val c = Ui.dpf(context, 8f) + r
                chamfer = c
                p.moveTo(c, 0f); p.lineTo(w, 0f); p.lineTo(w, h - c); p.lineTo(w - c, h)
                p.lineTo(0f, h); p.lineTo(0f, c); p.close()
            }
            PanelStyle.MECHA -> {
                val c = Ui.dpf(context, 6f) + r * 0.8f
                chamfer = c
                p.moveTo(c, 0f); p.lineTo(w - c, 0f); p.lineTo(w, c); p.lineTo(w, h - c)
                p.lineTo(w - c, h); p.lineTo(c, h); p.lineTo(0f, h - c); p.lineTo(0f, c); p.close()
            }
        }
        panelPath = p
        val a = theme.panelAlpha
        fillPaint.shader = LinearGradient(
            0f, 0f, 0f, h,
            HudThemes.withAlpha(theme.panelTop, a), HudThemes.withAlpha(theme.panelBottom, a), Shader.TileMode.CLAMP
        )
        glassShader = LinearGradient(
            0f, 0f, 0f, h * 0.35f, 0x30FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f) return
        val d = resources.displayMetrics.density
        c.drawPath(panelPath, fillPaint)

        when (theme.style) {
            PanelStyle.GLASS -> {
                c.save()
                c.clipPath(panelPath)
                fxPaint.shader = glassShader
                c.drawRect(0f, 0f, w, h * 0.35f, fxPaint)
                fxPaint.shader = null
                c.restore()
                strokePaint.color = theme.stroke
                strokePaint.strokeWidth = d
                c.drawPath(panelPath, strokePaint)
            }
            PanelStyle.CYBER_ANGULAR -> {
                c.save()
                c.clipPath(panelPath)
                fxPaint.color = HudThemes.withAlpha(theme.accent, 20)
                fxPaint.strokeWidth = d
                val step = 16f * d
                var x = 0f
                while (x < w) { c.drawLine(x, 0f, x, h, fxPaint); x += step }
                var y = 0f
                while (y < h) { c.drawLine(0f, y, w, y, fxPaint); y += step }
                fxPaint.color = HudThemes.withAlpha(theme.accent, 70)
                val tri = Path()
                tri.moveTo(chamfer, 0f); tri.lineTo(chamfer + 54f * d, 0f); tri.lineTo(chamfer, 54f * d); tri.close()
                fxPaint.style = Paint.Style.FILL
                c.drawPath(tri, fxPaint)
                c.restore()
                strokePaint.color = theme.accent
                strokePaint.strokeWidth = 2f * d
                c.drawPath(panelPath, strokePaint)
            }
            PanelStyle.MECHA -> {
                strokePaint.color = theme.stroke
                strokePaint.strokeWidth = 1.5f * d
                c.drawPath(panelPath, strokePaint)
                strokePaint.color = theme.accent
                strokePaint.strokeWidth = 3f * d
                c.drawLine(chamfer, 1.5f * d, chamfer + 34f * d, 1.5f * d, strokePaint)
                c.drawLine(w - chamfer - 34f * d, h - 1.5f * d, w - chamfer, h - 1.5f * d, strokePaint)
            }
            PanelStyle.FLAT -> {
                strokePaint.color = theme.stroke
                strokePaint.strokeWidth = d
                c.drawPath(panelPath, strokePaint)
            }
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.action == MotionEvent.ACTION_OUTSIDE) {
            onClose()
            return true
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun styleChrome() {
        val pad = Ui.dp(context, 14) + if (theme.style == PanelStyle.CYBER_ANGULAR || theme.style == PanelStyle.MECHA) Ui.dp(context, 4) else 0
        column.setPadding(pad, pad, pad, pad)
        titleView.setTextColor(theme.textPrimary)
        subtitleView.setTextColor(theme.textSecondary)
        statusView.setTextColor(theme.textSecondary)
        for (b in listOf(backBtn, closeBtn)) {
            b.textSize = 12f
            b.gravity = Gravity.CENTER
            b.setTextColor(theme.textPrimary)
            b.setPadding(Ui.dp(context, 12), Ui.dp(context, 8), Ui.dp(context, 12), Ui.dp(context, 8))
            b.background = Ui.rounded(theme.tile, Ui.tileRadius(context, theme), theme.stroke, Ui.dp(context, 1))
        }
    }

    // =========================================================================================
    // Pages
    // =========================================================================================

    private fun profile(): GameProfile = GameActions.profileFor(deps, game)

    private fun gameLabel(): String = profile().label.ifBlank { game }

    private fun goMain() {
        page = Page.MAIN
        detailContent = null
        render()
    }

    private fun render() {
        bodyHolder.removeAllViews()
        turbine = null; modeLabel = null; modeSub = null; modeChips = null; modeResult = null
        releaseAnimators()
        cpuGauge = null; tempGauge = null; ramGauge = null
        fpsView = null; fpsNote = null; statLine = null
        fpsChart = null; pingChart = null; tempChart = null; gridHolder = null

        val v: View = when (page) {
            Page.MAIN -> buildMain()
            Page.DETAIL -> detailContent ?: run { page = Page.MAIN; buildMain() }
            Page.CUSTOMIZE -> buildCustomizer()
        }
        (v.parent as? ViewGroup)?.removeView(v)
        bodyHolder.addView(v, ViewGroup.LayoutParams(Ui.MATCH, Ui.WRAP))
        backBtn.visibility = if (page == Page.MAIN) View.GONE else View.VISIBLE
        titleView.text = when (page) {
            Page.MAIN -> gameLabel()
            Page.DETAIL -> detailTitle
            Page.CUSTOMIZE -> "Customize"
        }
        subtitleView.text = if (page == Page.MAIN) "HyperEngine Game Turbo Pro" else gameLabel()
        updateStatus()
    }

    private fun updateStatus() {
        val st = lastEngine
        statusView.setTextColor(theme.textSecondary)
        statusView.text = buildString {
            append(deps.bridge.state.value.mode.label)
            if (st.sessionActive) append("  |  tweaks active")
            st.restoreCountdownSec?.let { append("  |  restore in ${it}s") }
            st.busy?.let { append("  |  $it") }
        }
    }

    // ---- main page ----

    private fun buildMain(): View {
        val ctx = context
        val col = Ui.vbox(ctx)

        // boost row
        val row = Ui.hbox(ctx)
        row.gravity = Gravity.CENTER_VERTICAL
        val tv = TurbineView(ctx)
        tv.setOnClickListener { toggleWild() }
        turbine = tv
        row.addView(tv, Ui.lp(Ui.dp(ctx, 92), Ui.dp(ctx, 92), 0f, 0, 0, Ui.dp(ctx, 12), 0))
        val info = Ui.vbox(ctx)
        val ml = Ui.label(ctx, "", 17f, theme.textPrimary, true)
        val ms = Ui.label(ctx, "", 11f, theme.textSecondary)
        modeLabel = ml
        modeSub = ms
        info.addView(ml)
        info.addView(ms, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, Ui.dp(ctx, 3), 0, 0))
        row.addView(info, Ui.lp(0, Ui.WRAP, 1f))
        col.addView(row)

        val chips = ChipGroup(ctx, theme, listOf("Battery", "Balanced", "Wild Boost"), 1, 3) { i ->
            applyMode(GameActions.MODES[i])
        }
        modeChips = chips
        col.addView(chips, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 8), 0, 0))
        val mr = Ui.label(ctx, "", 10f, theme.textSecondary)
        modeResult = mr
        col.addView(mr, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, Ui.dp(ctx, 3), Ui.dp(ctx, 2), 0, 0))

        // fps readout
        col.addView(Ui.section(ctx, theme, "Live telemetry"))
        val fv = Ui.label(ctx, "--", 30f, theme.textSecondary, true)
        val fn = Ui.label(ctx, "", 10f, theme.textSecondary)
        fpsView = fv
        fpsNote = fn
        val fpsRow = Ui.hbox(ctx)
        fpsRow.gravity = Gravity.CENTER_VERTICAL
        fpsRow.addView(fv, Ui.lp(0, Ui.WRAP, 1f))
        val fan = AnimationController.fanBlades(ctx, 34)
        fanView = fan
        fanSpinner = AnimationController.FanSpinner(fan)
        fpsRow.addView(fan, Ui.lp(Ui.dp(ctx, 34), Ui.dp(ctx, 34)))
        col.addView(fpsRow)
        col.addView(fn, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, Ui.dp(ctx, 2), 0, Ui.dp(ctx, 6)))

        // gauges
        val gr = Ui.hbox(ctx)
        fun gauge(): GaugeView = GaugeView(ctx).apply {
            style = theme.gauge
            trackColor = HudThemes.withAlpha(theme.textPrimary, 40)
            textColor = theme.textPrimary
            subColor = theme.textSecondary
        }
        val g1 = gauge(); val g2 = gauge(); val g3 = gauge()
        cpuGauge = g1; tempGauge = g2; ramGauge = g3
        cpuSmooth = AnimationController.SmoothGauge(g1)
        tempSmooth = AnimationController.SmoothGauge(g2)
        ramSmooth = AnimationController.SmoothGauge(g3)
        for (g in listOf(g1, g2, g3)) gr.addView(g, Ui.lp(0, Ui.dp(ctx, 92), 1f))
        col.addView(gr)

        val sl = Ui.label(ctx, "", 11f, theme.textPrimary)
        statLine = sl
        col.addView(sl, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 6), 0, Ui.dp(ctx, 4)))

        fun chart(title: String, color: Int): MiniChartView = MiniChartView(ctx).apply {
            this.title = title
            lineColor = color
            textColor = theme.textPrimary
            subColor = theme.textSecondary
            gridColor = HudThemes.withAlpha(theme.textPrimary, 30)
        }
        val c1 = chart("FPS", theme.accent).apply { fixedMin = 0f; minRange = 30f }
        val c2 = chart("PING", theme.accent2).apply { minRange = 20f }
        val c3 = chart("BATTERY TEMP", theme.warn).apply { minRange = 6f }
        fpsChart = c1; pingChart = c2; tempChart = c3
        for (c in listOf(c1, c2, c3)) col.addView(c, Ui.lp(Ui.MATCH, Ui.dp(ctx, 66), 0f, 0, Ui.dp(ctx, 4), 0, 0))

        // tools
        col.addView(Ui.section(ctx, theme, "Tools"))
        val grid = Ui.vbox(ctx)
        gridHolder = grid
        col.addView(grid)

        // footer
        val foot = Ui.hbox(ctx)
        foot.addView(Ui.button(ctx, theme, "Restore now") {
            scope.launch {
                val rep = deps.engine.restoreAll("sidebar button")
                toast(if (rep.complete) "All settings restored" else "Some items could not be restored yet")
            }
        }, Ui.lp(0, Ui.WRAP, 1f, 0, 0, Ui.dp(ctx, 4), 0))
        foot.addView(Ui.button(ctx, theme, "Customize", true) {
            page = Page.CUSTOMIZE
            render()
        }, Ui.lp(0, Ui.WRAP, 1f, Ui.dp(ctx, 4), 0, 0, 0))
        col.addView(foot, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 14), 0, Ui.dp(ctx, 6)))

        refreshBoost()
        fillGrid()
        lastSample?.let { onSample(it) }
        return col
    }

    private fun toggleWild() {
        val target = if (profile().gameMode == GameModeLevel.PERFORMANCE) GameModeLevel.STANDARD else GameModeLevel.PERFORMANCE
        applyMode(target)
    }

    private fun applyMode(level: GameModeLevel) {
        scope.launch {
            val (ok, msg) = GameActions.summary(GameActions.applyMode(deps, game, level))
            modeResult?.let {
                it.setTextColor(if (ok) theme.good else theme.hot)
                it.text = msg
            }
            refreshBoost()
            fillGrid()
        }
    }

    private fun refreshBoost() {
        val p = profile()
        turbine?.setMode(p.gameMode, theme)
        modeLabel?.text = when (p.gameMode) {
            GameModeLevel.BATTERY -> "BATTERY SAVER"
            GameModeLevel.STANDARD -> "BALANCED"
            GameModeLevel.PERFORMANCE -> "WILD BOOST"
        }
        modeLabel?.setTextColor(
            when (p.gameMode) {
                GameModeLevel.BATTERY -> theme.good
                GameModeLevel.STANDARD -> theme.accent
                GameModeLevel.PERFORMANCE -> theme.accent2
            }
        )
        val ds = p.downscale?.let { String.format(Locale.US, "downscale %.0f%%", it * 100f) }
        val fps = if (p.targetFps > 0) "FPS cap ${p.targetFps}" else null
        modeSub?.text = listOfNotNull(ds, fps).joinToString("   ").ifBlank { "No downscale or FPS cap" }
        modeChips?.select(GameActions.MODES.indexOf(p.gameMode))
        updateFan(lastSample?.cpuPct ?: -1f)
    }

    /** Blade speed follows the game mode (the active RPM tier) and rises with CPU load, whichever is higher. */
    private fun updateFan(cpuPct: Float) {
        val spinner = fanSpinner ?: return
        val byMode = AnimationController.FanSpeed.forMode(profile().gameMode)
        val byLoad = AnimationController.FanSpeed.forLoad(cpuPct)
        spinner.setSpeed(if (byLoad.degPerSec > byMode.degPerSec) byLoad else byMode, theme)
    }

    private fun releaseAnimators() {
        cpuSmooth?.release(); tempSmooth?.release(); ramSmooth?.release()
        cpuSmooth = null; tempSmooth = null; ramSmooth = null
        fanSpinner?.release()
        fanSpinner = null
        fanView = null
    }

    /** The tool tiles, for the wing's staggered fade-in. */
    fun wingChildren(): List<View> {
        val h = gridHolder ?: return emptyList()
        val out = ArrayList<View>()
        for (i in 0 until h.childCount) {
            val row = h.getChildAt(i) as? ViewGroup ?: continue
            for (j in 0 until row.childCount) {
                val c = row.getChildAt(j)
                if (c.isClickable) out += c
            }
        }
        return out
    }

    // ---- tool grid ----

    private fun order(): List<String> {
        val known = ToolIds.ALL.toSet()
        val saved = global.sidebar.toolOrder.filter { it in known }.distinct()
        return saved + ToolIds.ALL.filter { it !in saved }
    }

    private fun fillGrid() {
        val holder = gridHolder ?: return
        holder.removeAllViews()
        val ctx = context
        val hidden = global.sidebar.hiddenTools.toSet()
        val shown = order().filter { it !in hidden && ToolRegistry.has(it) }
        if (shown.isEmpty()) {
            holder.addView(Ui.label(ctx, "No tools shown. Open Customize to enable some.", 11f, theme.textSecondary))
            return
        }
        val panelW = minOf(Ui.dp(ctx, 340), (screen().x * 0.9f).toInt())
        val cols = if (panelW >= Ui.dp(ctx, 300)) 4 else 3
        for (chunk in shown.chunked(cols)) {
            val row = Ui.hbox(ctx)
            for (id in chunk) row.addView(tile(id), Ui.lp(0, Ui.WRAP, 1f, Ui.dp(ctx, 2), Ui.dp(ctx, 4), Ui.dp(ctx, 2), Ui.dp(ctx, 4)))
            for (i in chunk.size until cols) row.addView(View(ctx), Ui.lp(0, 1, 1f))
            holder.addView(row, Ui.lp(Ui.MATCH, Ui.WRAP))
        }
    }

    private fun tile(id: String): View {
        val ctx = context
        val info = ToolCatalog.info(id)
        val tool = ToolRegistry.get(id)
        val active = tool?.isActive(this) == true
        val box: View = if (info.iconRes != 0) {
            FrameLayout(ctx).apply {
                background = Ui.rounded(
                    if (active) HudThemes.withAlpha(theme.accent, 0x33) else theme.tile, Ui.tileRadius(ctx, theme),
                    if (active) theme.accent else theme.stroke, Ui.dp(ctx, if (active) 2 else 1)
                )
                val icon = VIcon.view(ctx, info.iconRes, 28)
                VIcon.start(icon.drawable)
                addView(icon, FrameLayout.LayoutParams(Ui.dp(ctx, 28), Ui.dp(ctx, 28), Gravity.CENTER))
            }
        } else {
            TextView(ctx).apply {
                text = info.code
                gravity = Gravity.CENTER
                textSize = 13f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                setTextColor(if (active) HudThemes.onAccent(theme.accent) else theme.textPrimary)
                background = Ui.rounded(
                    if (active) theme.accent else theme.tile, Ui.tileRadius(ctx, theme),
                    if (active) theme.accent else theme.stroke, Ui.dp(ctx, 1)
                )
            }
        }
        val cap = Ui.label(ctx, info.title, 10f, theme.textSecondary).apply {
            gravity = Gravity.CENTER
            maxLines = 2
        }
        val cell = Ui.vbox(ctx)
        cell.gravity = Gravity.CENTER_HORIZONTAL
        cell.addView(box, Ui.lp(Ui.dp(ctx, 50), Ui.dp(ctx, 50)))
        cell.addView(cap, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 4), 0, 0))
        cell.setOnClickListener { tool?.onTap(this) }
        return cell
    }

    // =========================================================================================
    // Customizer
    // =========================================================================================

    private fun updateGlobal(t: (GlobalSettings) -> GlobalSettings) = deps.repo.updateGlobal(t)
    private fun updateSidebar(t: (SidebarConfig) -> SidebarConfig) = deps.repo.updateGlobal { it.copy(sidebar = t(it.sidebar)) }
    private fun updateHandle(t: (HandleConfig) -> HandleConfig) = deps.repo.updateGlobal { it.copy(handle = t(it.handle)) }

    private fun buildCustomizer(): View {
        val ctx = context
        val col = Ui.vbox(ctx)
        val sb = global.sidebar
        val h = global.handle

        // ---- theme ----
        col.addView(Ui.section(ctx, theme, "Theme"))
        col.addView(ChipGroup(ctx, theme, HudThemes.LABELS, global.theme.ordinal, 2) { i ->
            updateGlobal { it.copy(theme = ThemeId.values()[i]) }
        })
        if (global.theme == ThemeId.AMOLED_BLACK) {
            col.addView(Ui.label(ctx, "AMOLED mode: solid black, no blur, no animations, opacity is ignored.", 10f, theme.textSecondary),
                Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, Ui.dp(ctx, 4), 0, 0))
        }

        // ---- panel ----
        col.addView(Ui.section(ctx, theme, "Sidebar panel"))
        col.addView(Ui.labeledSlider(ctx, theme, "Background opacity", "%", 20, 100, sb.opacityPct) { v ->
            updateSidebar { it.copy(opacityPct = v) }
        })
        col.addView(Ui.labeledSlider(ctx, theme, "Corner radius", " dp", 0, 32, sb.cornerRadiusDp) { v ->
            updateSidebar { it.copy(cornerRadiusDp = v) }
        }, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 8), 0, 0))

        // ---- colours ----
        col.addView(Ui.section(ctx, theme, "Accent colours"))
        col.addView(ChipGroup(ctx, theme, listOf("Theme colours", "Custom HEX"), if (sb.useCustomAccent) 1 else 0, 2) { i ->
            updateSidebar { it.copy(useCustomAccent = i == 1) }
        })
        if (sb.useCustomAccent) {
            col.addView(Ui.label(ctx, "Primary (Balanced)", 11f, theme.textPrimary), Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, Ui.dp(ctx, 8), 0, 0))
            col.addView(HexColorPicker(ctx, theme, sb.primaryHex) { hex -> updateSidebar { it.copy(primaryHex = hex) } })
            col.addView(Ui.label(ctx, "Secondary (Wild Boost)", 11f, theme.textPrimary), Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, Ui.dp(ctx, 10), 0, 0))
            col.addView(HexColorPicker(ctx, theme, sb.secondaryHex) { hex -> updateSidebar { it.copy(secondaryHex = hex) } })
        }

        // ---- tool grid ----
        col.addView(Ui.section(ctx, theme, "Tool grid"))
        col.addView(Ui.label(ctx, "Show, hide and reorder the shortcuts. Tools from later phases appear here once installed.", 10f, theme.textSecondary),
            Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, 0, 0, Ui.dp(ctx, 4)))
        val ord = order()
        for (id in ord) {
            val info = ToolCatalog.info(id)
            val reg = ToolRegistry.has(id)
            val row = Ui.hbox(ctx)
            row.gravity = Gravity.CENTER_VERTICAL
            val name = Ui.label(
                ctx, info.title + if (reg) "" else "  (phase ${info.phase})", 12f,
                if (reg) theme.textPrimary else theme.textSecondary
            )
            row.addView(name, Ui.lp(0, Ui.WRAP, 1f))
            if (reg) {
                val isHidden = id in sb.hiddenTools
                row.addView(Ui.button(ctx, theme, if (isHidden) "Hidden" else "Shown", !isHidden) {
                    updateSidebar { s -> s.copy(hiddenTools = if (isHidden) s.hiddenTools - id else (s.hiddenTools + id).distinct()) }
                }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, Ui.dp(ctx, 4), 0, 0, 0))
                row.addView(Ui.button(ctx, theme, "Up") { moveTool(id, -1) }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, Ui.dp(ctx, 4), 0, 0, 0))
                row.addView(Ui.button(ctx, theme, "Down") { moveTool(id, 1) }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, Ui.dp(ctx, 4), 0, 0, 0))
            }
            col.addView(row, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 4), 0, 0))
        }

        // ---- edge handle ----
        col.addView(Ui.section(ctx, theme, "Edge handle"))
        col.addView(ChipGroup(ctx, theme, listOf("Left", "Right", "Top"), h.side.ordinal, 3) { i ->
            updateHandle { it.copy(side = EdgeSide.values()[i]) }
        })
        val d = resources.displayMetrics.density
        val scr = screen()
        val axisDp = ((if (h.side == EdgeSide.TOP) scr.x else scr.y) / d).toInt()
        val offMax = max(40, axisDp - h.heightDp)
        col.addView(Ui.labeledSlider(ctx, theme, "Position offset", " dp", 0, offMax, h.offsetDp.coerceAtMost(offMax)) { v ->
            updateHandle { it.copy(offsetDp = v) }
        }, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 8), 0, 0))
        col.addView(Ui.labeledSlider(ctx, theme, "Width", " dp", 4, 16, h.widthDp) { v -> updateHandle { it.copy(widthDp = v) } },
            Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 6), 0, 0))
        col.addView(Ui.labeledSlider(ctx, theme, "Length", " dp", 40, 160, h.heightDp) { v -> updateHandle { it.copy(heightDp = v) } },
            Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 6), 0, 0))
        col.addView(Ui.labeledSlider(ctx, theme, "Idle opacity", "%", 10, 100, h.autoHideAlphaPct) { v ->
            updateHandle { it.copy(autoHideAlphaPct = v) }
        }, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 6), 0, 0))
        col.addView(Ui.label(ctx, "Handle colour", 11f, theme.textPrimary), Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, Ui.dp(ctx, 10), 0, 0))
        col.addView(HexColorPicker(ctx, theme, h.colorHex) { hex -> updateHandle { it.copy(colorHex = hex) } })

        // ---- automation ----
        col.addView(Ui.section(ctx, theme, "Automation"))
        col.addView(Ui.labeledSlider(ctx, theme, "Restore after game is away", " s", 0, 120, global.restoreDelaySec) { v ->
            updateGlobal { it.copy(restoreDelaySec = v) }
        })
        col.addView(Ui.labeledSlider(ctx, theme, "Temperature alert", " C", 35, 50, global.tempAlertC) { v ->
            updateGlobal { it.copy(tempAlertC = v) }
        }, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 6), 0, Ui.dp(ctx, 10)))
        return col
    }

    /** Moves a tool relative to its neighbouring INSTALLED tool so Up/Down always changes the visible order. */
    private fun moveTool(id: String, delta: Int) {
        val ord = order().toMutableList()
        val regs = ord.filter { ToolRegistry.has(it) }
        val pos = regs.indexOf(id)
        val other = regs.getOrNull(pos + delta) ?: return
        val a = ord.indexOf(id)
        val b = ord.indexOf(other)
        ord[a] = other
        ord[b] = id
        updateSidebar { it.copy(toolOrder = ord) }
    }
}
