package com.hyperengine.gameturbo.hub

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.hyperengine.gameturbo.HyperApp
import com.hyperengine.gameturbo.core.OptimizationEngine
import com.hyperengine.gameturbo.core.SystemBridgeExecutor
import com.hyperengine.gameturbo.core.TelemetryMonitor
import com.hyperengine.gameturbo.data.GameProfileRepository
import com.hyperengine.gameturbo.ui.HudTheme
import com.hyperengine.gameturbo.ui.HudThemes
import com.hyperengine.gameturbo.ui.PanelStyle
import com.hyperengine.gameturbo.ui.Ui
import kotlinx.coroutines.CoroutineScope
import java.util.Locale
import java.util.concurrent.Executors

// =============================================================================================
// Host + page contract
// =============================================================================================

/**
 * Everything a hub page needs. The activity creates one per instance; when the theme changes the
 * activity is recreated, so [theme] never changes during the life of a host.
 */
class HubHost(val activity: Activity, val scope: CoroutineScope, val theme: HudTheme) {

    private val app get() = HyperApp.instance

    val repo: GameProfileRepository get() = app.repository
    val bridge: SystemBridgeExecutor get() = app.bridge
    val engine: OptimizationEngine get() = app.engine
    val telemetry: TelemetryMonitor get() = app.telemetry
    val library = GameLibrary(activity.applicationContext, app.repository, app.bridge)

    /** Switches to the page with this id (no-op when no such page is registered). */
    var showPage: (String) -> Unit = {}

    /**
     * Opens the full per-game rule editor for a package. Null until a page that provides one is
     * registered; the hub only offers a "Rules" entry when it is non-null.
     */
    var rulesEditor: ((String) -> Unit)? = null

    /** Run by the activity in onDestroy: lets full-screen editors close their window so nothing leaks. */
    val destroyHooks = ArrayList<() -> Unit>()

    fun dp(v: Int): Int = Ui.dp(activity, v)

    fun toast(msg: String, long: Boolean = false) {
        Toast.makeText(activity.applicationContext, msg, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show()
    }
}

/** One tab of the hub (Games, Freeze List, Themes, ...). All methods run on the main thread. */
interface HubPage {
    val id: String
    val title: String
    val glyph: String
    fun createView(): View
    fun onShow() {}
    fun onHide() {}
    fun onDestroy() {}
    fun onPermissionsChanged() {}
    fun saveState(out: Bundle) {}
    fun restoreState(saved: Bundle) {}
}

/** The list of tabs. Add a page by appending it to the list returned from [create]. */
object HubPageRegistry {
    fun create(host: HubHost): List<HubPage> {
        // Phase 6 Part 2: the per-game rule editor is what every "Rules and automation" entry opens
        val rules = RulesEditor(host)
        host.rulesEditor = { pkg -> rules.open(pkg) }
        return listOf(
            GamesPage(host),
            FreezePage(host),
            LabPage(host),
            RomLabPage(host),
            ThemesPage(host)
        )
    }
}

// =============================================================================================
// Style helpers
// =============================================================================================

object HubStyle {

    /** Corner radius for big panels, following the user's corner-radius slider for the soft themes. */
    fun panelRadius(host: HubHost): Float = radius(host.activity, host.theme, 18)

    fun radius(ctx: android.content.Context, theme: HudTheme, base: Int): Float = when (theme.style) {
        PanelStyle.GLASS, PanelStyle.FLAT -> Ui.dpf(ctx, theme.cornerDp.coerceIn(6, 32).toFloat() * base / 20f)
        PanelStyle.CYBER_ANGULAR -> Ui.dpf(ctx, 2f)
        PanelStyle.MECHA -> Ui.dpf(ctx, 5f)
    }

    fun opaquePanel(theme: HudTheme): Int =
        HudThemes.blend(theme.panelTop, theme.panelBottom, 0.35f) or 0xFF000000.toInt()

    fun screenBackground(theme: HudTheme) = android.graphics.drawable.GradientDrawable(
        android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(theme.panelTop or 0xFF000000.toInt(), theme.panelBottom or 0xFF000000.toInt())
    )

    fun cardBackground(host: HubHost, focusStroke: Boolean = false): android.graphics.drawable.GradientDrawable {
        val t = host.theme
        val d = android.graphics.drawable.GradientDrawable(
            android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(
                HudThemes.withAlpha(t.panelTop, if (t.blur) 0xE8 else 0xFF),
                HudThemes.withAlpha(t.panelBottom, if (t.blur) 0xE8 else 0xFF)
            )
        )
        d.cornerRadius = radius(host.activity, t, 22)
        val strokeColor = if (t.style == PanelStyle.CYBER_ANGULAR || focusStroke) t.accent else t.stroke
        d.setStroke(host.dp(if (t.style == PanelStyle.CYBER_ANGULAR) 2 else 1), strokeColor)
        return d
    }

    fun chip(host: HubHost, text: String, color: Int): TextView = TextView(host.activity).apply {
        this.text = text
        textSize = 10f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(color)
        includeFontPadding = false
        setPadding(host.dp(7), host.dp(4), host.dp(7), host.dp(4))
        background = Ui.rounded(HudThemes.withAlpha(color, 0x26), radius(host.activity, host.theme, 8), HudThemes.withAlpha(color, 0x80), host.dp(1))
    }
}

object Fmt {
    fun ago(ms: Long, now: Long = System.currentTimeMillis()): String {
        if (ms <= 0L) return "never"
        val s = ((now - ms) / 1000L).coerceAtLeast(0L)
        return when {
            s < 60L -> "just now"
            s < 3600L -> "${s / 60L}m ago"
            s < 86_400L -> "${s / 3600L}h ago"
            s < 7 * 86_400L -> "${s / 86_400L}d ago"
            else -> "${s / (7 * 86_400L)}w ago"
        }
    }

    fun minutes(m: Int): String = if (m < 60) "${m}m" else "${m / 60}h ${m % 60}m"

    fun gb(mb: Long): String = String.format(Locale.US, "%.1f", mb / 1024f)
}

// =============================================================================================
// Dialog builder
// =============================================================================================

private class MaxHeightScrollView(ctx: android.content.Context, private val maxPx: Int) : ScrollView(ctx) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, View.MeasureSpec.makeMeasureSpec(maxPx, View.MeasureSpec.AT_MOST))
    }
}

/** Themed dialog used by every hub screen: title, scrolling body, button row. */
class HubDialog(private val host: HubHost, title: String? = null) {

    private val ctx = host.activity
    private val theme = host.theme
    private val dialog = Dialog(host.activity)
    private val panel = Ui.vbox(ctx)
    val body: LinearLayout = Ui.vbox(ctx)
    private val actions = Ui.hbox(ctx)
    private var actionCount = 0

    val isShowing: Boolean get() = dialog.isShowing

    init {
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        panel.background = Ui.rounded(HubStyle.opaquePanel(theme), HubStyle.panelRadius(host), theme.stroke, host.dp(1))
        panel.setPadding(host.dp(16), host.dp(16), host.dp(16), host.dp(12))
        if (title != null) {
            panel.addView(Ui.label(ctx, title, 16f, theme.textPrimary, true))
        }
        val screenH = ctx.resources.displayMetrics.heightPixels
        val scroll = MaxHeightScrollView(ctx, (screenH * 0.62f).toInt())
        scroll.isFillViewport = false
        scroll.addView(body)
        panel.addView(scroll, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(8), 0, 0))
        actions.gravity = Gravity.END
        panel.addView(actions, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(10), 0, 0))
        dialog.setContentView(panel)
    }

    fun setCancelable(value: Boolean): HubDialog {
        dialog.setCancelable(value)
        return this
    }

    fun onDismiss(block: () -> Unit): HubDialog {
        dialog.setOnDismissListener { block() }
        return this
    }

    fun text(msg: String, color: Int = theme.textSecondary, sp: Float = 12f, mono: Boolean = false): TextView =
        Ui.label(ctx, msg, sp, color).also {
            if (mono) it.typeface = Typeface.MONOSPACE
            it.setLineSpacing(0f, 1.15f)
            body.addView(it, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(4), 0, host.dp(4)))
        }

    fun add(v: View, topDp: Int = 6): HubDialog {
        body.addView(v, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(topDp), 0, 0))
        return this
    }

    /** A tappable tile. Closes the dialog first unless [keepOpen]. */
    fun row(title: String, sub: String? = null, filled: Boolean = false, keepOpen: Boolean = false, onClick: () -> Unit): HubDialog {
        val tile = Ui.vbox(ctx)
        tile.setPadding(host.dp(12), host.dp(11), host.dp(12), host.dp(11))
        val fill = if (filled) theme.accent else theme.tile
        tile.background = Ui.rounded(fill, Ui.tileRadius(ctx, theme), if (filled) theme.accent else theme.stroke, host.dp(1))
        val titleColor = if (filled) HudThemes.onAccent(theme.accent) else theme.textPrimary
        tile.addView(Ui.label(ctx, title, 13f, titleColor, true))
        if (!sub.isNullOrBlank()) {
            val subColor = if (filled) HudThemes.withAlpha(titleColor, 0xC0) else theme.textSecondary
            tile.addView(Ui.label(ctx, sub, 11f, subColor).apply { setPadding(0, host.dp(2), 0, 0) })
        }
        tile.setOnClickListener {
            if (!keepOpen) dismiss()
            onClick()
        }
        body.addView(tile, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(6), 0, 0))
        return this
    }

    fun button(label: String, filled: Boolean = false, keepOpen: Boolean = false, onClick: () -> Unit = {}): HubDialog {
        val b = Ui.button(ctx, theme, label, filled) {
            if (!keepOpen) dismiss()
            onClick()
        }
        actions.addView(b, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, if (actionCount++ == 0) 0 else host.dp(8), 0, 0, 0))
        return this
    }

    fun show(): HubDialog {
        if (host.activity.isFinishing) return this
        dialog.window?.setLayout((ctx.resources.displayMetrics.widthPixels * 0.92f).toInt(), WindowManager.LayoutParams.WRAP_CONTENT)
        dialog.window?.setSoftInputMode(
            WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN
        )
        runCatching { dialog.show() }
        return this
    }

    fun dismiss() {
        runCatching { if (dialog.isShowing) dialog.dismiss() }
    }

    companion object {
        fun confirm(host: HubHost, title: String, message: String, okLabel: String, onOk: () -> Unit) {
            HubDialog(host, title)
                .also { it.text(message, host.theme.textPrimary, 13f) }
                .button("Cancel")
                .button(okLabel, filled = true, onClick = onOk)
                .show()
        }

        fun info(host: HubHost, title: String, message: String, mono: Boolean = false) {
            HubDialog(host, title)
                .also { it.text(message, host.theme.textPrimary, if (mono) 11f else 13f, mono) }
                .button("Close", filled = true)
                .show()
        }
    }
}

// =============================================================================================
// System settings screens
// =============================================================================================

object HubIntents {

    private fun start(host: HubHost, intent: Intent, failMsg: String) {
        try {
            host.activity.startActivity(intent)
        } catch (_: Throwable) {
            host.toast(failMsg, true)
        }
    }

    private fun pkgUri(host: HubHost) = Uri.parse("package:" + host.activity.packageName)

    fun overlay(host: HubHost) =
        start(host, Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkgUri(host)), "Open Settings > Apps > Special access > Display over other apps")

    fun usageAccess(host: HubHost) =
        start(host, Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS), "Open Settings > Apps > Special access > Usage access")

    fun writeSettings(host: HubHost) =
        start(host, Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, pkgUri(host)), "Open Settings > Apps > Special access > Modify system settings")

    fun accessibility(host: HubHost) =
        start(host, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS), "Open Settings > Accessibility")

    fun notificationListener(host: HubHost) =
        start(host, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS), "Open Settings > Notifications > Device and app notifications")

    fun batteryOptimization(host: HubHost) =
        start(host, Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkgUri(host)), "Open Settings > Battery > Unrestricted")

    fun appDetails(host: HubHost, pkg: String) =
        start(host, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")), "Cannot open app info")

    /** Opens Shizuku when installed, otherwise its store page (falling back to the GitHub releases). */
    fun shizuku(host: HubHost) {
        val pm = host.activity.packageManager
        val launch = pm.getLaunchIntentForPackage(SHIZUKU_PKG)
        if (launch != null) {
            start(host, launch, "Cannot open Shizuku")
            return
        }
        try {
            host.activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$SHIZUKU_PKG")))
        } catch (_: Throwable) {
            start(host, Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/RikkaApps/Shizuku/releases")), "Install Shizuku from GitHub (RikkaApps/Shizuku)")
        }
    }

    private const val SHIZUKU_PKG = "moe.shizuku.privileged.api"
}

// =============================================================================================
// Game icons
// =============================================================================================

/** Placeholder shown while the real launcher icon loads: first letter on a tinted rounded square. */
class LetterDrawable(private val letter: String, private val fill: Int) : Drawable() {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun draw(canvas: Canvas) {
        val b = bounds
        val r = b.width() * 0.22f
        paint.style = Paint.Style.FILL
        paint.color = fill
        canvas.drawRoundRect(RectF(b), r, r, paint)
        paint.color = Color.WHITE
        paint.textAlign = Paint.Align.CENTER
        paint.typeface = Typeface.DEFAULT_BOLD
        paint.textSize = b.height() * 0.5f
        val y = b.exactCenterY() - (paint.descent() + paint.ascent()) / 2f
        canvas.drawText(letter, b.exactCenterX(), y, paint)
    }

    override fun setAlpha(alpha: Int) {
        paint.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        paint.colorFilter = colorFilter
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Memory-cached, off-main-thread loader for launcher icons. */
object GameIcons {

    private val cache = object : LruCache<String, Bitmap>(maxOf(4096, (Runtime.getRuntime().maxMemory() / 1024L / 10L).toInt())) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }
    private val io = Executors.newFixedThreadPool(2) { r -> Thread(r, "hyper-icons").apply { isDaemon = true } }
    private val main = Handler(Looper.getMainLooper())

    fun load(ctx: android.content.Context, pkg: String, label: String, sizePx: Int, target: ImageView, placeholderFill: Int) {
        target.tag = pkg
        val key = "$pkg@$sizePx"
        val hit = cache.get(key)
        if (hit != null) {
            target.setImageBitmap(hit)
            return
        }
        val letter = label.trim().take(1).uppercase(Locale.US).ifEmpty { "?" }
        target.setImageDrawable(LetterDrawable(letter, placeholderFill))
        val app = ctx.applicationContext
        io.execute {
            val bmp = try {
                val d = app.packageManager.getApplicationIcon(pkg)
                val out = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
                d.setBounds(0, 0, sizePx, sizePx)
                d.draw(Canvas(out))
                out
            } catch (_: Throwable) {
                null
            }
            if (bmp != null) {
                cache.put(key, bmp)
                main.post { if (target.tag == pkg) target.setImageBitmap(bmp) }
            }
        }
    }
}
