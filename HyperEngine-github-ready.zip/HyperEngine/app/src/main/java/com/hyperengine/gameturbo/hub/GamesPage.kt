package com.hyperengine.gameturbo.hub

import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.hyperengine.gameturbo.R
import com.hyperengine.gameturbo.ui.ChipGroup
import com.hyperengine.gameturbo.ui.HudThemes
import com.hyperengine.gameturbo.ui.Ui
import com.hyperengine.gameturbo.ui.VIcon
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/** Themed single-line text input, shared by hub screens. */
internal fun hubInput(host: HubHost, hint: String): EditText = EditText(host.activity).apply {
    this.hint = hint
    textSize = 13f
    setSingleLine()
    inputType = InputType.TYPE_CLASS_TEXT
    imeOptions = EditorInfo.IME_ACTION_DONE
    setTextColor(host.theme.textPrimary)
    setHintTextColor(host.theme.textSecondary)
    setPadding(host.dp(12), host.dp(10), host.dp(12), host.dp(10))
    background = Ui.rounded(host.theme.tile, Ui.tileRadius(host.activity, host.theme), host.theme.stroke, host.dp(1))
}

internal fun EditText.onTextChanged(block: (String) -> Unit) {
    addTextChangedListener(object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        override fun afterTextChanged(s: Editable?) {
            block(s?.toString().orEmpty())
        }
    })
}

/**
 * The Games tab: search, sort, 3D carousel / grid switch, an info bar for the selected game and the
 * "Add a game" picker. Everything shown comes from [GameLibrary] and the saved profiles.
 */
class GamesPage(private val host: HubHost) : HubPage {

    override val id = "games"
    override val title = "Games"
    override val glyph = ""

    private val ctx = host.activity
    private val theme = host.theme
    private val repo = host.repo

    private var entries: List<GameEntry> = emptyList()
    private var shown: List<GameEntry> = emptyList()
    private var query = ""
    private var selectedPkg: String? = null
    private var scanned = false
    private var scanJob: Job? = null

    private lateinit var root: LinearLayout
    private lateinit var search: EditText
    private lateinit var sortBtn: TextView
    private lateinit var toggle: ChipGroup
    private lateinit var frame: FrameLayout
    private lateinit var carouselBox: LinearLayout
    private lateinit var carousel: Carousel3DView
    private lateinit var grid: GameGridView
    private lateinit var info: TextView
    private lateinit var empty: LinearLayout
    private lateinit var emptyText: TextView

    // ── view construction ──

    override fun createView(): View {
        root = Ui.vbox(ctx)

        // row 1: search + add
        val row1 = Ui.hbox(ctx)
        row1.gravity = Gravity.CENTER_VERTICAL
        search = hubInput(host, "Search games")
        search.onTextChanged {
            query = it
            applyFilter()
        }
        row1.addView(search, Ui.lp(0, Ui.WRAP, 1f))
        row1.addView(Ui.button(ctx, theme, "Add", true) { showAddDialog() }.also { VIcon.setOnText(it, R.drawable.ic_plus, 14, HudThemes.onAccent(theme.accent), atStart = true) }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, host.dp(8), 0, 0, 0))
        root.addView(row1, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, 0, 0, host.dp(6)))

        // row 2: 3D / grid switch + sort
        val row2 = Ui.hbox(ctx)
        row2.gravity = Gravity.CENTER_VERTICAL
        toggle = ChipGroup(ctx, theme, listOf("3D", "Grid"), repo.global.value.hubView.coerceIn(0, 1), 2) { i ->
            repo.updateGlobal { it.copy(hubView = i) }
        }
        row2.addView(toggle, Ui.lp(host.dp(130), Ui.WRAP, 0f, -host.dp(3), 0, 0, 0))
        sortBtn = Ui.button(ctx, theme, "", false) {
            repo.updateGlobal { it.copy(hubSort = (it.hubSort + 1) % GameSort.LABELS.size) }
        }
        row2.addView(sortBtn, Ui.lp(0, Ui.WRAP, 1f, host.dp(8), 0, 0, 0))
        root.addView(row2, Ui.lp(Ui.MATCH, Ui.WRAP))

        // content: carousel (+ info) or grid or the empty state
        frame = FrameLayout(ctx)
        root.addView(frame, Ui.lp(Ui.MATCH, 0, 1f, 0, host.dp(4), 0, 0))

        carousel = Carousel3DView(ctx)
        carousel.adapter = object : Carousel3DView.Adapter {
            override fun count(): Int = shown.size
            override fun createCard(parent: ViewGroup): View = GameCardView(host)
            override fun bind(card: View, index: Int) {
                val e = shown.getOrNull(index) ?: return
                val c = card as GameCardView
                c.bind(e, repo.profile(e.pkg), host.library.hasUsageAccess())
                c.onPlay = { GameLauncher.boostAndPlay(host, e) }
                c.onMenu = { GameActions.show(host, e) }
            }
        }
        carousel.onCenterChanged = { i ->
            shown.getOrNull(i)?.let {
                selectedPkg = it.pkg
                updateInfo()
            }
        }
        carousel.onCenterTap = { i -> shown.getOrNull(i)?.let { GameActions.show(host, it) } }
        carousel.onCenterLongPress = { i -> shown.getOrNull(i)?.let { GameActions.show(host, it) } }
        carouselBox = Ui.vbox(ctx)
        carouselBox.addView(carousel, Ui.lp(Ui.MATCH, 0, 1f))

        grid = GameGridView(host)
        grid.onTap = { e ->
            selectedPkg = e.pkg
            updateInfo()
            grid.submit(shown, selectedPkg)
            GameActions.show(host, e)
        }
        grid.onLongPress = grid.onTap

        info = Ui.label(ctx, "", 11f, theme.textSecondary)
        info.gravity = Gravity.CENTER
        info.setLineSpacing(0f, 1.15f)
        info.maxLines = 3
        info.setPadding(host.dp(8), host.dp(2), host.dp(8), host.dp(6))
        root.addView(info, Ui.lp(Ui.MATCH, Ui.WRAP))

        empty = Ui.vbox(ctx)
        empty.gravity = Gravity.CENTER
        empty.setPadding(host.dp(24), host.dp(24), host.dp(24), host.dp(24))
        emptyText = Ui.label(ctx, "", 13f, theme.textSecondary)
        emptyText.gravity = Gravity.CENTER
        emptyText.setLineSpacing(0f, 1.2f)
        empty.addView(emptyText, Ui.lp(Ui.MATCH, Ui.WRAP))
        empty.addView(Ui.button(ctx, theme, "Add a game", true) { showAddDialog() }.also { VIcon.setOnText(it, R.drawable.ic_plus, 14, HudThemes.onAccent(theme.accent), atStart = true) }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, host.dp(14), 0, 0))

        syncControls()
        observe()
        refresh()
        return root
    }

    private fun observe() {
        // profile edits (mode change, reset, HUD tweaks) -> redraw what is on screen
        host.scope.launch {
            repo.profiles.collect { if (scanned) rebind() }
        }
        // layout / sort / hidden-list changes
        host.scope.launch {
            var last: Triple<Int, Int, List<String>>? = null
            repo.global.collect { g ->
                val key = Triple(g.hubView, g.hubSort, g.hubHidden)
                val prev = last
                last = key
                if (prev != null && prev != key) {
                    syncControls()
                    if (prev.third != key.third) refresh() else applyFilter()
                }
            }
        }
    }

    // ── HubPage ──

    override fun onShow() = refresh()

    override fun onPermissionsChanged() = refresh()

    override fun onDestroy() {
        scanJob?.cancel()
    }

    override fun saveState(out: Bundle) {
        out.putString(KEY_SELECTED, selectedPkg)
        out.putString(KEY_QUERY, query)
    }

    override fun restoreState(saved: Bundle) {
        selectedPkg = saved.getString(KEY_SELECTED)
        query = saved.getString(KEY_QUERY).orEmpty()
        if (this::search.isInitialized && search.text.toString() != query) search.setText(query)
    }

    // ── data ──

    private fun refresh() {
        scanJob?.cancel()
        scanJob = host.scope.launch {
            entries = host.library.scan(repo.global.value.hubSort)
            scanned = true
            applyFilter()
        }
    }

    private fun applyFilter() {
        val g = repo.global.value
        val sorted = host.library.sorted(entries, g.hubSort)
        val q = query.trim().lowercase()
        shown = if (q.isEmpty()) sorted else sorted.filter { it.label.lowercase().contains(q) || it.pkg.lowercase().contains(q) }
        render()
    }

    private fun syncControls() {
        val g = repo.global.value
        sortBtn.text = "Sort: " + GameSort.LABELS[g.hubSort.coerceIn(0, GameSort.LABELS.size - 1)]
        toggle.select(g.hubView.coerceIn(0, 1))
    }

    // ── rendering ──

    private fun render() {
        val view = repo.global.value.hubView
        frame.removeAllViews()
        if (shown.isEmpty()) {
            emptyText.text = when {
                !scanned -> "Looking for your games..."
                query.isNotBlank() -> "No game matches \"${query.trim()}\"."
                else -> "No games found yet.\n\nTap Add to pick any installed app. Games from the Play Store show up here automatically once Android lists them as games."
            }
            frame.addView(empty, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
            updateInfo()
            return
        }
        val idx = shown.indexOfFirst { it.pkg == selectedPkg }.let { if (it < 0) 0 else it }
        selectedPkg = shown[idx].pkg
        if (view == 0) {
            frame.addView(carouselBox, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
            carousel.notifyDataChanged()
            carousel.setIndex(idx, false)
        } else {
            frame.addView(grid, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
            grid.submit(shown, selectedPkg)
        }
        updateInfo()
    }

    /** A profile changed: redraw cards / tiles without losing the position. */
    private fun rebind() {
        if (shown.isEmpty()) return
        if (repo.global.value.hubView == 0) carousel.notifyDataChanged() else grid.submit(shown, selectedPkg)
        updateInfo()
    }

    private fun updateInfo() {
        val e = shown.firstOrNull { it.pkg == selectedPkg }
        if (e == null) {
            info.text = ""
            return
        }
        val week = if (e.weekMin > 0) "\nThis week: ${Fmt.minutes(e.weekMin)}" else ""
        info.text = GameText.summary(repo.profile(e.pkg)) + week
    }

    // ── add a game ──

    private fun showAddDialog() {
        val d = HubDialog(host, "Add a game")
        val box = hubInput(host, "Search installed apps")
        val list = Ui.vbox(ctx)
        var apps: List<AppRow> = emptyList()
        var loaded = false

        fun fill() {
            list.removeAllViews()
            if (!loaded) {
                list.addView(Ui.label(ctx, "Loading apps...", 12f, theme.textSecondary))
                return
            }
            val q = box.text.toString().trim().lowercase()
            val matches = if (q.isEmpty()) apps else apps.filter { it.label.lowercase().contains(q) || it.pkg.lowercase().contains(q) }
            if (matches.isEmpty()) {
                list.addView(Ui.label(ctx, "No app matches.", 12f, theme.textSecondary))
                return
            }
            for (a in matches.take(MAX_PICKER_ROWS)) {
                val row = Ui.hbox(ctx)
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(host.dp(8), host.dp(8), host.dp(8), host.dp(8))
                row.background = Ui.rounded(theme.tile, Ui.tileRadius(ctx, theme), theme.stroke, host.dp(1))
                val icon = ImageView(ctx)
                GameIcons.load(ctx, a.pkg, a.label, host.dp(36), icon, HudThemes.withAlpha(theme.accent, 0x99))
                row.addView(icon, Ui.lp(host.dp(36), host.dp(36)))
                val col = Ui.vbox(ctx)
                col.addView(Ui.label(ctx, a.label, 13f, theme.textPrimary, true).apply { maxLines = 1 })
                col.addView(Ui.label(ctx, a.pkg, 10f, theme.textSecondary).apply { maxLines = 1 })
                row.addView(col, Ui.lp(0, Ui.WRAP, 1f, host.dp(10), 0, 0, 0))
                row.setOnClickListener {
                    repo.getOrCreate(a.pkg, a.label)
                    repo.updateGlobal { g -> g.copy(hubHidden = g.hubHidden - a.pkg) }
                    selectedPkg = a.pkg
                    d.dismiss()
                    refresh()
                    host.toast("Added ${a.label}")
                }
                list.addView(row, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, host.dp(5), 0, 0))
            }
            if (matches.size > MAX_PICKER_ROWS) {
                list.addView(
                    Ui.label(ctx, "Showing the first $MAX_PICKER_ROWS of ${matches.size}. Type to narrow it down.", 11f, theme.textSecondary)
                        .apply { setPadding(0, host.dp(8), 0, 0) }
                )
            }
        }

        box.onTextChanged { fill() }
        d.add(box)
        d.add(list, 4)
        d.button("Cancel")
        d.show()
        fill()
        host.scope.launch {
            apps = host.library.launchableApps(entries.map { it.pkg }.toSet())
            loaded = true
            if (d.isShowing) fill()
        }
    }

    companion object {
        private const val KEY_SELECTED = "games.selected"
        private const val KEY_QUERY = "games.query"
        private const val MAX_PICKER_ROWS = 60
    }
}
