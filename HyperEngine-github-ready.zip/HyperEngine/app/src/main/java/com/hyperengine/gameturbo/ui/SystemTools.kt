package com.hyperengine.gameturbo.ui

import android.Manifest
import android.content.pm.PackageManager
import android.view.View
import androidx.core.content.ContextCompat
import com.hyperengine.gameturbo.HyperApp
import com.hyperengine.gameturbo.service.ScreenRecordService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** One tap: hide the HUD, take the phone's own screenshot, bring the HUD back. */
class ShotTool : HudTool("shot") {
    override fun onTap(host: ToolHost) {
        host.scope.launch {
            val r = HyperApp.instance.system.screenshot()
            host.toast(r.message)
        }
    }
}

/** The phone's own recorder when it has one, otherwise the built-in MediaProjection recorder. */
class RecordTool : HudTool("record") {

    private var job: Job? = null

    override fun isActive(host: ToolHost): Boolean = ScreenRecordService.state.value.recording

    override fun onTap(host: ToolHost) {
        val ctx = host.hostContext
        val theme = host.theme
        val sys = HyperApp.instance.system
        val col = Ui.vbox(ctx)
        val oem = sys.oemRecorderPackage()
        var withMic = false

        col.addView(Ui.section(ctx, theme, "Phone's own recorder"))
        if (oem != null) {
            col.addView(ToolUi.note(host, "Found $oem. Its own floating controls appear over the game."))
            col.addView(Ui.button(ctx, theme, "Open the phone's screen recorder", true) {
                val r = sys.openOemRecorder()
                host.toast(r.message)
            }, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 6), 0, 0))
        } else {
            col.addView(ToolUi.note(host, "No manufacturer screen recorder is installed on this phone. Use the built-in recorder below."))
        }

        col.addView(Ui.section(ctx, theme, "Built-in recorder"))
        col.addView(ToolUi.note(host, "Records the screen at up to 1080p and 60 fps to Movies/HyperEngine. Game sound is not captured (Android blocks it for recorders)."))
        val micGranted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        col.addView(ToolUi.check(ctx, theme, "Record the microphone too" + if (micGranted) "" else " (permission missing)", false) { withMic = it })
        val status = Ui.label(ctx, "", 12f, theme.textSecondary)
        val row = Ui.hbox(ctx)
        row.addView(Ui.button(ctx, theme, "Start", true) {
            val r = sys.startBuiltInRecorder(withMic)
            status.setTextColor(if (r.ok) theme.good else theme.hot)
            status.text = r.message
        }, Ui.lp(0, Ui.WRAP, 1f, 0, 0, Ui.dp(ctx, 4), 0))
        row.addView(Ui.button(ctx, theme, "Stop and save") {
            val r = sys.stopBuiltInRecorder()
            status.setTextColor(theme.textSecondary)
            status.text = r.message
        }, Ui.lp(0, Ui.WRAP, 1f, Ui.dp(ctx, 4), 0, 0, 0))
        col.addView(row, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 8), 0, 0))
        col.addView(status, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 6), 0, 0))

        // live state: elapsed time, finished file, errors
        job?.cancel()
        job = host.scope.launch {
            var wasRecording = false
            while (isActive) {
                val s = ScreenRecordService.state.value
                if (s.recording) {
                    val sec = ((System.currentTimeMillis() - s.startedAt) / 1000L).toInt()
                    status.setTextColor(theme.hot)
                    status.text = String.format(java.util.Locale.US, "Recording  %02d:%02d", sec / 60, sec % 60) +
                        (if (s.notice.isEmpty()) "" else "\n" + s.notice)
                } else if (wasRecording) {
                    status.setTextColor(if (s.error.isEmpty()) theme.good else theme.hot)
                    status.text = if (s.error.isEmpty()) "Saved to " + s.where else s.error
                } else if (s.error.isNotEmpty()) {
                    status.setTextColor(theme.hot)
                    status.text = s.error
                }
                if (s.recording != wasRecording) host.refreshTiles()
                wasRecording = s.recording
                delay(500L)
            }
        }
        host.openDetail("Screen recorder", col)
    }
}

/** RedMagic Studio: cast, PC mirroring helper and the keyboard / mouse mapper entry. */
class StudioTool : HudTool("cast") {

    override fun onTap(host: ToolHost) {
        val ctx = host.hostContext
        val theme = host.theme
        val sys = HyperApp.instance.system
        val col = Ui.vbox(ctx)

        col.addView(Ui.section(ctx, theme, "Cast to a TV or monitor"))
        col.addView(ToolUi.note(host, "Opens the phone's own cast picker (Xiaomi MiPlay where it exists) on top of the game."))
        col.addView(Ui.button(ctx, theme, "Open cast screen", true) {
            host.toast(sys.openCast().message)
        }, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 6), 0, 0))

        col.addView(Ui.section(ctx, theme, "PC mirroring (scrcpy over Wi-Fi)"))
        val info = Ui.label(ctx, "Reading...", 12f, theme.textPrimary)
        val cmd = Ui.label(ctx, "", 12f, theme.accent, true)
        val msg = Ui.label(ctx, "", 11f, theme.textSecondary)
        col.addView(info)
        col.addView(cmd, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 0, Ui.dp(ctx, 4), 0, 0))

        fun refresh() {
            host.scope.launch {
                val i = sys.adbBridgeInfo()
                info.text = "Wi-Fi address: " + (i.ip ?: "not connected") +
                    "\nadb TCP port: " + (if (i.tcpPort > 0) i.tcpPort.toString() else "not set") +
                    "\nUSB debugging: " + (if (i.usbDebugging) "on" else "off") +
                    "   Wireless debugging: " + (if (i.wirelessDebugging) "on" else "off")
                cmd.text = i.connectCommand ?: if (i.ip != null) "adb connect " + i.ip + ":<port from Wireless debugging>" else ""
            }
        }
        refresh()
        val row = Ui.hbox(ctx)
        row.addView(Ui.button(ctx, theme, "Set port 5555", true) {
            host.scope.launch {
                val r = sys.setAdbTcpPort(5555)
                msg.setTextColor(if (r.ok) theme.good else theme.hot)
                msg.text = r.message
                refresh()
            }
        }, Ui.lp(0, Ui.WRAP, 1f, 0, 0, Ui.dp(ctx, 3), 0))
        row.addView(Ui.button(ctx, theme, "Developer options") {
            host.toast(sys.openDeveloperSettings().message)
        }, Ui.lp(0, Ui.WRAP, 1f, Ui.dp(ctx, 3), 0, Ui.dp(ctx, 3), 0))
        row.addView(Ui.button(ctx, theme, "Refresh") { refresh() }, Ui.lp(0, Ui.WRAP, 1f, Ui.dp(ctx, 3), 0, 0, 0))
        col.addView(row, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 8), 0, 0))
        col.addView(msg, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 4), 0, 0))
        col.addView(
            ToolUi.note(
                host,
                "Android 11+: Wireless debugging in Developer options pairs without any restart and is the better choice. " +
                    "The classic port setting only takes effect after USB debugging is toggled, and HyperEngine never restarts adb itself because that would stop Shizuku."
            ),
            Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 6), 0, 0)
        )

        col.addView(Ui.section(ctx, theme, "Keyboard and mouse"))
        val devices = sys.hidDevices()
        col.addView(
            ToolUi.note(
                host,
                if (devices.isEmpty()) "No external keyboard or mouse detected. Plug one in over USB OTG or pair it by Bluetooth."
                else devices.joinToString("\n") { d ->
                    d.name + " (" + listOfNotNull(if (d.keyboard) "keyboard" else null, if (d.mouse) "mouse" else null).joinToString(", ") + ")"
                }
            )
        )
        col.addView(Ui.button(ctx, theme, "Open the keyboard mapper", true) {
            ToolRegistry.get("kbm")?.onTap(host)
        }, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 6), 0, 0))

        host.openDetail("RedMagic Studio", col)
    }
}

/** Settings for the in-game call banner, plus a layout preview. */
class CallsTool : HudTool("calls") {

    override fun isActive(host: ToolHost): Boolean = HyperApp.instance.repository.global.value.calls.bannerEnabled

    override fun onTap(host: ToolHost) {
        val ctx = host.hostContext
        val theme = host.theme
        val repo = host.deps.repo
        val calls = HyperApp.instance.calls
        val c = repo.global.value.calls
        val col = Ui.vbox(ctx)
        col.addView(
            ToolUi.note(
                host,
                "When the phone rings during a game a banner drops in at the top with Answer on speaker, Reject and Mute. " +
                    "Answering keeps you in the game and turns the speakerphone on."
            )
        )
        col.addView(ToolUi.check(ctx, theme, "Show the call banner in games", c.bannerEnabled) { on ->
            repo.updateGlobal { it.copy(calls = it.calls.copy(bannerEnabled = on)) }
            host.refreshTiles()
        })
        col.addView(ToolUi.check(ctx, theme, "Turn the speaker on when I answer", c.speakerOnAnswer) { on ->
            repo.updateGlobal { it.copy(calls = it.calls.copy(speakerOnAnswer = on)) }
        })

        col.addView(Ui.section(ctx, theme, "Permissions"))
        fun yn(b: Boolean) = if (b) "granted" else "missing"
        col.addView(
            ToolUi.note(
                host,
                "Phone state (sees the ringing): " + yn(calls.hasPermission()) +
                    "\nAnswer calls (answers and rejects): " + yn(calls.canAnswer()) +
                    "\nCaller names come from the dialer's notification (needs notification access) or your contacts."
            )
        )
        val msg = Ui.label(ctx, "", 11f, theme.textSecondary)
        col.addView(Ui.button(ctx, theme, "Grant phone permissions (Shizuku)") {
            host.scope.launch {
                val a = host.deps.bridge.grantRuntimePermission(Manifest.permission.READ_PHONE_STATE)
                val b = host.deps.bridge.grantRuntimePermission(Manifest.permission.ANSWER_PHONE_CALLS)
                val ok = a.ok && b.ok
                msg.setTextColor(if (ok) theme.good else theme.hot)
                msg.text = if (ok) "Granted" else (if (!a.ok) a.message else b.message)
            }
        }, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 6), 0, 0))
        col.addView(msg, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 4), 0, 0))

        col.addView(Ui.section(ctx, theme, "Layout"))
        col.addView(Ui.button(ctx, theme, "Preview the banner", true) {
            HudBus.callPreview?.invoke() ?: host.toast("Open this from inside a game to preview the banner")
        }, Ui.lp(Ui.MATCH, Ui.WRAP))
        col.addView(ToolUi.note(host, "Drag the banner up or down to move it. The position is remembered."), Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, Ui.dp(ctx, 4), 0, 0))
        host.openDetail("Call banner", col as View)
    }
}
