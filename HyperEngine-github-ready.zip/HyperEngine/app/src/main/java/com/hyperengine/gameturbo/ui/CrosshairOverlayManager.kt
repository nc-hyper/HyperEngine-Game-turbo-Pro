package com.hyperengine.gameturbo.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Point
import android.os.Build
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import com.hyperengine.gameturbo.R
import com.hyperengine.gameturbo.core.ColorMath
import com.hyperengine.gameturbo.data.CrosshairConfig
import com.hyperengine.gameturbo.data.CrosshairShape
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max

private const val OFFSET_LIMIT = 400

/** Clamps every value to the range the UI promises, so a hand-edited backup cannot break drawing. */
private fun CrosshairConfig.clean(): CrosshairConfig = copy(
    sizePx = sizePx.coerceIn(4, 80),
    strokePx = strokePx.coerceIn(1, 10),
    gapPx = gapPx.coerceIn(0, 30),
    outlinePx = outlinePx.coerceIn(0, 4),
    opacityPct = opacityPct.coerceIn(10, 100),
    offsetX = offsetX.coerceIn(-OFFSET_LIMIT, OFFSET_LIMIT),
    offsetY = offsetY.coerceIn(-OFFSET_LIMIT, OFFSET_LIMIT)
)

// =============================================================================================
// The reticle itself
// =============================================================================================

/**
 * Draws one of 8 reticles on a transparent square. All geometry is in real pixels.
 *
 *  - size   : arm length (cross, T, X, chevron, box bracket) or diameter (dot, rings)
 *  - gap    : distance from the centre to where the arms start (rings: extra radius,
 *             chevron: how far the apex sits above the centre)
 *  - stroke : line thickness
 *  - outline: border drawn around every line, black or a contrasting colour
 *
 * Opacity: the host window is pinned at alpha 0.79 because Android blocks touches that pass through
 * an overlay above 0.8. So 100 % on the slider means "the most opaque Android allows" (79 % on
 * screen) and the range below it is linear. The whole shape is drawn inside one layer, so the
 * outline never shows through the line when the opacity is below 100 %.
 */
class CrosshairView(context: Context) : View(context) {

    private var cfg = CrosshairConfig()
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.BUTT
        strokeJoin = Paint.Join.MITER
        strokeMiter = 10f
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val path = Path()
    private val hsv = FloatArray(3)

    private var pulseAt = 0L
    private var level = 1f
    private var lastFrame = 0L

    init {
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    fun setConfig(c: CrosshairConfig) {
        cfg = c
        invalidate()
    }

    /** A touch started somewhere on screen: expand briefly (only visible when Tap expansion is on). */
    fun pulse() {
        pulseAt = SystemClock.uptimeMillis()
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()

        // exponential smoothing towards the expanded or the resting size
        val target = if (cfg.tapExpansion && pulseAt != 0L && now - pulseAt < HOLD_MS) 1f + EXPAND else 1f
        val dt = if (lastFrame == 0L) 16L else (now - lastFrame).coerceIn(1L, 100L)
        lastFrame = now
        level += (target - level) * (1f - exp(-dt / TAU))
        val animating = abs(target - level) > 0.004f
        if (!animating) {
            level = target
            lastFrame = 0L
        }

        val color = currentColor(now)
        val w = width.toFloat()
        val h = height.toFloat()
        val layerAlpha = (cfg.opacityPct / 100f).coerceIn(0.1f, 1f)
        val save = canvas.saveLayerAlpha(0f, 0f, w, h, (layerAlpha * 255f).toInt())

        // an odd line width is centred on a pixel boundary; shift half a pixel so it stays razor sharp
        val half = if (cfg.strokePx % 2 == 1) 0.5f else 0f
        val cx = w / 2f + half
        val cy = h / 2f + half

        if (cfg.outlinePx > 0) drawShape(canvas, cx, cy, level, outlineColor(color), cfg.outlinePx.toFloat())
        drawShape(canvas, cx, cy, level, color, 0f)
        canvas.restoreToCount(save)

        if (animating) postInvalidateOnAnimation() else if (cfg.chroma) postInvalidateDelayed(33L)
    }

    /** [ext] is the outline thickness: 0 for the main pass, the border width for the outline pass. */
    private fun drawShape(c: Canvas, cx: Float, cy: Float, k: Float, color: Int, ext: Float) {
        stroke.color = color
        stroke.strokeWidth = cfg.strokePx + 2f * ext
        fill.color = color
        val gap = cfg.gapPx * k
        val len = cfg.sizePx * k
        when (cfg.shape) {
            CrosshairShape.CLASSIC_CROSS -> arms(c, cx, cy, gap, len, ext, true)
            CrosshairShape.T_CROSS -> arms(c, cx, cy, gap, len, ext, false)
            CrosshairShape.DOT -> c.drawCircle(cx, cy, len / 2f + ext, fill)
            CrosshairShape.CIRCLE_DOT -> {
                c.drawCircle(cx, cy, len / 2f + gap, stroke)
                c.drawCircle(cx, cy, max(cfg.strokePx * 0.9f, 1.5f) + ext, fill)
            }
            CrosshairShape.HOLLOW_RING -> c.drawCircle(cx, cy, len / 2f + gap, stroke)
            CrosshairShape.CHEVRON -> chevron(c, cx, cy - gap, len, ext)
            CrosshairShape.BOX_RETICLE -> box(c, cx, cy, len / 2f + gap, max(len * 0.4f, 3f), ext)
            CrosshairShape.X_MARKER -> diagonals(c, cx, cy, gap, len, ext)
        }
    }

    /** A straight line whose two ends are pushed outwards by [ext], so an outline wraps the tips too. */
    private fun seg(c: Canvas, x0: Float, y0: Float, x1: Float, y1: Float, ext: Float) {
        val dx = x1 - x0
        val dy = y1 - y0
        val l = hypot(dx, dy)
        if (l < 0.0001f) return
        val ux = dx / l
        val uy = dy / l
        c.drawLine(x0 - ux * ext, y0 - uy * ext, x1 + ux * ext, y1 + uy * ext, stroke)
    }

    private fun arms(c: Canvas, cx: Float, cy: Float, gap: Float, len: Float, ext: Float, top: Boolean) {
        seg(c, cx + gap, cy, cx + gap + len, cy, ext)
        seg(c, cx - gap, cy, cx - gap - len, cy, ext)
        seg(c, cx, cy + gap, cx, cy + gap + len, ext)
        if (top) seg(c, cx, cy - gap, cx, cy - gap - len, ext)
    }

    private fun diagonals(c: Canvas, cx: Float, cy: Float, gap: Float, len: Float, ext: Float) {
        for (sx in DIRS) for (sy in DIRS) {
            seg(
                c,
                cx + sx * D * gap, cy + sy * D * gap,
                cx + sx * D * (gap + len), cy + sy * D * (gap + len),
                ext
            )
        }
    }

    /** "^" with its apex at ([ax], [ay]); the tips are [len] long at 45 degrees. */
    private fun chevron(c: Canvas, ax: Float, ay: Float, len: Float, ext: Float) {
        val reach = D * (len + ext)
        path.reset()
        path.moveTo(ax - reach, ay + reach)
        path.lineTo(ax, ay)
        path.lineTo(ax + reach, ay + reach)
        c.drawPath(path, stroke)
    }

    /** Four corner brackets of a square whose half-width is [half]. */
    private fun box(c: Canvas, cx: Float, cy: Float, half: Float, bracket: Float, ext: Float) {
        for (sx in DIRS) for (sy in DIRS) {
            val px = cx + sx * half
            val py = cy + sy * half
            path.reset()
            path.moveTo(px - sx * (bracket + ext), py)
            path.lineTo(px, py)
            path.lineTo(px, py - sy * (bracket + ext))
            c.drawPath(path, stroke)
        }
    }

    private fun currentColor(now: Long): Int {
        if (cfg.chroma) {
            hsv[0] = (now % CHROMA_MS).toFloat() * 360f / CHROMA_MS
            hsv[1] = 1f
            hsv[2] = 1f
            return Color.HSVToColor(hsv)
        }
        return HudThemes.parse(cfg.colorHex, DEFAULT_COLOR)
    }

    /** Black by default. "Inverted" picks the colour that contrasts most with the reticle. */
    private fun outlineColor(color: Int): Int {
        if (!cfg.invertedOutline) return Color.BLACK
        val inv = Color.rgb(255 - Color.red(color), 255 - Color.green(color), 255 - Color.blue(color))
        return when {
            abs(luma(inv) - luma(color)) >= 90f -> inv
            luma(color) > 128f -> Color.BLACK
            else -> Color.WHITE
        }
    }

    private fun luma(c: Int): Float = 0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)

    companion object {
        const val EXPAND = 0.35f
        private const val HOLD_MS = 260L
        private const val TAU = 55f
        private const val CHROMA_MS = 3000L
        private const val D = 0.70710677f
        private val DEFAULT_COLOR = 0xFF00FF66.toInt()
        private val DIRS = intArrayOf(-1, 1)

        /** Window edge length (even, so the centre lands on a pixel) that fits the largest expanded reticle. */
        fun sideFor(c: CrosshairConfig): Int {
            val reach: Float = when (c.shape) {
                CrosshairShape.DOT -> c.sizePx / 2f
                CrosshairShape.CIRCLE_DOT, CrosshairShape.HOLLOW_RING, CrosshairShape.BOX_RETICLE ->
                    c.sizePx / 2f + c.gapPx
                CrosshairShape.CHEVRON -> c.gapPx + c.sizePx * D
                else -> (c.gapPx + c.sizePx).toFloat()
            }
            val full = (reach + c.strokePx + 2f * c.outlinePx + 2f) * (1f + EXPAND)
            var side = ceil(full * 2f).toInt() + 4
            if (side % 2 == 1) side++
            return side
        }
    }
}

/**
 * A 1x1 px touchable window with FLAG_WATCH_OUTSIDE_TOUCH. Android tells it (ACTION_OUTSIDE) every
 * time a new touch starts anywhere else, which is the only touch signal an overlay can get without
 * taking touches from the game.
 */
private class OutsideTouchWatcher(context: Context, private val onTouchStart: () -> Unit) : View(context) {
    init {
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.actionMasked == MotionEvent.ACTION_OUTSIDE) onTouchStart()
        return false
    }
}

// =============================================================================================
// Window management
// =============================================================================================

/**
 * Owns the crosshair window: a small square centred on the screen (plus the per-game X/Y
 * calibration offset), FLAG_NOT_TOUCHABLE | FLAG_NOT_FOCUSABLE so every touch goes to the game.
 *
 * [apply] is used both for live previews while a slider moves and for the saved profile, so the
 * overlay always shows what the sliders show. Main thread only.
 */
class CrosshairOverlayManager(context: Context, private val wm: WindowManager) {

    private val ctx: Context = context.applicationContext

    /** Called when a new window was added, so the controller can lift the handle/sidebar above it. */
    var onAttached: (() -> Unit)? = null

    private var active = false
    private var cfg = CrosshairConfig()
    private var view: CrosshairView? = null
    private var params: WindowManager.LayoutParams? = null
    private var attached = false
    private var watcher: View? = null
    private var watcherAttached = false

    fun show(c: CrosshairConfig) {
        active = true
        apply(c)
    }

    fun apply(c: CrosshairConfig) {
        val clean = c.clean()
        val same = clean == cfg
        cfg = clean
        if (!active || !cfg.enabled) {
            detach()
            return
        }
        if (same && attached) return

        val v = view ?: CrosshairView(ctx).also { view = it }
        v.setConfig(cfg)
        val p = params ?: buildParams().also { params = it }
        place(p, CrosshairView.sideFor(cfg))
        try {
            if (attached) {
                wm.updateViewLayout(v, p)
            } else {
                wm.addView(v, p)
                attached = true
                onAttached?.invoke()
            }
        } catch (_: Throwable) {
            // window could not be added (permission revoked mid-game): stay detached, nothing half-attached
            attached = false
        }
        syncWatcher()
    }

    fun hide() {
        active = false
        detach()
    }

    /** Call after rotation or a display size change. */
    fun relayout() {
        val p = params ?: return
        val v = view ?: return
        if (!attached) return
        place(p, CrosshairView.sideFor(cfg))
        runCatching { wm.updateViewLayout(v, p) }
    }

    /** A touch started (from the outside-touch probe, or from an accessibility service later on). */
    fun pulse() {
        view?.pulse()
    }

    // ---- internals ----

    @Suppress("DEPRECATION")
    private fun realSize(): Point = Point().also { wm.defaultDisplay.getRealSize(it) }

    private fun place(p: WindowManager.LayoutParams, side: Int) {
        val scr = realSize()
        p.width = side
        p.height = side
        p.x = (scr.x - side) / 2 + cfg.offsetX
        p.y = (scr.y - side) / 2 + cfg.offsetY
    }

    private fun buildParams(): WindowManager.LayoutParams {
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.LEFT
        p.alpha = ColorMath.MAX_OVERLAY_ALPHA   // above 0.8 Android would block touches under the reticle
        p.title = "HyperEngineCrosshair"
        if (Build.VERSION.SDK_INT >= 28) {
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return p
    }

    private fun syncWatcher() {
        val need = active && cfg.enabled && cfg.tapExpansion
        if (need && !watcherAttached) {
            val w = OutsideTouchWatcher(ctx) { view?.pulse() }
            val p = WindowManager.LayoutParams(
                1, 1,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            p.gravity = Gravity.TOP or Gravity.LEFT
            p.x = 0
            p.y = 0
            p.title = "HyperEngineTouchProbe"
            try {
                wm.addView(w, p)
                watcher = w
                watcherAttached = true
            } catch (_: Throwable) {
                watcher = null
                watcherAttached = false
            }
        } else if (!need && watcherAttached) {
            removeWatcher()
        }
    }

    private fun removeWatcher() {
        val w = watcher
        watcher = null
        if (watcherAttached && w != null) runCatching { wm.removeViewImmediate(w) }
        watcherAttached = false
    }

    private fun detach() {
        removeWatcher()
        val v = view
        if (attached && v != null) runCatching { wm.removeViewImmediate(v) }
        attached = false
        view = null
        params = null
    }
}

// =============================================================================================
// Crosshair Studio (sidebar tool page)
// =============================================================================================

class CrosshairTool(private val manager: CrosshairOverlayManager) : HudTool("crosshair") {

    override fun isActive(host: ToolHost): Boolean =
        GameActions.profileFor(host.deps, host.game).crosshair.enabled

    override fun onTap(host: ToolHost) {
        val ctx = host.hostContext
        val theme = host.theme
        val repo = host.deps.repo
        var cfg = GameActions.profileFor(host.deps, host.game).crosshair
        val col = Ui.vbox(ctx)

        col.addView(ToolUi.note(host,
            "A precision reticle in the exact centre of the screen. It lives in a window that never takes " +
                "touches, so the game plays exactly as before. Opacity 100 % is the most Android allows (79 %) - " +
                "above that the system would start blocking touches under the reticle. Your calibration is " +
                "saved per game."))

        fun commit(next: CrosshairConfig, rebuild: Boolean = false) {
            cfg = next
            manager.apply(cfg)
            repo.update(host.game) { it.copy(crosshair = cfg) }
            host.refreshTiles()
            if (rebuild) onTap(host)
        }

        col.addView(ChipGroup(ctx, theme, listOf("Off", "On"), if (cfg.enabled) 1 else 0, 2) { i ->
            commit(cfg.copy(enabled = i == 1))
        })

        // ---- shape ----
        col.addView(Ui.section(ctx, theme, "Shape"))
        val shapes = CrosshairShape.values()
        val shapeLabels = listOf("Cross", "Dot", "Circle-dot", "T-cross", "Chevron", "Box", "Ring", "X")
        col.addView(ChipGroup(ctx, theme, shapeLabels, shapes.indexOf(cfg.shape), 4) { i ->
            commit(cfg.copy(shape = shapes[i], enabled = true))
        })

        // ---- geometry (live preview while dragging, saved on release) ----
        col.addView(Ui.section(ctx, theme, "Geometry"))
        col.addView(ToolUi.liveSlider(ctx, theme, "Size", " px", 4, 80, cfg.sizePx,
            { manager.apply(cfg.copy(sizePx = it, enabled = true)) }, { commit(cfg.copy(sizePx = it, enabled = true)) }))
        col.addView(ToolUi.liveSlider(ctx, theme, "Thickness", " px", 1, 10, cfg.strokePx,
            { manager.apply(cfg.copy(strokePx = it, enabled = true)) }, { commit(cfg.copy(strokePx = it, enabled = true)) }))
        col.addView(ToolUi.liveSlider(ctx, theme, "Centre gap", " px", 0, 30, cfg.gapPx,
            { manager.apply(cfg.copy(gapPx = it, enabled = true)) }, { commit(cfg.copy(gapPx = it, enabled = true)) }))
        col.addView(ToolUi.liveSlider(ctx, theme, "Outline", " px", 0, 4, cfg.outlinePx,
            { manager.apply(cfg.copy(outlinePx = it, enabled = true)) }, { commit(cfg.copy(outlinePx = it, enabled = true)) }))
        col.addView(ToolUi.liveSlider(ctx, theme, "Opacity", " %", 10, 100, cfg.opacityPct,
            { manager.apply(cfg.copy(opacityPct = it, enabled = true)) }, { commit(cfg.copy(opacityPct = it, enabled = true)) }))

        // ---- colour and effects ----
        col.addView(Ui.section(ctx, theme, "Colour"))
        col.addView(HexColorPicker(ctx, theme, cfg.colorHex) { hex -> commit(cfg.copy(colorHex = hex, enabled = true)) })
        col.addView(ToolUi.check(ctx, theme, "RGB chroma cycle (ignores the colour above)", cfg.chroma) {
            commit(cfg.copy(chroma = it, enabled = true))
        })
        col.addView(ToolUi.check(ctx, theme, "High-contrast inverted outline", cfg.invertedOutline) {
            commit(cfg.copy(invertedOutline = it, enabled = true))
        })
        col.addView(ToolUi.check(ctx, theme, "Tap expansion (grows while you touch the screen)", cfg.tapExpansion) {
            commit(cfg.copy(tapExpansion = it, enabled = true))
        })
        col.addView(ToolUi.note(host,
            "Tap expansion reacts when a touch starts (Android does not tell an overlay when it ends), so " +
                "the reticle pulses on every new touch and settles a moment later."))

        // ---- micro calibration ----
        col.addView(Ui.section(ctx, theme, "Calibration (1 px steps, hold to repeat)"))
        val offsetView = Ui.label(ctx, "", 12f, theme.accent, true)
        fun showOffset() {
            offsetView.text = "X ${cfg.offsetX} px     Y ${cfg.offsetY} px"
        }
        fun nudge(dx: Int, dy: Int) {
            cfg = cfg.copy(
                offsetX = (cfg.offsetX + dx).coerceIn(-OFFSET_LIMIT, OFFSET_LIMIT),
                offsetY = (cfg.offsetY + dy).coerceIn(-OFFSET_LIMIT, OFFSET_LIMIT),
                enabled = true
            )
            manager.apply(cfg)
            showOffset()
        }
        fun persist() {
            repo.update(host.game) { it.copy(crosshair = cfg) }
            host.refreshTiles()
        }
        showOffset()
        col.addView(offsetView, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 0, 0, 0, Ui.dp(ctx, 6)))

        fun pad(): View = View(ctx)
        fun row(a: View, b: View, c: View): LinearLayout {
            val r = Ui.hbox(ctx)
            val m = Ui.dp(ctx, 3)
            val h = Ui.dp(ctx, 44)
            r.addView(a, Ui.lp(0, h, 1f, m, m, m, m))
            r.addView(b, Ui.lp(0, h, 1f, m, m, m, m))
            r.addView(c, Ui.lp(0, h, 1f, m, m, m, m))
            return r
        }
        val up = ToolUi.repeatButton(ctx, theme, "", { nudge(0, -1) }, { persist() }, R.drawable.ic_chevron_up)
        val down = ToolUi.repeatButton(ctx, theme, "", { nudge(0, 1) }, { persist() }, R.drawable.ic_chevron_down)
        val left = ToolUi.repeatButton(ctx, theme, "", { nudge(-1, 0) }, { persist() }, R.drawable.ic_chevron_left)
        val right = ToolUi.repeatButton(ctx, theme, "", { nudge(1, 0) }, { persist() }, R.drawable.ic_chevron_right)
        val reset = ToolUi.repeatButton(ctx, theme, "0", {
            cfg = cfg.copy(offsetX = 0, offsetY = 0, enabled = true)
            manager.apply(cfg)
            showOffset()
        }, { persist() })
        col.addView(row(pad(), up, pad()))
        col.addView(row(left, reset, right))
        col.addView(row(pad(), down, pad()))

        host.openDetail("Crosshair studio", col)
    }
}
