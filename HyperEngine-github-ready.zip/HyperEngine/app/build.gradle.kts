import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// ---------------------------------------------------------------------------------------------
// Release signing. Put a file named keystore.properties next to the root build.gradle.kts (it is
// already in .gitignore) with these four lines:
//
//     storeFile=/absolute/or/relative/path/to/release.jks
//     storePassword=...
//     keyAlias=...
//     keyPassword=...
//
// Without that file the release build still works, but the APK is unsigned and cannot be installed
// until you sign it (apksigner) yourself.
// ---------------------------------------------------------------------------------------------
val keystoreProps = Properties().apply {
    val f = rootProject.file("keystore.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
val hasSigning = keystoreProps.getProperty("storeFile") != null

// R8 shrinking / obfuscation is OFF unless you ask for it:   ./gradlew assembleRelease -Phyper.minify=true
// Rules for it are in proguard-rules.pro, but they have not been tested on a device yet.
val minifyRelease = providers.gradleProperty("hyper.minify").orNull == "true"

android {
    namespace = "com.hyperengine.gameturbo"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.hyperengine.gameturbo"
        minSdk = 26
        // 33 keeps the overlay / foreground-service behaviour the rest of the app was tuned for.
        targetSdk = 33
        versionCode = 27
        versionName = "1.7.1-part11-fix"
    }

    signingConfigs {
        if (hasSigning) {
            create("release") {
                storeFile = rootProject.file(keystoreProps.getProperty("storeFile"))
                storePassword = keystoreProps.getProperty("storePassword")
                keyAlias = keystoreProps.getProperty("keyAlias")
                keyPassword = keystoreProps.getProperty("keyPassword")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = minifyRelease
            isShrinkResources = minifyRelease
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            if (hasSigning) signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    kotlinOptions {
        jvmTarget = "1.8"
    }
}

dependencies {
    // Coroutines + JSON persistence
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("com.google.code.gson:gson:2.10.1")

    // Shizuku: privileged shell + binder wrapper (IInputManager / system services)
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")

    // Hidden-API exemptions (needed to reflect on android.hardware.input.IInputManager)
    implementation("org.lsposed.hiddenapibypass:hiddenapibypass:4.3")

    // WindowInsetsControllerCompat for the portrait window handling
    implementation("androidx.core:core-ktx:1.12.0")

    // Phase 3: physics (SpringAnimation / SpringForce) for icon press, HUD wings and the carousel
    implementation("androidx.dynamicanimation:dynamicanimation:1.0.0")
}
